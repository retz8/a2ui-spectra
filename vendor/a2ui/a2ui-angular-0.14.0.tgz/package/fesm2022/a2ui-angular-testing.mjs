import { signal } from '@angular/core';

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/// <reference types="jasmine" />
/**
 * Sets the props input of a component in a type-safe way, for use in tests.
 */
function setComponentProps(fixture, props) {
    fixture.componentRef.setInput('props', props);
}
/**
 * Creates a mock BoundProperty for testing.
 */
function createBoundProperty(val, template) {
    return {
        value: signal(val),
        raw: val,
        template,
        onUpdate: jasmine.createSpy('onUpdate'),
    };
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { createBoundProperty, setComponentProps };
//# sourceMappingURL=a2ui-angular-testing.mjs.map
