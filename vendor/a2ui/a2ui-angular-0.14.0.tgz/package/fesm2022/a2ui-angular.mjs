import * as i0 from '@angular/core';
import { InjectionToken, inject, ElementRef, DestroyRef, Directive, isSignal, untracked, isWritableSignal, effect, computed, signal, EnvironmentInjector, Injectable, ApplicationRef, NgZone, createComponent, Injector, makeEnvironmentProviders, provideEnvironmentInitializer, input, ChangeDetectorRef, reflectComponentType, ChangeDetectionStrategy, Component, Optional, Inject } from '@angular/core';
import { setValue, peekValue, setSignalImplementation, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, computed as computed$1, getValue, ResolvedBinding, isWritable, isComponentNode, isAtLeastVersion, effect as effect$1, MessageProcessor, NodeResolver, Catalog } from '@a2ui/web_core';
import { createAccessibilityTargets, bindHostAccessibility, setMarkdownRenderer, A2UI_ELEMENT_CONNECTED_EVENT, isWebComponentImplementation, registerUniversalElement, dispatchA2uiElementConnected } from '@a2ui/web_core/universal';
import { NgComponentOutlet } from '@angular/common';
import { A2uiDateTimeInput, A2uiSlider, A2uiChoicePicker, A2uiCheckBox, A2uiDivider, A2uiModal, A2uiTabs, A2uiCard, A2uiList, A2uiAudioPlayer, A2uiVideo, A2uiIcon, A2uiImage, A2uiTextField, A2uiButton, A2uiColumn, A2uiRow, A2uiText, createBasicCatalogFunctions, BasicCatalogThemeSchema } from '@a2ui/web_core/catalogs/basic/v1';
export { BASIC_FUNCTIONS } from '@a2ui/web_core/catalogs/basic/v1';

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * The directives an Angular catalog component uses to mark elements for its
 * host's accessibility attributes (see `bindHostAccessibility` in
 * `@a2ui/web_core/universal`). Each host element, `ComponentHostComponent`
 * or `AngularWcHost`, provides its own `A2UI_ACCESSIBILITY_TARGETS`, so a
 * directive marks an element for the nearest host above it.
 */
/** The accessibility targets of the host element the current component renders in. */
const A2UI_ACCESSIBILITY_TARGETS = new InjectionToken('A2UI_ACCESSIBILITY_TARGETS');
/** Provides a host element's own accessibility targets. */
function provideAccessibilityTargets() {
    return { provide: A2UI_ACCESSIBILITY_TARGETS, useFactory: createAccessibilityTargets };
}
/** Puts the directive's element in one of its host's target slots while it exists. */
function markElement(slotOf) {
    const targets = inject(A2UI_ACCESSIBILITY_TARGETS, { optional: true });
    if (!targets)
        return;
    const slot = slotOf(targets);
    const element = inject(ElementRef).nativeElement;
    setValue(slot, element);
    inject(DestroyRef).onDestroy(() => {
        if (peekValue(slot) === element) {
            setValue(slot, null);
        }
    });
}
/**
 * Marks the element that carries the component's `accessibility.label`,
 * `accessibility.description` and validation state, such as its input
 * (`<input a2uiAccessibilityTarget>`). It gets `aria-invalid` while a check
 * fails. Without it, the component's host element is labelled as a
 * `role="group"` and no element gets the validation state.
 */
class AccessibilityTargetDirective {
    constructor() {
        markElement(targets => targets.target);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: AccessibilityTargetDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.17", type: AccessibilityTargetDirective, isStandalone: true, selector: "[a2uiAccessibilityTarget]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: AccessibilityTargetDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[a2uiAccessibilityTarget]' }]
        }], ctorParameters: () => [] });
/**
 * Marks the element that shows the component's validation errors. While there
 * are errors, the `a2uiAccessibilityTarget` element gets `aria-describedby`
 * pointing at it, and it gets an `id` if it has none.
 */
class ValidationErrorsDirective {
    constructor() {
        markElement(targets => targets.errors);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ValidationErrorsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.17", type: ValidationErrorsDirective, isStandalone: true, selector: "[a2uiValidationErrors]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ValidationErrorsDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[a2uiValidationErrors]' }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let isAttached = false;
/** Asserts that a value is an Angular signal. */
function assertAngularSignal(value) {
    if (!isSignal(value)) {
        throw new Error('Received unexpected value. Expected an Angular signal.');
    }
}
/**
 * Configures the A2UI web_core to use Angular's native signals.
 * @param injector The Angular Injector to use for effects.
 */
function initializeAngularReactivity(injector) {
    if (isAttached) {
        return;
    }
    const angularSignalImpl = {
        signal: (initialValue) => signal(initialValue),
        computed: (computeFn) => computed(computeFn),
        effect: (effectFn) => {
            return untracked(() => {
                let cleanup;
                const ref = effect(onCleanup => {
                    cleanup = effectFn();
                    if (cleanup) {
                        onCleanup(cleanup);
                    }
                }, { injector });
                return () => ref.destroy();
            });
        },
        batchWrite: (batchFn) => {
            // Angular signals batch automatically. We just execute the function.
            batchFn();
        },
        isSignal: (val) => isSignal(val),
        getValue: (sig) => sig(),
        setValue: (sig, value) => {
            assertAngularSignal(sig);
            if (isWritableSignal(sig)) {
                sig.set(value);
            }
        },
        peekValue: (sig) => {
            assertAngularSignal(sig);
            return untracked(() => sig());
        },
    };
    setSignalImplementation(angularSignalImpl);
    isAttached = true;
    // Clean up the implementation since attempting to use a destroyed injector will throw.
    // Note that in practice this will should only happen in tests, in real apps the environment
    // injector is created once and exists during the lifetime of the page.
    injector.get(DestroyRef).onDestroy(() => {
        if (isAttached) {
            setSignalImplementation(_PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION);
            isAttached = false;
        }
    });
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Binds the resolved properties of a `ComponentNode` to reactive Angular Signals.
 *
 * `NodeResolver` already resolves every property of a node: dynamic values arrive
 * as `ResolvedBinding` instances (writable ones carry their setter), actions as
 * ready-to-call closures, child properties as live `ComponentNode` references, and
 * `checks` as `isValid`, `validationErrors`, and `validationResults`. This service
 * is a thin adapter that exposes each entry of `node.props` as a {@link BoundProperty}
 * for {@link ComponentHostComponent} and {@link AngularWcHost}.
 */
class ComponentBinder {
    boundCleanups = new WeakMap();
    constructor() {
        initializeAngularReactivity(inject(EnvironmentInjector));
    }
    /**
     * Binds all properties of a resolved `ComponentNode` to an object of Angular Signals.
     *
     * Reads only from `node.props`; no additional `DataContext` subscriptions are created.
     *
     * @param node The resolved ComponentNode.
     * @returns A map of property names to reactive `BoundProperty` wrappers.
     */
    bindNode(node) {
        const rawProps = node.context?.componentModel.properties ?? {};
        const bound = {};
        for (const key of Object.keys(peekValue(node.props))) {
            bound[key] = this.bindNodeProperty(node, key, rawProps[key]);
        }
        return bound;
    }
    bindNodeProperty(node, key, rawVal) {
        const valueSignal = computed$1(() => this.unwrapNodePropValue(key, getValue(node.props)[key], node.dataPath));
        assertAngularSignal(valueSignal);
        return {
            value: valueSignal,
            raw: rawVal,
            template: this.extractNodeTemplate(key, rawVal),
            onUpdate: (newValue) => {
                const binding = peekValue(node.props)[key];
                if (binding instanceof ResolvedBinding && isWritable(binding)) {
                    binding.set(newValue);
                }
            },
        };
    }
    extractNodeTemplate(key, rawVal) {
        if (key !== 'children' || !isChildListTemplateObject(rawVal)) {
            return undefined;
        }
        const path = rawVal['@path'] ?? rawVal.path;
        return rawVal.componentId && path ? { id: rawVal.componentId, path } : undefined;
    }
    unwrapNodePropValue(key, val, defaultBasePath) {
        if (val instanceof ResolvedBinding) {
            return this.unwrapNodePropValue(key, val.value, defaultBasePath);
        }
        if (isComponentNode(val)) {
            return toChild(val);
        }
        if (Array.isArray(val)) {
            if (key === 'children') {
                return val.map(item => isComponentNode(item) ? toChild(item) : this.normalizeChildItem(item, defaultBasePath));
            }
            return val.map(item => this.unwrapNodePropValue(key, item, defaultBasePath));
        }
        if (['child', 'trigger', 'content'].includes(key)) {
            return this.normalizeChildItem(val, defaultBasePath);
        }
        if (val && typeof val === 'object' && Object.getPrototypeOf(val) === Object.prototype) {
            const out = {};
            for (const [k, v] of Object.entries(val)) {
                out[k] = this.unwrapNodePropValue(k, v, defaultBasePath);
            }
            return out;
        }
        return val;
    }
    /**
     * Unsubscribes any reactive signal subscriptions created by {@link bind}.
     *
     * Property maps returned by {@link bindNode} hold no subscriptions of their own, so
     * calling this with one of them is a no-op.
     *
     * @param bound The bound property map returned by {@link bind} or {@link bindNode}.
     */
    unbind(bound) {
        if (!bound)
            return;
        const cleanups = this.boundCleanups.get(bound);
        if (!cleanups)
            return;
        this.boundCleanups.delete(bound);
        for (const cleanup of cleanups) {
            cleanup();
        }
    }
    /**
     * Binds all properties of a component to an object of Angular Signals from its
     * `ComponentContext`, resolving data bindings through the `DataContext` directly.
     *
     * @deprecated Use {@link bindNode}. Hosts bind from the resolved `ComponentNode` via
     *   `bindNode(node)`. This path remains for elements that are given a `ComponentContext`
     *   without a node and will be removed in a future release.
     * @param context The ComponentContext containing the model and data context.
     * @returns An object where each key corresponds to a component prop and its value is an Angular Signal.
     */
    bind(context) {
        const props = context.componentModel.properties;
        const bound = {};
        const cleanups = [];
        const checksKey = isAtLeastVersion(context.dataContext.surface?.protocolVersion ??
            context.dataContext.surface?.defaultCatalog?.protocolVersion, '1.0')
            ? '@checks'
            : 'checks';
        for (const key of Object.keys(props)) {
            const value = props[key];
            bound[key] = this.bindProperty(key, value, context, cleanups);
            // Below v1.0 a component's check rules are `checks`; from v1.0 the
            // processor stores them under `@checks`, while any bare `checks` entry
            // is an ordinary custom component property.
            if (key === checksKey) {
                const checkProps = this.bindChecks(value, context, cleanups);
                bound['isValid'] = checkProps.isValid;
                bound['validationErrors'] = checkProps.validationErrors;
            }
        }
        if (cleanups.length > 0) {
            this.boundCleanups.set(bound, cleanups);
        }
        return bound;
    }
    bindProperty(key, value, context, cleanups) {
        const isChildListTemplate = value && typeof value === 'object' && 'componentId' in value && 'path' in value;
        const isBoundPath = value && typeof value === 'object' && 'path' in value && !('componentId' in value);
        const baseSignal = isChildListTemplate
            ? this.createChildListSignal(value, context, cleanups)
            : context.dataContext.resolveSignal(value);
        const { valueSignal, template } = this.transformStructuralSignal(key, value, baseSignal, context);
        if (valueSignal?.unsubscribe) {
            cleanups.push(() => valueSignal.unsubscribe());
        }
        return {
            value: valueSignal,
            raw: value,
            template,
            onUpdate: isBoundPath
                ? (newValue) => context.dataContext.set(value.path, newValue)
                : () => { }, // No-op for non-bound values
        };
    }
    createChildListSignal(value, context, cleanups) {
        const listSig = context.dataContext.resolveSignal({ path: value.path });
        if (listSig?.unsubscribe) {
            cleanups.push(() => listSig.unsubscribe());
        }
        assertAngularSignal(listSig);
        const listContext = context.dataContext.nested(value.path);
        return computed$1(() => {
            const arr = listSig();
            const currentArr = Array.isArray(arr) ? arr : [];
            return currentArr.map((_, i) => ({
                id: value.componentId,
                basePath: listContext.nested(String(i)).path,
            }));
        });
    }
    transformStructuralSignal(key, value, valueSignal, context) {
        if (['child', 'trigger', 'content'].includes(key)) {
            assertAngularSignal(valueSignal);
            return {
                template: undefined,
                valueSignal: computed$1(() => this.normalizeChildItem(valueSignal(), context.dataContext.path)),
            };
        }
        if (key === 'children') {
            assertAngularSignal(valueSignal);
            const id = value?.componentId;
            const path = value?.path;
            const template = id && path ? { id, path } : undefined;
            return {
                template,
                valueSignal: computed$1(() => {
                    const val = valueSignal();
                    const arr = Array.isArray(val) ? val : [];
                    return arr.map(item => this.normalizeChildItem(item, context.dataContext.path));
                }),
            };
        }
        return { valueSignal, template: undefined };
    }
    normalizeChildItem(val, basePath) {
        if (!val)
            return null;
        if (typeof val === 'object' && 'id' in val) {
            return val;
        }
        return { id: val, basePath };
    }
    bindChecks(value, context, cleanups) {
        const checksArray = Array.isArray(value) ? value : [];
        const ruleResults = checksArray.map(rule => {
            const condition = rule.condition ?? rule;
            const message = rule.message ?? 'Validation failed';
            const conditionSig = context.dataContext.resolveSignal(condition);
            const messageSig = context.dataContext.resolveSignal(message);
            if (conditionSig?.unsubscribe) {
                cleanups.push(() => conditionSig.unsubscribe());
            }
            if (messageSig?.unsubscribe) {
                cleanups.push(() => messageSig.unsubscribe());
            }
            return { conditionSig, messageSig };
        });
        const isValidSignal = computed$1(() => ruleResults.every(r => !this.evaluateCheckRule(r.conditionSig, r.messageSig).isBlockingError));
        const validationErrorsSignal = computed$1(() => {
            const errors = [];
            for (const r of ruleResults) {
                const result = this.evaluateCheckRule(r.conditionSig, r.messageSig);
                if (result.isBlockingError) {
                    errors.push(result.errorMessage);
                }
            }
            return errors;
        });
        return {
            isValid: {
                value: isValidSignal,
                raw: null,
                onUpdate: () => { },
            },
            validationErrors: {
                value: validationErrorsSignal,
                raw: null,
                onUpdate: () => { },
            },
        };
    }
    evaluateCheckRule(conditionSig, messageSig) {
        assertAngularSignal(conditionSig);
        assertAngularSignal(messageSig);
        const rawResult = conditionSig();
        if (typeof rawResult === 'object' && rawResult !== null && 'valid' in rawResult) {
            const resObj = rawResult;
            const isValid = Boolean(resObj['valid']);
            const severity = typeof resObj['severity'] === 'string' ? resObj['severity'] : 'error';
            const dynamicMsg = typeof resObj['message'] === 'string' && resObj['message'] ? resObj['message'] : undefined;
            return {
                isBlockingError: !isValid && severity === 'error',
                errorMessage: dynamicMsg || messageSig() || 'Validation failed',
            };
        }
        const isValid = Boolean(rawResult);
        return {
            isBlockingError: !isValid,
            errorMessage: messageSig() || 'Validation failed',
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ComponentBinder, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ComponentBinder, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ComponentBinder, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
function toChild(node) {
    return { id: node.componentId, basePath: node.dataPath, node };
}
function isChildListTemplateObject(value) {
    return (typeof value === 'object' &&
        value !== null &&
        !Array.isArray(value) &&
        Object.hasOwn(value, 'componentId') &&
        (Object.hasOwn(value, 'path') || Object.hasOwn(value, '@path')));
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const activeInjectors = [];
const hostInjectors = new WeakMap();
const surfaceGroupInjectors = new Map();
/**
 * Sets the Angular `Injector` used by wrapped Angular components whose host element was not
 * given one explicitly and cannot resolve one from a DOM ancestor or `SurfaceGroupModel`.
 *
 * Wrapped components are created at catalog definition time, before any injector exists, so the
 * injector is resolved when the element connects: the element's own `injector` property wins
 * (the Angular `ComponentHostComponent` sets it on the elements it mounts), followed by the
 * nearest registered DOM host ancestor, the `SurfaceGroupModel` owning the surface, and finally
 * the most recently registered active injector.
 *
 * @param injector The injector to use as a fallback, or `undefined` to clear all fallback injectors.
 */
function setDefaultUniversalInjector(injector) {
    if (!injector) {
        activeInjectors.length = 0;
        return;
    }
    const existingIndex = activeInjectors.indexOf(injector);
    if (existingIndex !== -1) {
        activeInjectors.splice(existingIndex, 1);
    }
    activeInjectors.push(injector);
}
/**
 * Removes `injector` from the active fallback injector stack so that a destroyed injector is not
 * handed to elements connected later while preserving other live renderer injectors.
 */
function clearDefaultUniversalInjector(injector) {
    const index = activeInjectors.indexOf(injector);
    if (index !== -1) {
        activeInjectors.splice(index, 1);
    }
}
/**
 * Associates a DOM host node (such as `ComponentHostComponent`'s host element) with its Angular
 * `Injector` so descendant universal elements can discover their enclosing component-tree injector.
 *
 * @param injector The host's injector, or `undefined` to drop the association.
 */
function registerUniversalHostInjector(host, injector) {
    if (injector) {
        hostInjectors.set(host, injector);
    }
    else {
        hostInjectors.delete(host);
    }
}
/**
 * Associates an `A2uiRendererService`'s `SurfaceGroupModel` with its Angular `Injector` so
 * universal elements can resolve the owning renderer's injector even when detached from a host.
 *
 * @param injector The renderer's injector, or `undefined` to drop the association.
 */
function registerSurfaceGroupInjector(group, injector) {
    if (injector) {
        surfaceGroupInjectors.set(group, injector);
    }
    else {
        surfaceGroupInjectors.delete(group);
    }
}
/**
 * Resolves the Angular `Injector` for a universal custom element from its DOM ancestry, its
 * owning `SurfaceGroupModel`, or the active fallback injector stack.
 */
function resolveUniversalInjector(node, context) {
    let current = node;
    while (current) {
        const hostInjector = hostInjectors.get(current);
        if (hostInjector) {
            return hostInjector;
        }
        current =
            current.parentNode ??
                (typeof ShadowRoot !== 'undefined' && current instanceof ShadowRoot ? current.host : null);
    }
    const surface = context?.dataContext.surface;
    if (surface) {
        for (const [group, groupInjector] of surfaceGroupInjectors) {
            if (group.getSurface(surface.id) === surface) {
                return groupInjector;
            }
        }
    }
    return activeInjectors[activeInjectors.length - 1];
}
/**
 * Custom Element host that mounts and manages the lifecycle of an Angular component inside the
 * DOM for universal A2UI rendering.
 *
 * The Angular component to mount is resolved when the element connects, from the catalog entry of
 * the element's `context` (the entry that owns this element), so `context` must be set before the
 * element is attached to the document. `customElements` refuses to define one class under two tag
 * names, so {@link toWebComponent} derives an empty subclass per Angular component.
 *
 * While connected with a `node`, the element applies the node's `accessibility` attributes and
 * validation state, on itself or on the elements the component marks with
 * `a2uiAccessibilityTarget` and `a2uiValidationErrors`.
 */
class AngularWcHost extends HTMLElement {
    componentRef;
    appRef;
    binder;
    ngZone;
    _node;
    _context;
    boundProps;
    contextSubscription;
    _injector;
    /**
     * Created on the first connect, once `ComponentBinder` has set up Angular reactivity, so its
     * signals are Angular signals.
     */
    accessibilityTargets;
    accessibilityNode;
    stopAccessibility;
    set injector(inj) {
        this._injector = inj;
    }
    get injector() {
        return this._injector ?? resolveUniversalInjector(this.parentNode, this._context);
    }
    connectedCallback() {
        this.style.display = 'contents';
        if (!this.componentRef) {
            const injector = this.injector;
            if (!injector) {
                throw new Error(`Cannot instantiate Web Component '${this.tagName.toLowerCase()}': no Angular Injector ` +
                    `available. Set the element's 'injector' property or configure the renderer with ` +
                    `'provideA2Ui'.`);
            }
            registerUniversalHostInjector(this, injector);
            const node = this._node;
            const context = this._context;
            if (!node && !context) {
                throw new Error(`Cannot instantiate Web Component '${this.tagName.toLowerCase()}': 'node' or 'context' must be ` +
                    `set before the element is connected.`);
            }
            // The catalog entry that owns this element pairs it with the Angular component to mount.
            const entry = node
                ? node.impl
                : context.componentModel.catalog.components.get(context.componentModel.type);
            const type = node?.type ?? context.componentModel.type;
            if (typeof entry?.component !== 'function') {
                throw new Error(`Cannot instantiate Web Component '${this.tagName.toLowerCase()}': catalog entry ` +
                    `'${type}' has no Angular component.`);
            }
            this.appRef = injector.get(ApplicationRef);
            this.binder = injector.get(ComponentBinder);
            this.ngZone = injector.get(NgZone, null);
            this.accessibilityTargets ??= createAccessibilityTargets();
            this.componentRef = createComponent(entry.component, {
                environmentInjector: injector.get(EnvironmentInjector),
                // The component marks its elements in this element's targets, not in
                // those of the `ComponentHostComponent` that may have created it.
                elementInjector: Injector.create({
                    providers: [{ provide: A2UI_ACCESSIBILITY_TARGETS, useValue: this.accessibilityTargets }],
                    parent: injector,
                }),
                hostElement: this,
            });
            this.appRef.attachView(this.componentRef.hostView);
        }
        // `disconnectedCallback` drops the subscription and a moved element reconnects without
        // `node` or `context` being set again, so (re)subscribe on every connect.
        if (this._node) {
            this.subscribeToNode(this._node);
        }
        else if (this._context) {
            this.subscribeToContext(this._context);
        }
        this.updateContext();
        this.bindAccessibility();
    }
    subscribeToNode(node) {
        this.contextSubscription?.unsubscribe();
        let lastProps = getValue(node.props);
        const stop = effect$1(() => {
            const nextProps = getValue(node.props);
            if (nextProps === lastProps)
                return;
            lastProps = nextProps;
            const notify = () => {
                if (this.hasSameBoundKeys(nextProps, node.context?.componentModel.properties)) {
                    this.componentRef?.changeDetectorRef.detectChanges();
                }
                else {
                    this.updateContext();
                }
            };
            if (this.ngZone) {
                this.ngZone.run(notify);
            }
            else {
                notify();
            }
        });
        this.contextSubscription = { unsubscribe: stop };
    }
    hasSameBoundKeys(nextProps, rawProps) {
        if (!this.boundProps)
            return false;
        const boundKeys = Object.keys(this.boundProps);
        const nextKeys = Object.keys(nextProps);
        if (boundKeys.length !== nextKeys.length)
            return false;
        return nextKeys.every(key => Object.prototype.hasOwnProperty.call(this.boundProps, key) &&
            (!rawProps || this.boundProps[key].raw === rawProps[key]));
    }
    subscribeToContext(ctx) {
        this.contextSubscription?.unsubscribe();
        this.contextSubscription = ctx.componentModel.onUpdated.subscribe(() => {
            if (this.ngZone) {
                this.ngZone.run(() => {
                    this.updateContext();
                });
            }
            else {
                this.updateContext();
            }
        });
    }
    set node(node) {
        if (node === this._node) {
            return;
        }
        this._node = node;
        if (!node) {
            // Parents assign `node` (possibly undefined) and then `context`; `set context`
            // rebinds, so clearing the node must not tear down the current bindings. The
            // accessibility binding follows the node, so it stops here.
            this.unbindAccessibility();
            return;
        }
        if (node.context) {
            this._context = node.context;
        }
        if (this.componentRef) {
            this.subscribeToNode(node);
            this.updateContext();
        }
        this.bindAccessibility();
    }
    get node() {
        return this._node;
    }
    /** @deprecated Assign `node` instead. */
    set context(ctx) {
        if (this._node && this._node.context !== ctx) {
            this._node = undefined;
        }
        this._context = ctx;
        if (this._node) {
            this.subscribeToNode(this._node);
        }
        else {
            this.subscribeToContext(ctx);
        }
        this.updateContext();
        this.bindAccessibility();
    }
    /** @deprecated Read `node` instead. */
    get context() {
        return this._context;
    }
    updateContext() {
        const node = this._node;
        const context = this._context ?? node?.context;
        if (!this.componentRef || !this.binder || (!node && !context))
            return;
        this.binder.unbind(this.boundProps);
        const boundProps = node ? this.binder.bindNode(node) : this.binder.bind(context);
        this.boundProps = boundProps;
        this.componentRef.setInput('props', boundProps);
        this.componentRef.setInput('surfaceId', context?.dataContext.surface?.id);
        this.componentRef.setInput('componentId', node?.componentId ?? context.componentModel.id);
        this.componentRef.setInput('dataContextPath', node?.dataPath ?? context.dataContext.path);
        this.componentRef.changeDetectorRef.detectChanges();
    }
    /** Keeps the ARIA attributes in step with the node while the element is connected. */
    bindAccessibility() {
        const node = this._node;
        const targets = this.accessibilityTargets;
        if (!this.isConnected || !targets || node === this.accessibilityNode)
            return;
        this.unbindAccessibility();
        this.accessibilityNode = node;
        if (node) {
            this.stopAccessibility = bindHostAccessibility(this, node, targets);
        }
    }
    unbindAccessibility() {
        this.stopAccessibility?.();
        this.stopAccessibility = undefined;
        this.accessibilityNode = undefined;
    }
    disconnectedCallback() {
        registerUniversalHostInjector(this, undefined);
        this.unbindAccessibility();
        this.contextSubscription?.unsubscribe();
        this.contextSubscription = undefined;
        this.binder?.unbind(this.boundProps);
        this.boundProps = undefined;
        if (this.componentRef) {
            this.appRef?.detachView(this.componentRef.hostView);
            this.componentRef.destroy();
            this.componentRef = undefined;
            this.appRef = undefined;
            this.binder = undefined;
            this.ngZone = undefined;
        }
    }
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class MarkdownRenderer {
}
class DefaultMarkdownRenderer extends MarkdownRenderer {
    static warningLogged = false;
    async render(markdown, options) {
        try {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore - optional peer dependency throws TS1323 under Angular compiler but not under NodeNext
            const { renderMarkdown } = await import('@a2ui/markdown-it');
            return await renderMarkdown(markdown, options);
        }
        catch {
            if (!DefaultMarkdownRenderer.warningLogged) {
                console.warn('[DefaultMarkdownRenderer] Failed to load optional `@a2ui/markdown-it` renderer. Using fallback.');
                DefaultMarkdownRenderer.warningLogged = true;
            }
            return markdown;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DefaultMarkdownRenderer, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DefaultMarkdownRenderer, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DefaultMarkdownRenderer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });
function provideMarkdownRenderer(renderFn) {
    if (renderFn) {
        return {
            provide: MarkdownRenderer,
            useValue: {
                render: renderFn,
            },
        };
    }
    return { provide: MarkdownRenderer, useClass: DefaultMarkdownRenderer };
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Injection token for the A2UI renderer configuration.
 */
const A2UI_RENDERER_CONFIG = new InjectionToken('A2UI_RENDERER_CONFIG');
/**
 * Provides the A2UI renderer configuration.
 *
 * @param configOrFactory The configuration or a factory function that returns the configuration.
 * @returns The providers for the A2UI renderer.
 */
function provideA2Ui(configOrFactory) {
    return makeEnvironmentProviders([
        {
            provide: A2UI_RENDERER_CONFIG,
            ...(typeof configOrFactory === 'function'
                ? { useFactory: configOrFactory }
                : { useValue: configOrFactory }),
        },
        // Switch web_core to Angular signals before any `MessageProcessor` or `NodeResolver`
        // exists, so every signal they create is tracked by Angular `computed` and `effect`.
        provideEnvironmentInitializer(() => initializeAngularReactivity(inject(EnvironmentInjector))),
    ]);
}
/**
 * Manages A2UI rendering sessions by bridging the MessageProcessor to Angular.
 *
 * This service is the central entry point for the A2UI renderer. It maintains a
 * {@link MessageProcessor} that turns A2UI protocol messages into a reactive
 * {@link SurfaceGroupModel}.
 */
class A2uiRendererService {
    _messageProcessor;
    _catalogs = [];
    _injector = inject(Injector);
    _config = inject(A2UI_RENDERER_CONFIG, { optional: true });
    _useUniversalComponents = this._config?.useUniversalComponents ?? false;
    constructor() {
        initializeAngularReactivity(this._injector.get(EnvironmentInjector));
        // Angular components wrapped as Web Components need an injector when a universal container
        // creates them outside of ComponentHostComponent.
        setDefaultUniversalInjector(this._injector);
        if (this._useUniversalComponents) {
            // Universal basic catalog elements render markdown through web_core's global renderer;
            // native Angular components inject `MarkdownRenderer` directly.
            const markdownRenderer = this._injector.get(MarkdownRenderer, null);
            if (markdownRenderer) {
                setMarkdownRenderer((markdown, options) => markdownRenderer.render(markdown, options));
            }
        }
        this._catalogs = this._config?.catalogs ?? [];
        this._messageProcessor = new MessageProcessor(this._catalogs, this._config?.actionHandler, this._config?.processorOptions);
        registerSurfaceGroupInjector(this._messageProcessor.model, this._injector);
    }
    /**
     * Processes a list or envelope of A2UI messages and updates the internal surface models.
     *
     * This should be called whenever new messages arrive from an agent or orchestrator.
     *
     * @param messages The messages or envelope to process.
     */
    processMessages(messages) {
        this._messageProcessor.processMessages(messages);
    }
    /**
     * Asynchronously processes a list or envelope of A2UI messages and awaits any pending
     * function calls.
     *
     * @param messages The messages or envelope to process.
     */
    async processMessagesAsync(messages) {
        await this._messageProcessor.processMessagesAsync(messages);
    }
    /**
     * Calls an agent function on a specific surface and returns a promise for the result.
     *
     * @param surfaceId The target surface ID.
     * @param call The function name or call descriptor.
     * @param argsOrOptions Function arguments or call options.
     * @param options Call options if arguments were provided.
     */
    callAgentFunction(surfaceId, call, argsOrOptions, options) {
        if (typeof call === 'string') {
            const fnCall = { call, args: argsOrOptions };
            return this._messageProcessor.callAgentFunction(surfaceId, fnCall, options);
        }
        return this._messageProcessor.callAgentFunction(surfaceId, call, argsOrOptions);
    }
    /**
     * The underlying MessageProcessor instance.
     */
    get processor() {
        return this._messageProcessor;
    }
    /**
     * The current surface group model containing all active surfaces.
     *
     * Surfaces can be retrieved from this group using their `surfaceId`.
     */
    get surfaceGroup() {
        return this._messageProcessor.model;
    }
    /**
     * Whether universal web components rendering is enabled application-wide.
     */
    get useUniversalComponents() {
        return this._useUniversalComponents;
    }
    ngOnDestroy() {
        registerSurfaceGroupInjector(this._messageProcessor.model, undefined);
        this._messageProcessor.dispose();
        this._messageProcessor.model.dispose();
        clearDefaultUniversalInjector(this._injector);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: A2uiRendererService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: A2uiRendererService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: A2uiRendererService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Owns the `NodeResolver` for one rendered surface.
 *
 * {@link SurfaceComponent} provides an instance per surface so every
 * {@link ComponentHostComponent} underneath it shares one resolved node tree
 * for the lifetime of the surface view. A host rendered outside a surface
 * component creates its own instance and disposes it when destroyed.
 */
class SurfaceNodeResolver {
    resolver;
    surface;
    /**
     * Returns the resolver for `surface`, creating it on first use and replacing
     * (and disposing) the previous one when the surface changes.
     *
     * @param surface The surface model to resolve.
     */
    resolverFor(surface) {
        if (!this.resolver || this.surface !== surface) {
            this.resolver?.dispose();
            this.resolver = new NodeResolver(surface);
            this.surface = surface;
        }
        return this.resolver;
    }
    ngOnDestroy() {
        this.resolver?.dispose();
        this.resolver = undefined;
        this.surface = undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SurfaceNodeResolver, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SurfaceNodeResolver });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SurfaceNodeResolver, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Connected events a `ComponentHostComponent` already handed to `onElementConnected`.
 * Ancestor hosts skip these instead of stopping propagation, so other listeners still see them.
 */
const handledConnectedEvents = new WeakSet();
/**
 * Finds the node for `componentId` at `dataPath` in the tree below `value`.
 *
 * Reads child props with `getValue`, so a reactive context that calls this
 * re-runs when any visited node's props change.
 */
function findNodeInTree(value, componentId, dataPath) {
    if (isComponentNode(value)) {
        if (value.componentId === componentId && value.dataPath === dataPath && !value.isPlaceholder) {
            return value;
        }
        return findNodeInList(Object.values(getValue(value.props)), componentId, dataPath);
    }
    if (value instanceof ResolvedBinding) {
        return findNodeInTree(value.value, componentId, dataPath);
    }
    if (Array.isArray(value)) {
        return findNodeInList(value, componentId, dataPath);
    }
    if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
        return findNodeInList(Object.values(value), componentId, dataPath);
    }
    return undefined;
}
function findNodeInList(items, componentId, dataPath) {
    for (const item of items) {
        const found = findNodeInTree(item, componentId, dataPath);
        if (found)
            return found;
    }
    return undefined;
}
/**
 * Dynamically renders an A2UI component as defined in the current surface model.
 *
 * This component acts as a bridge between the A2UI surface model and UI components.
 * It can render both native Angular `@Component` implementations (via `NgComponentOutlet`)
 * and universal W3C Web Components (by instantiating and appending the custom element tag).
 *
 * The component to render is the resolved `ComponentNode` for `componentKey`: a
 * {@link Child} reference produced by a parent's bound props carries its node
 * directly, while a bare id (or a child reference without a node) is resolved from
 * the surface's `NodeResolver` root tree and tracked until it appears.
 *
 * Usually, you'll use the higher-level {@link SurfaceComponent} which automatically
 * sets up a host for the 'root' component.
 */
class ComponentHostComponent {
    /** The key of the component to render, either an ID string or a child reference. Defaults to 'root'. */
    componentKey = input('root', ...(ngDevMode ? [{ debugName: "componentKey" }] : /* istanbul ignore next */ []));
    /** The unique identifier of the surface this component belongs to. */
    surfaceId = input.required(...(ngDevMode ? [{ debugName: "surfaceId" }] : /* istanbul ignore next */ []));
    elementRef = inject((ElementRef));
    rendererService = inject(A2uiRendererService);
    binder = inject(ComponentBinder);
    destroyRef = inject(DestroyRef);
    ngZone = inject(NgZone);
    cdr = inject(ChangeDetectorRef);
    injector = inject(Injector);
    sharedResolver = inject(SurfaceNodeResolver, { optional: true });
    accessibilityTargets = inject(A2UI_ACCESSIBILITY_TARGETS, { self: true });
    ownResolver;
    componentType = signal(null, ...(ngDevMode ? [{ debugName: "componentType" }] : /* istanbul ignore next */ []));
    props = signal({}, ...(ngDevMode ? [{ debugName: "props" }] : /* istanbul ignore next */ []));
    metadata = signal(undefined, ...(ngDevMode ? [{ debugName: "metadata" }] : /* istanbul ignore next */ []));
    acceptsMetadata = computed(() => {
        const type = this.componentType();
        if (!type)
            return false;
        const mirror = reflectComponentType(type);
        return mirror?.inputs.some(i => i.templateName === 'metadata') ?? false;
    }, ...(ngDevMode ? [{ debugName: "acceptsMetadata" }] : /* istanbul ignore next */ []));
    componentInputs = computed(() => {
        // prettier-ignore
        const inputs = {
            // Quoted to prevent property renaming under Closure Compiler.
            'props': this.props(),
            'surfaceId': this.surfaceId(),
            'componentId': this.resolvedComponentId,
            'dataContextPath': this.resolvedDataContextPath,
        };
        if (this.acceptsMetadata()) {
            inputs['metadata'] = this.metadata();
        }
        return inputs;
    }, ...(ngDevMode ? [{ debugName: "componentInputs" }] : /* istanbul ignore next */ []));
    /** Bumped when a surface that was missing is created, so the setup effect re-runs. */
    surfaceRetry = signal(0, ...(ngDevMode ? [{ debugName: "surfaceRetry" }] : /* istanbul ignore next */ []));
    currentBoundProps;
    resolvedNode;
    activeSurface;
    mountedWcEl = null;
    resolvedComponentId = '';
    resolvedDataContextPath = '/';
    stopProps;
    stopMetadata;
    surfaceSub;
    stopAccessibility;
    constructor() {
        registerUniversalHostInjector(this.elementRef.nativeElement, this.injector);
        this.elementRef.nativeElement.addEventListener(A2UI_ELEMENT_CONNECTED_EVENT, this.onElementConnected);
        effect(() => {
            const key = this.componentKey();
            const surfaceId = this.surfaceId();
            this.surfaceRetry();
            if (!key || !surfaceId)
                return;
            const surface = untracked(() => this.rendererService.surfaceGroup?.getSurface(surfaceId));
            if (!surface) {
                untracked(() => this.waitForSurface(surfaceId));
                return;
            }
            const { id, basePath } = parseKey(key);
            // Tracked: re-runs when the resolved node for this key changes.
            const node = this.resolveNode(surface, key, id, basePath);
            untracked(() => this.mount(surface, node, id, basePath));
        });
        this.destroyRef.onDestroy(() => {
            registerUniversalHostInjector(this.elementRef.nativeElement, undefined);
            this.elementRef.nativeElement.removeEventListener(A2UI_ELEMENT_CONNECTED_EVENT, this.onElementConnected);
            this.resetState();
            this.ownResolver?.ngOnDestroy();
            this.ownResolver = undefined;
        });
    }
    /**
     * Hands a universal element that connected below this host to its catalog entry's
     * `onElementConnected` callback. The nearest host marks the event as handled, so ancestor
     * hosts skip it while other listeners above can still observe it.
     */
    onElementConnected = (event) => {
        if (handledConnectedEvents.has(event))
            return;
        // The event is composed, so `event.target` is retargeted to the outermost shadow host
        // in this tree. The first entry of the composed path is the element that dispatched it.
        const element = event.composedPath()[0];
        const context = element?.context ?? element?.node?.context;
        const componentModel = context?.componentModel;
        if (!element || !context || !componentModel)
            return;
        handledConnectedEvents.add(event);
        const catalog = componentModel.catalog;
        const entry = catalog?.components?.get(componentModel.type);
        entry?.onElementConnected?.(element, context, this.injector);
    };
    waitForSurface(surfaceId) {
        this.resetState();
        console.warn(`Surface ${surfaceId} not found. Waiting for it...`);
        this.surfaceSub?.unsubscribe();
        let unsubscribed = false;
        const sub = this.rendererService.surfaceGroup?.onSurfaceCreated?.subscribe(s => {
            if (s.id === surfaceId) {
                unsubscribed = true;
                if (this.surfaceSub) {
                    this.surfaceSub.unsubscribe();
                    this.surfaceSub = undefined;
                }
                this.ngZone.run(() => this.surfaceRetry.update(n => n + 1));
            }
        });
        if (sub) {
            this.surfaceSub = sub;
            if (unsubscribed) {
                this.surfaceSub.unsubscribe();
                this.surfaceSub = undefined;
            }
        }
    }
    resolverFor(surface) {
        if (this.sharedResolver) {
            return this.sharedResolver.resolverFor(surface);
        }
        this.ownResolver ??= new SurfaceNodeResolver();
        return this.ownResolver.resolverFor(surface);
    }
    /**
     * Resolves the node to render. A child reference that already carries its node is
     * used as is; otherwise the node is looked up from the surface root (tracked).
     */
    resolveNode(surface, key, id, basePath) {
        if (typeof key === 'object' && key.node) {
            return key.node;
        }
        const root = getValue(this.resolverFor(surface).rootNode);
        if (!root)
            return undefined;
        if (root.componentId === id && root.dataPath === basePath) {
            return root;
        }
        return findNodeInTree(root, id, basePath) ?? (root.componentId === id ? root : undefined);
    }
    mount(surface, node, id, basePath) {
        if (node && node === this.resolvedNode && surface === this.activeSurface) {
            return;
        }
        this.resetState();
        this.activeSurface = surface;
        this.resolvedComponentId = id;
        this.resolvedDataContextPath = basePath;
        if (!node || node.isPlaceholder || !node.impl || !node.context) {
            this.reportUnresolved(surface, node, id);
            return;
        }
        this.resolvedNode = node;
        this.resolvedDataContextPath = node.dataPath;
        // Entries from `createComponentImplementation` carry both an Angular component and a Custom
        // Element; the flag picks which one to mount. Web Component-only entries render only with the
        // flag on (their placeholder `component` reports the misconfiguration otherwise).
        if (this.rendererService.useUniversalComponents && isWebComponentImplementation(node.impl)) {
            this.setupWebComponent(node.impl, node);
        }
        else {
            this.setupAngularComponent(node.impl.component, node);
        }
    }
    reportUnresolved(surface, node, id) {
        if (node?.state === 'unknown-type') {
            const catalog = surface.componentsModel.get(id)?.catalog;
            console.error(`Component type "${node.type}" not found in catalog "${catalog?.id}"`);
            return;
        }
        if (node?.state === 'cyclic') {
            console.error(`Component ${id} references one of its own ancestors in surface ${surface.id}`);
            return;
        }
        console.warn(`Component ${id} not found in surface ${surface.id}. Waiting for it...`);
    }
    setupAngularComponent(componentClass, node) {
        this.componentType.set(componentClass);
        this.updateProps();
        this.metadata.set(getValue(node.metadata));
        // A Web Component applies its own accessibility attributes; an Angular
        // component gets them on this host.
        this.stopAccessibility = bindHostAccessibility(this.elementRef.nativeElement, node, this.accessibilityTargets);
        let lastProps = getValue(node.props);
        this.stopProps = effect$1(() => {
            const nextProps = getValue(node.props);
            if (nextProps === lastProps)
                return;
            lastProps = nextProps;
            this.ngZone.run(() => {
                if (this.hasSameBoundKeys(nextProps, node.context?.componentModel.properties)) {
                    this.cdr.markForCheck();
                }
                else {
                    this.updateProps();
                }
            });
        });
        let lastMeta = getValue(node.metadata);
        this.stopMetadata = effect$1(() => {
            const nextMeta = getValue(node.metadata);
            if (nextMeta === lastMeta)
                return;
            lastMeta = nextMeta;
            this.ngZone.run(() => {
                this.metadata.set(nextMeta);
                this.cdr.markForCheck();
            });
        });
    }
    /** Re-binds the props of the mounted Angular component and schedules change detection. */
    updateProps() {
        if (!this.resolvedNode)
            return;
        if (this.currentBoundProps) {
            this.binder.unbind(this.currentBoundProps);
        }
        const nextProps = this.binder.bindNode(this.resolvedNode);
        this.currentBoundProps = nextProps;
        this.props.set(nextProps);
        this.cdr.markForCheck();
    }
    hasSameBoundKeys(nextProps, rawProps) {
        if (!this.currentBoundProps)
            return false;
        const boundKeys = Object.keys(this.currentBoundProps);
        const nextKeys = Object.keys(nextProps);
        if (boundKeys.length !== nextKeys.length)
            return false;
        return nextKeys.every(key => Object.prototype.hasOwnProperty.call(this.currentBoundProps, key) &&
            (!rawProps || this.currentBoundProps[key].raw === rawProps[key]));
    }
    setupWebComponent(implementation, node) {
        this.componentType.set(null);
        this.props.set({});
        registerUniversalElement(implementation);
        const tagName = implementation.tagName;
        const el = document.createElement(tagName);
        el.injector = this.injector;
        el.node = node;
        this.mountedWcEl = el;
        this.elementRef.nativeElement.appendChild(el);
        // Lit elements report themselves on connect; this covers elements of any other base class.
        dispatchA2uiElementConnected(el);
    }
    /**
     * Resets the component host state, unsubscribing from active subscriptions
     * and clearing component properties to avoid rendering stale data while
     * a new component is being loaded.
     */
    resetState() {
        this.stopProps?.();
        this.stopProps = undefined;
        this.stopMetadata?.();
        this.stopMetadata = undefined;
        this.surfaceSub?.unsubscribe();
        this.surfaceSub = undefined;
        this.stopAccessibility?.();
        this.stopAccessibility = undefined;
        this.resolvedNode = undefined;
        this.activeSurface = undefined;
        this.componentType.set(null);
        if (this.currentBoundProps) {
            this.binder.unbind(this.currentBoundProps);
            this.currentBoundProps = undefined;
        }
        this.props.set({});
        this.metadata.set(undefined);
        this.resolvedDataContextPath = '/';
        if (this.mountedWcEl) {
            this.mountedWcEl.remove();
            this.mountedWcEl = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ComponentHostComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ComponentHostComponent, isStandalone: true, selector: "a2ui-v09-component-host", inputs: { componentKey: { classPropertyName: "componentKey", publicName: "componentKey", isSignal: true, isRequired: false, transformFunction: null }, surfaceId: { classPropertyName: "surfaceId", publicName: "surfaceId", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "attr.data-a2ui-empty": "componentType() ? null : \"\"" }, styleAttribute: "display: contents;" }, providers: [provideAccessibilityTargets()], ngImport: i0, template: `
    @if (componentType()) {
      <ng-container *ngComponentOutlet="componentType()!; inputs: componentInputs()"></ng-container>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ComponentHostComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'a2ui-v09-component-host',
                    imports: [NgComponentOutlet],
                    // The Angular component this host mounts marks its elements in these.
                    providers: [provideAccessibilityTargets()],
                    host: {
                        style: 'display: contents;',
                        // Marks a host that renders nothing (its component has not resolved), so a container that
                        // wraps each child in an item element can drop that item too (see ListComponent).
                        '[attr.data-a2ui-empty]': 'componentType() ? null : ""',
                    },
                    // The quotes around the input keys passed to *ngComponentOutlet are critical to survive Closure
                    // minification. Prettier keeps them (`quoteProps: "preserve"` in the root `.prettierrc`).
                    template: `
    @if (componentType()) {
      <ng-container *ngComponentOutlet="componentType()!; inputs: componentInputs()"></ng-container>
    }
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { componentKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "componentKey", required: false }] }], surfaceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "surfaceId", required: true }] }] } });
function parseKey(key) {
    if (typeof key === 'object' && key !== null && 'id' in key) {
        return { id: key.id, basePath: key.basePath || '/' };
    }
    return { id: key, basePath: '/' };
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * High-level component for rendering an entire A2UI surface.
 *
 * This component handles the boilerplate of setting up a {@link ComponentHostComponent}
 * for the 'root' component of a surface and owns the surface's `NodeResolver` (via
 * {@link SurfaceNodeResolver}) so all hosts beneath it share one resolved node tree.
 * It is the recommended way to embed an A2UI surface in an Angular application.
 */
class SurfaceComponent {
    /** The unique identifier of the surface to render. */
    surfaceId = input.required(...(ngDevMode ? [{ debugName: "surfaceId" }] : /* istanbul ignore next */ []));
    /**
     * The path within the surface's data model that represents the current state.
     * Defaults to the root ('/').
     */
    dataContextPath = input('/', ...(ngDevMode ? [{ debugName: "dataContextPath" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SurfaceComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.17", type: SurfaceComponent, isStandalone: true, selector: "a2ui-v09-surface", inputs: { surfaceId: { classPropertyName: "surfaceId", publicName: "surfaceId", isSignal: true, isRequired: true, transformFunction: null }, dataContextPath: { classPropertyName: "dataContextPath", publicName: "dataContextPath", isSignal: true, isRequired: false, transformFunction: null } }, host: { styleAttribute: "display: contents;" }, providers: [SurfaceNodeResolver], ngImport: i0, template: `
    <a2ui-v09-component-host
      [componentKey]="{id: 'root', basePath: dataContextPath()}"
      [surfaceId]="surfaceId()"
    >
    </a2ui-v09-component-host>
  `, isInline: true, dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SurfaceComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'a2ui-v09-surface',
                    standalone: true,
                    imports: [ComponentHostComponent],
                    providers: [SurfaceNodeResolver],
                    host: {
                        style: 'display: contents;',
                    },
                    template: `
    <a2ui-v09-component-host
      [componentKey]="{id: 'root', basePath: dataContextPath()}"
      [surfaceId]="surfaceId()"
    >
    </a2ui-v09-component-host>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { surfaceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "surfaceId", required: true }] }], dataContextPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataContextPath", required: false }] }] } });

/**
 * Base class for A2UI catalog component in Angular.
 *
 * All Angular catalog components should extend this base class,
 * which provides type safe access to props() and other common
 * fields.
 */
class CatalogComponent {
    /**
     * Reactive properties resolved from the A2UI ComponentModel.
     */
    props = input({}, ...(ngDevMode ? [{ debugName: "props" }] : /* istanbul ignore next */ []));
    metadata = input(undefined, ...(ngDevMode ? [{ debugName: "metadata" }] : /* istanbul ignore next */ []));
    extensions = computed(() => this.metadata()?.extensions, ...(ngDevMode ? [{ debugName: "extensions" }] : /* istanbul ignore next */ []));
    surfaceId = input.required(...(ngDevMode ? [{ debugName: "surfaceId" }] : /* istanbul ignore next */ []));
    componentId = input.required(...(ngDevMode ? [{ debugName: "componentId" }] : /* istanbul ignore next */ []));
    dataContextPath = input('/', ...(ngDevMode ? [{ debugName: "dataContextPath" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CatalogComponent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.17", type: CatalogComponent, isStandalone: true, inputs: { props: { classPropertyName: "props", publicName: "props", isSignal: true, isRequired: false, transformFunction: null }, metadata: { classPropertyName: "metadata", publicName: "metadata", isSignal: true, isRequired: false, transformFunction: null }, surfaceId: { classPropertyName: "surfaceId", publicName: "surfaceId", isSignal: true, isRequired: true, transformFunction: null }, componentId: { classPropertyName: "componentId", publicName: "componentId", isSignal: true, isRequired: true, transformFunction: null }, dataContextPath: { classPropertyName: "dataContextPath", publicName: "dataContextPath", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CatalogComponent, decorators: [{
            type: Directive
        }], propDecorators: { props: [{ type: i0.Input, args: [{ isSignal: true, alias: "props", required: false }] }], metadata: [{ type: i0.Input, args: [{ isSignal: true, alias: "metadata", required: false }] }], surfaceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "surfaceId", required: true }] }], componentId: [{ type: i0.Input, args: [{ isSignal: true, alias: "componentId", required: true }] }], dataContextPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataContextPath", required: false }] }] } });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Normalizes a data model path by combining a relative path with a base context.
 *
 * This is used to create unique absolute paths for components within a repeating
 * collection or nested structure.
 *
 * @param path The relative or absolute path from the component properties.
 * @param dataContextPath The current base data context path.
 * @param index The index of the child component.
 * @returns A fully normalized absolute path for the indexed child.
 */
function getNormalizedPath(path, dataContextPath, index) {
    let normalized = path || '';
    if (!normalized.startsWith('/')) {
        const base = dataContextPath === '/' ? '' : dataContextPath;
        normalized = `${base}/${normalized}`;
    }
    if (normalized.endsWith('/')) {
        normalized = normalized.slice(0, -1);
    }
    return `${normalized}/${index}`;
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const angularWcCache = new WeakMap();
const tagNameCounts = new Map();
/**
 * Computes a unique custom element tag name of the form `a2ui-ng-<name>`.
 *
 * Names are disambiguated with an incrementing suffix (`a2ui-ng-<name>-2`, ...) so that two
 * different Angular components sharing a component name get distinct tags.
 */
function computeTagName(name) {
    const baseTagName = `a2ui-ng-${name.toLowerCase()}`;
    const count = (tagNameCounts.get(baseTagName) ?? 0) + 1;
    tagNameCounts.set(baseTagName, count);
    return count === 1 ? baseTagName : `${baseTagName}-${count}`;
}
/**
 * Copies the `ComponentApi` fields of `api`, leaving out the fields of a richer entry such as
 * `component`, `tagName` and `element`.
 */
function componentApiFields(api) {
    return {
        name: api.name,
        schema: api.schema,
        allowedParents: api.allowedParents,
        allowedChildren: api.allowedChildren,
        ...(api.metadata !== undefined ? { metadata: api.metadata } : {}),
    };
}
/**
 * Wraps an Angular `@Component` class declaration (`AngularComponentImplementation`) into a
 * W3C Custom Element (`WebComponentImplementation`).
 *
 * The returned implementation carries a generated `a2ui-ng-<name>` tag and an element class that
 * mounts the Angular component when connected. The element is not defined in the
 * `customElements` registry here; renderers define it on demand with `registerUniversalElement`
 * right before rendering it, like any other `WebComponentImplementation`.
 *
 * Calling this twice with the same component class returns the same implementation.
 *
 * @param componentImpl The AngularComponentImplementation combining the ComponentApi schema and component class.
 * @returns The WebComponentImplementation representation.
 */
function toWebComponent(componentImpl) {
    const componentClass = componentImpl.component;
    const cached = angularWcCache.get(componentClass);
    if (cached) {
        return cached;
    }
    const tagName = computeTagName(componentImpl.name);
    // `customElements` refuses to define the same class under two tag names, so each Angular
    // component gets its own (otherwise identical) element class.
    const element = class extends AngularWcHost {
    };
    const implementation = {
        ...componentApiFields(componentImpl),
        tagName,
        element,
    };
    angularWcCache.set(componentClass, implementation);
    return implementation;
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Placeholder Angular component for catalog entries that only provide a Web Component.
 *
 * `AngularCatalog` assigns it so every entry has a `component`. It is only instantiated when
 * `RendererConfiguration.useUniversalComponents` is off, in which case Web Components are not
 * rendered, so it renders nothing and reports the misconfiguration.
 */
class UniversalOnlyComponent {
    props = input({}, ...(ngDevMode ? [{ debugName: "props" }] : /* istanbul ignore next */ []));
    surfaceId = input.required(...(ngDevMode ? [{ debugName: "surfaceId" }] : /* istanbul ignore next */ []));
    componentId = input.required(...(ngDevMode ? [{ debugName: "componentId" }] : /* istanbul ignore next */ []));
    dataContextPath = input('/', ...(ngDevMode ? [{ debugName: "dataContextPath" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        console.error(`Component "${this.componentId()}" in surface "${this.surfaceId()}" is a Web Component ` +
            `and requires 'useUniversalComponents' to render.`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: UniversalOnlyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.17", type: UniversalOnlyComponent, isStandalone: true, selector: "a2ui-v09-universal-only", inputs: { props: { classPropertyName: "props", publicName: "props", isSignal: true, isRequired: false, transformFunction: null }, surfaceId: { classPropertyName: "surfaceId", publicName: "surfaceId", isSignal: true, isRequired: true, transformFunction: null }, componentId: { classPropertyName: "componentId", publicName: "componentId", isSignal: true, isRequired: true, transformFunction: null }, dataContextPath: { classPropertyName: "dataContextPath", publicName: "dataContextPath", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: UniversalOnlyComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'a2ui-v09-universal-only',
                    template: '',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { props: [{ type: i0.Input, args: [{ isSignal: true, alias: "props", required: false }] }], surfaceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "surfaceId", required: true }] }], componentId: [{ type: i0.Input, args: [{ isSignal: true, alias: "componentId", required: true }] }], dataContextPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataContextPath", required: false }] }] } });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * A collection of component and function implementations mapped to
 * A2UI protocol types.
 *
 * Accepts native Angular components (`AngularComponentImplementation`) and
 * universal Web Components (`WebComponentImplementation`). Web Component
 * entries render only when `RendererConfiguration.useUniversalComponents`
 * is enabled.
 *
 * Catalogs are used by the {@link MessageProcessor} to resolve component
 * definitions and by {@link ComponentHostComponent} to instantiate the
 * correct Angular components.
 */
class AngularCatalog extends Catalog {
    constructor(id, protocolVersionOrComponents, componentsOrFunctions, functionsOrThemeSchema, themeSchemaOrInstructions, instructions) {
        if (typeof protocolVersionOrComponents !== 'string') {
            // Pre-1.0 (v0.9) signature: `new AngularCatalog(id, components, functions, ...)`.
            super(id, '0.9', (protocolVersionOrComponents ?? []).map(toAngularComponentImplementation), componentsOrFunctions, functionsOrThemeSchema, themeSchemaOrInstructions);
        }
        else {
            const components = (componentsOrFunctions ?? []);
            super(id, protocolVersionOrComponents, components.map(toAngularComponentImplementation), functionsOrThemeSchema, themeSchemaOrInstructions, instructions);
        }
    }
}
function toAngularComponentImplementation(entry) {
    if (!isAngularComponentImplementation(entry)) {
        // Workaround, needed only while 1P apps migrate to `useUniversalComponents: true`: until
        // then every catalog entry must carry an Angular component, so Web Component-only entries
        // get a placeholder that reports the missing flag instead of rendering.
        return { ...entry, component: UniversalOnlyComponent };
    }
    if (!isWebComponentImplementation(entry)) {
        // Attach a lazy Web Component wrapper to plain `{...api, component}` entries so universal
        // container elements (`a2ui-basic-column`, `a2ui-card`, etc.) can resolve them by `tagName`
        // via `renderA2uiNode` without requiring callers to wrap with `createComponentImplementation`.
        // The fields are added to the entry itself so callers keep entry identity (for example
        // `catalog.components.get('X') === X_IMPL`); only non-extensible entries are copied.
        const webComponent = toWebComponent(entry);
        const fields = { tagName: webComponent.tagName, element: webComponent.element };
        return Object.isExtensible(entry) ? Object.assign(entry, fields) : { ...entry, ...fields };
    }
    return entry;
}
/**
 * Duck-types a catalog entry as an {@link AngularComponentImplementation}
 * (`typeof api.component === 'function'`), so catalogs built from plain object
 * literals are recognized without class inheritance or brand symbols.
 */
function isAngularComponentImplementation(api) {
    return (typeof api === 'object' &&
        api !== null &&
        'component' in api &&
        typeof api.component === 'function');
}
/**
 * Creates a catalog entry for an Angular component that can be rendered both natively and as a
 * universal Web Component.
 *
 * The entry also carries a Custom Element (`tagName`, `element`): the one of `componentApi` when
 * it is a `WebComponentImplementation` (for example a `@a2ui/web_core` basic catalog component),
 * otherwise `component` wrapped with {@link toWebComponent}. Universal container components can
 * therefore render the entry by tag, and the renderer mounts the element instead of `component`
 * when `RendererConfiguration.useUniversalComponents` is enabled.
 *
 * @param componentApi The ComponentApi or WebComponentImplementation defining the schema and name.
 * @param component The Angular Component class.
 * @returns The entry, usable both natively and as a Web Component.
 */
function createComponentImplementation(componentApi, component) {
    const webComponent = isWebComponentImplementation(componentApi)
        ? componentApi
        : toWebComponent({ ...componentApiFields(componentApi), component });
    // Annotated wider than the return type so the Custom Element fields pass the object literal
    // check; to consumers the entry is an AngularComponentImplementation that also satisfies
    // `isWebComponentImplementation`.
    const implementation = {
        ...componentApiFields(componentApi),
        tagName: webComponent.tagName,
        element: webComponent.element,
        component,
    };
    return implementation;
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * The set of default Angular universal implementations for each component in the v1.0 basic catalog.
 * Using string literals as keys, to survive property renaming, as these names need to match the JSON payload.
 */
// Ignore Prettier to preserve quoted keys, needed to survive property renaming.
// prettier-ignore
const DEFAULT_COMPONENT_IMPLEMENTATIONS = {
    'text': createComponentImplementation(A2uiText, UniversalOnlyComponent),
    'row': createComponentImplementation(A2uiRow, UniversalOnlyComponent),
    'column': createComponentImplementation(A2uiColumn, UniversalOnlyComponent),
    'button': createComponentImplementation(A2uiButton, UniversalOnlyComponent),
    'textField': createComponentImplementation(A2uiTextField, UniversalOnlyComponent),
    'image': createComponentImplementation(A2uiImage, UniversalOnlyComponent),
    'icon': createComponentImplementation(A2uiIcon, UniversalOnlyComponent),
    'video': createComponentImplementation(A2uiVideo, UniversalOnlyComponent),
    'audioPlayer': createComponentImplementation(A2uiAudioPlayer, UniversalOnlyComponent),
    'list': createComponentImplementation(A2uiList, UniversalOnlyComponent),
    'card': createComponentImplementation(A2uiCard, UniversalOnlyComponent),
    'tabs': createComponentImplementation(A2uiTabs, UniversalOnlyComponent),
    'modal': createComponentImplementation(A2uiModal, UniversalOnlyComponent),
    'divider': createComponentImplementation(A2uiDivider, UniversalOnlyComponent),
    'checkBox': createComponentImplementation(A2uiCheckBox, UniversalOnlyComponent),
    'choicePicker': createComponentImplementation(A2uiChoicePicker, UniversalOnlyComponent),
    'slider': createComponentImplementation(A2uiSlider, UniversalOnlyComponent),
    'dateTimeInput': createComponentImplementation(A2uiDateTimeInput, UniversalOnlyComponent),
};
/**
 * The set of UI components provided by the v1.0 basic catalog.
 */
const BASIC_COMPONENTS = Object.values(DEFAULT_COMPONENT_IMPLEMENTATIONS);
/**
 * A base class for v1.0 basic catalogs, providing extensibility for non-DI use cases.
 */
class BasicCatalogBase extends AngularCatalog {
    constructor(options = {}) {
        const id = options.id ?? 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json';
        const functions = options.functions ?? createBasicCatalogFunctions({ locale: options.locale });
        const overrides = options.components ?? {};
        const components = [
            ...Object.entries(DEFAULT_COMPONENT_IMPLEMENTATIONS).map(([key, defaultValue]) => {
                const impl = overrides[key] ?? defaultValue;
                const result = { name: impl.name || defaultValue.name || key };
                for (const prop of Object.keys(impl)) {
                    if (prop !== 'name') {
                        result[prop] = impl[prop];
                    }
                }
                return result;
            }),
            ...(options.extraComponents ?? []),
        ];
        super(id, '1.0', components, functions, options.themeSchema ?? BasicCatalogThemeSchema);
    }
}
const BASIC_CATALOG_OPTIONS = new InjectionToken('BASIC_CATALOG_OPTIONS_V1_0');
/**
 * The v1.0 basic catalog of components and functions for Angular.
 */
class BasicCatalog extends BasicCatalogBase {
    constructor(options) {
        super(options ?? {});
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, deps: [{ token: BASIC_CATALOG_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASIC_CATALOG_OPTIONS]
                }] }] });
/**
 * Provides the A2UI v1.0 renderer configuration, defaulting `useUniversalComponents` to `true`.
 *
 * @param configOrFactory The configuration or a factory function that returns the configuration.
 * @returns The providers for the A2UI renderer.
 */
function provideA2UI(configOrFactory) {
    return makeEnvironmentProviders([
        {
            provide: A2UI_RENDERER_CONFIG,
            ...(typeof configOrFactory === 'function'
                ? {
                    useFactory: () => {
                        const cfg = configOrFactory();
                        return { useUniversalComponents: true, ...cfg };
                    },
                }
                : {
                    useValue: { useUniversalComponents: true, ...configOrFactory },
                }),
        },
    ]);
}

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Core Services and Components

/**
 * Generated bundle index. Do not edit.
 */

export { A2UI_RENDERER_CONFIG, A2uiRendererService, AccessibilityTargetDirective, AngularCatalog, BASIC_CATALOG_OPTIONS, BASIC_COMPONENTS, BasicCatalog, BasicCatalogBase, CatalogComponent, ComponentBinder, ComponentHostComponent, DefaultMarkdownRenderer, MarkdownRenderer, SurfaceComponent, SurfaceNodeResolver, UniversalOnlyComponent, ValidationErrorsDirective, createComponentImplementation, getNormalizedPath, provideA2UI, provideA2Ui, provideMarkdownRenderer, toWebComponent };
//# sourceMappingURL=a2ui-angular.mjs.map
