import { CatalogComponent, A2uiRendererService, MarkdownRenderer, ComponentHostComponent, AccessibilityTargetDirective, ValidationErrorsDirective, createComponentImplementation, AngularCatalog } from '@a2ui/angular';
export { A2UI_RENDERER_CONFIG, A2uiRendererService, AccessibilityTargetDirective, AngularCatalog, CatalogComponent, ComponentBinder, ComponentHostComponent, DefaultMarkdownRenderer, MarkdownRenderer, SurfaceComponent, SurfaceNodeResolver, UniversalOnlyComponent, ValidationErrorsDirective, createComponentImplementation, getNormalizedPath, provideA2Ui, provideMarkdownRenderer, toWebComponent } from '@a2ui/angular';
import * as i0 from '@angular/core';
import { inject, computed, HostBinding, Directive, signal, effect, ChangeDetectionStrategy, Component, InjectionToken, Optional, Inject, Injectable } from '@angular/core';
import { injectBasicCatalogStyles, isValidCssColor, A2uiDateTimeInput, A2uiSlider, A2uiChoicePicker, A2uiCheckBox, A2uiDivider, A2uiModal, A2uiTabs, A2uiCard, A2uiList, A2uiAudioPlayer, A2uiVideo, A2uiIcon, A2uiImage, A2uiTextField, A2uiButton, A2uiColumn, A2uiRow, A2uiText, createBasicCatalogFunctions, BasicCatalogThemeSchema } from '@a2ui/web_core/v0_9/basic_catalog';
export { BASIC_FUNCTIONS } from '@a2ui/web_core/v0_9/basic_catalog';
import { DataContext } from '@a2ui/web_core/v0_9';

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Base class for A2UI basic catalog components in Angular.
 *
 * Automatically injects the basic catalog styles when the component is instantiated.
 * Also binds the primary brand color to the host element.
 */
class BasicCatalogComponent extends CatalogComponent {
    rendererService = inject(A2uiRendererService);
    surface = computed(() => {
        return this.rendererService.surfaceGroup.getSurface(this.surfaceId());
    }, ...(ngDevMode ? [{ debugName: "surface" }] : /* istanbul ignore next */ []));
    theme = computed(() => {
        return this.surface()?.theme;
    }, ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    primaryColor = computed(() => {
        return this.theme()?.primaryColor;
    }, ...(ngDevMode ? [{ debugName: "primaryColor" }] : /* istanbul ignore next */ []));
    /**
     * Weight is applied as flex css property on the component host HTML element.
     */
    weight = computed(() => {
        const props = this.props();
        return props['weight']?.value() ?? null;
    }, ...(ngDevMode ? [{ debugName: "weight" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        injectBasicCatalogStyles();
    }
    /**
     * Binds the flex style to the host element based on the weight.
     */
    get flexStyle() {
        return this.weight() !== null ? `${this.weight()}` : null;
    }
    get primaryColorStyle() {
        const color = this.primaryColor();
        if (typeof color === 'string' && isValidCssColor(color)) {
            return color;
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalogComponent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.17", type: BasicCatalogComponent, isStandalone: true, host: { properties: { "style.flex": "this.flexStyle", "style.--a2ui-color-primary": "this.primaryColorStyle" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalogComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { flexStyle: [{
                type: HostBinding,
                args: ['style.flex']
            }], primaryColorStyle: [{
                type: HostBinding,
                args: ['style.--a2ui-color-primary']
            }] } });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Text component (v0.9).
 *
 * Renders text with support for simple Markdown.
 *
 * Supported CSS variables:
 * - `--a2ui-text-color-text`: Controls the text color.
 * - `--a2ui-text-margin`: Controls the margin of text elements.
 * - `--a2ui-font-family-title`: Controls the font family for titles.
 * - `--a2ui-line-height-headings`: Controls the line height for headings.
 * - `--a2ui-line-height-body`: Controls the line height for body text.
 * - `--a2ui-text-caption-color`: Controls the color for caption text.
 * - `--a2ui-text-a-color`: Controls the color for links.
 * - `--a2ui-text-a-font-weight`: Controls the font weight for links.
 * - Font sizes: `--a2ui-font-size-2xl`, `--a2ui-font-size-xl`, `--a2ui-font-size-l`, `--a2ui-font-size-m`, `--a2ui-font-size-s`, `--a2ui-font-size-xs`.
 */
class TextComponent extends BasicCatalogComponent {
    markdownRenderer = inject(MarkdownRenderer);
    static NON_MARKDOWN_VARIANTS = new Set([
        'h1',
        'h2',
        'h3',
        'h4',
        'h5',
        'caption',
    ]);
    variant = computed(() => this.props()['variant']?.value() || 'body', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    // Dynamic bindings (e.g. `{ path: 'quantity' }`) can resolve to non-string values;
    // coerce to string before markdown rendering.
    text = computed(() => this.props()['text']?.value()?.toString() ?? '', ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    isNonMarkdownVariant = computed(() => {
        return TextComponent.NON_MARKDOWN_VARIANTS.has(this.variant());
    }, ...(ngDevMode ? [{ debugName: "isNonMarkdownVariant" }] : /* istanbul ignore next */ []));
    resolvedText = signal('', ...(ngDevMode ? [{ debugName: "resolvedText" }] : /* istanbul ignore next */ []));
    renderRequestId = 0;
    constructor() {
        super();
        effect(() => {
            if (this.isNonMarkdownVariant()) {
                return;
            }
            const text = this.text();
            const requestId = ++this.renderRequestId;
            this.markdownRenderer.render(text).then(rendered => {
                if (requestId === this.renderRequestId) {
                    this.resolvedText.set(rendered);
                }
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: TextComponent, isStandalone: true, selector: "a2ui-v09-text", usesInheritance: true, ngImport: i0, template: `
    @if (isNonMarkdownVariant()) {
      <span [class]="'a2ui-text ' + variant()">
        <!-- Nesting block elements like h1 inside a span is not correct HTML5. We should refactor this-->
        @switch (variant()) {
          @case ('h1') {
            <h1>{{ text() }}</h1>
          }
          @case ('h2') {
            <h2>{{ text() }}</h2>
          }
          @case ('h3') {
            <h3>{{ text() }}</h3>
          }
          @case ('h4') {
            <h4>{{ text() }}</h4>
          }
          @case ('h5') {
            <h5>{{ text() }}</h5>
          }
          @case ('caption') {
            <em>{{ text() }}</em>
          }
        }
      </span>
    } @else {
      <span [class]="'a2ui-text ' + variant()" [innerHTML]="resolvedText()"></span>
    }
  `, isInline: true, styles: [":host ::ng-deep .a2ui-text p,:host ::ng-deep .a2ui-text h1,:host ::ng-deep .a2ui-text h2,:host ::ng-deep .a2ui-text h3,:host ::ng-deep .a2ui-text h4,:host ::ng-deep .a2ui-text h5,:host ::ng-deep .a2ui-text h6,:host ::ng-deep .a2ui-text ol,:host ::ng-deep .a2ui-text ul,:host ::ng-deep .a2ui-text li,:host ::ng-deep .a2ui-text blockquote,:host ::ng-deep .a2ui-text pre{margin:var(--_a2ui-text-margin, 0)}:host ::ng-deep .a2ui-text{color:var( --_a2ui-text-color, var(--a2ui-text-color-text, var(--a2ui-color-on-background)) )}:host ::ng-deep .a2ui-text h1,:host ::ng-deep .a2ui-text h2,:host ::ng-deep .a2ui-text h3,:host ::ng-deep .a2ui-text h4,:host ::ng-deep .a2ui-text h5,:host ::ng-deep .a2ui-text h6{font-family:var(--a2ui-font-family-title, inherit);line-height:var(--a2ui-line-height-headings, 1.2)}:host ::ng-deep .a2ui-text h1{font-size:var(--a2ui-font-size-2xl)}:host ::ng-deep .a2ui-text h2{font-size:var(--a2ui-font-size-xl)}:host ::ng-deep .a2ui-text h3{font-size:var(--a2ui-font-size-l)}:host ::ng-deep .a2ui-text p,:host ::ng-deep .a2ui-text h4{font-size:var(--a2ui-font-size-m)}:host ::ng-deep .a2ui-text h5{font-size:var(--a2ui-font-size-s)}:host ::ng-deep .a2ui-text p{line-height:var(--a2ui-line-height-body, 1.5)}:host ::ng-deep .a2ui-text.caption{font-size:var(--a2ui-font-size-xs);color:var(--a2ui-text-caption-color, light-dark(#666, #aaa))}:host ::ng-deep .a2ui-text a{color:var(--a2ui-text-a-color, inherit);font-weight:var(--a2ui-text-a-font-weight, inherit)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TextComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-text', standalone: true, template: `
    @if (isNonMarkdownVariant()) {
      <span [class]="'a2ui-text ' + variant()">
        <!-- Nesting block elements like h1 inside a span is not correct HTML5. We should refactor this-->
        @switch (variant()) {
          @case ('h1') {
            <h1>{{ text() }}</h1>
          }
          @case ('h2') {
            <h2>{{ text() }}</h2>
          }
          @case ('h3') {
            <h3>{{ text() }}</h3>
          }
          @case ('h4') {
            <h4>{{ text() }}</h4>
          }
          @case ('h5') {
            <h5>{{ text() }}</h5>
          }
          @case ('caption') {
            <em>{{ text() }}</em>
          }
        }
      </span>
    } @else {
      <span [class]="'a2ui-text ' + variant()" [innerHTML]="resolvedText()"></span>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host ::ng-deep .a2ui-text p,:host ::ng-deep .a2ui-text h1,:host ::ng-deep .a2ui-text h2,:host ::ng-deep .a2ui-text h3,:host ::ng-deep .a2ui-text h4,:host ::ng-deep .a2ui-text h5,:host ::ng-deep .a2ui-text h6,:host ::ng-deep .a2ui-text ol,:host ::ng-deep .a2ui-text ul,:host ::ng-deep .a2ui-text li,:host ::ng-deep .a2ui-text blockquote,:host ::ng-deep .a2ui-text pre{margin:var(--_a2ui-text-margin, 0)}:host ::ng-deep .a2ui-text{color:var( --_a2ui-text-color, var(--a2ui-text-color-text, var(--a2ui-color-on-background)) )}:host ::ng-deep .a2ui-text h1,:host ::ng-deep .a2ui-text h2,:host ::ng-deep .a2ui-text h3,:host ::ng-deep .a2ui-text h4,:host ::ng-deep .a2ui-text h5,:host ::ng-deep .a2ui-text h6{font-family:var(--a2ui-font-family-title, inherit);line-height:var(--a2ui-line-height-headings, 1.2)}:host ::ng-deep .a2ui-text h1{font-size:var(--a2ui-font-size-2xl)}:host ::ng-deep .a2ui-text h2{font-size:var(--a2ui-font-size-xl)}:host ::ng-deep .a2ui-text h3{font-size:var(--a2ui-font-size-l)}:host ::ng-deep .a2ui-text p,:host ::ng-deep .a2ui-text h4{font-size:var(--a2ui-font-size-m)}:host ::ng-deep .a2ui-text h5{font-size:var(--a2ui-font-size-s)}:host ::ng-deep .a2ui-text p{line-height:var(--a2ui-line-height-body, 1.5)}:host ::ng-deep .a2ui-text.caption{font-size:var(--a2ui-font-size-xs);color:var(--a2ui-text-caption-color, light-dark(#666, #aaa))}:host ::ng-deep .a2ui-text a{color:var(--a2ui-text-a-color, inherit);font-weight:var(--a2ui-text-a-font-weight, inherit)}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Maps A2UI justification values to CSS justify-content values.
 */
const JUSTIFY_MAP = {
    start: 'flex-start',
    center: 'center',
    end: 'flex-end',
    spaceBetween: 'space-between',
    spaceAround: 'space-around',
    spaceEvenly: 'space-evenly',
    stretch: 'stretch',
};
/**
 * Maps A2UI alignment values to CSS align-items values.
 */
const ALIGN_MAP = {
    start: 'flex-start',
    center: 'center',
    end: 'flex-end',
    stretch: 'stretch',
    baseline: 'baseline',
};

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Row component (v0.9).
 *
 * Arranges child components in a horizontal flex layout. Supports both static
 * lists of children and repeating templates bound to a data collection.
 *
 * Supported CSS variables:
 * - `--a2ui-row-gap`: Controls the gap between items in the row. Defaults to `--a2ui-spacing-m` (16px).
 */
class RowComponent extends BasicCatalogComponent {
    justify = computed(() => {
        const val = this.props()['justify']?.value();
        return val ? JUSTIFY_MAP[val] || val : undefined;
    }, ...(ngDevMode ? [{ debugName: "justify" }] : /* istanbul ignore next */ []));
    align = computed(() => {
        const val = this.props()['align']?.value();
        return val ? ALIGN_MAP[val] || val : undefined;
    }, ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    children = computed(() => this.props()['children'].value() || [], ...(ngDevMode ? [{ debugName: "children" }] : /* istanbul ignore next */ []));
    trackChild(_index, child) {
        return `${child.basePath}/${child.id}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: RowComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: RowComponent, isStandalone: true, selector: "a2ui-v09-row", host: { properties: { "style.display": "\"flex\"", "style.flex-direction": "\"row\"", "style.gap": "\"var(--a2ui-row-gap, var(--a2ui-spacing-m, 16px))\"", "style.justify-content": "justify()", "style.align-items": "align()" } }, usesInheritance: true, ngImport: i0, template: `
    @for (child of children(); track trackChild($index, child)) {
      <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
      </a2ui-v09-component-host>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: RowComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'a2ui-v09-row',
                    standalone: true,
                    imports: [ComponentHostComponent],
                    host: {
                        '[style.display]': '"flex"',
                        '[style.flex-direction]': '"row"',
                        '[style.gap]': '"var(--a2ui-row-gap, var(--a2ui-spacing-m, 16px))"',
                        '[style.justify-content]': 'justify()',
                        '[style.align-items]': 'align()',
                    },
                    template: `
    @for (child of children(); track trackChild($index, child)) {
      <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
      </a2ui-v09-component-host>
    }
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Column component (v0.9).
 *
 * Arranges child components in a vertical flex layout. Supports both static
 * lists of children and repeating templates bound to a data collection.
 *
 * Supported CSS variables:
 * - `--a2ui-column-gap`: Controls the gap between items in the column. Defaults to `--a2ui-spacing-m` (16px).
 */
class ColumnComponent extends BasicCatalogComponent {
    justify = computed(() => {
        const val = this.props()['justify']?.value();
        return val ? JUSTIFY_MAP[val] || val : undefined;
    }, ...(ngDevMode ? [{ debugName: "justify" }] : /* istanbul ignore next */ []));
    align = computed(() => {
        const val = this.props()['align']?.value();
        return val ? ALIGN_MAP[val] || val : undefined;
    }, ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    children = computed(() => this.props()['children'].value() || [], ...(ngDevMode ? [{ debugName: "children" }] : /* istanbul ignore next */ []));
    trackChild(_index, child) {
        return `${child.basePath}/${child.id}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ColumnComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ColumnComponent, isStandalone: true, selector: "a2ui-v09-column", host: { properties: { "style.display": "\"flex\"", "style.flex-direction": "\"column\"", "style.width": "\"100%\"", "style.gap": "\"var(--a2ui-column-gap, var(--a2ui-spacing-m, 16px))\"", "style.justify-content": "justify()", "style.align-items": "align()" } }, usesInheritance: true, ngImport: i0, template: `
    @for (child of children(); track trackChild($index, child)) {
      <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
      </a2ui-v09-component-host>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ColumnComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'a2ui-v09-column',
                    standalone: true,
                    imports: [ComponentHostComponent],
                    host: {
                        '[style.display]': '"flex"',
                        '[style.flex-direction]': '"column"',
                        '[style.width]': '"100%"',
                        '[style.gap]': '"var(--a2ui-column-gap, var(--a2ui-spacing-m, 16px))"',
                        '[style.justify-content]': 'justify()',
                        '[style.align-items]': 'align()',
                    },
                    template: `
    @for (child of children(); track trackChild($index, child)) {
      <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
      </a2ui-v09-component-host>
    }
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Button component (v0.9).
 *
 * Renders a clickable button with a single child component (usually Text).
 * Dispatches an action when clicked if an `action` property is provided.
 *
 * Supported CSS variables:
 * - `--a2ui-button-padding`: Controls the padding.
 * - `--a2ui-button-border-radius`: Controls the border radius.
 * - `--a2ui-button-border`: Controls the border.
 * - `--a2ui-button-margin`: Controls the margin.
 * - `--a2ui-button-background`: Controls the background color.
 * - `--a2ui-button-box-shadow`: Controls the box shadow.
 * - `--a2ui-button-font-weight`: Controls the font weight.
 */
class ButtonComponent extends BasicCatalogComponent {
    variant = computed(() => this.props()['variant']?.value() ?? 'default', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    child = computed(() => this.props()['child']?.value(), ...(ngDevMode ? [{ debugName: "child" }] : /* istanbul ignore next */ []));
    action = computed(() => this.props()['action']?.value(), ...(ngDevMode ? [{ debugName: "action" }] : /* istanbul ignore next */ []));
    handleClick() {
        const action = this.action();
        if (!action)
            return;
        // Hosts bound from a resolved `ComponentNode` deliver actions as ready-to-call closures.
        if (typeof action === 'function') {
            void action();
            return;
        }
        const surface = this.surface();
        if (surface) {
            const dataContext = new DataContext(surface, this.dataContextPath());
            const resolvedAction = dataContext.resolveAction(action);
            surface.dispatchAction(resolvedAction, this.componentId());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ButtonComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ButtonComponent, isStandalone: true, selector: "a2ui-v09-button", usesInheritance: true, ngImport: i0, template: `
    <button
      a2uiAccessibilityTarget
      [type]="variant() === 'primary' ? 'submit' : 'button'"
      [class]="'a2ui-button ' + variant()"
      (click)="handleClick()"
      [disabled]="props()['isValid']?.value() === false"
    >
      @if (child()) {
        <a2ui-v09-component-host [componentKey]="child()!" [surfaceId]="surfaceId()">
        </a2ui-v09-component-host>
      }
    </button>
  `, isInline: true, styles: [".a2ui-button{padding:var( --a2ui-button-padding, var(--a2ui-spacing-m, .5rem) var(--a2ui-spacing-l, 1rem) );border-radius:var(--a2ui-button-border-radius, var(--a2ui-spacing-s, .25rem));border:var( --a2ui-button-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );cursor:pointer;margin:var(--a2ui-button-margin, var(--a2ui-spacing-m, .5rem));background:var(--a2ui-button-background, var(--a2ui-color-surface, #fff));box-shadow:var(--a2ui-button-box-shadow, none);font-weight:var(--a2ui-button-font-weight, normal);--_a2ui-text-margin: 0;--_a2ui-text-color: var(--a2ui-color-on-secondary, #333);color:var(--_a2ui-text-color)}.a2ui-button.primary{background-color:var(--a2ui-color-primary, #17e);--_a2ui-text-color: var(--a2ui-color-on-primary, #fff);color:var(--_a2ui-text-color);border:none}.a2ui-button.borderless{background:none;border:none;padding:0;color:var(--a2ui-color-primary, #17e)}.a2ui-button:disabled{background-color:#e9ecef;color:#6c757d;border-color:#ced4da;cursor:not-allowed}\n"], dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }, { kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-button', standalone: true, imports: [ComponentHostComponent, AccessibilityTargetDirective], template: `
    <button
      a2uiAccessibilityTarget
      [type]="variant() === 'primary' ? 'submit' : 'button'"
      [class]="'a2ui-button ' + variant()"
      (click)="handleClick()"
      [disabled]="props()['isValid']?.value() === false"
    >
      @if (child()) {
        <a2ui-v09-component-host [componentKey]="child()!" [surfaceId]="surfaceId()">
        </a2ui-v09-component-host>
      }
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-button{padding:var( --a2ui-button-padding, var(--a2ui-spacing-m, .5rem) var(--a2ui-spacing-l, 1rem) );border-radius:var(--a2ui-button-border-radius, var(--a2ui-spacing-s, .25rem));border:var( --a2ui-button-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );cursor:pointer;margin:var(--a2ui-button-margin, var(--a2ui-spacing-m, .5rem));background:var(--a2ui-button-background, var(--a2ui-color-surface, #fff));box-shadow:var(--a2ui-button-box-shadow, none);font-weight:var(--a2ui-button-font-weight, normal);--_a2ui-text-margin: 0;--_a2ui-text-color: var(--a2ui-color-on-secondary, #333);color:var(--_a2ui-text-color)}.a2ui-button.primary{background-color:var(--a2ui-color-primary, #17e);--_a2ui-text-color: var(--a2ui-color-on-primary, #fff);color:var(--_a2ui-text-color);border:none}.a2ui-button.borderless{background:none;border:none;padding:0;color:var(--a2ui-color-primary, #17e)}.a2ui-button:disabled{background-color:#e9ecef;color:#6c757d;border-color:#ced4da;cursor:not-allowed}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI TextField component (v0.9).
 *
 * Renders a text input field with an optional label.
 * Updates the bound data model property on every input change.
 *
 * Supported CSS variables:
 * - `--a2ui-color-input`: Controls the background color of the input.
 * - `--a2ui-color-on-input`: Controls the text color of the input.
 * - `--a2ui-textfield-border`: Controls the border of the input.
 * - `--a2ui-textfield-border-radius`: Controls the border radius of the input.
 * - `--a2ui-textfield-padding`: Controls the padding of the input.
 * - `--a2ui-textfield-color-border-focus`: Controls the border color on focus.
 * - `--a2ui-textfield-color-error`: Controls the border and text color for error states.
 * - `--a2ui-textfield-label-font-size`: Controls the font size of the label.
 * - `--a2ui-textfield-label-font-weight`: Controls the font weight of the label.
 */
class TextFieldComponent extends BasicCatalogComponent {
    label = computed(() => this.props()['label']?.value(), ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = computed(() => this.props()['value']?.value() || '', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    variant = computed(() => this.props()['variant']?.value(), ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    placeholder = computed(() => this.props()['placeholder']?.value() ?? null, ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    inputType = computed(() => {
        switch (this.variant()) {
            case 'obscured':
                return 'password';
            case 'number':
                return 'number';
            default:
                return 'text';
        }
    }, ...(ngDevMode ? [{ debugName: "inputType" }] : /* istanbul ignore next */ []));
    handleInput(event) {
        const value = event.target.value;
        // Update the data path.  If anything is listening to this path, it will be
        // notified.
        this.props()['value']?.onUpdate(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TextFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: TextFieldComponent, isStandalone: true, selector: "a2ui-v09-text-field", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-text-field-container">
      @if (label()) {
        <label>{{ label() }}</label>
      }
      <input
        a2uiAccessibilityTarget
        [type]="inputType()"
        [value]="value()"
        [attr.placeholder]="placeholder()"
        (input)="handleInput($event)"
        [class.invalid]="props()['isValid']?.value() === false"
      />
      @if (props()['validationErrors']?.value()?.length) {
        <div a2uiValidationErrors class="a2ui-validation-errors">
          @for (message of props()['validationErrors']?.value(); track message) {
            <div class="a2ui-error-message">{{ message }}</div>
          }
        </div>
      }
    </div>
  `, isInline: true, styles: [".a2ui-text-field-container{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);margin:var(--a2ui-spacing-xs, 4px)}label{font-size:var( --a2ui-textfield-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-textfield-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}input{padding:var(--a2ui-textfield-padding, 8px);border:var(--a2ui-textfield-border, 1px solid var(--a2ui-color-border, #ccc));border-radius:var(--a2ui-textfield-border-radius, 4px);background-color:var(--a2ui-color-input, #fff);color:var(--a2ui-color-on-input, #333)}input:focus{border-color:var(--a2ui-textfield-color-border-focus, var(--a2ui-color-primary, #17e));outline:none}input.invalid{border-color:var(--a2ui-textfield-color-error, var(--a2ui-color-error, red))}.a2ui-error-message{color:var(--a2ui-textfield-color-error, var(--a2ui-color-error, red));font-size:var(--a2ui-font-size-xs, 12px)}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }, { kind: "directive", type: ValidationErrorsDirective, selector: "[a2uiValidationErrors]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TextFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-text-field', standalone: true, imports: [AccessibilityTargetDirective, ValidationErrorsDirective], template: `
    <div class="a2ui-text-field-container">
      @if (label()) {
        <label>{{ label() }}</label>
      }
      <input
        a2uiAccessibilityTarget
        [type]="inputType()"
        [value]="value()"
        [attr.placeholder]="placeholder()"
        (input)="handleInput($event)"
        [class.invalid]="props()['isValid']?.value() === false"
      />
      @if (props()['validationErrors']?.value()?.length) {
        <div a2uiValidationErrors class="a2ui-validation-errors">
          @for (message of props()['validationErrors']?.value(); track message) {
            <div class="a2ui-error-message">{{ message }}</div>
          }
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-text-field-container{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);margin:var(--a2ui-spacing-xs, 4px)}label{font-size:var( --a2ui-textfield-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-textfield-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}input{padding:var(--a2ui-textfield-padding, 8px);border:var(--a2ui-textfield-border, 1px solid var(--a2ui-color-border, #ccc));border-radius:var(--a2ui-textfield-border-radius, 4px);background-color:var(--a2ui-color-input, #fff);color:var(--a2ui-color-on-input, #333)}input:focus{border-color:var(--a2ui-textfield-color-border-focus, var(--a2ui-color-primary, #17e));outline:none}input.invalid{border-color:var(--a2ui-textfield-color-error, var(--a2ui-color-error, red))}.a2ui-error-message{color:var(--a2ui-textfield-color-error, var(--a2ui-color-error, red));font-size:var(--a2ui-font-size-xs, 12px)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Image component (v0.9).
 *
 * Renders an image with configurable fit and shape variants.
 *
 * Supported CSS variables:
 * - `--a2ui-image-border-radius`: Controls the rounded corners.
 * - `--a2ui-image-icon-size`: Size of the icon variant.
 * - `--a2ui-image-avatar-size`: Size of the avatar variant.
 * - `--a2ui-image-small-feature-size`: Max-width of smallFeature variant.
 * - `--a2ui-image-large-feature-size`: Max-height of largeFeature variant.
 * - `--a2ui-image-header-size`: Height of header variant.
 */
class ImageComponent extends BasicCatalogComponent {
    url = computed(() => this.props()['url']?.value(), ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    description = computed(() => this.props()['description']?.value() || '', ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    fit = computed(() => {
        const val = this.props()['fit']?.value() || 'cover';
        return val === 'scaleDown' ? 'scale-down' : val;
    }, ...(ngDevMode ? [{ debugName: "fit" }] : /* istanbul ignore next */ []));
    variant = computed(() => this.props()['variant']?.value() || 'default', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ImageComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.17", type: ImageComponent, isStandalone: true, selector: "a2ui-v09-image", usesInheritance: true, ngImport: i0, template: `
    <img
      a2uiAccessibilityTarget
      [src]="url()"
      [alt]="description()"
      [style.object-fit]="fit()"
      [class]="'a2ui-image ' + variant()"
    />
  `, isInline: true, styles: [".a2ui-image{display:block;max-width:100%;height:auto;border-radius:var(--a2ui-image-border-radius, var(--a2ui-border-radius, 8px))}.a2ui-image.icon{width:var(--a2ui-image-icon-size, 24px);height:var(--a2ui-image-icon-size, 24px)}.a2ui-image.avatar{width:var(--a2ui-image-avatar-size, 40px);height:var(--a2ui-image-avatar-size, 40px);border-radius:50%}.a2ui-image.smallFeature{max-width:var(--a2ui-image-small-feature-size, 100px)}.a2ui-image.largeFeature{max-height:var(--a2ui-image-large-feature-size, 400px)}.a2ui-image.header{height:var(--a2ui-image-header-size, 200px)}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-image', standalone: true, imports: [AccessibilityTargetDirective], template: `
    <img
      a2uiAccessibilityTarget
      [src]="url()"
      [alt]="description()"
      [style.object-fit]="fit()"
      [class]="'a2ui-image ' + variant()"
    />
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-image{display:block;max-width:100%;height:auto;border-radius:var(--a2ui-image-border-radius, var(--a2ui-border-radius, 8px))}.a2ui-image.icon{width:var(--a2ui-image-icon-size, 24px);height:var(--a2ui-image-icon-size, 24px)}.a2ui-image.avatar{width:var(--a2ui-image-avatar-size, 40px);height:var(--a2ui-image-avatar-size, 40px);border-radius:50%}.a2ui-image.smallFeature{max-width:var(--a2ui-image-small-feature-size, 100px)}.a2ui-image.largeFeature{max-height:var(--a2ui-image-large-feature-size, 400px)}.a2ui-image.header{height:var(--a2ui-image-header-size, 200px)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ICON_NAME_OVERRIDES = {
    play: 'play_arrow',
    rewind: 'fast_rewind',
    favoriteOff: 'favorite_border',
    starOff: 'star_border',
};
/**
 * Angular implementation of the A2UI Icon component (v0.9).
 *
 * Supports both Material Icons (by name) and custom SVG icons (by path).
 *
 * Supported CSS variables:
 * - `--a2ui-icon-size`: Controls the width, height, and font size of the icon.
 * - `--a2ui-icon-font-family`: Controls the font family for icon fonts.
 * - `--a2ui-icon-color`: Controls the color of the icon.
 * - `--a2ui-icon-font-variation-settings`: Controls font variation settings (e.g. FILL).
 */
class IconComponent extends BasicCatalogComponent {
    iconNameRaw = computed(() => this.props()['name']?.value(), ...(ngDevMode ? [{ debugName: "iconNameRaw" }] : /* istanbul ignore next */ []));
    isSvgPath = computed(() => {
        const name = this.iconNameRaw();
        return typeof name === 'object' && name !== null && 'svgPath' in name;
    }, ...(ngDevMode ? [{ debugName: "isSvgPath" }] : /* istanbul ignore next */ []));
    svgPath = computed(() => {
        const name = this.iconNameRaw();
        if (typeof name === 'object' && name !== null && 'svgPath' in name) {
            return name.svgPath;
        }
        return '';
    }, ...(ngDevMode ? [{ debugName: "svgPath" }] : /* istanbul ignore next */ []));
    iconName = computed(() => {
        const name = this.iconNameRaw();
        if (typeof name !== 'string')
            return '';
        if (ICON_NAME_OVERRIDES[name])
            return ICON_NAME_OVERRIDES[name];
        // Convert camelCase to snake_case for Material Icons
        return name.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
    }, ...(ngDevMode ? [{ debugName: "iconName" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: IconComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: IconComponent, isStandalone: true, selector: "a2ui-v09-icon", usesInheritance: true, ngImport: i0, template: `
    @if (isSvgPath()) {
      <svg class="a2ui-icon svg" viewBox="0 0 24 24">
        <path [attr.d]="svgPath()"></path>
      </svg>
    } @else {
      <i class="material-icons a2ui-icon">
        {{ iconName() }}
      </i>
    }
  `, isInline: true, styles: [".a2ui-icon{display:inline-block;width:var(--a2ui-icon-size, 24px);height:var(--a2ui-icon-size, 24px);font-size:var(--a2ui-icon-size, 24px);font-family:var(--a2ui-icon-font-family, \"Material Icons\");color:var( --a2ui-icon-color, var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333)) );font-variation-settings:var(--a2ui-icon-font-variation-settings, \"FILL\" 1);line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;font-feature-settings:\"liga\";vertical-align:middle}.a2ui-icon.svg{fill:currentColor}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-icon', standalone: true, imports: [], template: `
    @if (isSvgPath()) {
      <svg class="a2ui-icon svg" viewBox="0 0 24 24">
        <path [attr.d]="svgPath()"></path>
      </svg>
    } @else {
      <i class="material-icons a2ui-icon">
        {{ iconName() }}
      </i>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-icon{display:inline-block;width:var(--a2ui-icon-size, 24px);height:var(--a2ui-icon-size, 24px);font-size:var(--a2ui-icon-size, 24px);font-family:var(--a2ui-icon-font-family, \"Material Icons\");color:var( --a2ui-icon-color, var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333)) );font-variation-settings:var(--a2ui-icon-font-variation-settings, \"FILL\" 1);line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;font-feature-settings:\"liga\";vertical-align:middle}.a2ui-icon.svg{fill:currentColor}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Video component (v0.9).
 *
 * Renders a video player with standard controls.
 *
 * Supported CSS variables:
 * - `--a2ui-video-border-radius`: Controls the border radius of the video element.
 */
class VideoComponent extends BasicCatalogComponent {
    url = computed(() => this.props()['url']?.value(), ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    posterUrl = computed(() => {
        const p = this.props();
        return p['posterUrl']?.value() || p['poster']?.value() || null;
    }, ...(ngDevMode ? [{ debugName: "posterUrl" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: VideoComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.17", type: VideoComponent, isStandalone: true, selector: "a2ui-v09-video", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-video-container">
      <video
        a2uiAccessibilityTarget
        [attr.src]="url() || null"
        [attr.poster]="posterUrl()"
        controls
        class="a2ui-video"
      >
        Your browser does not support the video tag.
      </video>
    </div>
  `, isInline: true, styles: [".a2ui-video-container{width:100%;max-width:100%}.a2ui-video{width:100%;height:auto;display:block;border-radius:var(--a2ui-video-border-radius, 0)}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: VideoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-video', standalone: true, imports: [AccessibilityTargetDirective], template: `
    <div class="a2ui-video-container">
      <video
        a2uiAccessibilityTarget
        [attr.src]="url() || null"
        [attr.poster]="posterUrl()"
        controls
        class="a2ui-video"
      >
        Your browser does not support the video tag.
      </video>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-video-container{width:100%;max-width:100%}.a2ui-video{width:100%;height:auto;display:block;border-radius:var(--a2ui-video-border-radius, 0)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI AudioPlayer component (v0.9).
 *
 * Renders an audio player with standard controls and an optional description.
 *
 * Supported CSS variables:
 * - `--a2ui-audioplayer-background`: Controls the background of the player. Defaults to `transparent`.
 * - `--a2ui-audioplayer-border-radius`: Controls the border radius. Defaults to `0`.
 * - `--a2ui-audioplayer-padding`: Controls the padding. Defaults to `0`.
 */
class AudioPlayerComponent extends BasicCatalogComponent {
    description = computed(() => this.props()['description']?.value(), ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    url = computed(() => this.props()['url']?.value(), ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: AudioPlayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: AudioPlayerComponent, isStandalone: true, selector: "a2ui-v09-audio-player", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-audio-player">
      @if (description()) {
        <div class="a2ui-audio-description">
          {{ description() }}
        </div>
      }
      <audio a2uiAccessibilityTarget [attr.src]="url() || null" controls class="a2ui-audio">
        Your browser does not support the audio tag.
      </audio>
    </div>
  `, isInline: true, styles: [".a2ui-audio-player{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, .25rem);background:var(--a2ui-audioplayer-background, transparent);border-radius:var(--a2ui-audioplayer-border-radius, 0);padding:var(--a2ui-audioplayer-padding, 0);width:100%}.a2ui-audio-description{font-size:var(--a2ui-font-size-s, .875rem);color:var(--a2ui-text-caption-color, light-dark(#666, #aaa))}.a2ui-audio{width:100%}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: AudioPlayerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-audio-player', standalone: true, imports: [AccessibilityTargetDirective], template: `
    <div class="a2ui-audio-player">
      @if (description()) {
        <div class="a2ui-audio-description">
          {{ description() }}
        </div>
      }
      <audio a2uiAccessibilityTarget [attr.src]="url() || null" controls class="a2ui-audio">
        Your browser does not support the audio tag.
      </audio>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-audio-player{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, .25rem);background:var(--a2ui-audioplayer-background, transparent);border-radius:var(--a2ui-audioplayer-border-radius, 0);padding:var(--a2ui-audioplayer-padding, 0);width:100%}.a2ui-audio-description{font-size:var(--a2ui-font-size-s, .875rem);color:var(--a2ui-text-caption-color, light-dark(#666, #aaa))}.a2ui-audio{width:100%}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI List component (v0.9).
 *
 * Renders a list of child components with support for ordered, unordered,
 * and unstyled layouts in both vertical and horizontal directions.
 *
 * Supported CSS variables:
 * - `--a2ui-list-gap`: Controls the gap between items.
 * - `--a2ui-list-padding`: Controls the padding (applied to padding-inline-start).
 */
class ListComponent extends BasicCatalogComponent {
    listStyle = computed(() => this.props()['listStyle']?.value(), ...(ngDevMode ? [{ debugName: "listStyle" }] : /* istanbul ignore next */ []));
    direction = computed(() => this.props()['direction']?.value() || 'vertical', ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
    align = computed(() => {
        const val = this.props()['align']?.value();
        return val ? ALIGN_MAP[val] || 'stretch' : null;
    }, ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    children = computed(() => this.props()['children'].value(), ...(ngDevMode ? [{ debugName: "children" }] : /* istanbul ignore next */ []));
    listTag = computed(() => {
        const style = this.listStyle();
        if (style === 'ordered')
            return 'ol';
        if (style === 'unordered')
            return 'ul';
        return 'div';
    }, ...(ngDevMode ? [{ debugName: "listTag" }] : /* istanbul ignore next */ []));
    styleType = computed(() => {
        const style = this.listStyle();
        if (style === 'none')
            return 'none';
        return '';
    }, ...(ngDevMode ? [{ debugName: "styleType" }] : /* istanbul ignore next */ []));
    /**
     * Track-by function to ensure stable change detection for list items.
     * Uses the full resolved path (`basePath/id`) to uniquely identify items.
     */
    trackBy = (index, item) => `${item.basePath}/${item.id}`;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ListComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ListComponent, isStandalone: true, selector: "a2ui-v09-list", usesInheritance: true, ngImport: i0, template: `
    @switch (listTag()) {
      @case ('ol') {
        <ol
          [class]="'a2ui-list ' + direction()"
          [style.list-style-type]="styleType()"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <li>
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </li>
          }
        </ol>
      }
      @case ('ul') {
        <ul
          [class]="'a2ui-list ' + direction()"
          [style.list-style-type]="styleType()"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <li>
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </li>
          }
        </ul>
      }
      @default {
        <div
          [class]="'a2ui-list ' + direction()"
          style="list-style-type: none;"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <div class="a2ui-list-item-none">
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </div>
          }
        </div>
      }
    }
  `, isInline: true, styles: [".a2ui-list{display:flex;padding-inline-start:var(--a2ui-list-padding, var(--a2ui-spacing-l, 24px));margin:0}.a2ui-list.vertical{flex-direction:column;gap:var(--a2ui-list-gap, var(--a2ui-spacing-s, 8px))}.a2ui-list.horizontal{flex-direction:row;gap:var(--a2ui-list-gap, var(--a2ui-spacing-m, 16px));list-style-position:inside}.a2ui-list-item-none{display:block}.horizontal .a2ui-list-item-none{display:inline-block}li:has(>a2ui-v09-component-host[data-a2ui-empty]),.a2ui-list-item-none:has(>a2ui-v09-component-host[data-a2ui-empty]){display:none}\n"], dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-list', standalone: true, imports: [ComponentHostComponent], template: `
    @switch (listTag()) {
      @case ('ol') {
        <ol
          [class]="'a2ui-list ' + direction()"
          [style.list-style-type]="styleType()"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <li>
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </li>
          }
        </ol>
      }
      @case ('ul') {
        <ul
          [class]="'a2ui-list ' + direction()"
          [style.list-style-type]="styleType()"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <li>
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </li>
          }
        </ul>
      }
      @default {
        <div
          [class]="'a2ui-list ' + direction()"
          style="list-style-type: none;"
          [style.align-items]="align()"
        >
          @for (child of children(); track trackBy($index, child)) {
            <div class="a2ui-list-item-none">
              <a2ui-v09-component-host [componentKey]="child" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            </div>
          }
        </div>
      }
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-list{display:flex;padding-inline-start:var(--a2ui-list-padding, var(--a2ui-spacing-l, 24px));margin:0}.a2ui-list.vertical{flex-direction:column;gap:var(--a2ui-list-gap, var(--a2ui-spacing-s, 8px))}.a2ui-list.horizontal{flex-direction:row;gap:var(--a2ui-list-gap, var(--a2ui-spacing-m, 16px));list-style-position:inside}.a2ui-list-item-none{display:block}.horizontal .a2ui-list-item-none{display:inline-block}li:has(>a2ui-v09-component-host[data-a2ui-empty]),.a2ui-list-item-none:has(>a2ui-v09-component-host[data-a2ui-empty]){display:none}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Card component (v0.9).
 *
 * Renders a container with a shadow and rounded corners for grouping related content.
 *
 * Supported CSS variables:
 * - `--a2ui-card-padding`: Controls the padding.
 * - `--a2ui-card-border-radius`: Controls the border radius.
 * - `--a2ui-card-box-shadow`: Controls the box shadow.
 * - `--a2ui-card-background`: Controls the background color.
 * - `--a2ui-card-border`: Controls the border.
 * - `--a2ui-card-margin`: Controls the margin.
 */
class CardComponent extends BasicCatalogComponent {
    child = computed(() => this.props()['child']?.value(), ...(ngDevMode ? [{ debugName: "child" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CardComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: CardComponent, isStandalone: true, selector: "a2ui-v09-card", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-card">
      @if (child()) {
        <a2ui-v09-component-host [componentKey]="child()!" [surfaceId]="surfaceId()">
        </a2ui-v09-component-host>
      }
    </div>
  `, isInline: true, styles: [".a2ui-card{padding:var(--a2ui-card-padding, var(--a2ui-spacing-m, 16px));border-radius:var(--a2ui-card-border-radius, var(--a2ui-border-radius, 8px));box-shadow:var(--a2ui-card-box-shadow, 0 2px 4px rgba(0, 0, 0, .1));background:var(--a2ui-card-background, var(--a2ui-color-surface, #fff));border:var( --a2ui-card-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );margin:var(--a2ui-card-margin, var(--a2ui-spacing-m, 16px))}\n"], dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-card', standalone: true, imports: [ComponentHostComponent], template: `
    <div class="a2ui-card">
      @if (child()) {
        <a2ui-v09-component-host [componentKey]="child()!" [surfaceId]="surfaceId()">
        </a2ui-v09-component-host>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-card{padding:var(--a2ui-card-padding, var(--a2ui-spacing-m, 16px));border-radius:var(--a2ui-card-border-radius, var(--a2ui-border-radius, 8px));box-shadow:var(--a2ui-card-box-shadow, 0 2px 4px rgba(0, 0, 0, .1));background:var(--a2ui-card-background, var(--a2ui-color-surface, #fff));border:var( --a2ui-card-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );margin:var(--a2ui-card-margin, var(--a2ui-spacing-m, 16px))}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Tabs component (v0.9).
 *
 * Renders a set of tabs where each tab has a label and associated content.
 * Manages the active tab state internally.
 *
 * Supported CSS variables:
 * - `--a2ui-tabs-border`: Controls the border of the tab bar.
 * - `--a2ui-tabs-header-background`: Controls the background of tab buttons.
 * - `--a2ui-tabs-header-color`: Controls the text color of tab buttons.
 * - `--a2ui-tabs-header-background-active`: Controls the background of the active tab button.
 * - `--a2ui-tabs-header-color-active`: Controls the text color of the active tab button.
 * - `--a2ui-tabs-content-padding`: Controls the padding of the tab content.
 */
class TabsComponent extends BasicCatalogComponent {
    activeTabIndex = signal(0, ...(ngDevMode ? [{ debugName: "activeTabIndex" }] : /* istanbul ignore next */ []));
    tabs = computed(() => this.props()['tabs']?.value() || [], ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    activeTab = computed(() => this.tabs()[this.activeTabIndex()], ...(ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []));
    normalizedActiveTabChild = computed(() => {
        const child = this.activeTab()?.child;
        if (!child)
            return null;
        if (typeof child === 'object' && child !== null && 'id' in child) {
            return child;
        }
        return { id: child, basePath: this.dataContextPath() };
    }, ...(ngDevMode ? [{ debugName: "normalizedActiveTabChild" }] : /* istanbul ignore next */ []));
    setActiveTab(index) {
        this.activeTabIndex.set(index);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TabsComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: TabsComponent, isStandalone: true, selector: "a2ui-v09-tabs", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-tabs">
      <div class="a2ui-tab-bar">
        @for (tab of tabs(); track tab; let i = $index) {
          <button
            class="a2ui-tab-button"
            [class.active]="activeTabIndex() === i"
            (click)="setActiveTab(i)"
          >
            {{ tab.title }}
          </button>
        }
      </div>
      @if (normalizedActiveTabChild()) {
        <div class="a2ui-tab-content">
          <a2ui-v09-component-host
            [componentKey]="normalizedActiveTabChild()!"
            [surfaceId]="surfaceId()"
          >
          </a2ui-v09-component-host>
        </div>
      }
    </div>
  `, isInline: true, styles: [".a2ui-tabs{display:flex;flex-direction:column;width:100%}.a2ui-tab-bar{display:flex;border-bottom:var(--a2ui-tabs-border, 2px solid var(--a2ui-color-border, #eee));gap:var(--a2ui-spacing-m, 16px)}.a2ui-tab-button{padding:var(--a2ui-spacing-s, 8px) var(--a2ui-spacing-m, 16px);border:none;background:var(--a2ui-tabs-header-background, transparent);cursor:pointer;font-weight:500;color:var(--a2ui-tabs-header-color, var(--a2ui-text-caption-color, #666));border-bottom:2px solid transparent;margin-bottom:-2px}.a2ui-tab-button.active{background:var(--a2ui-tabs-header-background-active, transparent);color:var(--a2ui-tabs-header-color-active, var(--a2ui-color-primary, #007bff));border-bottom:2px solid var(--a2ui-color-primary, #007bff)}.a2ui-tab-content{padding:var(--a2ui-tabs-content-padding, var(--a2ui-spacing-m, 16px) 0)}\n"], dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: TabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-tabs', standalone: true, imports: [ComponentHostComponent], template: `
    <div class="a2ui-tabs">
      <div class="a2ui-tab-bar">
        @for (tab of tabs(); track tab; let i = $index) {
          <button
            class="a2ui-tab-button"
            [class.active]="activeTabIndex() === i"
            (click)="setActiveTab(i)"
          >
            {{ tab.title }}
          </button>
        }
      </div>
      @if (normalizedActiveTabChild()) {
        <div class="a2ui-tab-content">
          <a2ui-v09-component-host
            [componentKey]="normalizedActiveTabChild()!"
            [surfaceId]="surfaceId()"
          >
          </a2ui-v09-component-host>
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-tabs{display:flex;flex-direction:column;width:100%}.a2ui-tab-bar{display:flex;border-bottom:var(--a2ui-tabs-border, 2px solid var(--a2ui-color-border, #eee));gap:var(--a2ui-spacing-m, 16px)}.a2ui-tab-button{padding:var(--a2ui-spacing-s, 8px) var(--a2ui-spacing-m, 16px);border:none;background:var(--a2ui-tabs-header-background, transparent);cursor:pointer;font-weight:500;color:var(--a2ui-tabs-header-color, var(--a2ui-text-caption-color, #666));border-bottom:2px solid transparent;margin-bottom:-2px}.a2ui-tab-button.active{background:var(--a2ui-tabs-header-background-active, transparent);color:var(--a2ui-tabs-header-color-active, var(--a2ui-color-primary, #007bff));border-bottom:2px solid var(--a2ui-color-primary, #007bff)}.a2ui-tab-content{padding:var(--a2ui-tabs-content-padding, var(--a2ui-spacing-m, 16px) 0)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Modal component (v0.9).
 *
 * Renders a trigger component that opening an overlay containing a content component.
 *
 * Supported CSS variables:
 * - `--a2ui-modal-background`: Controls the background of the modal content.
 * - `--a2ui-modal-padding`: Controls the padding of the modal content.
 * - `--a2ui-modal-border-radius`: Controls the border radius of the modal content.
 * - `--a2ui-modal-box-shadow`: Controls the box shadow of the modal content.
 * - `--a2ui-modal-backdrop-bg`: Controls the background of the backdrop.
 */
class ModalComponent extends BasicCatalogComponent {
    isOpen = signal(false, ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    trigger = computed(() => this.props()['trigger']?.value(), ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    content = computed(() => this.props()['content']?.value(), ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    openModal() {
        this.isOpen.set(true);
    }
    closeModal() {
        this.isOpen.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ModalComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ModalComponent, isStandalone: true, selector: "a2ui-v09-modal", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-modal-wrapper">
      <div (click)="openModal()" class="a2ui-modal-trigger">
        @if (trigger()) {
          <a2ui-v09-component-host [componentKey]="trigger()!" [surfaceId]="surfaceId()">
          </a2ui-v09-component-host>
        }
      </div>

      @if (isOpen()) {
        <div class="a2ui-modal-overlay" (click)="closeModal()">
          <div
            class="a2ui-modal-content"
            role="dialog"
            aria-modal="true"
            (click)="$event.stopPropagation()"
          >
            <button
              type="button"
              class="a2ui-modal-close"
              aria-label="Close"
              (click)="closeModal()"
            >
              &times;
            </button>
            @if (content()) {
              <a2ui-v09-component-host [componentKey]="content()!" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            }
          </div>
        </div>
      }
    </div>
  `, isInline: true, styles: [".a2ui-modal-wrapper{display:inline-block}.a2ui-modal-trigger{cursor:pointer}.a2ui-modal-overlay{position:fixed;top:0;left:0;width:100vw;height:100vh;background:var(--a2ui-modal-backdrop-bg, rgba(0, 0, 0, .5));display:flex;justify-content:center;align-items:center;z-index:1000}.a2ui-modal-content{background:var(--a2ui-modal-background, var(--a2ui-color-surface, white));padding:var(--a2ui-modal-padding, var(--a2ui-spacing-xl, 32px));border-radius:var(--a2ui-modal-border-radius, var(--a2ui-border-radius, 8px));position:relative;min-width:300px;max-width:80%;max-height:80%;overflow-y:auto;box-shadow:var(--a2ui-modal-box-shadow, 0 10px 25px rgba(0, 0, 0, .2))}.a2ui-modal-close{position:absolute;top:10px;right:15px;border:none;background:none;font-size:24px;cursor:pointer;color:var(--a2ui-text-caption-color, #999)}.a2ui-modal-close:hover{color:var(--a2ui-text-color, #333)}\n"], dependencies: [{ kind: "component", type: ComponentHostComponent, selector: "a2ui-v09-component-host", inputs: ["componentKey", "surfaceId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-modal', standalone: true, imports: [ComponentHostComponent], template: `
    <div class="a2ui-modal-wrapper">
      <div (click)="openModal()" class="a2ui-modal-trigger">
        @if (trigger()) {
          <a2ui-v09-component-host [componentKey]="trigger()!" [surfaceId]="surfaceId()">
          </a2ui-v09-component-host>
        }
      </div>

      @if (isOpen()) {
        <div class="a2ui-modal-overlay" (click)="closeModal()">
          <div
            class="a2ui-modal-content"
            role="dialog"
            aria-modal="true"
            (click)="$event.stopPropagation()"
          >
            <button
              type="button"
              class="a2ui-modal-close"
              aria-label="Close"
              (click)="closeModal()"
            >
              &times;
            </button>
            @if (content()) {
              <a2ui-v09-component-host [componentKey]="content()!" [surfaceId]="surfaceId()">
              </a2ui-v09-component-host>
            }
          </div>
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-modal-wrapper{display:inline-block}.a2ui-modal-trigger{cursor:pointer}.a2ui-modal-overlay{position:fixed;top:0;left:0;width:100vw;height:100vh;background:var(--a2ui-modal-backdrop-bg, rgba(0, 0, 0, .5));display:flex;justify-content:center;align-items:center;z-index:1000}.a2ui-modal-content{background:var(--a2ui-modal-background, var(--a2ui-color-surface, white));padding:var(--a2ui-modal-padding, var(--a2ui-spacing-xl, 32px));border-radius:var(--a2ui-modal-border-radius, var(--a2ui-border-radius, 8px));position:relative;min-width:300px;max-width:80%;max-height:80%;overflow-y:auto;box-shadow:var(--a2ui-modal-box-shadow, 0 10px 25px rgba(0, 0, 0, .2))}.a2ui-modal-close{position:absolute;top:10px;right:15px;border:none;background:none;font-size:24px;cursor:pointer;color:var(--a2ui-text-caption-color, #999)}.a2ui-modal-close:hover{color:var(--a2ui-text-color, #333)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Divider component (v0.9).
 *
 * Renders a horizontal or vertical line to separate content.
 *
 * Supported CSS variables:
 * - `--a2ui-divider-border`: Controls the border of the divider (horizontal and vertical).
 * - `--a2ui-divider-spacing`: Controls the margin around the divider.
 */
class DividerComponent extends BasicCatalogComponent {
    axis = computed(() => this.props()['axis']?.value() ?? 'horizontal', ...(ngDevMode ? [{ debugName: "axis" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DividerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.17", type: DividerComponent, isStandalone: true, selector: "a2ui-v09-divider", host: { properties: { "style.display": "\"block\"", "style.width": "axis() === \"horizontal\" ? \"100%\" : \"auto\"" } }, usesInheritance: true, ngImport: i0, template: `
    <hr
      class="a2ui-divider"
      [class.horizontal]="axis() === 'horizontal'"
      [class.vertical]="axis() === 'vertical'"
    />
  `, isInline: true, styles: [".a2ui-divider{border:0;border-top:var( --a2ui-divider-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );margin:var(--a2ui-divider-spacing, var(--a2ui-spacing-m, 16px)) 0;width:100%}.a2ui-divider.vertical{width:var(--a2ui-border-width, 1px);height:100%;margin:0 var(--a2ui-divider-spacing, var(--a2ui-spacing-m, 16px));border-top:0;border-left:var( --a2ui-divider-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) )}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DividerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-divider', standalone: true, imports: [], host: {
                        '[style.display]': '"block"',
                        '[style.width]': 'axis() === "horizontal" ? "100%" : "auto"',
                    }, template: `
    <hr
      class="a2ui-divider"
      [class.horizontal]="axis() === 'horizontal'"
      [class.vertical]="axis() === 'vertical'"
    />
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-divider{border:0;border-top:var( --a2ui-divider-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) );margin:var(--a2ui-divider-spacing, var(--a2ui-spacing-m, 16px)) 0;width:100%}.a2ui-divider.vertical{width:var(--a2ui-border-width, 1px);height:100%;margin:0 var(--a2ui-divider-spacing, var(--a2ui-spacing-m, 16px));border-top:0;border-left:var( --a2ui-divider-border, var(--a2ui-border-width, 1px) solid var(--a2ui-color-border, #ccc) )}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI CheckBox component (v0.9).
 *
 * Renders a checkbox with a label. Updates the bound data model property
 * when the checked state changes.
 *
 * Supported CSS variables:
 * - `--a2ui-checkbox-margin`: Controls the margin.
 * - `--a2ui-checkbox-gap`: Controls the gap between checkbox and label.
 * - `--a2ui-checkbox-label-font-size`: Controls the font size of the label.
 * - `--a2ui-checkbox-label-font-weight`: Controls the font weight of the label.
 * - `--a2ui-checkbox-size`: Controls the width and height of the checkbox.
 * - `--a2ui-checkbox-background`: Controls the background of the checkbox.
 * - `--a2ui-checkbox-border`: Controls the border of the checkbox.
 * - `--a2ui-checkbox-border-radius`: Controls the border radius of the checkbox.
 * - `--a2ui-checkbox-color-error`: Controls the color for error states.
 */
class CheckBoxComponent extends BasicCatalogComponent {
    value = computed(() => this.props()['value']?.value() === true, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = computed(() => this.props()['label']?.value(), ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    handleChange(event) {
        const checked = event.target.checked;
        this.props()['value']?.onUpdate(checked);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CheckBoxComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.17", type: CheckBoxComponent, isStandalone: true, selector: "a2ui-v09-check-box", usesInheritance: true, ngImport: i0, template: `
    <label class="a2ui-check-box-label">
      <input
        a2uiAccessibilityTarget
        type="checkbox"
        [checked]="value()"
        (change)="handleChange($event)"
        class="a2ui-check-box-input"
      />
      <span class="a2ui-check-box-text">{{ label() }}</span>
    </label>
  `, isInline: true, styles: [".a2ui-check-box-label{display:flex;align-items:center;gap:var(--a2ui-checkbox-gap, var(--a2ui-spacing-s, .5rem));cursor:pointer;padding:4px 0;margin:var(--a2ui-checkbox-margin, var(--a2ui-spacing-m, 16px));color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-check-box-input{width:var(--a2ui-checkbox-size, 1rem);height:var(--a2ui-checkbox-size, 1rem);cursor:pointer;background:var(--a2ui-checkbox-background, inherit);border:var(--a2ui-checkbox-border, var(--a2ui-border-width, 1px) solid #ccc);border-radius:var(--a2ui-checkbox-border-radius, 4px);accent-color:var(--a2ui-color-primary)}.a2ui-check-box-text{font-size:var( --a2ui-checkbox-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 16px)) );font-weight:var(--a2ui-checkbox-label-font-weight, bold)}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: CheckBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-check-box', standalone: true, imports: [AccessibilityTargetDirective], template: `
    <label class="a2ui-check-box-label">
      <input
        a2uiAccessibilityTarget
        type="checkbox"
        [checked]="value()"
        (change)="handleChange($event)"
        class="a2ui-check-box-input"
      />
      <span class="a2ui-check-box-text">{{ label() }}</span>
    </label>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-check-box-label{display:flex;align-items:center;gap:var(--a2ui-checkbox-gap, var(--a2ui-spacing-s, .5rem));cursor:pointer;padding:4px 0;margin:var(--a2ui-checkbox-margin, var(--a2ui-spacing-m, 16px));color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-check-box-input{width:var(--a2ui-checkbox-size, 1rem);height:var(--a2ui-checkbox-size, 1rem);cursor:pointer;background:var(--a2ui-checkbox-background, inherit);border:var(--a2ui-checkbox-border, var(--a2ui-border-width, 1px) solid #ccc);border-radius:var(--a2ui-checkbox-border-radius, 4px);accent-color:var(--a2ui-color-primary)}.a2ui-check-box-text{font-size:var( --a2ui-checkbox-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 16px)) );font-weight:var(--a2ui-checkbox-label-font-weight, bold)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI ChoicePicker component (v0.9).
 *
 * Renders a set of options as either radio buttons/checkboxes or chips.
 * Supports both single and multiple selection.
 *
 * Supported CSS variables:
 * - `--a2ui-choicepicker-gap`: Controls spacing between options/chips.
 * - `--a2ui-choicepicker-padding`: Controls padding of the container.
 * - `--a2ui-choicepicker-checkbox-size`: Controls size of checkboxes/radios.
 * - `--a2ui-choicepicker-chip-padding`: Controls padding of chips.
 * - `--a2ui-choicepicker-chip-border-radius`: Controls border radius of chips.
 * - `--a2ui-choicepicker-chip-border`: Controls border of chips.
 * - `--a2ui-choicepicker-chip-background`: Controls background of chips.
 * - `--a2ui-choicepicker-chip-background-selected`: Controls background of selected chips.
 */
class ChoicePickerComponent extends BasicCatalogComponent {
    // Radio group names are document-scoped while component ids are only
    // surface-scoped, so the group name qualifies the component id with the
    // surface id and the data context path (which disambiguates instances
    // stamped from a list template within one surface).
    groupName = computed(() => {
        const sanitizedPath = this.dataContextPath().replace(/[^a-zA-Z0-9-]/g, '_');
        return `a2ui-choice-${this.surfaceId()}-${this.componentId()}-${sanitizedPath}`;
    }, ...(ngDevMode ? [{ debugName: "groupName" }] : /* istanbul ignore next */ []));
    displayStyle = computed(() => this.props()['displayStyle']?.value(), ...(ngDevMode ? [{ debugName: "displayStyle" }] : /* istanbul ignore next */ []));
    options = computed(() => this.props()['options']?.value() || [], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    variant = computed(() => this.props()['variant']?.value(), ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    selectedValue = computed(() => this.props()['value']?.value(), ...(ngDevMode ? [{ debugName: "selectedValue" }] : /* istanbul ignore next */ []));
    isMultiple() {
        return this.variant() === 'multipleSelection';
    }
    isSelected(value) {
        const selected = this.selectedValue();
        if (Array.isArray(selected)) {
            return selected.includes(value);
        }
        return selected === value;
    }
    onCheckChange(value, event) {
        const checked = event.target.checked;
        this.updateValue(value, checked);
    }
    toggleActive(value) {
        const current = this.isSelected(value);
        this.updateValue(value, !current);
    }
    updateValue(value, active) {
        const current = this.selectedValue();
        if (this.isMultiple()) {
            let next = Array.isArray(current) ? [...current] : [];
            if (active) {
                if (!next.includes(value))
                    next.push(value);
            }
            else {
                next = next.filter((v) => v !== value);
            }
            this.props()['value']?.onUpdate(next);
        }
        else {
            if (active) {
                this.props()['value']?.onUpdate([value]);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ChoicePickerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: ChoicePickerComponent, isStandalone: true, selector: "a2ui-v09-choice-picker", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-choice-picker">
      <!-- Chips Variant -->
      @if (displayStyle() === 'chips') {
        <div class="a2ui-chips-group">
          @for (option of options(); track option.value) {
            <button
              class="a2ui-chip"
              [class.active]="isSelected(option.value)"
              (click)="toggleActive(option.value)"
            >
              {{ option.label }}
            </button>
          }
        </div>
      } @else {
        <!-- Checkbox/Radio Variant -->
        <div class="a2ui-options-group">
          @for (option of options(); track option.value) {
            <label class="a2ui-option-label">
              <input
                [type]="isMultiple() ? 'checkbox' : 'radio'"
                [attr.name]="isMultiple() ? null : groupName()"
                [value]="option.value"
                [checked]="isSelected(option.value)"
                (change)="onCheckChange(option.value, $event)"
                class="a2ui-option-input"
              />
              <span class="a2ui-option-text">{{ option.label }}</span>
            </label>
          }
        </div>
      }
    </div>
  `, isInline: true, styles: [".a2ui-choice-picker{width:100%;padding:var(--a2ui-choicepicker-padding, 0)}.a2ui-options-group{display:flex;flex-direction:column;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem))}.a2ui-option-label{display:flex;align-items:center;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem));cursor:pointer;color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-option-input{width:var(--a2ui-choicepicker-checkbox-size, 1rem);height:var(--a2ui-choicepicker-checkbox-size, 1rem)}.a2ui-chips-group{display:flex;flex-wrap:wrap;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem))}.a2ui-chip{padding:var( --a2ui-choicepicker-chip-padding, var(--a2ui-spacing-s, .5rem) var(--a2ui-spacing-m, 1rem) );border-radius:var(--a2ui-choicepicker-chip-border-radius, 100px);border:var(--a2ui-choicepicker-chip-border, 1px solid var(--a2ui-color-border, #ccc));background:var(--a2ui-choicepicker-chip-background, var(--a2ui-color-surface, #fff));cursor:pointer;transition:all .2s}.a2ui-chip.active{background-color:var( --a2ui-choicepicker-chip-background-selected, var(--a2ui-color-primary, #17e) );color:var(--a2ui-color-on-primary, #fff);border-color:var( --a2ui-choicepicker-chip-background-selected, var(--a2ui-color-primary, #17e) )}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: ChoicePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-choice-picker', standalone: true, imports: [], template: `
    <div class="a2ui-choice-picker">
      <!-- Chips Variant -->
      @if (displayStyle() === 'chips') {
        <div class="a2ui-chips-group">
          @for (option of options(); track option.value) {
            <button
              class="a2ui-chip"
              [class.active]="isSelected(option.value)"
              (click)="toggleActive(option.value)"
            >
              {{ option.label }}
            </button>
          }
        </div>
      } @else {
        <!-- Checkbox/Radio Variant -->
        <div class="a2ui-options-group">
          @for (option of options(); track option.value) {
            <label class="a2ui-option-label">
              <input
                [type]="isMultiple() ? 'checkbox' : 'radio'"
                [attr.name]="isMultiple() ? null : groupName()"
                [value]="option.value"
                [checked]="isSelected(option.value)"
                (change)="onCheckChange(option.value, $event)"
                class="a2ui-option-input"
              />
              <span class="a2ui-option-text">{{ option.label }}</span>
            </label>
          }
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-choice-picker{width:100%;padding:var(--a2ui-choicepicker-padding, 0)}.a2ui-options-group{display:flex;flex-direction:column;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem))}.a2ui-option-label{display:flex;align-items:center;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem));cursor:pointer;color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-option-input{width:var(--a2ui-choicepicker-checkbox-size, 1rem);height:var(--a2ui-choicepicker-checkbox-size, 1rem)}.a2ui-chips-group{display:flex;flex-wrap:wrap;gap:var(--a2ui-choicepicker-gap, var(--a2ui-spacing-xs, .25rem))}.a2ui-chip{padding:var( --a2ui-choicepicker-chip-padding, var(--a2ui-spacing-s, .5rem) var(--a2ui-spacing-m, 1rem) );border-radius:var(--a2ui-choicepicker-chip-border-radius, 100px);border:var(--a2ui-choicepicker-chip-border, 1px solid var(--a2ui-color-border, #ccc));background:var(--a2ui-choicepicker-chip-background, var(--a2ui-color-surface, #fff));cursor:pointer;transition:all .2s}.a2ui-chip.active{background-color:var( --a2ui-choicepicker-chip-background-selected, var(--a2ui-color-primary, #17e) );color:var(--a2ui-color-on-primary, #fff);border-color:var( --a2ui-choicepicker-chip-background-selected, var(--a2ui-color-primary, #17e) )}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI Slider component (v0.9).
 *
 * Renders a range input slider with a label and its current value.
 *
 * Supported CSS variables:
 * - `--a2ui-slider-margin`: Controls the margin of the container.
 * - `--a2ui-slider-label-font-size`: Controls the font size of the label.
 * - `--a2ui-slider-label-font-weight`: Controls the font weight of the label.
 * - `--a2ui-slider-thumb-color`: Controls the accent color of the thumb.
 * - `--a2ui-slider-track-color`: Controls the background of the track.
 */
class SliderComponent extends BasicCatalogComponent {
    label = computed(() => this.props()['label']?.value(), ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = computed(() => this.props()['value']?.value(), ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    min = computed(() => this.props()['min']?.value() ?? 0, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = computed(() => this.props()['max']?.value() ?? 100, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    steps = computed(() => this.props()['steps']?.value(), ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    stepAttr = computed(() => {
        const s = this.steps();
        return typeof s === 'number' && s > 0 ? (this.max() - this.min()) / s : null;
    }, ...(ngDevMode ? [{ debugName: "stepAttr" }] : /* istanbul ignore next */ []));
    handleInput(event) {
        const val = Number(event.target.value);
        this.props()['value']?.onUpdate(val);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SliderComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: SliderComponent, isStandalone: true, selector: "a2ui-v09-slider", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-slider-container">
      <div class="a2ui-slider-header">
        <span class="a2ui-slider-label">{{ label() }}</span>
        <span class="a2ui-slider-value">{{ value() }}</span>
      </div>
      <input
        a2uiAccessibilityTarget
        type="range"
        [min]="min()"
        [max]="max()"
        [attr.step]="stepAttr()"
        [value]="value()"
        (input)="handleInput($event)"
        class="a2ui-slider"
        [class.invalid]="props()['isValid']?.value() === false"
      />
      @if (props()['validationErrors']?.value()?.length) {
        <div a2uiValidationErrors class="a2ui-validation-errors">
          @for (message of props()['validationErrors']?.value(); track message) {
            <div class="a2ui-error-message">{{ message }}</div>
          }
        </div>
      }
    </div>
  `, isInline: true, styles: [".a2ui-slider-container{width:100%;display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);margin:var(--a2ui-slider-margin, var(--a2ui-spacing-m, 16px))}.a2ui-slider-header{display:flex;justify-content:space-between;font-size:var( --a2ui-slider-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-slider-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-slider{width:100%;cursor:pointer;accent-color:var(--a2ui-slider-thumb-color, var(--a2ui-color-primary, #007bff));background:var(--a2ui-slider-track-color, var(--a2ui-color-secondary, #e9ecef))}.a2ui-error-message{color:var(--a2ui-slider-color-error, var(--a2ui-color-error, red));font-size:var(--a2ui-font-size-xs, 12px)}\n"], dependencies: [{ kind: "directive", type: AccessibilityTargetDirective, selector: "[a2uiAccessibilityTarget]" }, { kind: "directive", type: ValidationErrorsDirective, selector: "[a2uiValidationErrors]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: SliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-slider', standalone: true, imports: [AccessibilityTargetDirective, ValidationErrorsDirective], template: `
    <div class="a2ui-slider-container">
      <div class="a2ui-slider-header">
        <span class="a2ui-slider-label">{{ label() }}</span>
        <span class="a2ui-slider-value">{{ value() }}</span>
      </div>
      <input
        a2uiAccessibilityTarget
        type="range"
        [min]="min()"
        [max]="max()"
        [attr.step]="stepAttr()"
        [value]="value()"
        (input)="handleInput($event)"
        class="a2ui-slider"
        [class.invalid]="props()['isValid']?.value() === false"
      />
      @if (props()['validationErrors']?.value()?.length) {
        <div a2uiValidationErrors class="a2ui-validation-errors">
          @for (message of props()['validationErrors']?.value(); track message) {
            <div class="a2ui-error-message">{{ message }}</div>
          }
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-slider-container{width:100%;display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);margin:var(--a2ui-slider-margin, var(--a2ui-spacing-m, 16px))}.a2ui-slider-header{display:flex;justify-content:space-between;font-size:var( --a2ui-slider-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-slider-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-slider{width:100%;cursor:pointer;accent-color:var(--a2ui-slider-thumb-color, var(--a2ui-color-primary, #007bff));background:var(--a2ui-slider-track-color, var(--a2ui-color-secondary, #e9ecef))}.a2ui-error-message{color:var(--a2ui-slider-color-error, var(--a2ui-color-error, red));font-size:var(--a2ui-font-size-xs, 12px)}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Angular implementation of the A2UI DateTimeInput component (v0.9).
 *
 * Renders date and/or time input fields. Combines them into an ISO string
 * for the bound data model property.
 *
 * Supported CSS variables:
 * - `--a2ui-datetimeinput-background`: Controls the background of inputs.
 * - `--a2ui-datetimeinput-color`: Controls the text color of inputs.
 * - `--a2ui-datetimeinput-border`: Controls the border of inputs.
 * - `--a2ui-datetimeinput-border-radius`: Controls the border radius of inputs.
 * - `--a2ui-datetimeinput-padding`: Controls the padding of inputs.
 * - `--a2ui-datetimeinput-label-font-size`: Controls the font size of the label.
 * - `--a2ui-datetimeinput-label-font-weight`: Controls the font weight of the label.
 */
class DateTimeInputComponent extends BasicCatalogComponent {
    label = computed(() => this.props()['label']?.value(), ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    enableTime = computed(() => this.props()['enableTime']?.value() ?? false, ...(ngDevMode ? [{ debugName: "enableTime" }] : /* istanbul ignore next */ []));
    enableDate = computed(() => this.props()['enableDate']?.value() ?? !this.enableTime(), ...(ngDevMode ? [{ debugName: "enableDate" }] : /* istanbul ignore next */ []));
    rawValue = computed(() => this.props()['value']?.value() || '', ...(ngDevMode ? [{ debugName: "rawValue" }] : /* istanbul ignore next */ []));
    rawMin = computed(() => this.props()['min']?.value() || '', ...(ngDevMode ? [{ debugName: "rawMin" }] : /* istanbul ignore next */ []));
    rawMax = computed(() => this.props()['max']?.value() || '', ...(ngDevMode ? [{ debugName: "rawMax" }] : /* istanbul ignore next */ []));
    dateValue = computed(() => {
        const val = this.rawValue();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[0].substring(0, 10);
        return val.includes('-') ? val.substring(0, 10) : '';
    }, ...(ngDevMode ? [{ debugName: "dateValue" }] : /* istanbul ignore next */ []));
    timeValue = computed(() => {
        const val = this.rawValue();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[1].substring(0, 5);
        return val.includes(':') ? val.substring(0, 5) : '';
    }, ...(ngDevMode ? [{ debugName: "timeValue" }] : /* istanbul ignore next */ []));
    minDate = computed(() => {
        const val = this.rawMin();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[0].substring(0, 10);
        return val.includes('-') ? val.substring(0, 10) : '';
    }, ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    maxDate = computed(() => {
        const val = this.rawMax();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[0].substring(0, 10);
        return val.includes('-') ? val.substring(0, 10) : '';
    }, ...(ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []));
    minTime = computed(() => {
        const val = this.rawMin();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[1].substring(0, 5);
        return val.includes(':') ? val.substring(0, 5) : '';
    }, ...(ngDevMode ? [{ debugName: "minTime" }] : /* istanbul ignore next */ []));
    maxTime = computed(() => {
        const val = this.rawMax();
        if (!val)
            return '';
        if (val.includes('T'))
            return val.split('T')[1].substring(0, 5);
        return val.includes(':') ? val.substring(0, 5) : '';
    }, ...(ngDevMode ? [{ debugName: "maxTime" }] : /* istanbul ignore next */ []));
    handleDateChange(event) {
        const date = event.target.value;
        const current = this.rawValue();
        if (this.enableTime()) {
            const time = current.includes('T')
                ? current.split('T')[1]
                : current.includes(':')
                    ? current
                    : '00:00:00';
            this.props()['value']?.onUpdate(`${date}T${time}`);
        }
        else {
            this.props()['value']?.onUpdate(date);
        }
    }
    handleTimeChange(event) {
        const time = event.target.value;
        if (this.enableDate()) {
            const current = this.rawValue();
            const date = current.includes('T')
                ? current.split('T')[0]
                : current.includes('-')
                    ? current
                    : new Date().toISOString().split('T')[0];
            this.props()['value']?.onUpdate(`${date}T${time}:00`);
        }
        else {
            this.props()['value']?.onUpdate(time);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DateTimeInputComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.17", type: DateTimeInputComponent, isStandalone: true, selector: "a2ui-v09-date-time-input", usesInheritance: true, ngImport: i0, template: `
    <div class="a2ui-date-time-container">
      @if (label()) {
        <label class="a2ui-date-time-label">
          {{ label() }}
        </label>
      }
      <div class="a2ui-date-time-inputs">
        @if (enableDate()) {
          <input
            type="date"
            [attr.min]="minDate() || null"
            [attr.max]="maxDate() || null"
            [value]="dateValue()"
            (change)="handleDateChange($event)"
            class="a2ui-date-time-input"
          />
        }
        @if (enableTime()) {
          <input
            type="time"
            [attr.min]="minTime() || null"
            [attr.max]="maxTime() || null"
            [value]="timeValue()"
            (change)="handleTimeChange($event)"
            class="a2ui-date-time-input"
          />
        }
      </div>
    </div>
  `, isInline: true, styles: [".a2ui-date-time-container{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);width:100%}.a2ui-date-time-label{font-size:var( --a2ui-datetimeinput-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-datetimeinput-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-date-time-inputs{display:flex;gap:var(--a2ui-spacing-s, 8px);width:100%}.a2ui-date-time-input{padding:var(--a2ui-datetimeinput-padding, 8px);border-radius:var(--a2ui-datetimeinput-border-radius, 4px);border:var(--a2ui-datetimeinput-border, 1px solid var(--a2ui-color-border, #ccc));background-color:var(--a2ui-datetimeinput-background, var(--a2ui-color-input, #fff));color:var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333));font-family:inherit;flex:1}.a2ui-date-time-input::-webkit-datetime-edit,.a2ui-date-time-input::-webkit-datetime-edit-fields-wrapper{color:var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: DateTimeInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a2ui-v09-date-time-input', standalone: true, imports: [], template: `
    <div class="a2ui-date-time-container">
      @if (label()) {
        <label class="a2ui-date-time-label">
          {{ label() }}
        </label>
      }
      <div class="a2ui-date-time-inputs">
        @if (enableDate()) {
          <input
            type="date"
            [attr.min]="minDate() || null"
            [attr.max]="maxDate() || null"
            [value]="dateValue()"
            (change)="handleDateChange($event)"
            class="a2ui-date-time-input"
          />
        }
        @if (enableTime()) {
          <input
            type="time"
            [attr.min]="minTime() || null"
            [attr.max]="maxTime() || null"
            [value]="timeValue()"
            (change)="handleTimeChange($event)"
            class="a2ui-date-time-input"
          />
        }
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".a2ui-date-time-container{display:flex;flex-direction:column;gap:var(--a2ui-spacing-xs, 4px);width:100%}.a2ui-date-time-label{font-size:var( --a2ui-datetimeinput-label-font-size, var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px)) );font-weight:var(--a2ui-datetimeinput-label-font-weight, bold);color:var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))}.a2ui-date-time-inputs{display:flex;gap:var(--a2ui-spacing-s, 8px);width:100%}.a2ui-date-time-input{padding:var(--a2ui-datetimeinput-padding, 8px);border-radius:var(--a2ui-datetimeinput-border-radius, 4px);border:var(--a2ui-datetimeinput-border, 1px solid var(--a2ui-color-border, #ccc));background-color:var(--a2ui-datetimeinput-background, var(--a2ui-color-input, #fff));color:var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333));font-family:inherit;flex:1}.a2ui-date-time-input::-webkit-datetime-edit,.a2ui-date-time-input::-webkit-datetime-edit-fields-wrapper{color:var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333))}\n"] }]
        }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * The set of default Angular implementations for each component in the basic catalog.
 * Using string literals as keys, to survive property renaming, as these names need to match the JSON payload.
 */
// Ignore Prettier to preserve quoted keys, needed to survive property renaming.
// prettier-ignore
const DEFAULT_COMPONENT_IMPLEMENTATIONS = {
    'text': createComponentImplementation(A2uiText, TextComponent),
    'row': createComponentImplementation(A2uiRow, RowComponent),
    'column': createComponentImplementation(A2uiColumn, ColumnComponent),
    'button': createComponentImplementation(A2uiButton, ButtonComponent),
    'textField': createComponentImplementation(A2uiTextField, TextFieldComponent),
    'image': createComponentImplementation(A2uiImage, ImageComponent),
    'icon': createComponentImplementation(A2uiIcon, IconComponent),
    'video': createComponentImplementation(A2uiVideo, VideoComponent),
    'audioPlayer': createComponentImplementation(A2uiAudioPlayer, AudioPlayerComponent),
    'list': createComponentImplementation(A2uiList, ListComponent),
    'card': createComponentImplementation(A2uiCard, CardComponent),
    'tabs': createComponentImplementation(A2uiTabs, TabsComponent),
    'modal': createComponentImplementation(A2uiModal, ModalComponent),
    'divider': createComponentImplementation(A2uiDivider, DividerComponent),
    'checkBox': createComponentImplementation(A2uiCheckBox, CheckBoxComponent),
    'choicePicker': createComponentImplementation(A2uiChoicePicker, ChoicePickerComponent),
    'slider': createComponentImplementation(A2uiSlider, SliderComponent),
    'dateTimeInput': createComponentImplementation(A2uiDateTimeInput, DateTimeInputComponent),
};
/**
 * The set of Angular UI components provided by the basic catalog.
 */
const BASIC_COMPONENTS = Object.values(DEFAULT_COMPONENT_IMPLEMENTATIONS);
/**
 * A base class for basic catalogs, providing extensibility for non-DI use cases.
 */
class BasicCatalogBase extends AngularCatalog {
    constructor(options = {}) {
        const id = options.id ?? 'https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json';
        const functions = options.functions ?? createBasicCatalogFunctions({ locale: options.locale });
        const overrides = options.components ?? {};
        const components = [
            ...Object.entries(DEFAULT_COMPONENT_IMPLEMENTATIONS).map(([key, defaultValue]) => {
                const impl = overrides[key] ?? defaultValue;
                return { ...impl, name: impl.name || key };
            }),
            ...(options.extraComponents ?? []),
        ];
        super(id, '0.9', components, functions, options.themeSchema ?? BasicCatalogThemeSchema);
    }
}
const BASIC_CATALOG_OPTIONS = new InjectionToken('BASIC_CATALOG_OPTIONS');
/**
 * A basic catalog of components and functions for v0.9 verification.
 *
 * This catalog includes a wide range of UI components (Text, Button, Row, etc.)
 * and utility functions (formatString) defined in the A2UI v0.9
 * basic catalog specification.
 */
class BasicCatalog extends BasicCatalogBase {
    constructor(options) {
        super(options ?? {});
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, deps: [{ token: BASIC_CATALOG_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: BasicCatalog, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASIC_CATALOG_OPTIONS]
                }] }] });

/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Public API surface for A2UI Angular Renderer v0.9.
 *
 * This module provides the core services, components, and catalogs required
 * to render A2UI surfaces using the v0.9 protocol.
 *
 * @module v0.9
 */
// Core Services and Components re-exported from @a2ui/angular

/**
 * Generated bundle index. Do not edit.
 */

export { AudioPlayerComponent, BASIC_CATALOG_OPTIONS, BASIC_COMPONENTS, BasicCatalog, BasicCatalogBase, ButtonComponent, CardComponent, CheckBoxComponent, ChoicePickerComponent, ColumnComponent, DateTimeInputComponent, DividerComponent, IconComponent, ImageComponent, ListComponent, ModalComponent, RowComponent, SliderComponent, TabsComponent, TextComponent, TextFieldComponent, VideoComponent };
//# sourceMappingURL=a2ui-angular-src-v0_9.mjs.map
