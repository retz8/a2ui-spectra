import * as _angular_core from '@angular/core';
import { Type, Binding, InjectionToken, EnvironmentProviders } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import * as WebCore from '@a2ui/web_core/v0_8';
import * as zod from 'zod';
import * as Primitives from '@a2ui/web_core/types/primitives';
import * as _a2ui_web_core from '@a2ui/web_core';

type Action = WebCore.Action;
type FunctionCall = unknown;
type SurfaceID = string;
type StringValue = WebCore.StringValue;
type BooleanValue = WebCore.BooleanValue;
type NumberValue = WebCore.NumberValue;
type Surface$1 = WebCore.Surface;
type A2UIClientEventMessage = WebCore.A2UIClientEventMessage;
type ClientToServerMessage = A2UIClientEventMessage;
type ServerToClientMessage = WebCore.ServerToClientMessage;
declare const A2uiMessageSchema: zod.ZodEffects<zod.ZodObject<{
    beginRendering: zod.ZodOptional<zod.ZodObject<{
        surfaceId: zod.ZodString;
        catalogId: zod.ZodOptional<zod.ZodString>;
        root: zod.ZodString;
        styles: zod.ZodOptional<zod.ZodObject<{
            font: zod.ZodOptional<zod.ZodString>;
            primaryColor: zod.ZodOptional<zod.ZodString>;
        }, "strict", zod.ZodTypeAny, {
            font?: string | undefined;
            primaryColor?: string | undefined;
        }, {
            font?: string | undefined;
            primaryColor?: string | undefined;
        }>>;
    }, "strict", zod.ZodTypeAny, {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    }, {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    }>>;
    surfaceUpdate: zod.ZodOptional<zod.ZodEffects<zod.ZodObject<{
        surfaceId: zod.ZodString;
        components: zod.ZodArray<zod.ZodObject<{
            id: zod.ZodString;
            weight: zod.ZodOptional<zod.ZodNumber>;
            component: zod.ZodEffects<zod.ZodRecord<zod.ZodString, zod.ZodAny>, Record<string, any>, Record<string, any>>;
        }, "strict", zod.ZodTypeAny, {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }, {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }>, "many">;
    }, "strict", zod.ZodTypeAny, {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    }, {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    }>, {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    }, {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    }>>;
    dataModelUpdate: zod.ZodOptional<zod.ZodObject<{
        surfaceId: zod.ZodString;
        path: zod.ZodOptional<zod.ZodString>;
        contents: zod.ZodArray<zod.ZodEffects<zod.ZodType<any, zod.ZodTypeDef, any>, any, any>, "many">;
    }, "strict", zod.ZodTypeAny, {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    }, {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    }>>;
    deleteSurface: zod.ZodOptional<zod.ZodObject<{
        surfaceId: zod.ZodString;
    }, "strict", zod.ZodTypeAny, {
        surfaceId: string;
    }, {
        surfaceId: string;
    }>>;
}, "strict", zod.ZodTypeAny, {
    deleteSurface?: {
        surfaceId: string;
    } | undefined;
    beginRendering?: {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    } | undefined;
    surfaceUpdate?: {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    } | undefined;
    dataModelUpdate?: {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    } | undefined;
}, {
    deleteSurface?: {
        surfaceId: string;
    } | undefined;
    beginRendering?: {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    } | undefined;
    surfaceUpdate?: {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    } | undefined;
    dataModelUpdate?: {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    } | undefined;
}>, {
    deleteSurface?: {
        surfaceId: string;
    } | undefined;
    beginRendering?: {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    } | undefined;
    surfaceUpdate?: {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    } | undefined;
    dataModelUpdate?: {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    } | undefined;
}, {
    deleteSurface?: {
        surfaceId: string;
    } | undefined;
    beginRendering?: {
        surfaceId: string;
        root: string;
        catalogId?: string | undefined;
        styles?: {
            font?: string | undefined;
            primaryColor?: string | undefined;
        } | undefined;
    } | undefined;
    surfaceUpdate?: {
        surfaceId: string;
        components: {
            id: string;
            component: Record<string, any>;
            weight?: number | undefined;
        }[];
    } | undefined;
    dataModelUpdate?: {
        surfaceId: string;
        contents: any[];
        path?: string | undefined;
    } | undefined;
}>;
type A2uiMessage = WebCore.A2uiMessage;
interface Component<P = Record<string, unknown>> {
    id: string;
    type: string;
    properties: P;
}
type AnyComponentNode = WebCore.AnyComponentNode;
type CustomNode = WebCore.CustomNode;
type Theme$1 = WebCore.Theme;
type RowNode = WebCore.RowNode;
type ColumnNode = WebCore.ColumnNode;
type TextNode = WebCore.TextNode;
type ListNode = WebCore.ListNode;
type ImageNode = WebCore.ImageNode;
type IconNode = WebCore.IconNode;
type VideoNode = WebCore.VideoNode;
type AudioPlayerNode = WebCore.AudioPlayerNode;
type ButtonNode = WebCore.ButtonNode;
type DividerNode = WebCore.DividerNode;
type MultipleChoiceNode = WebCore.MultipleChoiceNode;
type TextFieldNode = WebCore.TextFieldNode;
type CheckboxNode = WebCore.CheckboxNode;
type SliderNode = WebCore.SliderNode;
type DateTimeInputNode = WebCore.DateTimeInputNode;
type TabsNode = WebCore.TabsNode;
type ModalNode = WebCore.ModalNode;
type CardNode = WebCore.CardNode;
type ResolvedRow = WebCore.ResolvedRow;
type ResolvedColumn = WebCore.ResolvedColumn;
type ResolvedText = WebCore.ResolvedText;
type ResolvedList = WebCore.ResolvedList;
type ResolvedImage = WebCore.ResolvedImage;
type ResolvedIcon = WebCore.ResolvedIcon;
type ResolvedVideo = WebCore.ResolvedVideo;
type ResolvedAudioPlayer = WebCore.ResolvedAudioPlayer;
type ResolvedButton = WebCore.ResolvedButton;
type ResolvedDivider = WebCore.ResolvedDivider;
type ResolvedMultipleChoice = WebCore.ResolvedMultipleChoice;
type ResolvedTextField = WebCore.ResolvedTextField;
type ResolvedCheckbox = WebCore.ResolvedCheckbox;
type ResolvedSlider = WebCore.ResolvedSlider;
type ResolvedDateTimeInput = WebCore.ResolvedDateTimeInput;
type ResolvedTabs = WebCore.ResolvedTabs;
type ResolvedModal = WebCore.ResolvedModal;
type ResolvedCard = WebCore.ResolvedCard;
type MarkdownRenderer$1 = WebCore.MarkdownRenderer;
type MarkdownRendererOptions = WebCore.MarkdownRendererOptions;

type types_d_A2UIClientEventMessage = A2UIClientEventMessage;
type types_d_A2uiMessage = A2uiMessage;
declare const types_d_A2uiMessageSchema: typeof A2uiMessageSchema;
type types_d_Action = Action;
type types_d_AnyComponentNode = AnyComponentNode;
type types_d_AudioPlayerNode = AudioPlayerNode;
type types_d_BooleanValue = BooleanValue;
type types_d_ButtonNode = ButtonNode;
type types_d_CardNode = CardNode;
type types_d_CheckboxNode = CheckboxNode;
type types_d_ClientToServerMessage = ClientToServerMessage;
type types_d_ColumnNode = ColumnNode;
type types_d_Component<P = Record<string, unknown>> = Component<P>;
type types_d_CustomNode = CustomNode;
type types_d_DateTimeInputNode = DateTimeInputNode;
type types_d_DividerNode = DividerNode;
type types_d_FunctionCall = FunctionCall;
type types_d_IconNode = IconNode;
type types_d_ImageNode = ImageNode;
type types_d_ListNode = ListNode;
type types_d_MarkdownRendererOptions = MarkdownRendererOptions;
type types_d_ModalNode = ModalNode;
type types_d_MultipleChoiceNode = MultipleChoiceNode;
type types_d_NumberValue = NumberValue;
type types_d_ResolvedAudioPlayer = ResolvedAudioPlayer;
type types_d_ResolvedButton = ResolvedButton;
type types_d_ResolvedCard = ResolvedCard;
type types_d_ResolvedCheckbox = ResolvedCheckbox;
type types_d_ResolvedColumn = ResolvedColumn;
type types_d_ResolvedDateTimeInput = ResolvedDateTimeInput;
type types_d_ResolvedDivider = ResolvedDivider;
type types_d_ResolvedIcon = ResolvedIcon;
type types_d_ResolvedImage = ResolvedImage;
type types_d_ResolvedList = ResolvedList;
type types_d_ResolvedModal = ResolvedModal;
type types_d_ResolvedMultipleChoice = ResolvedMultipleChoice;
type types_d_ResolvedRow = ResolvedRow;
type types_d_ResolvedSlider = ResolvedSlider;
type types_d_ResolvedTabs = ResolvedTabs;
type types_d_ResolvedText = ResolvedText;
type types_d_ResolvedTextField = ResolvedTextField;
type types_d_ResolvedVideo = ResolvedVideo;
type types_d_RowNode = RowNode;
type types_d_ServerToClientMessage = ServerToClientMessage;
type types_d_SliderNode = SliderNode;
type types_d_StringValue = StringValue;
type types_d_SurfaceID = SurfaceID;
type types_d_TabsNode = TabsNode;
type types_d_TextFieldNode = TextFieldNode;
type types_d_TextNode = TextNode;
type types_d_VideoNode = VideoNode;
declare namespace types_d {
  export { types_d_A2uiMessageSchema as A2uiMessageSchema };
  export type { types_d_A2UIClientEventMessage as A2UIClientEventMessage, types_d_A2uiMessage as A2uiMessage, types_d_Action as Action, types_d_AnyComponentNode as AnyComponentNode, types_d_AudioPlayerNode as AudioPlayerNode, types_d_BooleanValue as BooleanValue, types_d_ButtonNode as ButtonNode, types_d_CardNode as CardNode, types_d_CheckboxNode as CheckboxNode, types_d_ClientToServerMessage as ClientToServerMessage, types_d_ColumnNode as ColumnNode, types_d_Component as Component, types_d_CustomNode as CustomNode, types_d_DateTimeInputNode as DateTimeInputNode, types_d_DividerNode as DividerNode, types_d_FunctionCall as FunctionCall, types_d_IconNode as IconNode, types_d_ImageNode as ImageNode, types_d_ListNode as ListNode, MarkdownRenderer$1 as MarkdownRenderer, types_d_MarkdownRendererOptions as MarkdownRendererOptions, types_d_ModalNode as ModalNode, types_d_MultipleChoiceNode as MultipleChoiceNode, types_d_NumberValue as NumberValue, types_d_ResolvedAudioPlayer as ResolvedAudioPlayer, types_d_ResolvedButton as ResolvedButton, types_d_ResolvedCard as ResolvedCard, types_d_ResolvedCheckbox as ResolvedCheckbox, types_d_ResolvedColumn as ResolvedColumn, types_d_ResolvedDateTimeInput as ResolvedDateTimeInput, types_d_ResolvedDivider as ResolvedDivider, types_d_ResolvedIcon as ResolvedIcon, types_d_ResolvedImage as ResolvedImage, types_d_ResolvedList as ResolvedList, types_d_ResolvedModal as ResolvedModal, types_d_ResolvedMultipleChoice as ResolvedMultipleChoice, types_d_ResolvedRow as ResolvedRow, types_d_ResolvedSlider as ResolvedSlider, types_d_ResolvedTabs as ResolvedTabs, types_d_ResolvedText as ResolvedText, types_d_ResolvedTextField as ResolvedTextField, types_d_ResolvedVideo as ResolvedVideo, types_d_RowNode as RowNode, types_d_ServerToClientMessage as ServerToClientMessage, types_d_SliderNode as SliderNode, types_d_StringValue as StringValue, Surface$1 as Surface, types_d_SurfaceID as SurfaceID, types_d_TabsNode as TabsNode, types_d_TextFieldNode as TextFieldNode, types_d_TextNode as TextNode, Theme$1 as Theme, types_d_VideoNode as VideoNode };
}

interface A2UIClientEvent {
    message: A2UIClientEventMessage;
    completion: Subject<ServerToClientMessage[]>;
}
type DispatchedEvent = A2UIClientEvent;
declare class MessageProcessor {
    private baseProcessor;
    private readonly eventsSubject;
    readonly events: Observable<A2UIClientEvent>;
    private readonly versionSignal;
    readonly version: _angular_core.Signal<number>;
    constructor();
    /**
     * Increments the version signal to notify Angular that the data model has changed.
     * This should be called after any update to the underlying base processor's surfaces.
     */
    private notify;
    processMessages(messages: ServerToClientMessage[]): void;
    dispatch(message: A2UIClientEventMessage): Promise<ServerToClientMessage[]>;
    getData(node: AnyComponentNode, path: string, surfaceId?: string | null): unknown;
    setData(node: AnyComponentNode | null, path: string, value: any, surfaceId: string): void;
    resolvePath(path: string, dataContextPath?: string): string;
    getSurfaces(): ReadonlyMap<string, WebCore.Surface>;
    clearSurfaces(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MessageProcessor, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MessageProcessor>;
}

interface A2TextPayload {
    kind: 'text';
    text: string;
}
interface A2DataPayload {
    kind: 'data';
    data: ServerToClientMessage;
}
type A2AServerPayload = Array<A2DataPayload | A2TextPayload> | {
    error: string;
};

declare abstract class MarkdownRenderer {
    abstract render(markdown: string, options?: MarkdownRendererOptions): Promise<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MarkdownRenderer, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MarkdownRenderer>;
}
declare class DefaultMarkdownRenderer extends MarkdownRenderer {
    private static warningLogged;
    render(markdown: string, options?: MarkdownRendererOptions): Promise<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DefaultMarkdownRenderer, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DefaultMarkdownRenderer>;
}
declare function provideMarkdownRenderer(renderFn?: MarkdownRenderer$1): {
    provide: typeof MarkdownRenderer;
    useValue: {
        render: _a2ui_web_core.MarkdownRenderer;
    };
    useClass?: undefined;
} | {
    provide: typeof MarkdownRenderer;
    useClass: typeof DefaultMarkdownRenderer;
    useValue?: undefined;
};

declare class Theme {
    components: Theme$1['components'];
    elements: Theme$1['elements'];
    markdown: Theme$1['markdown'];
    additionalStyles?: Theme$1['additionalStyles'];
    update(theme: Theme$1): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Theme, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<Theme>;
}

declare abstract class DynamicComponent<T extends AnyComponentNode = AnyComponentNode> {
    protected readonly processor: MessageProcessor;
    protected readonly theme: Theme;
    readonly surfaceId: _angular_core.InputSignal<string | null>;
    readonly component: _angular_core.InputSignal<T>;
    readonly weight: _angular_core.InputSignal<string | number>;
    protected sendAction(action: Action): Promise<ServerToClientMessage[]>;
    protected resolvePrimitive(value: StringValue | null): string | null;
    protected resolvePrimitive(value: BooleanValue | null): boolean | null;
    protected resolvePrimitive(value: NumberValue | null): number | null;
    protected getUniqueId(prefix: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DynamicComponent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DynamicComponent<any>, never, never, { "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "component": { "alias": "component"; "required": true; "isSignal": true; }; "weight": { "alias": "weight"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

type CatalogLoader = () => Promise<Type<DynamicComponent<any>>> | Type<DynamicComponent<any>>;
type CatalogEntry<T extends AnyComponentNode> = CatalogLoader | {
    type: CatalogLoader;
    bindings: (data: T) => Binding[];
};
interface Catalog {
    [key: string]: CatalogEntry<AnyComponentNode>;
}
declare const Catalog: InjectionToken<Catalog>;

declare const DEFAULT_CATALOG: Catalog;
declare function registerStandardComponents(catalog: Catalog): void;

declare class AudioPlayer extends DynamicComponent<AudioPlayerNode> {
    readonly url: _angular_core.InputSignal<WebCore.StringValue | null>;
    protected readonly resolvedUrl: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AudioPlayer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AudioPlayer, "a2ui-audio", never, { "url": { "alias": "url"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Button extends DynamicComponent<ButtonNode> {
    readonly action: _angular_core.InputSignal<WebCore.Action | null>;
    readonly child: _angular_core.InputSignal<WebCore.AnyComponentNode | null>;
    readonly primary: _angular_core.InputSignal<boolean | null>;
    protected handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Button, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Button, "a2ui-button", never, { "action": { "alias": "action"; "required": false; "isSignal": true; }; "child": { "alias": "child"; "required": false; "isSignal": true; }; "primary": { "alias": "primary"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Card extends DynamicComponent<CardNode> {
    readonly child: _angular_core.InputSignal<WebCore.AnyComponentNode | null>;
    readonly children: _angular_core.InputSignal<WebCore.AnyComponentNode[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Card, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Card, "a2ui-card", never, { "child": { "alias": "child"; "required": false; "isSignal": true; }; "children": { "alias": "children"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Checkbox extends DynamicComponent<CheckboxNode> {
    readonly label: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly value: _angular_core.InputSignal<WebCore.BooleanValue | null>;
    protected inputChecked: _angular_core.Signal<boolean>;
    protected resolvedLabel: _angular_core.Signal<string | null>;
    protected readonly inputId: string;
    onToggle(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Checkbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Checkbox, "a2ui-checkbox", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Column extends DynamicComponent<ColumnNode> {
    readonly alignment: _angular_core.InputSignal<"start" | "center" | "end" | "stretch" | undefined>;
    readonly distribution: _angular_core.InputSignal<"start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined>;
    readonly children: _angular_core.InputSignal<WebCore.AnyComponentNode[] | null | undefined>;
    protected readonly classes: _angular_core.Signal<{
        [x: string]: boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Column, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Column, "a2ui-column", never, { "alignment": { "alias": "alignment"; "required": false; "isSignal": true; }; "distribution": { "alias": "distribution"; "required": false; "isSignal": true; }; "children": { "alias": "children"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DateTimeInput extends DynamicComponent<DateTimeInputNode> {
    readonly label: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly value: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly enableDate: _angular_core.InputSignal<boolean>;
    readonly enableTime: _angular_core.InputSignal<boolean>;
    protected readonly inputId: string;
    protected inputType: _angular_core.Signal<"date" | "datetime-local" | "time">;
    protected readonly resolvedLabel: _angular_core.Signal<string | null>;
    protected resolvedValue: _angular_core.Signal<string | null>;
    onChange(event: Event): void;
    private handleAction;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateTimeInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateTimeInput, "a2ui-datetime-input", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "enableDate": { "alias": "enableDate"; "required": false; "isSignal": true; }; "enableTime": { "alias": "enableTime"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Divider extends DynamicComponent<DividerNode> {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Divider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Divider, "a2ui-divider", never, {}, {}, never, never, true, never>;
}

declare class Icon extends DynamicComponent<IconNode> {
    readonly name: _angular_core.InputSignal<WebCore.StringValue | null>;
    protected readonly resolvedName: _angular_core.Signal<string>;
    private toSnakeCase;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Icon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Icon, "a2ui-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Image extends DynamicComponent<ImageNode> {
    readonly url: _angular_core.InputSignal<Primitives.StringValue | null>;
    readonly usageHint: _angular_core.InputSignal<"header" | "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | null | undefined>;
    readonly fit: _angular_core.InputSignal<"fill" | "none" | "contain" | "cover" | "scale-down" | null | undefined>;
    readonly altText: _angular_core.InputSignal<Primitives.StringValue | null>;
    protected readonly resolvedUrl: _angular_core.Signal<string | null>;
    protected readonly resolvedAltText: _angular_core.Signal<string>;
    protected classes: _angular_core.Signal<Record<string, boolean>>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Image, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Image, "a2ui-image", never, { "url": { "alias": "url"; "required": false; "isSignal": true; }; "usageHint": { "alias": "usageHint"; "required": false; "isSignal": true; }; "fit": { "alias": "fit"; "required": false; "isSignal": true; }; "altText": { "alias": "altText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class List extends DynamicComponent<ListNode> {
    readonly alignment: _angular_core.InputSignal<"start" | "center" | "end" | "stretch" | undefined>;
    readonly direction: _angular_core.InputSignal<"vertical" | "horizontal" | undefined>;
    readonly children: _angular_core.InputSignal<WebCore.AnyComponentNode[] | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<List, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<List, "a2ui-list", never, { "alignment": { "alias": "alignment"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "children": { "alias": "children"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Modal extends DynamicComponent<ModalNode> {
    readonly entryPointChild: _angular_core.InputSignal<WebCore.AnyComponentNode>;
    readonly contentChild: _angular_core.InputSignal<WebCore.AnyComponentNode>;
    protected readonly isOpen: _angular_core.WritableSignal<boolean>;
    openModal(): void;
    closeModal(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Modal, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Modal, "a2ui-modal", never, { "entryPointChild": { "alias": "entryPointChild"; "required": true; "isSignal": true; }; "contentChild": { "alias": "contentChild"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class MultipleChoice extends DynamicComponent<MultipleChoiceNode> {
    readonly label: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly options: _angular_core.InputSignal<{
        label: StringValue;
        value: string;
    }[]>;
    readonly selections: _angular_core.InputSignal<WebCore.AnyComponentNode | null>;
    protected readonly selectId: string;
    protected readonly resolvedLabel: _angular_core.Signal<string | null>;
    protected readonly resolvedOptions: _angular_core.Signal<{
        label: string | null;
        value: string;
    }[]>;
    protected readonly resolvedSelections: _angular_core.Signal<string[]>;
    onChange(event: Event): void;
    private handleAction;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultipleChoice, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultipleChoice, "a2ui-multiple-choice", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "selections": { "alias": "selections"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Row extends DynamicComponent<RowNode> {
    readonly alignment: _angular_core.InputSignal<"start" | "center" | "end" | "stretch" | undefined>;
    readonly distribution: _angular_core.InputSignal<"start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined>;
    readonly children: _angular_core.InputSignal<WebCore.AnyComponentNode[] | null | undefined>;
    protected readonly classes: _angular_core.Signal<{
        [x: string]: boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Row, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Row, "a2ui-row", never, { "alignment": { "alias": "alignment"; "required": false; "isSignal": true; }; "distribution": { "alias": "distribution"; "required": false; "isSignal": true; }; "children": { "alias": "children"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Slider extends DynamicComponent<SliderNode> {
    readonly label: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly value: _angular_core.InputSignal<WebCore.NumberValue | null>;
    readonly minValue: _angular_core.InputSignal<number>;
    readonly maxValue: _angular_core.InputSignal<number>;
    protected readonly inputId: string;
    protected readonly labelId: string;
    protected resolvedLabel: _angular_core.Signal<string | null>;
    protected resolvedValue: _angular_core.Signal<number | null>;
    onInput(event: Event): void;
    private handleAction;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Slider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Slider, "a2ui-slider", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "minValue": { "alias": "minValue"; "required": false; "isSignal": true; }; "maxValue": { "alias": "maxValue"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Surface {
    private readonly processor;
    readonly surfaceId: _angular_core.InputSignal<string>;
    readonly surfaceInput: _angular_core.InputSignal<WebCore.Surface | null>;
    protected readonly surface: _angular_core.Signal<WebCore.Surface | null>;
    protected readonly rootComponent: _angular_core.Signal<WebCore.AnyComponentNode | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Surface, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Surface, "a2ui-surface", never, { "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "surfaceInput": { "alias": "surface"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Tabs extends DynamicComponent<TabsNode> {
    readonly tabItems: _angular_core.InputSignal<WebCore.ResolvedTabItem[]>;
    protected readonly selectedIndex: _angular_core.WritableSignal<number>;
    protected selectTab(index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tabs, "a2ui-tabs", never, { "tabItems": { "alias": "tabItems"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TextField extends DynamicComponent<TextFieldNode> {
    readonly label: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly text: _angular_core.InputSignal<WebCore.StringValue | null>;
    readonly textFieldType: _angular_core.InputSignal<"number" | "date" | "shortText" | "longText" | "obscured" | undefined>;
    protected readonly inputId: string;
    protected resolvedLabel: _angular_core.Signal<string | null>;
    protected resolvedText: _angular_core.Signal<string | null>;
    protected htmlInputType: _angular_core.Signal<"text" | "number" | "date">;
    onInput(event: Event): void;
    private handleAction;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextField, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextField, "a2ui-text-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "textFieldType": { "alias": "textFieldType"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Text extends DynamicComponent<TextNode> {
    private markdownRenderer;
    readonly text: _angular_core.InputSignal<Primitives.StringValue | null>;
    readonly usageHint: _angular_core.InputSignal<"body" | "caption" | "h1" | "h2" | "h3" | "h4" | "h5" | null | undefined>;
    protected resolvedText: _angular_core.Signal<Promise<string>>;
    protected classes: _angular_core.Signal<Record<string, boolean>>;
    protected additionalStyles: _angular_core.Signal<Record<string, string> | null>;
    private areHintedStyles;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Text, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Text, "a2ui-text", never, { "text": { "alias": "text"; "required": true; "isSignal": true; }; "usageHint": { "alias": "usageHint"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Video extends DynamicComponent<VideoNode> {
    readonly url: _angular_core.InputSignal<WebCore.StringValue | null>;
    protected readonly resolvedUrl: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Video, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Video, "a2ui-video", never, { "url": { "alias": "url"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Renderer {
    private static hasInsertedStyles;
    private readonly catalog;
    private readonly container;
    private readonly processor;
    readonly surfaceId: _angular_core.InputSignal<string>;
    readonly component: _angular_core.InputSignal<WebCore.AnyComponentNode>;
    private currentId;
    private currentType;
    private currentComponentRef;
    constructor();
    private render;
    private resolveComponentType;
    /**
     * Updates the inputs of an existing component instance with the latest data from the node.
     * This is called during component reuse to keep the UI in sync without losing DOM state (like focus).
     */
    private updateInputs;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Renderer, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Renderer, "[a2ui-renderer]", never, { "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "component": { "alias": "component"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare function provideA2UI(config: {
    catalog: Catalog;
    theme: Theme$1;
}): EnvironmentProviders;

export { AudioPlayer, Button, Card, Catalog, Checkbox, Column, DEFAULT_CATALOG, DateTimeInput, Divider, DynamicComponent, Icon, Image, List, MarkdownRenderer, MessageProcessor, Modal, MultipleChoice, Renderer, Row, Slider, Surface, Tabs, Text, TextField, Theme, types_d as Types, Video, provideA2UI, provideMarkdownRenderer, registerStandardComponents };
export type { A2AServerPayload, A2DataPayload, A2TextPayload, A2UIClientEvent, CatalogEntry, CatalogLoader, DispatchedEvent };
