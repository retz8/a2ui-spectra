import * as _a2ui_angular from '@a2ui/angular';
import { AngularComponentImplementation, AngularCatalog, CatalogComponent, A2uiRendererService, Child } from '@a2ui/angular';
export { A2UI_RENDERER_CONFIG, A2uiRendererService, AccessibilityTargetDirective, AngularCatalog, AngularComponentImplementation, BoundProperty, CatalogComponent, Child, ComponentApiToProps, ComponentBinder, ComponentHostComponent, ComponentKey, ComponentTemplate, DefaultMarkdownRenderer, MarkdownRenderer, RendererConfiguration, SurfaceComponent, SurfaceNodeResolver, UniversalOnlyComponent, ValidationErrorsDirective, createComponentImplementation, getNormalizedPath, provideA2Ui, provideMarkdownRenderer, toWebComponent } from '@a2ui/angular';
import * as _angular_core from '@angular/core';
import { InjectionToken } from '@angular/core';
import { BasicCatalogTheme, TextApi, RowApi, ColumnApi, ButtonApi, TextFieldApi, ImageApi, IconApi, VideoApi, AudioPlayerApi, ListApi, CardApi, TabsApi, ModalApi, DividerApi, CheckBoxApi, ChoicePickerApi, SliderApi, DateTimeInputApi } from '@a2ui/web_core/v0_9/basic_catalog';
export { BASIC_FUNCTIONS } from '@a2ui/web_core/v0_9/basic_catalog';
import * as _a2ui_web_core_v0_9 from '@a2ui/web_core/v0_9';
import { FunctionImplementation, ComponentApi } from '@a2ui/web_core/v0_9';
import { z } from 'zod';
import * as _a2ui_web_core from '@a2ui/web_core';

/**
 * The set of default Angular implementations for each component in the basic catalog.
 * Using string literals as keys, to survive property renaming, as these names need to match the JSON payload.
 */
declare const DEFAULT_COMPONENT_IMPLEMENTATIONS: Record<string, AngularComponentImplementation>;
/**
 * Interface for specifying overrides and configuration for the basic catalog.
 */
interface BasicCatalogOptions {
    /**
     * An optional override for the catalog's unique identifier.
     */
    id?: string;
    /**
     * An optional locale to configure catalog-level formatting.
     */
    locale?: string;
    /**
     * Optional overrides for individual components in the catalog.
     */
    components?: Partial<{
        [K in keyof typeof DEFAULT_COMPONENT_IMPLEMENTATIONS]: AngularComponentImplementation;
    }>;
    /**
     * Optional additional components to include in the catalog beyond
     * the standard basic catalog components.
     *
     * @deprecated Use AngularCatalog constructor directly to combine BASIC_COMPONENTS with custom ones.
     */
    extraComponents?: AngularComponentImplementation[];
    /**
     * An optional set of function implementations to use instead of the defaults.
     *
     * @deprecated Use AngularCatalog constructor directly to combine BASIC_FUNCTIONS with custom ones.
     */
    functions?: FunctionImplementation[];
    /**
     * Optional theme schema to override default basic catalog theme schema.
     */
    themeSchema?: z.ZodType<BasicCatalogTheme>;
}
/**
 * The set of Angular UI components provided by the basic catalog.
 */
declare const BASIC_COMPONENTS: AngularComponentImplementation[];

/**
 * A base class for basic catalogs, providing extensibility for non-DI use cases.
 */
declare class BasicCatalogBase extends AngularCatalog {
    constructor(options?: BasicCatalogOptions);
}
declare const BASIC_CATALOG_OPTIONS: InjectionToken<BasicCatalogOptions>;
/**
 * A basic catalog of components and functions for v0.9 verification.
 *
 * This catalog includes a wide range of UI components (Text, Button, Row, etc.)
 * and utility functions (formatString) defined in the A2UI v0.9
 * basic catalog specification.
 */
declare class BasicCatalog extends BasicCatalogBase {
    constructor(options?: BasicCatalogOptions);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BasicCatalog, [{ optional: true; }]>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BasicCatalog>;
}

/**
 * Base class for A2UI basic catalog components in Angular.
 *
 * Automatically injects the basic catalog styles when the component is instantiated.
 * Also binds the primary brand color to the host element.
 */
declare abstract class BasicCatalogComponent<Api extends ComponentApi> extends CatalogComponent<Api> {
    protected rendererService: A2uiRendererService;
    readonly surface: _angular_core.Signal<_a2ui_web_core.SurfaceModel<_a2ui_angular.AngularComponentImplementation, _a2ui_web_core.FunctionImplementation> | undefined>;
    readonly theme: _angular_core.Signal<any>;
    readonly primaryColor: _angular_core.Signal<any>;
    /**
     * Weight is applied as flex css property on the component host HTML element.
     */
    protected readonly weight: _angular_core.Signal<number | null>;
    constructor();
    /**
     * Binds the flex style to the host element based on the weight.
     */
    get flexStyle(): string | null;
    get primaryColorStyle(): string | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BasicCatalogComponent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BasicCatalogComponent<any>, never, never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Text component (v0.9).
 *
 * Renders text with support for simple Markdown.
 *
 * Supported CSS variables:
 * - `--a2ui-text-color-text`: Controls the text color.
 * - `--a2ui-text-margin`: Controls the margin of text elements.
 * - `--a2ui-font-family-title`: Controls the font family for titles.
 * - `--a2ui-line-height-headings`: Controls the line height for headings.
 * - `--a2ui-line-height-body`: Controls the line height for body text.
 * - `--a2ui-text-caption-color`: Controls the color for caption text.
 * - `--a2ui-text-a-color`: Controls the color for links.
 * - `--a2ui-text-a-font-weight`: Controls the font weight for links.
 * - Font sizes: `--a2ui-font-size-2xl`, `--a2ui-font-size-xl`, `--a2ui-font-size-l`, `--a2ui-font-size-m`, `--a2ui-font-size-s`, `--a2ui-font-size-xs`.
 */
declare class TextComponent extends BasicCatalogComponent<typeof TextApi> {
    private markdownRenderer;
    private static readonly NON_MARKDOWN_VARIANTS;
    readonly variant: _angular_core.Signal<"h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body">;
    readonly text: _angular_core.Signal<string>;
    readonly isNonMarkdownVariant: _angular_core.Signal<boolean>;
    resolvedText: _angular_core.WritableSignal<string>;
    private renderRequestId;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextComponent, "a2ui-v09-text", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Row component (v0.9).
 *
 * Arranges child components in a horizontal flex layout. Supports both static
 * lists of children and repeating templates bound to a data collection.
 *
 * Supported CSS variables:
 * - `--a2ui-row-gap`: Controls the gap between items in the row. Defaults to `--a2ui-spacing-m` (16px).
 */
declare class RowComponent extends BasicCatalogComponent<typeof RowApi> {
    protected readonly justify: _angular_core.Signal<string | undefined>;
    protected readonly align: _angular_core.Signal<string | undefined>;
    protected readonly children: _angular_core.Signal<Child[]>;
    protected trackChild(_index: number, child: Child): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RowComponent, "a2ui-v09-row", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Column component (v0.9).
 *
 * Arranges child components in a vertical flex layout. Supports both static
 * lists of children and repeating templates bound to a data collection.
 *
 * Supported CSS variables:
 * - `--a2ui-column-gap`: Controls the gap between items in the column. Defaults to `--a2ui-spacing-m` (16px).
 */
declare class ColumnComponent extends BasicCatalogComponent<typeof ColumnApi> {
    protected readonly justify: _angular_core.Signal<string | undefined>;
    protected readonly align: _angular_core.Signal<string | undefined>;
    protected readonly children: _angular_core.Signal<Child[]>;
    protected trackChild(_index: number, child: Child): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColumnComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColumnComponent, "a2ui-v09-column", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Button component (v0.9).
 *
 * Renders a clickable button with a single child component (usually Text).
 * Dispatches an action when clicked if an `action` property is provided.
 *
 * Supported CSS variables:
 * - `--a2ui-button-padding`: Controls the padding.
 * - `--a2ui-button-border-radius`: Controls the border radius.
 * - `--a2ui-button-border`: Controls the border.
 * - `--a2ui-button-margin`: Controls the margin.
 * - `--a2ui-button-background`: Controls the background color.
 * - `--a2ui-button-box-shadow`: Controls the box shadow.
 * - `--a2ui-button-font-weight`: Controls the font weight.
 */
declare class ButtonComponent extends BasicCatalogComponent<typeof ButtonApi> {
    readonly variant: _angular_core.Signal<"default" | "primary" | "borderless">;
    readonly child: _angular_core.Signal<_a2ui_angular.Child>;
    readonly action: _angular_core.Signal<{
        event: {
            name: string;
            context?: Record<string, _a2ui_web_core_v0_9.DynamicValue> | undefined;
        };
    } | {
        functionCall: _a2ui_web_core_v0_9.FunctionCall;
    }>;
    handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonComponent, "a2ui-v09-button", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI TextField component (v0.9).
 *
 * Renders a text input field with an optional label.
 * Updates the bound data model property on every input change.
 *
 * Supported CSS variables:
 * - `--a2ui-color-input`: Controls the background color of the input.
 * - `--a2ui-color-on-input`: Controls the text color of the input.
 * - `--a2ui-textfield-border`: Controls the border of the input.
 * - `--a2ui-textfield-border-radius`: Controls the border radius of the input.
 * - `--a2ui-textfield-padding`: Controls the padding of the input.
 * - `--a2ui-textfield-color-border-focus`: Controls the border color on focus.
 * - `--a2ui-textfield-color-error`: Controls the border and text color for error states.
 * - `--a2ui-textfield-label-font-size`: Controls the font size of the label.
 * - `--a2ui-textfield-label-font-weight`: Controls the font weight of the label.
 */
declare class TextFieldComponent extends BasicCatalogComponent<typeof TextFieldApi> {
    readonly label: _angular_core.Signal<string>;
    readonly value: _angular_core.Signal<string>;
    readonly variant: _angular_core.Signal<"number" | "shortText" | "longText" | "obscured" | undefined>;
    readonly placeholder: _angular_core.Signal<string | null>;
    readonly inputType: _angular_core.Signal<"text" | "number" | "password">;
    handleInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextFieldComponent, "a2ui-v09-text-field", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Image component (v0.9).
 *
 * Renders an image with configurable fit and shape variants.
 *
 * Supported CSS variables:
 * - `--a2ui-image-border-radius`: Controls the rounded corners.
 * - `--a2ui-image-icon-size`: Size of the icon variant.
 * - `--a2ui-image-avatar-size`: Size of the avatar variant.
 * - `--a2ui-image-small-feature-size`: Max-width of smallFeature variant.
 * - `--a2ui-image-large-feature-size`: Max-height of largeFeature variant.
 * - `--a2ui-image-header-size`: Height of header variant.
 */
declare class ImageComponent extends BasicCatalogComponent<typeof ImageApi> {
    readonly url: _angular_core.Signal<string>;
    readonly description: _angular_core.Signal<string>;
    readonly fit: _angular_core.Signal<"fill" | "none" | "contain" | "cover" | "scale-down">;
    readonly variant: _angular_core.Signal<"default" | "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ImageComponent, "a2ui-v09-image", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Icon component (v0.9).
 *
 * Supports both Material Icons (by name) and custom SVG icons (by path).
 *
 * Supported CSS variables:
 * - `--a2ui-icon-size`: Controls the width, height, and font size of the icon.
 * - `--a2ui-icon-font-family`: Controls the font family for icon fonts.
 * - `--a2ui-icon-color`: Controls the color of the icon.
 * - `--a2ui-icon-font-variation-settings`: Controls font variation settings (e.g. FILL).
 */
declare class IconComponent extends BasicCatalogComponent<typeof IconApi> {
    readonly iconNameRaw: _angular_core.Signal<"event" | "play" | "rewind" | "favoriteOff" | "starOff" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "call" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "error" | "fastForward" | "favorite" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "pause" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "skipNext" | "skipPrevious" | "star" | "starHalf" | "stop" | "upload" | "visibility" | "visibilityOff" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | "warning" | {
        svgPath: string;
    }>;
    readonly isSvgPath: _angular_core.Signal<boolean>;
    readonly svgPath: _angular_core.Signal<string>;
    readonly iconName: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconComponent, "a2ui-v09-icon", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Video component (v0.9).
 *
 * Renders a video player with standard controls.
 *
 * Supported CSS variables:
 * - `--a2ui-video-border-radius`: Controls the border radius of the video element.
 */
declare class VideoComponent extends BasicCatalogComponent<typeof VideoApi> {
    readonly url: _angular_core.Signal<string>;
    readonly posterUrl: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VideoComponent, "a2ui-v09-video", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI AudioPlayer component (v0.9).
 *
 * Renders an audio player with standard controls and an optional description.
 *
 * Supported CSS variables:
 * - `--a2ui-audioplayer-background`: Controls the background of the player. Defaults to `transparent`.
 * - `--a2ui-audioplayer-border-radius`: Controls the border radius. Defaults to `0`.
 * - `--a2ui-audioplayer-padding`: Controls the padding. Defaults to `0`.
 */
declare class AudioPlayerComponent extends BasicCatalogComponent<typeof AudioPlayerApi> {
    readonly description: _angular_core.Signal<string | undefined>;
    readonly url: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AudioPlayerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AudioPlayerComponent, "a2ui-v09-audio-player", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI List component (v0.9).
 *
 * Renders a list of child components with support for ordered, unordered,
 * and unstyled layouts in both vertical and horizontal directions.
 *
 * Supported CSS variables:
 * - `--a2ui-list-gap`: Controls the gap between items.
 * - `--a2ui-list-padding`: Controls the padding (applied to padding-inline-start).
 */
declare class ListComponent extends BasicCatalogComponent<typeof ListApi> {
    readonly listStyle: _angular_core.Signal<any>;
    readonly direction: _angular_core.Signal<"horizontal" | "vertical">;
    readonly align: _angular_core.Signal<string | null>;
    readonly children: _angular_core.Signal<Child[]>;
    readonly listTag: _angular_core.Signal<"ol" | "ul" | "div">;
    readonly styleType: _angular_core.Signal<"" | "none">;
    /**
     * Track-by function to ensure stable change detection for list items.
     * Uses the full resolved path (`basePath/id`) to uniquely identify items.
     */
    readonly trackBy: (index: number, item: Child) => string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ListComponent, "a2ui-v09-list", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Card component (v0.9).
 *
 * Renders a container with a shadow and rounded corners for grouping related content.
 *
 * Supported CSS variables:
 * - `--a2ui-card-padding`: Controls the padding.
 * - `--a2ui-card-border-radius`: Controls the border radius.
 * - `--a2ui-card-box-shadow`: Controls the box shadow.
 * - `--a2ui-card-background`: Controls the background color.
 * - `--a2ui-card-border`: Controls the border.
 * - `--a2ui-card-margin`: Controls the margin.
 */
declare class CardComponent extends BasicCatalogComponent<typeof CardApi> {
    readonly child: _angular_core.Signal<_a2ui_angular.Child>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardComponent, "a2ui-v09-card", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Tabs component (v0.9).
 *
 * Renders a set of tabs where each tab has a label and associated content.
 * Manages the active tab state internally.
 *
 * Supported CSS variables:
 * - `--a2ui-tabs-border`: Controls the border of the tab bar.
 * - `--a2ui-tabs-header-background`: Controls the background of tab buttons.
 * - `--a2ui-tabs-header-color`: Controls the text color of tab buttons.
 * - `--a2ui-tabs-header-background-active`: Controls the background of the active tab button.
 * - `--a2ui-tabs-header-color-active`: Controls the text color of the active tab button.
 * - `--a2ui-tabs-content-padding`: Controls the padding of the tab content.
 */
declare class TabsComponent extends BasicCatalogComponent<typeof TabsApi> {
    activeTabIndex: _angular_core.WritableSignal<number>;
    readonly tabs: _angular_core.Signal<{
        child: string;
        title: string | {
            path: string;
        } | _a2ui_web_core_v0_9.FunctionCall;
    }[]>;
    readonly activeTab: _angular_core.Signal<{
        child: string;
        title: string | {
            path: string;
        } | _a2ui_web_core_v0_9.FunctionCall;
    }>;
    protected readonly normalizedActiveTabChild: _angular_core.Signal<{
        id: string;
        basePath: string;
    } | null>;
    setActiveTab(index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabsComponent, "a2ui-v09-tabs", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Modal component (v0.9).
 *
 * Renders a trigger component that opening an overlay containing a content component.
 *
 * Supported CSS variables:
 * - `--a2ui-modal-background`: Controls the background of the modal content.
 * - `--a2ui-modal-padding`: Controls the padding of the modal content.
 * - `--a2ui-modal-border-radius`: Controls the border radius of the modal content.
 * - `--a2ui-modal-box-shadow`: Controls the box shadow of the modal content.
 * - `--a2ui-modal-backdrop-bg`: Controls the background of the backdrop.
 */
declare class ModalComponent extends BasicCatalogComponent<typeof ModalApi> {
    isOpen: _angular_core.WritableSignal<boolean>;
    readonly trigger: _angular_core.Signal<_a2ui_angular.Child>;
    readonly content: _angular_core.Signal<_a2ui_angular.Child>;
    openModal(): void;
    closeModal(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalComponent, "a2ui-v09-modal", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Divider component (v0.9).
 *
 * Renders a horizontal or vertical line to separate content.
 *
 * Supported CSS variables:
 * - `--a2ui-divider-border`: Controls the border of the divider (horizontal and vertical).
 * - `--a2ui-divider-spacing`: Controls the margin around the divider.
 */
declare class DividerComponent extends BasicCatalogComponent<typeof DividerApi> {
    readonly axis: _angular_core.Signal<"horizontal" | "vertical">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DividerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DividerComponent, "a2ui-v09-divider", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI CheckBox component (v0.9).
 *
 * Renders a checkbox with a label. Updates the bound data model property
 * when the checked state changes.
 *
 * Supported CSS variables:
 * - `--a2ui-checkbox-margin`: Controls the margin.
 * - `--a2ui-checkbox-gap`: Controls the gap between checkbox and label.
 * - `--a2ui-checkbox-label-font-size`: Controls the font size of the label.
 * - `--a2ui-checkbox-label-font-weight`: Controls the font weight of the label.
 * - `--a2ui-checkbox-size`: Controls the width and height of the checkbox.
 * - `--a2ui-checkbox-background`: Controls the background of the checkbox.
 * - `--a2ui-checkbox-border`: Controls the border of the checkbox.
 * - `--a2ui-checkbox-border-radius`: Controls the border radius of the checkbox.
 * - `--a2ui-checkbox-color-error`: Controls the color for error states.
 */
declare class CheckBoxComponent extends BasicCatalogComponent<typeof CheckBoxApi> {
    readonly value: _angular_core.Signal<boolean>;
    readonly label: _angular_core.Signal<string>;
    handleChange(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckBoxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckBoxComponent, "a2ui-v09-check-box", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI ChoicePicker component (v0.9).
 *
 * Renders a set of options as either radio buttons/checkboxes or chips.
 * Supports both single and multiple selection.
 *
 * Supported CSS variables:
 * - `--a2ui-choicepicker-gap`: Controls spacing between options/chips.
 * - `--a2ui-choicepicker-padding`: Controls padding of the container.
 * - `--a2ui-choicepicker-checkbox-size`: Controls size of checkboxes/radios.
 * - `--a2ui-choicepicker-chip-padding`: Controls padding of chips.
 * - `--a2ui-choicepicker-chip-border-radius`: Controls border radius of chips.
 * - `--a2ui-choicepicker-chip-border`: Controls border of chips.
 * - `--a2ui-choicepicker-chip-background`: Controls background of chips.
 * - `--a2ui-choicepicker-chip-background-selected`: Controls background of selected chips.
 */
declare class ChoicePickerComponent extends BasicCatalogComponent<typeof ChoicePickerApi> {
    protected readonly groupName: _angular_core.Signal<string>;
    readonly displayStyle: _angular_core.Signal<"checkbox" | "chips" | undefined>;
    readonly options: _angular_core.Signal<{
        value: string;
        label: string | {
            path: string;
        } | _a2ui_web_core_v0_9.FunctionCall;
    }[]>;
    readonly variant: _angular_core.Signal<"multipleSelection" | "mutuallyExclusive" | undefined>;
    readonly selectedValue: _angular_core.Signal<string[]>;
    isMultiple(): boolean;
    isSelected(value: string): boolean;
    onCheckChange(value: string, event: Event): void;
    toggleActive(value: string): void;
    private updateValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChoicePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChoicePickerComponent, "a2ui-v09-choice-picker", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI Slider component (v0.9).
 *
 * Renders a range input slider with a label and its current value.
 *
 * Supported CSS variables:
 * - `--a2ui-slider-margin`: Controls the margin of the container.
 * - `--a2ui-slider-label-font-size`: Controls the font size of the label.
 * - `--a2ui-slider-label-font-weight`: Controls the font weight of the label.
 * - `--a2ui-slider-thumb-color`: Controls the accent color of the thumb.
 * - `--a2ui-slider-track-color`: Controls the background of the track.
 */
declare class SliderComponent extends BasicCatalogComponent<typeof SliderApi> {
    readonly label: _angular_core.Signal<string | undefined>;
    readonly value: _angular_core.Signal<number>;
    readonly min: _angular_core.Signal<number>;
    readonly max: _angular_core.Signal<number>;
    readonly steps: _angular_core.Signal<number | undefined>;
    readonly stepAttr: _angular_core.Signal<number | null>;
    handleInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SliderComponent, "a2ui-v09-slider", never, {}, {}, never, never, true, never>;
}

/**
 * Angular implementation of the A2UI DateTimeInput component (v0.9).
 *
 * Renders date and/or time input fields. Combines them into an ISO string
 * for the bound data model property.
 *
 * Supported CSS variables:
 * - `--a2ui-datetimeinput-background`: Controls the background of inputs.
 * - `--a2ui-datetimeinput-color`: Controls the text color of inputs.
 * - `--a2ui-datetimeinput-border`: Controls the border of inputs.
 * - `--a2ui-datetimeinput-border-radius`: Controls the border radius of inputs.
 * - `--a2ui-datetimeinput-padding`: Controls the padding of inputs.
 * - `--a2ui-datetimeinput-label-font-size`: Controls the font size of the label.
 * - `--a2ui-datetimeinput-label-font-weight`: Controls the font weight of the label.
 */
declare class DateTimeInputComponent extends BasicCatalogComponent<typeof DateTimeInputApi> {
    readonly label: _angular_core.Signal<string | undefined>;
    readonly enableTime: _angular_core.Signal<boolean>;
    readonly enableDate: _angular_core.Signal<boolean>;
    private readonly rawValue;
    private readonly rawMin;
    private readonly rawMax;
    readonly dateValue: _angular_core.Signal<string>;
    readonly timeValue: _angular_core.Signal<string>;
    readonly minDate: _angular_core.Signal<string>;
    readonly maxDate: _angular_core.Signal<string>;
    readonly minTime: _angular_core.Signal<string>;
    readonly maxTime: _angular_core.Signal<string>;
    handleDateChange(event: Event): void;
    handleTimeChange(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateTimeInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateTimeInputComponent, "a2ui-v09-date-time-input", never, {}, {}, never, never, true, never>;
}

export { AudioPlayerComponent, BASIC_CATALOG_OPTIONS, BASIC_COMPONENTS, BasicCatalog, BasicCatalogBase, ButtonComponent, CardComponent, CheckBoxComponent, ChoicePickerComponent, ColumnComponent, DateTimeInputComponent, DividerComponent, IconComponent, ImageComponent, ListComponent, ModalComponent, RowComponent, SliderComponent, TabsComponent, TextComponent, TextFieldComponent, VideoComponent };
export type { BasicCatalogOptions };
