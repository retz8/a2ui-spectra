import * as _angular_core from '@angular/core';
import { ComponentFixture } from '@angular/core/testing';
import { ComponentTemplate } from '@a2ui/angular/v0_9';

/**
 * Extracts the type of the props input from a component type.
 */
type ComponentToProps<C> = C extends {
    props: () => infer P;
} ? P : never;
/**
 * Sets the props input of a component in a type-safe way, for use in tests.
 */
declare function setComponentProps<T extends {
    props: () => any;
}>(fixture: ComponentFixture<T>, props: ComponentToProps<T>): void;
/**
 * Creates a mock BoundProperty for testing.
 */
declare function createBoundProperty<T>(val: T, template?: ComponentTemplate): {
    value: _angular_core.WritableSignal<T>;
    raw: T;
    template: ComponentTemplate | undefined;
    onUpdate: jasmine.Spy<jasmine.Func>;
};

export { createBoundProperty, setComponentProps };
export type { ComponentToProps };
