import * as i0 from '@angular/core';
import { Signal, Type, Injector, InjectionToken, OnDestroy, EnvironmentProviders, OnInit } from '@angular/core';
import { A2uiMetadata, Extensions, Catalog, ComponentApi, ComponentContext, FunctionImplementation, ActionListener, MessageProcessorOptions, ProcessableMessagePayload, CallOptions, MessageProcessor, SurfaceGroupModel, ComponentNode, SurfaceModel, NodeResolver, MarkdownRendererOptions, MarkdownRenderer as MarkdownRenderer$1 } from '@a2ui/web_core';
import { WebComponentImplementation } from '@a2ui/web_core/universal';
import * as zod from 'zod';
import { z } from 'zod';
import * as _a2ui_angular from '@a2ui/angular';
import { BasicCatalogTheme } from '@a2ui/web_core/catalogs/basic/v1';
export { BASIC_FUNCTIONS } from '@a2ui/web_core/catalogs/basic/v1';

/** Describes the properties that a Catalog component needs to implement. */
interface CatalogComponentInstance {
    readonly props: Signal<Record<string, unknown>>;
    readonly metadata?: Signal<A2uiMetadata | undefined>;
    readonly extensions?: Signal<Extensions | undefined>;
    readonly surfaceId: Signal<string>;
    readonly componentId: Signal<string>;
    readonly dataContextPath: Signal<string>;
}

/**
 * Temporary type used during basic catalog schema alignment to bypass strict type checking.
 *
 * To be removed once all properties implemented in Angular basic catalog components conform
 * to the basic catalog schema.
 * @see https://github.com/a2ui-project/a2ui/issues/1303
 */
type AnyDuringSchemaAlignment = any;
/**
 * Extends the generic {@link ComponentApi} to include Angular-specific component metadata.
 */
interface AngularComponentImplementation extends ComponentApi {
    /**
     * The Angular component class used to render this component.
     *
     * This class must be an Angular {@link Type} (e.g., a standalone component class)
     * that accepts `props`, `surfaceId`, and `dataContextPath` as inputs.
     */
    readonly component: Type<CatalogComponentInstance>;
    /**
     * Called once when a universal Web Component rendering this entry first connects to the DOM,
     * with the element, its context, and the injector of the enclosing `ComponentHostComponent`.
     *
     * Lets hosts decorate elements they do not own (for example, to add analytics attributes)
     * without subclassing them. It runs for every universal element the renderers create, whatever
     * its base class, and only universal elements trigger it, so it applies only when
     * `RendererConfiguration.useUniversalComponents` is enabled. A custom container that is not an
     * `A2uiLitElement` and creates child elements by hand reports each child by calling
     * `dispatchA2uiElementConnected` from `@a2ui/web_core/universal` after inserting it.
     */
    readonly onElementConnected?: (element: HTMLElement, context: ComponentContext, injector: Injector) => void;
}
/**
 * A collection of component and function implementations mapped to
 * A2UI protocol types.
 *
 * Accepts native Angular components (`AngularComponentImplementation`) and
 * universal Web Components (`WebComponentImplementation`). Web Component
 * entries render only when `RendererConfiguration.useUniversalComponents`
 * is enabled.
 *
 * Catalogs are used by the {@link MessageProcessor} to resolve component
 * definitions and by {@link ComponentHostComponent} to instantiate the
 * correct Angular components.
 */
declare class AngularCatalog extends Catalog<AngularComponentImplementation> {
    constructor(id: string, protocolVersion: string, components?: ReadonlyArray<AngularComponentImplementation | WebComponentImplementation>, functions?: FunctionImplementation[], themeSchema?: z.ZodTypeAny, instructions?: string);
    /**
     * Initializes a new v0.9 `AngularCatalog` with the pre-1.0 argument order.
     *
     * @deprecated Pass the protocol version as the second argument instead.
     *   Kept so catalogs written against `@a2ui/angular` 0.9.x keep
     *   constructing without a `protocolVersion`.
     */
    constructor(id: string, components?: ReadonlyArray<AngularComponentImplementation | WebComponentImplementation>, functions?: FunctionImplementation[], themeSchema?: z.ZodTypeAny, instructions?: string);
}
/**
 * Creates a catalog entry for an Angular component that can be rendered both natively and as a
 * universal Web Component.
 *
 * The entry also carries a Custom Element (`tagName`, `element`): the one of `componentApi` when
 * it is a `WebComponentImplementation` (for example a `@a2ui/web_core` basic catalog component),
 * otherwise `component` wrapped with {@link toWebComponent}. Universal container components can
 * therefore render the entry by tag, and the renderer mounts the element instead of `component`
 * when `RendererConfiguration.useUniversalComponents` is enabled.
 *
 * @param componentApi The ComponentApi or WebComponentImplementation defining the schema and name.
 * @param component The Angular Component class.
 * @returns The entry, usable both natively and as a Web Component.
 */
declare function createComponentImplementation(componentApi: ComponentApi | WebComponentImplementation, component: Type<CatalogComponentInstance>): AngularComponentImplementation;

/**
 * Configuration for the A2UI renderer.
 */
interface RendererConfiguration {
    /** The catalogs containing the available components and functions. */
    catalogs: AngularCatalog[];
    /**
     * When true, catalog entries that are both an Angular component and a Web Component (see
     * `createComponentImplementation`) render as W3C universal Web Components application-wide.
     * When false (default), they render as native Angular components.
     *
     * This only affects components rendered directly by the Angular renderer. Children of a
     * universal container component are always rendered as Web Components, because the container
     * resolves them by tag name.
     */
    useUniversalComponents?: boolean;
    /**
     * Optional handler for actions dispatched from any surface.
     *
     * When `processorOptions.unifiedOutbound` is true, `MessageProcessor` routes
     * surface actions and processing errors as wire envelopes to
     * `processorOptions.outboundListener`. `actionHandler` is still invoked for
     * every action, so use it for local side effects only to avoid sending
     * actions to the agent twice.
     */
    actionHandler?: ActionListener;
    /**
     * Optional configuration options for the underlying MessageProcessor,
     * including `outboundListener` and `unifiedOutbound`.
     */
    processorOptions?: MessageProcessorOptions;
}
/**
 * Injection token for the A2UI renderer configuration.
 */
declare const A2UI_RENDERER_CONFIG: InjectionToken<RendererConfiguration>;
/**
 * Provides the A2UI renderer configuration.
 *
 * @param configOrFactory The configuration or a factory function that returns the configuration.
 * @returns The providers for the A2UI renderer.
 */
declare function provideA2Ui(configOrFactory: RendererConfiguration | (() => RendererConfiguration)): EnvironmentProviders;
/**
 * Manages A2UI rendering sessions by bridging the MessageProcessor to Angular.
 *
 * This service is the central entry point for the A2UI renderer. It maintains a
 * {@link MessageProcessor} that turns A2UI protocol messages into a reactive
 * {@link SurfaceGroupModel}.
 */
declare class A2uiRendererService implements OnDestroy {
    private _messageProcessor;
    private _catalogs;
    private readonly _injector;
    private readonly _config;
    private readonly _useUniversalComponents;
    constructor();
    /**
     * Processes a list or envelope of A2UI messages and updates the internal surface models.
     *
     * This should be called whenever new messages arrive from an agent or orchestrator.
     *
     * @param messages The messages or envelope to process.
     */
    processMessages(messages: unknown[] | ProcessableMessagePayload | Record<string, unknown> | any): void;
    /**
     * Asynchronously processes a list or envelope of A2UI messages and awaits any pending
     * function calls.
     *
     * @param messages The messages or envelope to process.
     */
    processMessagesAsync(messages: unknown[] | ProcessableMessagePayload | Record<string, unknown> | any): Promise<void>;
    /**
     * Calls an agent function on a specific surface and returns a promise for the result.
     *
     * @param surfaceId The target surface ID.
     * @param call The function name or call descriptor.
     * @param argsOrOptions Function arguments or call options.
     * @param options Call options if arguments were provided.
     */
    callAgentFunction<TRes = unknown>(surfaceId: string, call: string | {
        call: string;
        args?: Record<string, unknown>;
        catalogId?: string;
    }, argsOrOptions?: Record<string, unknown> | CallOptions, options?: CallOptions): Promise<TRes>;
    /**
     * The underlying MessageProcessor instance.
     */
    get processor(): MessageProcessor<AngularComponentImplementation>;
    /**
     * The current surface group model containing all active surfaces.
     *
     * Surfaces can be retrieved from this group using their `surfaceId`.
     */
    get surfaceGroup(): SurfaceGroupModel<AngularComponentImplementation>;
    /**
     * Whether universal web components rendering is enabled application-wide.
     */
    get useUniversalComponents(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<A2uiRendererService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<A2uiRendererService>;
}

/** Data structure that represents a template used to render a collection of children. */
interface ComponentTemplate {
    id?: string;
    path?: string;
}
/**
 * Represents a component property bound to an Angular Signal and update logic.
 *
 * This interface is used by {@link ComponentBinder} to expose properties to
 * Angular components. It contains the current value as a Signal, the raw
 * property definition, and an update function.
 *
 * @template T The type of the property value.
 */
interface BoundProperty<T = unknown> {
    /**
     * The reactive Angular Signal containing the current resolved value.
     *
     * This signal automatically updates whenever the underlying A2UI data
     * model changes.
     */
    readonly value: Signal<T>;
    /**
     * The raw value from the A2UI ComponentModel.
     *
     * This may be a literal value or a data binding path object.
     */
    readonly raw: unknown;
    /** This field is present for "children" props that define their children using a template. */
    readonly template?: ComponentTemplate;
    /**
     * Callback to update the value in the A2UI DataContext.
     *
     * If the property is bound to a path in the data model, calling this
     * will update that path. If the property is a literal value, this
     * is typically a no-op.
     */
    readonly onUpdate: (newValue: T) => void;
}
type DataBindingType = {
    path: string;
} | {
    '@path': string;
};
type FunctionCallType = {
    call: string;
} | {
    '@call': string;
};
type DynamicSchemaValueToRaw<Input> = Exclude<Input, DataBindingType | FunctionCallType>;
type InferredInterfaceToProps<InferredSchema> = {
    [K in keyof InferredSchema]: K extends 'children' ? BoundProperty<Child[]> : K extends 'child' | 'trigger' | 'content' ? BoundProperty<Child> : BoundProperty<DynamicSchemaValueToRaw<InferredSchema[K]>>;
};
/** Structured validation result emitted by check rules. */
interface CheckValidationResult {
    valid: boolean;
    message: string;
    code?: string;
    severity: 'error' | 'warning' | 'info';
}
interface CheckProps {
    isValid: boolean;
    validationErrors: string[];
    validationResults?: CheckValidationResult[];
}
/**
 * The binder can add some properties to the Props object. This util adds them to the type.
 *
 * A component with check rules, `checks` below v1.0 or `@checks` from v1.0, gets the
 * validation props.
 */
type ExtendedProps<ComponentProps extends {
    [key: string]: unknown;
}> = 'checks' extends keyof ComponentProps ? ComponentProps & CheckProps : '@checks' extends keyof ComponentProps ? ComponentProps & CheckProps : ComponentProps;
/**
 * Utility to convert a component Api Type to the props Type, where the
 * values are wrapped in BoundProperty. This is used to correctly type the props()
 * in a UI component
 *
 * @example
 * export const TextComponentApi = {
 *   name: 'Text',
 *   schema: z.object({
 *     text: z.string(),
 *   })
 *   .strict(),
 * } satisfies ComponentApi;
 * export type TextComponentProps = ComponentApiToProps<typeof TextComponentApi>; // outputs { text: BoundProperty<string>; }
 */
type ComponentApiToProps<Api extends ComponentApi> = InferredInterfaceToProps<ExtendedProps<z.infer<Api['schema']>>>;

/** Represents a reference to a child component. */
interface Child {
    id: string;
    basePath: string;
    /**
     * The resolved node for this child when the parent was bound from a
     * `ComponentNode`. Hosts render it directly instead of searching the tree.
     */
    node?: ComponentNode;
}
/**
 * Binds the resolved properties of a `ComponentNode` to reactive Angular Signals.
 *
 * `NodeResolver` already resolves every property of a node: dynamic values arrive
 * as `ResolvedBinding` instances (writable ones carry their setter), actions as
 * ready-to-call closures, child properties as live `ComponentNode` references, and
 * `checks` as `isValid`, `validationErrors`, and `validationResults`. This service
 * is a thin adapter that exposes each entry of `node.props` as a {@link BoundProperty}
 * for {@link ComponentHostComponent} and {@link AngularWcHost}.
 */
declare class ComponentBinder {
    private readonly boundCleanups;
    constructor();
    /**
     * Binds all properties of a resolved `ComponentNode` to an object of Angular Signals.
     *
     * Reads only from `node.props`; no additional `DataContext` subscriptions are created.
     *
     * @param node The resolved ComponentNode.
     * @returns A map of property names to reactive `BoundProperty` wrappers.
     */
    bindNode(node: ComponentNode): Record<string, BoundProperty>;
    private bindNodeProperty;
    private extractNodeTemplate;
    private unwrapNodePropValue;
    /**
     * Unsubscribes any reactive signal subscriptions created by {@link bind}.
     *
     * Property maps returned by {@link bindNode} hold no subscriptions of their own, so
     * calling this with one of them is a no-op.
     *
     * @param bound The bound property map returned by {@link bind} or {@link bindNode}.
     */
    unbind(bound: Record<string, BoundProperty> | undefined): void;
    /**
     * Binds all properties of a component to an object of Angular Signals from its
     * `ComponentContext`, resolving data bindings through the `DataContext` directly.
     *
     * @deprecated Use {@link bindNode}. Hosts bind from the resolved `ComponentNode` via
     *   `bindNode(node)`. This path remains for elements that are given a `ComponentContext`
     *   without a node and will be removed in a future release.
     * @param context The ComponentContext containing the model and data context.
     * @returns An object where each key corresponds to a component prop and its value is an Angular Signal.
     */
    bind(context: ComponentContext): Record<string, BoundProperty>;
    private bindProperty;
    private createChildListSignal;
    private transformStructuralSignal;
    private normalizeChildItem;
    private bindChecks;
    private evaluateCheckRule;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentBinder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentBinder>;
}

/** The key of the component to render: an ID string or a {@link Child} reference. */
type ComponentKey = string | Child;
/**
 * Dynamically renders an A2UI component as defined in the current surface model.
 *
 * This component acts as a bridge between the A2UI surface model and UI components.
 * It can render both native Angular `@Component` implementations (via `NgComponentOutlet`)
 * and universal W3C Web Components (by instantiating and appending the custom element tag).
 *
 * The component to render is the resolved `ComponentNode` for `componentKey`: a
 * {@link Child} reference produced by a parent's bound props carries its node
 * directly, while a bare id (or a child reference without a node) is resolved from
 * the surface's `NodeResolver` root tree and tracked until it appears.
 *
 * Usually, you'll use the higher-level {@link SurfaceComponent} which automatically
 * sets up a host for the 'root' component.
 */
declare class ComponentHostComponent {
    /** The key of the component to render, either an ID string or a child reference. Defaults to 'root'. */
    componentKey: i0.InputSignal<ComponentKey>;
    /** The unique identifier of the surface this component belongs to. */
    surfaceId: i0.InputSignal<string>;
    private readonly elementRef;
    private readonly rendererService;
    private readonly binder;
    private readonly destroyRef;
    private readonly ngZone;
    private readonly cdr;
    private readonly injector;
    private readonly sharedResolver;
    private readonly accessibilityTargets;
    private ownResolver?;
    protected readonly componentType: i0.WritableSignal<Type<CatalogComponentInstance> | null>;
    protected readonly props: i0.WritableSignal<Record<string, BoundProperty<unknown>>>;
    protected readonly metadata: i0.WritableSignal<A2uiMetadata | undefined>;
    protected readonly acceptsMetadata: i0.Signal<boolean>;
    protected readonly componentInputs: i0.Signal<Record<string, unknown>>;
    /** Bumped when a surface that was missing is created, so the setup effect re-runs. */
    private readonly surfaceRetry;
    private currentBoundProps?;
    private resolvedNode?;
    private activeSurface?;
    private mountedWcEl;
    protected resolvedComponentId: string;
    protected resolvedDataContextPath: string;
    private stopProps?;
    private stopMetadata?;
    private surfaceSub?;
    private stopAccessibility?;
    constructor();
    /**
     * Hands a universal element that connected below this host to its catalog entry's
     * `onElementConnected` callback. The nearest host marks the event as handled, so ancestor
     * hosts skip it while other listeners above can still observe it.
     */
    private readonly onElementConnected;
    private waitForSurface;
    private resolverFor;
    /**
     * Resolves the node to render. A child reference that already carries its node is
     * used as is; otherwise the node is looked up from the surface root (tracked).
     */
    private resolveNode;
    private mount;
    private reportUnresolved;
    private setupAngularComponent;
    /** Re-binds the props of the mounted Angular component and schedules change detection. */
    private updateProps;
    private hasSameBoundKeys;
    private setupWebComponent;
    /**
     * Resets the component host state, unsubscribing from active subscriptions
     * and clearing component properties to avoid rendering stale data while
     * a new component is being loaded.
     */
    private resetState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentHostComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComponentHostComponent, "a2ui-v09-component-host", never, { "componentKey": { "alias": "componentKey"; "required": false; "isSignal": true; }; "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * The directives an Angular catalog component uses to mark elements for its
 * host's accessibility attributes (see `bindHostAccessibility` in
 * `@a2ui/web_core/universal`). Each host element, `ComponentHostComponent`
 * or `AngularWcHost`, provides its own `A2UI_ACCESSIBILITY_TARGETS`, so a
 * directive marks an element for the nearest host above it.
 */

/**
 * Marks the element that carries the component's `accessibility.label`,
 * `accessibility.description` and validation state, such as its input
 * (`<input a2uiAccessibilityTarget>`). It gets `aria-invalid` while a check
 * fails. Without it, the component's host element is labelled as a
 * `role="group"` and no element gets the validation state.
 */
declare class AccessibilityTargetDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AccessibilityTargetDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AccessibilityTargetDirective, "[a2uiAccessibilityTarget]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks the element that shows the component's validation errors. While there
 * are errors, the `a2uiAccessibilityTarget` element gets `aria-describedby`
 * pointing at it, and it gets an `id` if it has none.
 */
declare class ValidationErrorsDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationErrorsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidationErrorsDirective, "[a2uiValidationErrors]", never, {}, {}, never, never, true, never>;
}

/**
 * High-level component for rendering an entire A2UI surface.
 *
 * This component handles the boilerplate of setting up a {@link ComponentHostComponent}
 * for the 'root' component of a surface and owns the surface's `NodeResolver` (via
 * {@link SurfaceNodeResolver}) so all hosts beneath it share one resolved node tree.
 * It is the recommended way to embed an A2UI surface in an Angular application.
 */
declare class SurfaceComponent {
    /** The unique identifier of the surface to render. */
    surfaceId: i0.InputSignal<string>;
    /**
     * The path within the surface's data model that represents the current state.
     * Defaults to the root ('/').
     */
    dataContextPath: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SurfaceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SurfaceComponent, "a2ui-v09-surface", never, { "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "dataContextPath": { "alias": "dataContextPath"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Owns the `NodeResolver` for one rendered surface.
 *
 * {@link SurfaceComponent} provides an instance per surface so every
 * {@link ComponentHostComponent} underneath it shares one resolved node tree
 * for the lifetime of the surface view. A host rendered outside a surface
 * component creates its own instance and disposes it when destroyed.
 */
declare class SurfaceNodeResolver implements OnDestroy {
    private resolver?;
    private surface?;
    /**
     * Returns the resolver for `surface`, creating it on first use and replacing
     * (and disposing) the previous one when the surface changes.
     *
     * @param surface The surface model to resolve.
     */
    resolverFor(surface: SurfaceModel<AngularComponentImplementation>): NodeResolver<AngularComponentImplementation>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SurfaceNodeResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SurfaceNodeResolver>;
}

/**
 * Base class for A2UI catalog component in Angular.
 *
 * All Angular catalog components should extend this base class,
 * which provides type safe access to props() and other common
 * fields.
 */
declare abstract class CatalogComponent<Api extends ComponentApi> implements CatalogComponentInstance {
    /**
     * Reactive properties resolved from the A2UI ComponentModel.
     */
    readonly props: i0.InputSignal<_a2ui_angular.ExtendedProps<zod.TypeOf<Api["schema"]>> extends infer T ? { [K in keyof T]: K extends "children" ? _a2ui_angular.BoundProperty<_a2ui_angular.Child[]> : K extends "child" | "trigger" | "content" ? _a2ui_angular.BoundProperty<_a2ui_angular.Child> : _a2ui_angular.BoundProperty<Exclude<T[K], ({
        path: string;
    } | {
        '@path': string;
    }) | ({
        call: string;
    } | {
        '@call': string;
    })>>; } : never>;
    readonly metadata: i0.InputSignal<A2uiMetadata | undefined>;
    readonly extensions: i0.Signal<Readonly<Record<string, unknown>> | undefined>;
    readonly surfaceId: i0.InputSignal<string>;
    readonly componentId: i0.InputSignal<string>;
    readonly dataContextPath: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CatalogComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CatalogComponent<any>, never, never, { "props": { "alias": "props"; "required": false; "isSignal": true; }; "metadata": { "alias": "metadata"; "required": false; "isSignal": true; }; "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "componentId": { "alias": "componentId"; "required": true; "isSignal": true; }; "dataContextPath": { "alias": "dataContextPath"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Normalizes a data model path by combining a relative path with a base context.
 *
 * This is used to create unique absolute paths for components within a repeating
 * collection or nested structure.
 *
 * @param path The relative or absolute path from the component properties.
 * @param dataContextPath The current base data context path.
 * @param index The index of the child component.
 * @returns A fully normalized absolute path for the indexed child.
 */
declare function getNormalizedPath(path: string | undefined, dataContextPath: string, index: number): string;

declare abstract class MarkdownRenderer {
    abstract render(markdown: string, options?: MarkdownRendererOptions): Promise<string>;
}
declare class DefaultMarkdownRenderer extends MarkdownRenderer {
    private static warningLogged;
    render(markdown: string, options?: MarkdownRendererOptions): Promise<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultMarkdownRenderer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultMarkdownRenderer>;
}
declare function provideMarkdownRenderer(renderFn?: MarkdownRenderer$1): {
    provide: typeof MarkdownRenderer;
    useValue: {
        render: MarkdownRenderer$1;
    };
    useClass?: undefined;
} | {
    provide: typeof MarkdownRenderer;
    useClass: typeof DefaultMarkdownRenderer;
    useValue?: undefined;
};

/**
 * Wraps an Angular `@Component` class declaration (`AngularComponentImplementation`) into a
 * W3C Custom Element (`WebComponentImplementation`).
 *
 * The returned implementation carries a generated `a2ui-ng-<name>` tag and an element class that
 * mounts the Angular component when connected. The element is not defined in the
 * `customElements` registry here; renderers define it on demand with `registerUniversalElement`
 * right before rendering it, like any other `WebComponentImplementation`.
 *
 * Calling this twice with the same component class returns the same implementation.
 *
 * @param componentImpl The AngularComponentImplementation combining the ComponentApi schema and component class.
 * @returns The WebComponentImplementation representation.
 */
declare function toWebComponent(componentImpl: AngularComponentImplementation): WebComponentImplementation;

/**
 * Placeholder Angular component for catalog entries that only provide a Web Component.
 *
 * `AngularCatalog` assigns it so every entry has a `component`. It is only instantiated when
 * `RendererConfiguration.useUniversalComponents` is off, in which case Web Components are not
 * rendered, so it renders nothing and reports the misconfiguration.
 */
declare class UniversalOnlyComponent implements CatalogComponentInstance, OnInit {
    readonly props: i0.InputSignal<Record<string, unknown>>;
    readonly surfaceId: i0.InputSignal<string>;
    readonly componentId: i0.InputSignal<string>;
    readonly dataContextPath: i0.InputSignal<string>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UniversalOnlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UniversalOnlyComponent, "a2ui-v09-universal-only", never, { "props": { "alias": "props"; "required": false; "isSignal": true; }; "surfaceId": { "alias": "surfaceId"; "required": true; "isSignal": true; }; "componentId": { "alias": "componentId"; "required": true; "isSignal": true; }; "dataContextPath": { "alias": "dataContextPath"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * The set of default Angular universal implementations for each component in the v1.0 basic catalog.
 * Using string literals as keys, to survive property renaming, as these names need to match the JSON payload.
 */
declare const DEFAULT_COMPONENT_IMPLEMENTATIONS: Record<string, AngularComponentImplementation>;
/**
 * Interface for specifying overrides and configuration for the v1.0 basic catalog.
 */
interface BasicCatalogOptions {
    /**
     * An optional override for the catalog's unique identifier.
     */
    id?: string;
    /**
     * An optional locale to configure catalog-level formatting.
     */
    locale?: string;
    /**
     * Optional overrides for individual components in the catalog.
     */
    components?: Partial<{
        [K in keyof typeof DEFAULT_COMPONENT_IMPLEMENTATIONS]: AngularComponentImplementation;
    }>;
    /**
     * Optional additional components to include in the catalog beyond
     * the standard basic catalog components.
     */
    extraComponents?: AngularComponentImplementation[];
    /**
     * An optional set of function implementations to use instead of the defaults.
     */
    functions?: FunctionImplementation[];
    /**
     * Optional theme schema to override default basic catalog theme schema.
     */
    themeSchema?: z.ZodType<BasicCatalogTheme>;
}
/**
 * The set of UI components provided by the v1.0 basic catalog.
 */
declare const BASIC_COMPONENTS: AngularComponentImplementation[];

/**
 * A base class for v1.0 basic catalogs, providing extensibility for non-DI use cases.
 */
declare class BasicCatalogBase extends AngularCatalog {
    constructor(options?: BasicCatalogOptions);
}
declare const BASIC_CATALOG_OPTIONS: InjectionToken<BasicCatalogOptions>;
/**
 * The v1.0 basic catalog of components and functions for Angular.
 */
declare class BasicCatalog extends BasicCatalogBase {
    constructor(options?: BasicCatalogOptions);
    static ɵfac: i0.ɵɵFactoryDeclaration<BasicCatalog, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BasicCatalog>;
}
/**
 * Provides the A2UI v1.0 renderer configuration, defaulting `useUniversalComponents` to `true`.
 *
 * @param configOrFactory The configuration or a factory function that returns the configuration.
 * @returns The providers for the A2UI renderer.
 */
declare function provideA2UI(configOrFactory: RendererConfiguration | (() => RendererConfiguration)): EnvironmentProviders;

export { A2UI_RENDERER_CONFIG, A2uiRendererService, AccessibilityTargetDirective, AngularCatalog, BASIC_CATALOG_OPTIONS, BASIC_COMPONENTS, BasicCatalog, BasicCatalogBase, CatalogComponent, ComponentBinder, ComponentHostComponent, DefaultMarkdownRenderer, MarkdownRenderer, SurfaceComponent, SurfaceNodeResolver, UniversalOnlyComponent, ValidationErrorsDirective, createComponentImplementation, getNormalizedPath, provideA2UI, provideA2Ui, provideMarkdownRenderer, toWebComponent };
export type { AngularComponentImplementation, AnyDuringSchemaAlignment, BasicCatalogOptions, BoundProperty, CatalogComponentInstance, Child, ComponentApiToProps, ComponentKey, ComponentTemplate, ExtendedProps, RendererConfiguration };
