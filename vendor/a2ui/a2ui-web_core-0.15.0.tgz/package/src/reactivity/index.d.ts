/**
 * Lightweight reactive signal primitives for state observation.
 */
export { setSignalImplementation, signal, computed, effect, batchWrite, isSignal, getValue, setValue, peekValue, type Signal, type SignalImplementations, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, } from './signals.js';
//# sourceMappingURL=index.d.ts.map