export {};
//# sourceMappingURL=node-resolver.test.d.ts.map