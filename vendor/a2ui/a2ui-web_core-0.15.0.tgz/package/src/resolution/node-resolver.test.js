/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Conformance suite for the node layer, ported from the Python reference
 * (`python/a2ui_core/tests/test_node_graph.py`) plus tests for the
 * defects the reference is known to have: eager action resolution, shared-node
 * use-after-dispose, and whole-list template respawn.
 */
import assert from 'node:assert';
import { describe, it } from 'node:test';
import { z } from 'zod';
import { Catalog, createFunctionImplementation, } from '../catalog/types.js';
import { CommonSchemas } from '../types/common-types.js';
import { ComponentModel } from '../state/component-model.js';
import { SurfaceModel } from '../state/surface-model.js';
import { ActionSchema, ChildListSchema, ComponentIdSchema, DynamicStringSchema, } from '../v0_9/schema/common-types.js';
import { effect, getValue, peekValue, setValue } from '../reactivity/signals.js';
import { PLACEHOLDER_TYPE, isComponentNode } from './component-node.js';
import { NodeResolver } from './node-resolver.js';
import { ResolvedBinding, WritableBinding, isWritable } from './resolved-binding.js';
import * as v0_9 from '../v0_9/index.js';
import { MAX_DYNAMIC_CHILD_LIST_SIZE } from './generic-binder.js';
const TextApi = {
    name: 'Text',
    schema: z.object({ text: DynamicStringSchema.optional() }),
};
const ButtonApi = {
    name: 'Button',
    schema: z.object({ label: DynamicStringSchema.optional(), action: ActionSchema.optional() }),
};
const CardApi = {
    name: 'Card',
    schema: z.object({ child: ComponentIdSchema.optional() }),
};
const ColumnApi = {
    name: 'Column',
    schema: z.object({ children: ChildListSchema.optional() }),
};
const TabsApi = {
    name: 'Tabs',
    schema: z.object({
        items: z.array(z.object({ title: z.string(), child: ComponentIdSchema })).optional(),
    }),
};
const ShoutApi = {
    name: 'shout',
    returnType: 'string',
    schema: z.object({ value: z.coerce.string() }),
};
function makeCatalog() {
    return new Catalog('node-test-catalog', '0.9', [TextApi, ButtonApi, CardApi, ColumnApi, TabsApi], [createFunctionImplementation(ShoutApi, args => String(args.value).toUpperCase())]);
}
function setup() {
    const catalog = makeCatalog();
    const surface = new SurfaceModel('surf-1', catalog);
    const resolver = new NodeResolver(surface, catalog);
    return { catalog, surface, resolver };
}
function add(surface, id, type, props) {
    const catalog = surface.defaultCatalog;
    assert.ok(catalog, 'add() needs a surface with a default catalog');
    surface.componentsModel.addComponent(new ComponentModel(id, type, props, catalog));
}
function props(node) {
    return peekValue(node.props);
}
/** Unwraps a dynamic prop's `ResolvedBinding` snapshot, asserting it is one. */
function bound(node, key) {
    const binding = props(node)[key];
    assert.ok(binding instanceof ResolvedBinding, `expected ${key} to resolve to a ResolvedBinding`);
    return binding.value;
}
function child(node, key, index) {
    const value = index === undefined ? props(node)[key] : props(node)[key][index];
    assert.ok(isComponentNode(value), `expected ${key}[${index ?? ''}] to be a ComponentNode`);
    return value;
}
/** Counts emissions of a signal, excluding the subscription-time run. */
function countEmissions(sig) {
    let n = -1;
    const dispose = effect(() => {
        getValue(sig);
        n++;
    });
    return {
        get count() {
            return n;
        },
        dispose,
    };
}
const flush = () => new Promise(resolve => setTimeout(resolve, 0));
describe('NodeResolver conformance (port of test_node_graph.py)', () => {
    it('resolves the root and upgrades and downgrades referenced children (lifecycle)', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['child_1'] });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.type, 'Column');
        assert.strictEqual(child(root, 'children', 0).type, PLACEHOLDER_TYPE);
        add(surface, 'child_1', 'Text', { text: 'Hello Node' });
        const upgraded = child(root, 'children', 0);
        assert.strictEqual(upgraded.type, 'Text');
        assert.strictEqual(bound(upgraded, 'text'), 'Hello Node');
        surface.componentsModel.removeComponent('child_1');
        assert.strictEqual(child(root, 'children', 0).type, PLACEHOLDER_TYPE);
        assert.strictEqual(upgraded.disposed, true);
        resolver.dispose();
        surface.dispose();
    });
    it('exposes core node properties', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Card', { child: 'text-1' });
        add(surface, 'text-1', 'Text', { text: 'Hi' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.instanceId, 'root');
        assert.strictEqual(root.dataPath, '/');
        const textNode = child(root, 'child');
        assert.strictEqual(textNode.instanceId, 'text-1');
        assert.strictEqual(textNode.componentId, 'text-1');
        assert.strictEqual(textNode.type, 'Text');
        assert.strictEqual(textNode.dataPath, '/');
        resolver.dispose();
    });
    it('binds each resolved node with a context for its component and data path', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/items', [{ name: 'A' }]);
        add(surface, 'root', 'Column', { children: { componentId: 'item_tpl', path: '/items' } });
        add(surface, 'item_tpl', 'Text', { text: { path: 'name' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root?.context);
        assert.strictEqual(root.context.componentModel.id, 'root');
        assert.strictEqual(root.context.dataContext.path, '/');
        const item = child(root, 'children', 0);
        assert.ok(item.context);
        assert.strictEqual(item.context.componentModel.id, 'item_tpl');
        assert.strictEqual(item.context.dataContext.path, '/items/0');
        assert.strictEqual(item.context.dataContext.parent, root.context.dataContext);
        resolver.dispose();
    });
    it('gives a placeholder no context and its resolved replacement one', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Card', { child: 'late' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(child(root, 'child').context, undefined);
        add(surface, 'late', 'Text', { text: 'Hi' });
        const late = child(root, 'child');
        assert.strictEqual(late.isPlaceholder, false);
        assert.strictEqual(late.context?.componentModel.id, 'late');
        resolver.dispose();
    });
    it('resolves data-bound properties reactively', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/username', 'Alice');
        add(surface, 'root', 'Text', { text: { path: '/username' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(bound(root, 'text'), 'Alice');
        surface.dataModel.set('/username', 'Bob');
        assert.strictEqual(bound(root, 'text'), 'Bob');
        resolver.dispose();
    });
    it('resolves a single child reference to a live node', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Card', { child: 'text-1' });
        add(surface, 'text-1', 'Text', { text: 'Hello' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const textNode = child(root, 'child');
        assert.strictEqual(textNode.type, 'Text');
        assert.strictEqual(bound(textNode, 'text'), 'Hello');
        resolver.dispose();
    });
    it('gives every node a document-unique id that lives as long as the node', () => {
        const first = setup();
        const second = setup();
        for (const { surface } of [first, second]) {
            add(surface, 'root', 'Column', { children: ['a', 'a'] });
            add(surface, 'a', 'Text', { text: 'dup' });
        }
        const nodes = [first, second].flatMap(({ resolver }) => {
            const root = getValue(resolver.rootNode);
            assert.ok(root);
            return [root, ...props(root).children];
        });
        assert.strictEqual(nodes.length, 6);
        assert.strictEqual(new Set(nodes.map(n => n.id)).size, 6);
        for (const node of nodes) {
            assert.match(node.id, /^a2ui-n\d+$/);
        }
        // A property update keeps the node, so the id stays.
        const root = nodes[0];
        const before = child(root, 'children', 0);
        const model = first.surface.componentsModel.get('a');
        assert.ok(model);
        model.properties = { text: 'changed' };
        assert.strictEqual(child(root, 'children', 0), before);
        assert.strictEqual(child(root, 'children', 0).id, before.id);
        // A type change replaces the node, and the replacement has a new id.
        first.surface.componentsModel.removeComponent('a');
        add(first.surface, 'a', 'Button', { label: 'now a button' });
        const after = child(root, 'children', 0);
        assert.notStrictEqual(after, before);
        assert.notStrictEqual(after.id, before.id);
        // The serialized form keeps naming the component, not the node.
        assert.strictEqual(root.toJSON().id, 'root');
        first.resolver.dispose();
        second.resolver.dispose();
    });
    it('resolves an explicit children list in order', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['c1', 'c2'] });
        add(surface, 'c1', 'Text', { text: 'C1' });
        add(surface, 'c2', 'Text', { text: 'C2' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, 2);
        assert.strictEqual(bound(children[0], 'text'), 'C1');
        assert.strictEqual(bound(children[1], 'text'), 'C2');
        resolver.dispose();
    });
    it('gives repeated references to one component distinct sibling nodes and instance ids', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['a', 'a'] });
        add(surface, 'a', 'Text', { text: 'dup' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, 2);
        assert.notStrictEqual(children[0], children[1]);
        assert.strictEqual(children[0].instanceId, 'a');
        assert.strictEqual(children[1].instanceId, 'a#2');
        assert.strictEqual(bound(children[1], 'text'), 'dup');
        // Instance ids stay distinct when a list edit shifts the ordinals.
        add(surface, 'x', 'Text', { text: 'x' });
        const rootModel = surface.componentsModel.get('root');
        assert.ok(rootModel);
        rootModel.properties = { children: ['x', 'a', 'a'] };
        const after = props(root).children;
        assert.deepStrictEqual(after.map(n => n.instanceId), ['x', 'a', 'a#2']);
        resolver.dispose();
    });
    it('resolves a plain array of component ids as a child list', () => {
        // The intuitive third-party spelling: z.array(ComponentIdSchema) instead
        // of the ChildList union. The marker sits on the elements.
        const PlainListApi = {
            name: 'PlainList',
            schema: z.object({ children: z.array(ComponentIdSchema).optional() }),
        };
        const catalog = new Catalog('plain-list-catalog', '0.9', [TextApi, PlainListApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'PlainList', { children: ['a', 'b'] });
        add(surface, 'a', 'Text', { text: 'A' });
        add(surface, 'b', 'Text', { text: 'B' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, 2);
        assert.ok(isComponentNode(children[0]));
        assert.ok(isComponentNode(children[1]));
        assert.strictEqual(bound(children[0], 'text'), 'A');
        assert.strictEqual(bound(children[1], 'text'), 'B');
        resolver.dispose();
    });
    it('keeps instance ids distinct when a component id mimics a suffixed or scoped form', () => {
        const PaneApi = {
            name: 'Pane',
            schema: z.object({
                main: ComponentIdSchema.optional(),
                items: ChildListSchema.optional(),
            }),
        };
        const catalog = new Catalog('mimic-catalog', '0.9', [
            TextApi,
            ColumnApi,
            PaneApi,
        ]);
        // A sibling literally named 'a#2' next to duplicates of 'a'.
        {
            const surface = new SurfaceModel('surf-a', catalog);
            const resolver = new NodeResolver(surface, catalog);
            add(surface, 'root', 'Column', { children: ['a', 'a', 'a#2'] });
            add(surface, 'a', 'Text', { text: 'x' });
            add(surface, 'a#2', 'Text', { text: 'y' });
            const root = getValue(resolver.rootNode);
            assert.ok(root);
            const ids = props(root).children.map(n => n.instanceId);
            assert.strictEqual(new Set(ids).size, ids.length, `collision in ${ids.join(', ')}`);
            resolver.dispose();
        }
        // A root-scoped component literally named like a template instance,
        // next to the template instance it mimics.
        {
            const surface = new SurfaceModel('surf-b', catalog);
            const resolver = new NodeResolver(surface, catalog);
            surface.dataModel.set('/items', [{ v: 'row0' }]);
            add(surface, 'root', 'Pane', {
                main: 'a-[/items/0]',
                items: { componentId: 'a', path: '/items' },
            });
            add(surface, 'a-[/items/0]', 'Text', { text: 'literal' });
            add(surface, 'a', 'Text', { text: { path: 'v' } });
            const root = getValue(resolver.rootNode);
            assert.ok(root);
            const rootProps = props(root);
            const nodes = [rootProps.main, ...rootProps.items];
            const ids = nodes.map(n => n.instanceId);
            assert.strictEqual(new Set(ids).size, ids.length, `collision in ${ids.join(', ')}`);
            resolver.dispose();
        }
    });
    it('caps dynamic ChildList resolution to MAX_DYNAMIC_CHILD_LIST_SIZE in NodeResolver (Issue #2387)', () => {
        const catalog = new Catalog('large-list-catalog', '0.9', [TextApi, ColumnApi], []);
        const surface = new SurfaceModel('surf-large', catalog);
        const resolver = new NodeResolver(surface, catalog);
        const items = Array.from({ length: 12_000 }, (_, i) => ({ v: `row${i}` }));
        surface.dataModel.set('/items', items);
        add(surface, 'root', 'Column', {
            children: { componentId: 'item-comp', path: '/items' },
        });
        add(surface, 'item-comp', 'Text', { text: { path: 'v' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, MAX_DYNAMIC_CHILD_LIST_SIZE);
        assert.strictEqual(children[0].dataPath, '/items/0');
        assert.strictEqual(children[MAX_DYNAMIC_CHILD_LIST_SIZE - 1].dataPath, `/items/${MAX_DYNAMIC_CHILD_LIST_SIZE - 1}`);
        resolver.dispose();
    });
    it('keeps edges distinct when property names and component ids share delimiters', () => {
        // Field 'a' referencing 'b>c' and field 'a>b' referencing 'c' would
        // concatenate to the same edge key without escaping, disposing the
        // first node the moment the second resolves.
        const TrickyApi = {
            name: 'Tricky',
            schema: z.object({
                'a': ComponentIdSchema.optional(),
                'a>b': ComponentIdSchema.optional(),
            }),
        };
        const catalog = new Catalog('tricky-catalog', '0.9', [TextApi, TrickyApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Tricky', { 'a': 'b>c', 'a>b': 'c' });
        add(surface, 'b>c', 'Text', { text: 'first' });
        add(surface, 'c', 'Text', { text: 'second' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const first = props(root)['a'];
        const second = props(root)['a>b'];
        assert.ok(isComponentNode(first) && isComponentNode(second));
        assert.strictEqual(first.disposed, false);
        assert.strictEqual(second.disposed, false);
        assert.strictEqual(bound(first, 'text'), 'first');
        assert.strictEqual(bound(second, 'text'), 'second');
        // Both stay live: an update must reach the first node.
        const model = surface.componentsModel.get('b>c');
        assert.ok(model);
        model.properties = { text: 'updated' };
        assert.strictEqual(bound(props(root)['a'], 'text'), 'updated');
        resolver.dispose();
    });
    it('spawns one node per array item for a template child list', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/items', [{ name: 'A' }, { name: 'B' }]);
        add(surface, 'root', 'Column', { children: { componentId: 'item_tpl', path: '/items' } });
        add(surface, 'item_tpl', 'Text', { text: { path: 'name' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, 2);
        assert.strictEqual(children[0].instanceId, 'item_tpl-[/items/0]');
        assert.strictEqual(children[0].dataPath, '/items/0');
        assert.strictEqual(bound(children[0], 'text'), 'A');
        assert.strictEqual(bound(children[1], 'text'), 'B');
        resolver.dispose();
    });
    it('binds actions as closures that dispatch through the surface', async () => {
        const { surface, resolver } = setup();
        const actions = [];
        surface.onAction.subscribe(action => {
            actions.push(action);
        });
        surface.dataModel.set('/current_id', 42);
        add(surface, 'root', 'Button', {
            label: 'Go',
            action: { event: { name: 'submit', context: { itemId: { path: '/current_id' } } } },
        });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const fire = props(root).action;
        assert.strictEqual(typeof fire, 'function');
        fire();
        await flush();
        assert.strictEqual(actions.length, 1);
        assert.strictEqual(actions[0].name, 'submit');
        assert.strictEqual(actions[0].surfaceId, 'surf-1');
        assert.strictEqual(actions[0].sourceComponentId, 'root');
        assert.deepStrictEqual(actions[0].context, { itemId: 42 });
        resolver.dispose();
    });
    it('resolves an unresolved binding to undefined without failing', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Text', { text: { path: '/missing' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(bound(root, 'text'), undefined);
        resolver.dispose();
    });
    it('reconciles explicit children list changes, reusing surviving nodes', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['c1', 'c2'] });
        add(surface, 'c1', 'Text', { text: 'C1' });
        add(surface, 'c2', 'Text', { text: 'C2' });
        add(surface, 'c3', 'Text', { text: 'C3' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const before = props(root).children;
        const rootModel = surface.componentsModel.get('root');
        assert.ok(rootModel);
        rootModel.properties = { children: ['c1', 'c3'] };
        const after = props(root).children;
        assert.strictEqual(after.length, 2);
        assert.strictEqual(after[0], before[0]);
        assert.strictEqual(bound(after[1], 'text'), 'C3');
        assert.strictEqual(before[1].disposed, true);
        resolver.dispose();
    });
    it('reconciles a swap from explicit children to a template', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/items', [{ name: 'T0' }]);
        add(surface, 'root', 'Column', { children: ['c1'] });
        add(surface, 'c1', 'Text', { text: 'C1' });
        add(surface, 'item_tpl', 'Text', { text: { path: 'name' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const explicitChild = child(root, 'children', 0);
        const rootModel = surface.componentsModel.get('root');
        assert.ok(rootModel);
        rootModel.properties = { children: { componentId: 'item_tpl', path: '/items' } };
        const children = props(root).children;
        assert.strictEqual(children.length, 1);
        assert.strictEqual(bound(children[0], 'text'), 'T0');
        assert.strictEqual(explicitChild.disposed, true);
        resolver.dispose();
    });
    it('resolves function-call bindings reactively', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/username', 'alice');
        add(surface, 'root', 'Text', { text: { call: 'shout', args: { value: { path: '/username' } } } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(bound(root, 'text'), 'ALICE');
        surface.dataModel.set('/username', 'bob');
        assert.strictEqual(bound(root, 'text'), 'BOB');
        resolver.dispose();
    });
    it('resolves nested child references inside item arrays', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Tabs', {
            items: [
                { title: 'One', child: 't1' },
                { title: 'Two', child: 't2' },
            ],
        });
        add(surface, 't1', 'Text', { text: 'First' });
        add(surface, 't2', 'Text', { text: 'Second' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const items = props(root).items;
        assert.strictEqual(items.length, 2);
        assert.strictEqual(items[0].title, 'One');
        const first = items[0].child;
        assert.ok(isComponentNode(first));
        assert.strictEqual(bound(first, 'text'), 'First');
        const second = items[1].child;
        assert.ok(isComponentNode(second));
        assert.strictEqual(bound(second, 'text'), 'Second');
        resolver.dispose();
    });
    it('reconciles a deleted component back to a placeholder, leaving siblings alone', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['c1', 'c2'] });
        add(surface, 'c1', 'Text', { text: 'C1' });
        add(surface, 'c2', 'Text', { text: 'C2' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const before = props(root).children;
        surface.componentsModel.removeComponent('c2');
        const after = props(root).children;
        assert.strictEqual(after[0], before[0]);
        assert.strictEqual(after[1].type, PLACEHOLDER_TYPE);
        assert.strictEqual(before[1].disposed, true);
        resolver.dispose();
    });
    it('serializes the resolved tree, rendering actions and placeholders specially', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['card', 'btn', 'late'] });
        add(surface, 'card', 'Card', { child: 'txt' });
        add(surface, 'txt', 'Text', { text: 'Hello' });
        add(surface, 'btn', 'Button', { label: 'Go', action: { event: { name: 'go' } } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const json = root.toJSON();
        assert.deepStrictEqual(json, {
            id: 'root',
            type: 'Column',
            children: [
                {
                    id: 'card',
                    type: 'Card',
                    child: { id: 'txt', type: 'Text', text: 'Hello' },
                },
                { id: 'btn', type: 'Button', label: 'Go', action: '<Action>' },
                { id: 'late', type: PLACEHOLDER_TYPE, state: 'pending' },
            ],
        });
        resolver.dispose();
    });
});
describe('NodeResolver defect coverage (fixes over the Python reference)', () => {
    it('does not emit when an action-bearing component is resent unchanged', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: ['b1'] });
        add(surface, 'b1', 'Button', { label: 'Go', action: { event: { name: 'tap' } } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const button = peekValue(root.props)['children'][0];
        assert.strictEqual(typeof peekValue(button.props)['action'], 'function');
        const emissions = countEmissions(button.props);
        const model = surface.componentsModel.get('b1');
        assert.ok(model);
        model.properties = { label: 'Go', action: { event: { name: 'tap' } } };
        assert.strictEqual(emissions.count, 0, 'an unchanged resend must not emit for action-bearing components');
        const closureBefore = peekValue(button.props)['action'];
        model.properties = { label: 'Go', action: { event: { name: 'other' } } };
        assert.strictEqual(emissions.count, 1);
        assert.notStrictEqual(peekValue(button.props)['action'], closureBefore);
        emissions.dispose();
        resolver.dispose();
    });
    it('keeps a shared child alive for one parent when the other stops referencing it', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/label', 'shared text');
        add(surface, 'root', 'Column', { children: ['card_a', 'card_b'] });
        add(surface, 'card_a', 'Card', { child: 'shared' });
        add(surface, 'card_b', 'Card', { child: 'shared' });
        add(surface, 'shared', 'Text', { text: { path: '/label' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const cardA = child(root, 'children', 0);
        const cardB = child(root, 'children', 1);
        const sharedViaA = child(cardA, 'child');
        const sharedViaB = child(cardB, 'child');
        assert.notStrictEqual(sharedViaA, sharedViaB);
        const cardAModel = surface.componentsModel.get('card_a');
        assert.ok(cardAModel);
        cardAModel.properties = {};
        assert.strictEqual(sharedViaA.disposed, true);
        assert.strictEqual(sharedViaB.disposed, false);
        surface.dataModel.set('/label', 'still updating');
        assert.strictEqual(bound(sharedViaB, 'text'), 'still updating');
        resolver.dispose();
    });
    it('does not emit a parent props signal when only a child property changes (no bubbling)', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/username', 'Alice');
        surface.dataModel.set('/items', [{ name: 'A' }, { name: 'B' }]);
        add(surface, 'root', 'Column', { children: ['bound', 'tpl_col'] });
        add(surface, 'bound', 'Text', { text: { path: '/username' } });
        add(surface, 'tpl_col', 'Column', { children: { componentId: 'item_tpl', path: '/items' } });
        add(surface, 'item_tpl', 'Text', { text: { path: 'name' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const boundText = child(root, 'children', 0);
        const templateColumn = child(root, 'children', 1);
        const item0 = child(templateColumn, 'children', 0);
        const rootEmissions = countEmissions(root.props);
        const templateColumnEmissions = countEmissions(templateColumn.props);
        const boundEmissions = countEmissions(boundText.props);
        const item0Emissions = countEmissions(item0.props);
        surface.dataModel.set('/username', 'Bob');
        assert.strictEqual(boundEmissions.count, 1);
        assert.strictEqual(bound(boundText, 'text'), 'Bob');
        assert.strictEqual(rootEmissions.count, 0);
        // Editing one item's field re-fires the template's array subscription;
        // the item node must update while the template parent's props stay
        // identity-stable and silent.
        surface.dataModel.set('/items/0/name', 'A2');
        assert.strictEqual(bound(item0, 'text'), 'A2');
        assert.ok(item0Emissions.count >= 1);
        assert.strictEqual(templateColumnEmissions.count, 0);
        assert.strictEqual(rootEmissions.count, 0);
        rootEmissions.dispose();
        templateColumnEmissions.dispose();
        boundEmissions.dispose();
        item0Emissions.dispose();
        resolver.dispose();
    });
});
describe('NodeResolver malformed and unusual payloads', () => {
    it('renders cyclic references as placeholders instead of recursing', () => {
        const { surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'root', 'Card', { child: 'a' });
        add(surface, 'a', 'Card', { child: 'b' });
        add(surface, 'b', 'Card', { child: 'a' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const a = child(root, 'child');
        const b = child(a, 'child');
        const backReference = child(b, 'child');
        assert.strictEqual(backReference.type, PLACEHOLDER_TYPE);
        assert.strictEqual(backReference.state, 'cyclic');
        assert.strictEqual(backReference.componentId, 'a');
        assert.ok(errors.some(e => e.code === 'CYCLIC_REFERENCE'));
        assert.ok(resolver.activeNodeCount <= 5);
        resolver.dispose();
    });
    it('renders a self-referencing component as a placeholder child', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Card', { child: 'root' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(child(root, 'child').type, PLACEHOLDER_TYPE);
        resolver.dispose();
    });
    it('propagates changes to non-plain object values', () => {
        // The data model shallow-clones values when notifying, so the non-plain
        // object sits one level down, where the clone preserves its reference.
        const { surface, resolver } = setup();
        const first = new Map([['k', 1]]);
        const second = new Map([['k', 2]]);
        surface.dataModel.set('/blob', { wrapper: first });
        add(surface, 'root', 'Text', { text: { path: '/blob' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(bound(root, 'text').wrapper, first);
        surface.dataModel.set('/blob', { wrapper: second });
        assert.strictEqual(bound(root, 'text').wrapper, second);
        resolver.dispose();
    });
    it('dispatches UNKNOWN_COMPONENT_TYPE once per component, not per referencing edge', () => {
        const { surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'weird', 'Bogus', {});
        add(surface, 'root', 'Column', { children: ['weird', 'weird'] });
        assert.ok(getValue(resolver.rootNode));
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 1);
        surface.componentsModel.removeComponent('weird');
        add(surface, 'weird', 'Bogus', {});
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 2);
        resolver.dispose();
    });
    // Both stale-root tests register async listeners ahead of the resolver, as
    // any subscriber registered before it does in production: each event then
    // delivers to the resolver only after an await, by which time the model
    // has moved on.
    function setupWithDelayedDelivery() {
        const TextApi = {
            name: 'Text',
            schema: z.object({ text: DynamicStringSchema.optional() }),
        };
        const catalog = new Catalog('stale-root-catalog', '0.9', [TextApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        surface.componentsModel.onCreated.subscribe(async () => {
            await Promise.resolve();
        });
        surface.componentsModel.onDeleted.subscribe(async () => {
            await Promise.resolve();
        });
        add(surface, 'root', 'Text', { text: 'first' });
        const resolver = new NodeResolver(surface, catalog);
        return { surface, resolver };
    }
    it('does not rebuild the current root when a stale creation event arrives', async () => {
        const { surface, resolver } = setupWithDelayedDelivery();
        await flush();
        const seen = [];
        const stop = effect(() => {
            seen.push(getValue(resolver.rootNode));
        });
        // Replace the root twice in one synchronous block: the intermediate
        // creation is stale by the time it delivers.
        surface.componentsModel.removeComponent('root');
        add(surface, 'root', 'Text', { text: 'intermediate' });
        surface.componentsModel.removeComponent('root');
        add(surface, 'root', 'Text', { text: 'final' });
        await flush();
        const instances = new Set(seen.filter(Boolean));
        // The initially bound root plus one rebind to the final model; the stale
        // creation must not add a dispose-and-rebuild of the already-current
        // tree.
        assert.strictEqual(instances.size, 2, `saw ${instances.size} distinct root nodes after replacement`);
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.toJSON().text, 'final');
        stop();
        resolver.dispose();
    });
    it('does not create a phantom root from a stale creation after the root is gone', async () => {
        const { surface, resolver } = setupWithDelayedDelivery();
        await flush();
        const seen = [];
        const stop = effect(() => {
            seen.push(getValue(resolver.rootNode));
        });
        surface.componentsModel.removeComponent('root');
        add(surface, 'root', 'Text', { text: 'brief' });
        surface.componentsModel.removeComponent('root');
        await flush();
        // The stale creation delivers while the model has no root; nothing may
        // surface a pending stand-in for a root that does not exist.
        assert.ok(seen.every(node => !node || !node.isPlaceholder), 'a placeholder root was surfaced for an absent root');
        assert.strictEqual(getValue(resolver.rootNode), undefined);
        stop();
        resolver.dispose();
    });
    it('reports again after delete and re-add when the component id contains colons', () => {
        const { surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'root', 'Column', { children: ['weird:x'] });
        add(surface, 'weird:x', 'Bogus', {});
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 1);
        surface.componentsModel.removeComponent('weird:x');
        add(surface, 'weird:x', 'Bogus', {});
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 2);
        resolver.dispose();
    });
    it('reports a cycle again after it is fixed and reintroduced by a property update', () => {
        const { surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'root', 'Card', { child: 'card' });
        add(surface, 'card', 'Card', { child: 'card' });
        add(surface, 'leaf', 'Text', { text: 'ok' });
        assert.strictEqual(errors.filter(e => e.code === 'CYCLIC_REFERENCE').length, 1);
        const cardModel = surface.componentsModel.get('card');
        assert.ok(cardModel);
        cardModel.properties = { child: 'leaf' };
        assert.strictEqual(errors.filter(e => e.code === 'CYCLIC_REFERENCE').length, 1);
        cardModel.properties = { child: 'card' };
        assert.strictEqual(errors.filter(e => e.code === 'CYCLIC_REFERENCE').length, 2);
        resolver.dispose();
    });
    it('keeps a stable placeholder for a component whose type is not in the catalog', () => {
        const { surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'root', 'Card', { child: 'weird' });
        add(surface, 'weird', 'Bogus', {});
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const placeholder = child(root, 'child');
        assert.strictEqual(placeholder.type, 'Bogus');
        assert.strictEqual(placeholder.state, 'unknown-type');
        assert.deepStrictEqual(placeholder.toJSON(), {
            id: 'weird',
            type: 'Bogus',
            state: 'unknown-type',
        });
        const reportsBefore = errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length;
        const rootModel = surface.componentsModel.get('root');
        assert.ok(rootModel);
        rootModel.properties = { child: 'weird' };
        rootModel.properties = { child: 'weird' };
        assert.strictEqual(child(root, 'child'), placeholder);
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, reportsBefore);
        resolver.dispose();
    });
});
describe('NodeResolver absent dynamic properties', () => {
    it('represents omitted dynamic properties as read-only bindings at every level', () => {
        const GroupApi = {
            name: 'Group',
            schema: z.object({
                title: DynamicStringSchema.optional(),
                group: z
                    .object({
                    value: DynamicStringSchema.optional(),
                    label: z.string().optional(),
                })
                    .optional(),
            }),
        };
        const catalog = new Catalog('group-catalog', '0.9', [GroupApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Group', { group: { label: 'x' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const rootProps = props(root);
        const title = rootProps.title;
        assert.ok(title instanceof ResolvedBinding && !isWritable(title));
        assert.strictEqual(title.value, undefined);
        const group = rootProps.group;
        const value = group.value;
        assert.ok(value instanceof ResolvedBinding && !isWritable(value), 'nested omitted dynamic');
        assert.strictEqual(value.value, undefined);
        assert.strictEqual(group.label, 'x');
        resolver.dispose();
    });
});
describe('NodeResolver child markers survive schema description', () => {
    it('resolves a child whose componentId schema was described', () => {
        const Api = {
            name: 'DescribedCard',
            schema: z.object({ child: ComponentIdSchema.describe('The child to show.').optional() }),
        };
        const TextApi = { name: 'Text', schema: z.object({ text: DynamicStringSchema.optional() }) };
        const catalog = new Catalog('described-catalog', '0.9', [Api, TextApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'DescribedCard', { child: 'kid' });
        add(surface, 'kid', 'Text', { text: 'child text' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const child = props(root).child;
        assert.ok(isComponentNode(child), 'expected a resolved child node');
        assert.strictEqual(child.componentId, 'kid');
        resolver.dispose();
    });
    it('resolves a child list whose schema was described', () => {
        const Api = {
            name: 'DescribedColumn',
            schema: z.object({ children: ChildListSchema.describe('The children.').optional() }),
        };
        const TextApi = { name: 'Text', schema: z.object({ text: DynamicStringSchema.optional() }) };
        const catalog = new Catalog('described-catalog', '0.9', [Api, TextApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'DescribedColumn', { children: ['a', 'b'] });
        add(surface, 'a', 'Text', { text: 'one' });
        add(surface, 'b', 'Text', { text: 'two' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const children = props(root).children;
        assert.strictEqual(children.length, 2);
        assert.ok(children.every(isComponentNode));
        resolver.dispose();
    });
    it('still recognizes a hand-authored REF description', () => {
        const Api = {
            name: 'HandAuthored',
            schema: z.object({
                child: z
                    .string()
                    .describe('REF:common_types.json#/$defs/ComponentId|Authored by hand.')
                    .optional(),
            }),
        };
        const TextApi = { name: 'Text', schema: z.object({ text: DynamicStringSchema.optional() }) };
        const catalog = new Catalog('hand-catalog', '0.9', [Api, TextApi]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'HandAuthored', { child: 'kid' });
        add(surface, 'kid', 'Text', { text: 'x' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.ok(isComponentNode(props(root).child), 'expected a resolved child node');
        resolver.dispose();
    });
});
describe('NodeResolver resolved bindings (write path)', () => {
    it('makes bindings writable iff the payload bound a data path', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/username', 'alice');
        add(surface, 'root', 'Column', { children: ['lit', 'bnd', 'call'] });
        add(surface, 'lit', 'Text', { text: 'Literal' });
        add(surface, 'bnd', 'Text', { text: { path: '/username' } });
        add(surface, 'call', 'Text', { text: { call: 'shout', args: { value: { path: '/username' } } } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const [literalNode, boundNode, callNode] = props(root).children;
        const literal = props(literalNode).text;
        assert.strictEqual(literal.value, 'Literal');
        assert.strictEqual(isWritable(literal), false);
        assert.strictEqual('set' in literal, false);
        const call = props(callNode).text;
        assert.strictEqual(call.value, 'ALICE');
        assert.strictEqual(isWritable(call), false);
        assert.strictEqual('set' in call, false);
        const pathBound = props(boundNode).text;
        assert.strictEqual(pathBound.value, 'alice');
        if (!isWritable(pathBound)) {
            assert.fail('expected a writable binding');
        }
        pathBound.set('bob');
        assert.strictEqual(surface.dataModel.get('/username'), 'bob');
        assert.strictEqual(bound(boundNode, 'text'), 'bob');
        resolver.dispose();
    });
    it('rebinding a prop to a new path replaces the binding even when values are equal', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/a', 'same');
        surface.dataModel.set('/b', 'same');
        add(surface, 'root', 'Text', { text: { path: '/a' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        surface.componentsModel.get('root').properties = { text: { path: '/b' } };
        const binding = props(root).text;
        if (!isWritable(binding)) {
            assert.fail('expected a writable binding');
        }
        assert.strictEqual(binding.path, '/b');
        binding.set('written');
        assert.strictEqual(surface.dataModel.get('/b'), 'written');
        assert.strictEqual(surface.dataModel.get('/a'), 'same');
        resolver.dispose();
    });
    it('serializes path-bound properties as plain snapshot values', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/username', 'alice');
        add(surface, 'root', 'Text', { text: { path: '/username' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.deepStrictEqual(root.toJSON(), { id: 'root', type: 'Text', text: 'alice' });
        resolver.dispose();
    });
});
describe('NodeResolver stale event delivery', () => {
    it('reconciles events emitted before construction but delivered after', async () => {
        const catalog = makeCatalog();
        const surface = new SurfaceModel('surf-1', catalog);
        add(surface, 'root', 'Text', { text: 'original' });
        // Model events deliver to each listener in turn, awaiting async
        // listeners, so this delayer forces later subscribers to receive the
        // deletion after further mutations have happened.
        surface.componentsModel.onDeleted.subscribe(async () => {
            await flush();
        });
        surface.componentsModel.removeComponent('root');
        add(surface, 'root', 'Text', { text: 'fresh' });
        const resolver = new NodeResolver(surface, catalog);
        await flush();
        await flush();
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.disposed, false);
        assert.strictEqual(bound(root, 'text'), 'fresh');
        resolver.dispose();
    });
    it('replaces an unknown-type node whose component was replaced before a delayed deletion delivery', async () => {
        const catalog = makeCatalog();
        const surface = new SurfaceModel('surf-1', catalog);
        surface.componentsModel.onDeleted.subscribe(async () => {
            await flush();
        });
        const resolver = new NodeResolver(surface, catalog);
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        add(surface, 'root', 'Card', { child: 'weird' });
        add(surface, 'weird', 'Bogus', {});
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 1);
        surface.componentsModel.removeComponent('weird');
        add(surface, 'weird', 'Bogus2', {});
        await flush();
        await flush();
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const node = child(root, 'child');
        assert.strictEqual(node.type, 'Bogus2');
        assert.strictEqual(node.state, 'unknown-type');
        assert.strictEqual(errors.filter(e => e.code === 'UNKNOWN_COMPONENT_TYPE').length, 2);
        resolver.dispose();
    });
    it('keeps waiting for a component whose add and remove both preceded a delayed delivery', async () => {
        const catalog = makeCatalog();
        const surface = new SurfaceModel('surf-1', catalog);
        surface.componentsModel.onCreated.subscribe(async () => {
            await flush();
        });
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Column', { children: ['kid'] });
        await flush();
        await flush();
        // The delayed onCreated delivery clears the waiting registration; the
        // deletion then reuses the pending placeholder. A later legitimate add
        // must still upgrade it.
        add(surface, 'kid', 'Text', { text: 'one' });
        surface.componentsModel.removeComponent('kid');
        await flush();
        await flush();
        add(surface, 'kid', 'Text', { text: 'two' });
        await flush();
        await flush();
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const kid = child(root, 'children', 0);
        assert.strictEqual(kid.state, 'resolved');
        assert.strictEqual(bound(kid, 'text'), 'two');
        resolver.dispose();
    });
    it('rebinds a child node whose component model was replaced before a delayed deletion delivery', async () => {
        const catalog = makeCatalog();
        const surface = new SurfaceModel('surf-1', catalog);
        surface.componentsModel.onDeleted.subscribe(async () => {
            await flush();
        });
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Card', { child: 'leaf' });
        add(surface, 'leaf', 'Text', { text: 'old' });
        surface.componentsModel.removeComponent('leaf');
        add(surface, 'leaf', 'Text', { text: 'new' });
        await flush();
        await flush();
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const leaf = child(root, 'child');
        assert.strictEqual(leaf.disposed, false);
        assert.strictEqual(bound(leaf, 'text'), 'new');
        // The node must be bound to the current model, not the replaced one.
        const leafModel = surface.componentsModel.get('leaf');
        assert.ok(leafModel);
        leafModel.properties = { text: 'updated' };
        assert.strictEqual(bound(child(root, 'child'), 'text'), 'updated');
        resolver.dispose();
    });
});
describe('NodeResolver constructor checks and disposal', () => {
    it('rejects a catalog instance other than the surface catalog', () => {
        const catalogA = makeCatalog();
        const catalogB = makeCatalog();
        const surface = new SurfaceModel('surf-1', catalogA);
        assert.throws(() => new NodeResolver(surface, catalogB), /same catalog instance/);
    });
    it('rejects a schema-only catalog at compile time', () => {
        // The assertion is the @ts-expect-error below: the build fails if a
        // schema-only catalog ever satisfies NodeResolver's constructor bound.
        function schemaOnlyCatalogIsRejected(surface, schemaOnly) {
            // @ts-expect-error a schema-only catalog has no function implementations
            return new NodeResolver(surface, schemaOnly);
        }
        assert.strictEqual(typeof schemaOnlyCatalogIsRejected, 'function');
    });
    it('exposes no mutation API on resolved nodes', () => {
        const { surface, resolver } = setup();
        add(surface, 'root', 'Column', { children: [] });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        // @ts-expect-error setProps lives on MutableComponentNode, internal to the resolver
        const _setProps = root.setProps;
        // @ts-expect-error dispose lives on MutableComponentNode, internal to the resolver
        const _dispose = root.dispose;
        // ComponentNode is an interface: the package ships no runtime
        // constructor for nodes at all.
        assert.strictEqual('ComponentNode' in v0_9, false);
        // @ts-expect-error MutableComponentNode is not exported from the package
        const _leaked = v0_9.MutableComponentNode;
        resolver.dispose();
    });
    it('disposes the whole tree with the resolver, leaving no live nodes', () => {
        const { surface, resolver } = setup();
        surface.dataModel.set('/items', [{ name: 'A' }, { name: 'B' }]);
        add(surface, 'root', 'Column', { children: ['card', 'tpl_col'] });
        add(surface, 'card', 'Card', { child: 'txt' });
        add(surface, 'txt', 'Text', { text: 'Hello' });
        add(surface, 'tpl_col', 'Column', { children: { componentId: 'item_tpl', path: '/items' } });
        add(surface, 'item_tpl', 'Text', { text: { path: 'name' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.ok(resolver.activeNodeCount >= 6);
        resolver.dispose();
        assert.strictEqual(resolver.activeNodeCount, 0);
        assert.strictEqual(getValue(resolver.rootNode), undefined);
        assert.strictEqual(root.disposed, true);
        // A data change after disposal must not resurrect any binding.
        surface.dataModel.set('/items', [{ name: 'X' }]);
        assert.strictEqual(resolver.activeNodeCount, 0);
    });
    it("resolves a component against its own catalog, not the surface's default", () => {
        const { catalog, surface, resolver } = setup();
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        surface.componentsModel.addComponent(new ComponentModel('root', 'Column', { children: ['child1'] }, catalog));
        // The surface default declares Text, but this component's catalog doesn't.
        const emptyCat = new Catalog('empty', '0.9', []);
        surface.componentsModel.addComponent(new ComponentModel('child1', 'Text', { text: 'Empty Catalog' }, emptyCat));
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.type, 'Column');
        const c1 = child(root, 'children', 0);
        assert.strictEqual(c1.state, 'unknown-type');
        assert.deepStrictEqual(errors, [
            {
                code: 'UNKNOWN_COMPONENT_TYPE',
                message: "Component 'child1' has type 'Text', which is not in catalog 'empty'.",
                surfaceId: 'surf-1',
            },
        ]);
        resolver.dispose();
    });
});
describe('NodeResolver on a surface without a default catalog', () => {
    function setupNoDefault() {
        const catalog = makeCatalog();
        const surface = new SurfaceModel('no-default', undefined, new Map([[catalog.id, catalog]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
        const resolver = new NodeResolver(surface);
        return { catalog, surface, resolver, errors };
    }
    it('resolves each component against the catalog its model names', () => {
        const { catalog, surface, resolver, errors } = setupNoDefault();
        surface.componentsModel.addComponent(new ComponentModel('root', 'Card', { child: 'text-1' }, catalog));
        surface.componentsModel.addComponent(new ComponentModel('text-1', 'Text', { text: 'Hi' }, catalog));
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(root.type, 'Card');
        const text = child(root, 'child');
        assert.strictEqual(text.type, 'Text');
        assert.strictEqual(bound(text, 'text'), 'Hi');
        assert.deepStrictEqual(errors, []);
        resolver.dispose();
    });
    it('reports a component whose catalog lacks its type as an unknown type', () => {
        const { catalog, surface, resolver, errors } = setupNoDefault();
        surface.componentsModel.addComponent(new ComponentModel('root', 'Card', { child: 'orphan' }, catalog));
        const otherCatalog = new Catalog('other', '1.0', []);
        surface.componentsModel.addComponent(new ComponentModel('orphan', 'Text', { text: 'x' }, otherCatalog));
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const orphan = child(root, 'child');
        assert.strictEqual(orphan.state, 'unknown-type');
        assert.deepStrictEqual(errors, [
            {
                code: 'UNKNOWN_COMPONENT_TYPE',
                message: "Component 'orphan' has type 'Text', which is not in catalog 'other'.",
                surfaceId: 'no-default',
            },
        ]);
        resolver.dispose();
    });
    it('tracks node.metadata independently of node.props and forwards action metadata', async () => {
        const { catalog, surface, resolver } = setup();
        const actions = [];
        surface.onAction.subscribe(a => {
            actions.push(a);
        });
        surface.componentsModel.addComponent(new ComponentModel('root', 'Button', { label: 'Go', action: { event: { name: 'go_evt', context: { k: 'v' } } } }, catalog, { extensions: { trace: { spanId: '1' } } }));
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.deepStrictEqual(peekValue(root.metadata), { extensions: { trace: { spanId: '1' } } });
        // Attempting to write to read-only node.metadata throws TypeError
        assert.throws(() => setValue(root.metadata, { extensions: { x: 1 } }), TypeError);
        const propsCounter = countEmissions(root.props);
        const metaCounter = countEmissions(root.metadata);
        const model = surface.componentsModel.get('root');
        model.metadata = { extensions: { trace: { spanId: '2' } } };
        assert.strictEqual(propsCounter.count, 0);
        assert.strictEqual(metaCounter.count, 1);
        assert.deepStrictEqual(peekValue(root.metadata), { extensions: { trace: { spanId: '2' } } });
        const invokeAction = props(root).action;
        await invokeAction({ metadata: { extensions: { click_source: 'keyboard' } } });
        assert.strictEqual(actions.length, 1);
        assert.deepStrictEqual(actions[0].metadata, { extensions: { click_source: 'keyboard' } });
        propsCounter.dispose();
        metaCounter.dispose();
        resolver.dispose();
    });
});
describe('NodeResolver omitted property pruning on update (#3779)', () => {
    it('prunes omitted scalar, nested object, array, dynamic-bound, action, and ref properties on update (#3779)', async () => {
        const RichWidgetApi = {
            name: 'RichWidget',
            schema: z.object({
                variant: z.string().optional(),
                tags: z.array(z.string()).optional(),
                accessibility: z
                    .object({
                    label: DynamicStringSchema.optional(),
                    description: z.string().optional(),
                })
                    .optional(),
                value: DynamicStringSchema.optional(),
                action: ActionSchema.optional(),
                child: ComponentIdSchema.optional(),
                children: ChildListSchema.optional(),
            }),
        };
        const catalog = new Catalog('prune-test-catalog', '0.9', [TextApi, RichWidgetApi], []);
        const surface = new SurfaceModel('surf-prune', catalog);
        surface.dataModel.set('/val', 'Initial');
        surface.dataModel.set('/a11y', 'Save');
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'c1', 'Text', { text: 'Child 1' });
        add(surface, 'c2', 'Text', { text: 'Child 2' });
        add(surface, 'root', 'RichWidget', {
            variant: 'filled',
            tags: ['one', 'two'],
            accessibility: {
                label: { path: '/a11y' },
                description: 'Submit form',
            },
            value: { path: '/val' },
            action: { event: { name: 'submit' } },
            child: 'c1',
            children: ['c2'],
        });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const c1Node = child(root, 'child');
        const c2Node = child(root, 'children', 0);
        assert.strictEqual(props(root).variant, 'filled');
        assert.deepStrictEqual(props(root).tags, ['one', 'two']);
        assert.strictEqual(bound(root, 'value'), 'Initial');
        assert.strictEqual(isWritable(props(root).value), true);
        assert.strictEqual(typeof props(root).action, 'function');
        // Update omitting variant, tags, accessibility.description, value, action, child, and children
        const rootModel = surface.componentsModel.get('root');
        rootModel.properties = {
            accessibility: {
                label: { path: '/a11y' },
            },
        };
        assert.strictEqual(c1Node.disposed, true);
        assert.strictEqual(c2Node.disposed, true);
        assert.strictEqual(Object.hasOwn(props(root), 'variant'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'tags'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'action'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'child'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'children'), false);
        // Omitted DYNAMIC property resets to a read-only ResolvedBinding(undefined)
        assert.strictEqual(bound(root, 'value'), undefined);
        assert.strictEqual(isWritable(props(root).value), false);
        const a11y = props(root).accessibility;
        assert.strictEqual(Object.hasOwn(a11y, 'description'), false);
        assert.ok(a11y.label instanceof ResolvedBinding);
        assert.strictEqual(a11y.label.value, 'Save');
        // Old /val data binding is unsubscribed and does not emit or resurrect value
        const counter = countEmissions(root.props);
        surface.dataModel.set('/val', 'Changed');
        await flush();
        assert.strictEqual(counter.count, 0);
        assert.strictEqual(bound(root, 'value'), undefined);
        counter.dispose();
        // Matches a freshly initialized component with the same properties
        const freshSurface = new SurfaceModel('surf-fresh', catalog);
        freshSurface.dataModel.set('/a11y', 'Save');
        const freshResolver = new NodeResolver(freshSurface, catalog);
        add(freshSurface, 'root', 'RichWidget', {
            accessibility: {
                label: { path: '/a11y' },
            },
        });
        const freshRoot = getValue(freshResolver.rootNode);
        assert.ok(freshRoot);
        assert.deepStrictEqual(Object.keys(props(root)).sort(), Object.keys(props(freshRoot)).sort());
        assert.strictEqual(bound(root, 'value'), bound(freshRoot, 'value'));
        freshResolver.dispose();
        freshSurface.dispose();
        resolver.dispose();
        surface.dispose();
    });
    it('preserves checkable validation state when checks remain and prunes it when checks are omitted (#3779)', async () => {
        const required = {
            name: 'required',
            returnType: 'boolean',
            schema: z.object({ value: z.unknown() }),
            execute: (args) => Boolean(args.value),
        };
        const ValidatedInputApi = {
            name: 'ValidatedInput',
            schema: z.object({
                value: CommonSchemas.DynamicString.optional(),
                placeholder: z.string().optional(),
                checks: CommonSchemas.Checkable.shape.checks,
            }),
        };
        const catalog = new Catalog('check-prune-catalog', '1.0', [ValidatedInputApi], [required]);
        const surface = new SurfaceModel('surf-check', catalog);
        surface.dataModel.set('/name', '');
        const resolver = new NodeResolver(surface, catalog);
        const checks = [
            {
                condition: { '@call': 'required', args: { value: { '@path': '/name' } } },
                message: 'Name is required',
            },
        ];
        add(surface, 'root', 'ValidatedInput', {
            value: { '@path': '/name' },
            placeholder: 'Enter name',
            checks,
        });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(props(root).placeholder, 'Enter name');
        assert.strictEqual(props(root).isValid, false);
        assert.deepStrictEqual(props(root).validationErrors, ['Name is required']);
        // Update omitting placeholder while keeping checks preserves validation state
        const rootModel = surface.componentsModel.get('root');
        rootModel.properties = {
            value: { '@path': '/name' },
            checks,
        };
        assert.strictEqual(Object.hasOwn(props(root), 'placeholder'), false);
        assert.strictEqual(props(root).isValid, false);
        assert.deepStrictEqual(props(root).validationErrors, ['Name is required']);
        // Reactive data update still updates validation state
        surface.dataModel.set('/name', 'Alice');
        await flush();
        assert.strictEqual(props(root).isValid, true);
        assert.deepStrictEqual(props(root).validationErrors, []);
        assert.deepStrictEqual(props(root).validationResults, []);
        // Omitting checks clears checks, isValid, validationErrors, and validationResults
        rootModel.properties = {};
        assert.strictEqual(Object.hasOwn(props(root), 'checks'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'isValid'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'validationErrors'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'validationResults'), false);
        assert.strictEqual(bound(root, 'value'), undefined);
        // Changing /name afterwards does not resurrect validation props
        surface.dataModel.set('/name', '');
        await flush();
        assert.strictEqual(Object.hasOwn(props(root), 'isValid'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'validationErrors'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'validationResults'), false);
        resolver.dispose();
        surface.dispose();
    });
    it('prunes omitted non-ref properties during materialize even before a delayed binder onUpdated runs (#3779)', async () => {
        const WidgetWithChildApi = {
            name: 'WidgetWithChild',
            schema: z.object({
                variant: z.string().nullable().optional(),
                extraMap: z.record(z.string()).optional(),
                grid: z
                    .array(z.array(z.object({
                    title: z.string(),
                    badge: z.string().optional(),
                })))
                    .optional(),
                child: ComponentIdSchema.optional(),
                children: ChildListSchema.optional(),
            }),
        };
        const catalog = new Catalog('delayed-binder-catalog', '0.9', [TextApi, WidgetWithChildApi], []);
        const surface = new SurfaceModel('surf-delayed', catalog);
        add(surface, 'c1', 'Text', { text: 'First' });
        add(surface, 'c2', 'Text', { text: 'Second' });
        const rootModel = new ComponentModel('root', 'WidgetWithChild', {
            variant: 'outlined',
            extraMap: { keep: 'yes', drop: 'no' },
            grid: [
                [
                    { title: 'Cell 1', badge: 'New' },
                    { title: 'Cell 2', badge: 'Old' },
                ],
            ],
            child: 'pending-child',
            children: ['c1', 'c2'],
        }, catalog);
        let releaseGate;
        const gate = new Promise(resolve => {
            releaseGate = resolve;
        });
        let blockUpdates = false;
        // Subscribed before NodeResolver creates its GenericBinder so EventEmitter
        // awaits this listener before running GenericBinder.rebuildAllBindings.
        rootModel.onUpdated.subscribe(async () => {
            if (blockUpdates) {
                await gate;
            }
        });
        surface.componentsModel.addComponent(rootModel);
        const resolver = new NodeResolver(surface, catalog);
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(props(root).variant, 'outlined');
        assert.strictEqual(child(root, 'child').state, 'pending');
        assert.strictEqual(props(root).children.length, 2);
        // Update rootModel setting `variant: null`, omitting `extraMap.drop`,
        // `badge`, the second cell, and `c2` from `children`, while keeping
        // `child: 'pending-child'`, then add `pending-child` while GenericBinder's
        // onUpdated is still blocked.
        blockUpdates = true;
        rootModel.properties = {
            variant: null,
            extraMap: { keep: 'yes' },
            grid: [[{ title: 'Cell 1' }]],
            child: 'pending-child',
            children: ['c1'],
        };
        add(surface, 'pending-child', 'Text', { text: 'Arrived' });
        // materialize ran for pending-child arrival with stale lastBinderProps:
        // cleared `variant: null`, omitted `extraMap.drop`, nested `badge`, shrunk
        // array elements, and shrunk static `children` must already be reflected.
        assert.strictEqual(child(root, 'child').type, 'Text');
        assert.strictEqual(props(root).variant, null);
        assert.deepStrictEqual(props(root).extraMap, { keep: 'yes' });
        assert.deepStrictEqual(props(root).grid, [[{ title: 'Cell 1' }]]);
        assert.strictEqual(props(root).children.length, 1);
        assert.strictEqual(child(root, 'children', 0).componentId, 'c1');
        releaseGate();
        await flush();
        assert.strictEqual(props(root).variant, null);
        assert.deepStrictEqual(props(root).extraMap, { keep: 'yes' });
        assert.deepStrictEqual(props(root).grid, [[{ title: 'Cell 1' }]]);
        assert.strictEqual(props(root).children.length, 1);
        resolver.dispose();
        surface.dispose();
    });
});
describe('NodeResolver @accessibility mirror', () => {
    function setupV10(schema) {
        const catalog = new Catalog('a11y-catalog', '1.0', [{ name: 'Widget', schema }]);
        const surface = new SurfaceModel('surf-1', catalog);
        const resolver = new NodeResolver(surface, catalog);
        return { surface, resolver };
    }
    function label(value) {
        assert.ok(value && typeof value === 'object', 'expected accessibility attributes');
        const binding = value['label'];
        return binding instanceof ResolvedBinding ? binding.value : binding;
    }
    it('exposes @accessibility as accessibility in node props', async () => {
        const { surface, resolver } = setupV10(z.object({ text: z.string().optional() }));
        surface.dataModel.set('/label', 'Save');
        add(surface, 'root', 'Widget', { '@accessibility': { label: { '@path': '/label' } } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(props(root)['accessibility'], props(root)['@accessibility']);
        assert.strictEqual(label(props(root)['accessibility']), 'Save');
        surface.dataModel.set('/label', 'Cancel');
        await flush();
        assert.strictEqual(label(props(root)['accessibility']), 'Cancel');
        surface.componentsModel.get('root').properties = { text: 'x' };
        assert.ok(!('accessibility' in props(root)));
        assert.ok(!('@accessibility' in props(root)));
        resolver.dispose();
        surface.dispose();
    });
    it('leaves a custom accessibility the payload omits unset', () => {
        const { surface, resolver } = setupV10(z.object({ accessibility: z.enum(['high', 'low']).optional() }));
        add(surface, 'root', 'Widget', { '@accessibility': { label: 'Save' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.ok(!('accessibility' in props(root)));
        assert.strictEqual(label(props(root)['@accessibility']), 'Save');
        resolver.dispose();
        surface.dispose();
    });
});
describe('NodeResolver dynamic and unannotated ref schemas (#3783)', () => {
    it('resolves child and children for z.record, z.any, and z.unknown schemas and disposes removed children', () => {
        for (const [label, dynamicSchema] of [
            ['z.record', z.record(z.unknown())],
            ['z.any', z.any()],
            ['z.unknown', z.unknown()],
        ]) {
            const DynamicApi = { name: 'DynamicWidget', schema: dynamicSchema };
            const catalog = new Catalog(`dyn-${label}`, '0.9', [DynamicApi, TextApi]);
            const surface = new SurfaceModel('surf-1', catalog);
            const resolver = new NodeResolver(surface, catalog);
            add(surface, 'root', 'DynamicWidget', {
                title: 'Header',
                child: 'single-kid',
                children: ['list-a', 'list-b'],
            });
            add(surface, 'single-kid', 'Text', { text: 'Single' });
            add(surface, 'list-a', 'Text', { text: 'One' });
            add(surface, 'list-b', 'Text', { text: 'Two' });
            const root = getValue(resolver.rootNode);
            assert.ok(root, `${label}: expected root node`);
            assert.strictEqual(props(root).title, 'Header');
            const singleChild = props(root).child;
            assert.ok(isComponentNode(singleChild), `${label}: expected single child node`);
            assert.strictEqual(singleChild.componentId, 'single-kid');
            const listChildren = props(root).children;
            assert.strictEqual(listChildren.length, 2, `${label}: expected 2 list children`);
            assert.ok(listChildren.every(isComponentNode), `${label}: expected resolved list nodes`);
            assert.deepStrictEqual(listChildren.map(c => c.componentId), ['list-a', 'list-b']);
            // Updating properties disposes removed child nodes cleanly.
            const removedChild = listChildren[1];
            const rootModel = surface.componentsModel.get('root');
            rootModel.properties = { title: 'Updated', children: ['list-a'] };
            assert.strictEqual(removedChild.disposed, true, `${label}: removed child should dispose`);
            assert.strictEqual(singleChild.disposed, true, `${label}: omitted single child should dispose`);
            assert.strictEqual(Object.hasOwn(props(root), 'child'), false);
            assert.strictEqual(props(root).children.length, 1);
            resolver.dispose();
        }
    });
    it('resolves child and children for empty-shape z.object({}), passthrough, catchall, and Catalog.fromJson schemas', () => {
        const EmptyApi = { name: 'EmptyBox', schema: z.object({}) };
        const PassthroughApi = {
            name: 'PassthroughBox',
            schema: z.object({ variant: z.string().optional() }).passthrough(),
        };
        const CatchallApi = {
            name: 'CatchallBox',
            schema: z.object({ variant: z.string().optional() }).catchall(z.unknown()),
        };
        const catalog = new Catalog('open-obj-catalog', '0.9', [
            EmptyApi,
            PassthroughApi,
            CatchallApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-open', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'EmptyBox', { children: ['pt', 'ca'] });
        add(surface, 'pt', 'PassthroughBox', { variant: 'card', child: 'leaf-1' });
        add(surface, 'ca', 'CatchallBox', { variant: 'row', children: ['leaf-2'] });
        add(surface, 'leaf-1', 'Text', { text: 'Leaf 1' });
        add(surface, 'leaf-2', 'Text', { text: 'Leaf 2' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const [ptNode, caNode] = props(root).children;
        assert.ok(isComponentNode(ptNode));
        assert.ok(isComponentNode(caNode));
        assert.ok(isComponentNode(props(ptNode).child));
        assert.strictEqual(props(ptNode).child.componentId, 'leaf-1');
        const caChildren = props(caNode).children;
        assert.strictEqual(caChildren.length, 1);
        assert.ok(isComponentNode(caChildren[0]));
        assert.strictEqual(caChildren[0].componentId, 'leaf-2');
        resolver.dispose();
        const loadedJsonCatalog = Catalog.fromJson({
            catalogId: 'https://example.com/json-open.json',
            components: {
                DynamicContainer: {
                    type: 'object',
                    properties: { heading: { type: 'string' } },
                    additionalProperties: true,
                },
                UnannotatedStack: {
                    type: 'object',
                    properties: {
                        child: { type: 'string' },
                        children: { type: 'array', items: { type: 'string' } },
                    },
                },
                Label: {
                    type: 'object',
                    properties: { text: { type: 'string' } },
                    additionalProperties: false,
                },
            },
        });
        const jsonCatalog = new Catalog(loadedJsonCatalog.id, loadedJsonCatalog.protocolVersion, Array.from(loadedJsonCatalog.components.values()), []);
        const jsonSurface = new SurfaceModel('surf-json', jsonCatalog);
        const jsonResolver = new NodeResolver(jsonSurface, jsonCatalog);
        jsonSurface.componentsModel.addComponent(new ComponentModel('root', 'DynamicContainer', { heading: 'Top', child: 'stack' }, jsonCatalog));
        jsonSurface.componentsModel.addComponent(new ComponentModel('stack', 'UnannotatedStack', { child: 'lbl-1', children: ['lbl-2'] }, jsonCatalog));
        jsonSurface.componentsModel.addComponent(new ComponentModel('lbl-1', 'Label', { text: 'First' }, jsonCatalog));
        jsonSurface.componentsModel.addComponent(new ComponentModel('lbl-2', 'Label', { text: 'Second' }, jsonCatalog));
        const jsonRoot = getValue(jsonResolver.rootNode);
        assert.ok(jsonRoot);
        const stackNode = props(jsonRoot).child;
        assert.ok(isComponentNode(stackNode));
        assert.strictEqual(stackNode.componentId, 'stack');
        assert.ok(isComponentNode(props(stackNode).child));
        assert.strictEqual(props(stackNode).child.componentId, 'lbl-1');
        const stackChildren = props(stackNode).children;
        assert.strictEqual(stackChildren.length, 1);
        assert.ok(isComponentNode(stackChildren[0]));
        assert.strictEqual(stackChildren[0].componentId, 'lbl-2');
        jsonResolver.dispose();
    });
    it('resolves unannotated z.object({child, children}) alongside explicit custom ref fields without misclassifying incompatible types', () => {
        const UnannotatedApi = {
            name: 'UnannotatedLayout',
            schema: z.object({
                header: ComponentIdSchema.optional(),
                child: z.string().optional(),
                children: z.array(z.string()).optional(),
            }),
        };
        const IncompatibleApi = {
            name: 'IncompatibleFields',
            schema: z.object({
                child: z.boolean().optional(),
                children: z.number().optional(),
            }),
        };
        const catalog = new Catalog('mixed-catalog', '0.9', [
            UnannotatedApi,
            IncompatibleApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-mixed', catalog);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'UnannotatedLayout', {
            header: 'hdr',
            child: 'body',
            children: ['inc'],
        });
        add(surface, 'hdr', 'Text', { text: 'Header' });
        add(surface, 'body', 'Text', { text: 'Body' });
        add(surface, 'inc', 'IncompatibleFields', { child: true, children: 3 });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.ok(isComponentNode(props(root).header));
        assert.strictEqual(props(root).header.componentId, 'hdr');
        assert.ok(isComponentNode(props(root).child));
        assert.strictEqual(props(root).child.componentId, 'body');
        const [incNode] = props(root).children;
        assert.ok(isComponentNode(incNode));
        assert.strictEqual(props(incNode).child, true);
        assert.strictEqual(props(incNode).children, 3);
        resolver.dispose();
    });
    it('expands { componentId, path } templates into ComponentNode[] on unmarked, open, empty, and wrapped schemas', () => {
        const UnmarkedUnionListApi = {
            name: 'UnmarkedUnionList',
            schema: z.object({
                children: z
                    .union([z.array(z.string()), z.object({ componentId: z.string(), path: z.string() })])
                    .optional(),
            }),
        };
        const WrappedListApi = {
            name: 'WrappedList',
            schema: z.object({
                children: ChildListSchema.catch([]).pipe(z.any()).optional(),
            }),
        };
        const EmptyListApi = {
            name: 'EmptyList',
            schema: z.object({}),
        };
        const RecordListApi = {
            name: 'RecordList',
            schema: z.record(z.unknown()),
        };
        const catalog = new Catalog('template-catalog', '0.9', [
            UnmarkedUnionListApi,
            WrappedListApi,
            EmptyListApi,
            RecordListApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-tmpl', catalog);
        surface.dataModel.set('/items', [{ label: 'First' }, { label: 'Second' }]);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'UnmarkedUnionList', {
            children: ['wrapped', 'empty', 'record'],
        });
        add(surface, 'wrapped', 'WrappedList', {
            children: { componentId: 'item-tpl', path: '/items' },
        });
        add(surface, 'empty', 'EmptyList', {
            children: { componentId: 'item-tpl', path: '/items' },
        });
        add(surface, 'record', 'RecordList', {
            children: { componentId: 'item-tpl', path: '/items' },
        });
        add(surface, 'item-tpl', 'Text', { text: { path: 'label' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        const containers = props(root).children;
        assert.strictEqual(containers.length, 3);
        for (const container of containers) {
            const resolvedItems = props(container).children;
            assert.ok(Array.isArray(resolvedItems), `${container.type}: expected children array`);
            assert.strictEqual(resolvedItems.length, 2, `${container.type}: expected 2 expanded items`);
            assert.ok(resolvedItems.every(isComponentNode));
            assert.strictEqual(bound(resolvedItems[0], 'text'), 'First');
            assert.strictEqual(bound(resolvedItems[1], 'text'), 'Second');
        }
        // Verify unmarked union itself also expands a { componentId, path } template.
        const rootModel = surface.componentsModel.get('root');
        rootModel.properties = { children: { componentId: 'item-tpl', path: '/items' } };
        const expandedRootChildren = props(root).children;
        assert.strictEqual(expandedRootChildren.length, 2);
        assert.strictEqual(bound(expandedRootChildren[0], 'text'), 'First');
        assert.strictEqual(bound(expandedRootChildren[1], 'text'), 'Second');
        resolver.dispose();
    });
    it('resolves dynamic bindings, actions, accessibility, and child references on ZodIntersection, variant union, and ZodPipeline schemas', () => {
        const VariantAndIntersectedApi = {
            name: 'VariantContainer',
            schema: z
                .object({
                subtitle: DynamicStringSchema.optional(),
                onTap: ActionSchema.optional(),
            })
                .and(z.union([
                z.object({
                    mode: z.literal('single'),
                    title: DynamicStringSchema,
                    child: ComponentIdSchema.pipe(z.string()),
                }),
                z.object({
                    mode: z.literal('list'),
                    title: DynamicStringSchema,
                    children: ChildListSchema,
                }),
            ])),
        };
        const catalog = new Catalog('composite-catalog', '0.9', [
            VariantAndIntersectedApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-comp', catalog);
        surface.dataModel.set('/title', 'Hello Composite');
        surface.dataModel.set('/sub', 'Subtext');
        surface.dataModel.set('/a11y', 'Accessible Container');
        const actions = [];
        surface.onAction.subscribe(a => {
            actions.push(a);
        });
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'VariantContainer', {
            mode: 'single',
            title: { path: '/title' },
            subtitle: { path: '/sub' },
            child: 'kid-1',
            onTap: { event: { name: 'clicked' } },
            accessibility: { label: { path: '/a11y' } },
        });
        add(surface, 'kid-1', 'Text', { text: 'Child 1' });
        add(surface, 'kid-2', 'Text', { text: 'Child 2' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(bound(root, 'title'), 'Hello Composite');
        assert.strictEqual(bound(root, 'subtitle'), 'Subtext');
        const a11y = props(root).accessibility;
        assert.ok(a11y.label instanceof ResolvedBinding);
        assert.strictEqual(a11y.label.value, 'Accessible Container');
        assert.ok(isComponentNode(props(root).child));
        assert.strictEqual(props(root).child.componentId, 'kid-1');
        assert.strictEqual(typeof props(root).onTap, 'function');
        props(root).onTap();
        assert.strictEqual(actions.length, 1);
        // Switch variant to `list` and update bound data.
        surface.dataModel.set('/title', 'Updated Composite');
        surface.componentsModel.get('root').properties = {
            mode: 'list',
            title: { path: '/title' },
            children: ['kid-1', 'kid-2'],
        };
        assert.strictEqual(bound(root, 'title'), 'Updated Composite');
        assert.strictEqual(Object.hasOwn(props(root), 'child'), false);
        const listKids = props(root).children;
        assert.strictEqual(listKids.length, 2);
        assert.deepStrictEqual(listKids.map(k => k.componentId), ['kid-1', 'kid-2']);
        resolver.dispose();
    });
    it('resolves unannotated v0.8 entryPointChild and contentChild properties into ComponentNode instances', () => {
        const V08ModalApi = {
            name: 'Modal',
            schema: z.object({
                entryPointChild: z.string(),
                contentChild: z.string(),
            }),
        };
        const V08TextApi = {
            name: 'Text',
            schema: z.object({
                text: z.string(),
            }),
        };
        const v08Catalog = new Catalog('v08-custom', '0.8', [V08ModalApi, V08TextApi]);
        const surface = new SurfaceModel('surf-v08', v08Catalog);
        const resolver = new NodeResolver(surface, v08Catalog);
        add(surface, 'root', 'Modal', {
            entryPointChild: 'trigger-btn',
            contentChild: 'dialog-body',
        });
        add(surface, 'trigger-btn', 'Text', { text: 'Open' });
        add(surface, 'dialog-body', 'Text', { text: 'Modal Content' });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.ok(isComponentNode(props(root).entryPointChild));
        assert.strictEqual(props(root).entryPointChild.componentId, 'trigger-btn');
        assert.ok(isComponentNode(props(root).contentChild));
        assert.strictEqual(props(root).contentChild.componentId, 'dialog-body');
        resolver.dispose();
    });
    it('wraps dynamic bindings and actions on ZodRecord and .catchall() schemas into WritableBinding and prunes omitted entries', () => {
        const DynamicRecordApi = {
            name: 'DynamicRecordBox',
            schema: z
                .object({
                staticTag: z.string().optional(),
                child: ComponentIdSchema.optional(),
            })
                .catchall(DynamicStringSchema),
        };
        const ActionRecordApi = {
            name: 'ActionRecordBox',
            schema: z.record(ActionSchema),
        };
        const catalog = new Catalog('catchall-catalog', '0.9', [
            DynamicRecordApi,
            ActionRecordApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-catchall', catalog);
        surface.dataModel.set('/greeting', 'Initial Greeting');
        surface.dataModel.set('/note', 'Side Note');
        const dispatched = [];
        surface.onAction.subscribe(evt => {
            dispatched.push(evt);
        });
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'DynamicRecordBox', {
            staticTag: 'plain-tag',
            boundField: { path: '/greeting' },
            dropField: { path: '/note' },
            literalField: 'Static Catchall',
            child: 'actions-node',
        });
        add(surface, 'actions-node', 'ActionRecordBox', {
            primaryTap: { event: { name: 'primary' } },
        });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        assert.strictEqual(props(root).staticTag, 'plain-tag');
        assert.strictEqual(Object.hasOwn(props(root), 'setBoundField'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'setLiteralField'), false);
        const boundField = props(root).boundField;
        assert.ok(boundField instanceof WritableBinding);
        assert.strictEqual(boundField.value, 'Initial Greeting');
        boundField.set('Updated Via Catchall');
        assert.strictEqual(surface.dataModel.get('/greeting'), 'Updated Via Catchall');
        assert.strictEqual(props(root).boundField.value, 'Updated Via Catchall');
        const literalField = props(root).literalField;
        assert.ok(literalField instanceof ResolvedBinding);
        assert.strictEqual(literalField instanceof WritableBinding, false);
        assert.strictEqual(literalField.value, 'Static Catchall');
        const actionsNode = props(root).child;
        assert.ok(isComponentNode(actionsNode));
        assert.strictEqual(typeof props(actionsNode).primaryTap, 'function');
        props(actionsNode).primaryTap();
        assert.strictEqual(dispatched.length, 1);
        // Removing `dropField` prunes it cleanly while retaining `boundField`.
        surface.componentsModel.get('root').properties = {
            staticTag: 'plain-tag',
            boundField: { path: '/greeting' },
            child: 'actions-node',
        };
        assert.strictEqual(Object.hasOwn(props(root), 'dropField'), false);
        assert.strictEqual(Object.hasOwn(props(root), 'literalField'), false);
        resolver.dispose();
        surface.dispose();
    });
    it('resolves structured items, templates, string arrays, and single IDs on [list, nested] and [single, nested] unions in either branch order', () => {
        const StructuredSection = z.array(z.object({
            title: DynamicStringSchema,
            child: ComponentIdSchema,
        }));
        const ListFirstApi = {
            name: 'ListFirstSections',
            schema: z.union([
                z.object({ sections: ChildListSchema }),
                z.object({ sections: StructuredSection }),
            ]),
        };
        const NestedFirstApi = {
            name: 'NestedFirstSections',
            schema: z.object({
                sections: StructuredSection.or(ChildListSchema),
                slot: ComponentIdSchema.or(StructuredSection).optional(),
            }),
        };
        const catalog = new Catalog('union-nested-list-cat', '0.9', [
            ListFirstApi,
            NestedFirstApi,
            ColumnApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-union-nested', catalog);
        surface.dataModel.set('/secTitle', 'Dynamic Section Title');
        surface.dataModel.set('/rows', [{ label: 'Row A' }, { label: 'Row B' }]);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Column', { children: ['sec-structured', 'sec-template', 'sec-ids'] });
        add(surface, 'sec-structured', 'ListFirstSections', {
            sections: [{ title: { path: '/secTitle' }, child: 'leaf-1' }],
        });
        add(surface, 'sec-template', 'NestedFirstSections', {
            sections: { componentId: 'row-tpl', path: '/rows' },
            slot: 'leaf-2',
        });
        add(surface, 'sec-ids', 'ListFirstSections', {
            sections: ['leaf-1', 'leaf-2'],
        });
        add(surface, 'leaf-1', 'Text', { text: 'Leaf One' });
        add(surface, 'leaf-2', 'Text', { text: 'Leaf Two' });
        add(surface, 'row-tpl', 'Text', { text: { path: 'label' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        // 1. Structured array payload resolves `child` to ComponentNode and binds `title` to WritableBinding.
        const structuredNode = child(root, 'children', 0);
        const structuredSections = props(structuredNode).sections;
        assert.strictEqual(structuredSections.length, 1);
        assert.ok(structuredSections[0].title instanceof WritableBinding);
        assert.strictEqual(structuredSections[0].title.value, 'Dynamic Section Title');
        assert.ok(isComponentNode(structuredSections[0].child));
        assert.strictEqual(bound(structuredSections[0].child, 'text'), 'Leaf One');
        // 2. Template payload `{componentId, path}` expands into ComponentNode[] even when `nested` keys exist,
        //    and `[single, nested]` union resolves string `slot` into a ComponentNode.
        const templateNode = child(root, 'children', 1);
        const expandedSections = props(templateNode).sections;
        assert.strictEqual(expandedSections.length, 2);
        assert.ok(isComponentNode(expandedSections[0]));
        assert.ok(isComponentNode(expandedSections[1]));
        assert.strictEqual(bound(expandedSections[0], 'text'), 'Row A');
        assert.strictEqual(bound(expandedSections[1], 'text'), 'Row B');
        const slotChild = props(templateNode).slot;
        assert.ok(isComponentNode(slotChild));
        assert.strictEqual(bound(slotChild, 'text'), 'Leaf Two');
        // 3. Plain string ID list payload resolves into ComponentNode[].
        const idsNode = child(root, 'children', 2);
        const resolvedIds = props(idsNode).sections;
        assert.strictEqual(resolvedIds.length, 2);
        assert.strictEqual(bound(resolvedIds[0], 'text'), 'Leaf One');
        assert.strictEqual(bound(resolvedIds[1], 'text'), 'Leaf Two');
        resolver.dispose();
        surface.dispose();
    });
    it('resolves structured array branch of [single, nested] unions, narrowed [list, nested] templates, catchall child slots, and Catalog.fromJson oneOf dynamic child props', () => {
        const StructuredSection = z.array(z.object({
            title: CommonSchemas.DynamicString,
            child: ComponentIdSchema,
        }));
        const SingleOrNestedFirstApi = {
            name: 'SingleOrNestedFirst',
            schema: z.object({
                slot: ComponentIdSchema.or(StructuredSection).optional(),
            }),
        };
        const SingleOrNestedSecondApi = {
            name: 'SingleOrNestedSecond',
            schema: z.object({
                slot: StructuredSection.or(ComponentIdSchema).optional(),
            }),
        };
        const NarrowedListApi = {
            name: 'NarrowedList',
            schema: z
                .object({ sections: ChildListSchema.or(StructuredSection) })
                .and(z.object({ sections: ChildListSchema })),
        };
        const CatchallWithChildApi = {
            name: 'CatchallWithChild',
            schema: z.union([
                z.record(CommonSchemas.DynamicString),
                z.object({ fixed: CommonSchemas.Action, child: ComponentIdSchema.optional() }),
            ]),
        };
        const ActionRowsApi = {
            name: 'ActionRows',
            schema: z.object({
                rows: z.array(z.object({
                    componentId: z.string(),
                    path: z.string(),
                    iconChild: ComponentIdSchema.optional(),
                })),
            }),
        };
        const oneOfJsonCatalog = Catalog.fromJson({
            catalogId: 'oneof-dyn-child-cat',
            $defs: {
                DataBinding: {
                    type: 'object',
                    properties: { path: { type: 'string' } },
                    required: ['path'],
                },
                FunctionCall: {
                    type: 'object',
                    properties: { call: { type: 'string' } },
                    required: ['call'],
                },
                NestedBindingUnion: {
                    oneOf: [{ $ref: '#/$defs/DataBinding' }, { $ref: '#/$defs/FunctionCall' }],
                },
            },
            components: {
                DynamicChildProp: {
                    type: 'object',
                    properties: {
                        child: {
                            oneOf: [{ type: 'string' }, { $ref: '#/$defs/NestedBindingUnion' }],
                        },
                    },
                },
            },
        });
        const DynamicChildPropApi = oneOfJsonCatalog.components.get('DynamicChildProp');
        const catalog = new Catalog('union-edge-cat', '0.9', [
            SingleOrNestedFirstApi,
            SingleOrNestedSecondApi,
            NarrowedListApi,
            CatchallWithChildApi,
            ActionRowsApi,
            DynamicChildPropApi,
            ColumnApi,
            TextApi,
        ]);
        const surface = new SurfaceModel('surf-union-edge', catalog);
        surface.dataModel.set('/secTitle', 'Bound Item Title');
        surface.dataModel.set('/extraText', 'Bound Extra');
        surface.dataModel.set('/rows', [{ label: 'First' }, { label: 'Second' }]);
        const resolver = new NodeResolver(surface, catalog);
        add(surface, 'root', 'Column', {
            children: [
                'sn-first',
                'sn-second',
                'narrowed-tpl',
                'catchall-kid',
                'catchall-no-kid',
                'action-rows',
                'oneof-dyn-child',
            ],
        });
        add(surface, 'sn-first', 'SingleOrNestedFirst', {
            slot: [{ title: { path: '/secTitle' }, child: 'leaf-1' }],
        });
        add(surface, 'sn-second', 'SingleOrNestedSecond', {
            slot: [{ title: { path: '/secTitle' }, child: 'leaf-2' }],
        });
        add(surface, 'narrowed-tpl', 'NarrowedList', {
            sections: { componentId: 'row-tpl', path: '/rows' },
        });
        add(surface, 'catchall-kid', 'CatchallWithChild', {
            fixed: { event: { name: 'clicked' } },
            child: 'leaf-3',
            extra: { path: '/extraText' },
        });
        add(surface, 'catchall-no-kid', 'CatchallWithChild', {
            fixed: { event: { name: 'clicked-no-kid' } },
            extra: { path: '/extraText' },
        });
        add(surface, 'action-rows', 'ActionRows', {
            rows: [
                { componentId: 'not-a-template-id', path: '/route/settings' },
                { componentId: 'also-not-a-template-id', path: '/route/profile', iconChild: 'leaf-3' },
            ],
        });
        add(surface, 'oneof-dyn-child', 'DynamicChildProp', {
            child: { path: '/secTitle' },
        });
        add(surface, 'leaf-1', 'Text', { text: 'Leaf 1' });
        add(surface, 'leaf-2', 'Text', { text: 'Leaf 2' });
        add(surface, 'leaf-3', 'Text', { text: 'Leaf 3' });
        add(surface, 'row-tpl', 'Text', { text: { path: 'label' } });
        const root = getValue(resolver.rootNode);
        assert.ok(root);
        // 1 & 2: [single, nested] union resolves structured array branch in both orders,
        // and switching between array and single string ID disposes old children cleanly.
        for (const [idx, expectedText] of [
            [0, 'Leaf 1'],
            [1, 'Leaf 2'],
        ]) {
            const snNode = child(root, 'children', idx);
            const slotItems = props(snNode).slot;
            assert.strictEqual(slotItems.length, 1);
            assert.ok(slotItems[0].title instanceof WritableBinding);
            assert.strictEqual(slotItems[0].title.value, 'Bound Item Title');
            assert.ok(isComponentNode(slotItems[0].child));
            assert.strictEqual(bound(slotItems[0].child, 'text'), expectedText);
        }
        const prevNestedLeaf = props(child(root, 'children', 0)).slot[0].child;
        surface.componentsModel.get('sn-first').properties = { slot: 'leaf-3' };
        assert.strictEqual(prevNestedLeaf.disposed, true);
        const switchedSingle = props(child(root, 'children', 0)).slot;
        assert.ok(isComponentNode(switchedSingle));
        assert.strictEqual(bound(switchedSingle, 'text'), 'Leaf 3');
        // 3: Narrowed [list, nested] -> list expands {componentId, path} template into ComponentNode[].
        const narrowedNode = child(root, 'children', 2);
        const expanded = props(narrowedNode).sections;
        assert.strictEqual(expanded.length, 2);
        assert.strictEqual(bound(expanded[0], 'text'), 'First');
        assert.strictEqual(bound(expanded[1], 'text'), 'Second');
        // 4: Catchall + ComponentId + Action resolves `child` to ComponentNode, keeps `fixed` callable,
        // binds catchall `extra`, and leaves omitted `child` undefined instead of ResolvedBinding(undefined).
        const catchallNode = child(root, 'children', 3);
        assert.strictEqual(typeof props(catchallNode).fixed, 'function');
        assert.ok(isComponentNode(props(catchallNode).child));
        assert.strictEqual(bound(props(catchallNode).child, 'text'), 'Leaf 3');
        assert.ok(props(catchallNode).extra instanceof WritableBinding);
        assert.strictEqual(props(catchallNode).extra.value, 'Bound Extra');
        const catchallNoKidNode = child(root, 'children', 4);
        assert.strictEqual(typeof props(catchallNoKidNode).fixed, 'function');
        assert.strictEqual(Object.hasOwn(props(catchallNoKidNode), 'child'), false);
        assert.strictEqual(props(catchallNoKidNode).child, undefined);
        // 5: Nested-ref array item omitting optional `iconChild` is preserved as a plain object
        // rather than mistaken for a `{componentId, path}` template placeholder.
        const actionRowsNode = child(root, 'children', 5);
        const resolvedRows = props(actionRowsNode).rows;
        assert.strictEqual(resolvedRows.length, 2);
        assert.strictEqual(isComponentNode(resolvedRows[0]), false);
        assert.deepStrictEqual(resolvedRows[0], {
            componentId: 'not-a-template-id',
            path: '/route/settings',
        });
        assert.ok(isComponentNode(resolvedRows[1].iconChild));
        assert.strictEqual(bound(resolvedRows[1].iconChild, 'text'), 'Leaf 3');
        // 6: Catalog.fromJson oneOf DynamicString on `child` binds to DataModel instead of ComponentNode.
        const oneOfNode = child(root, 'children', 6);
        assert.ok(props(oneOfNode).child instanceof WritableBinding);
        assert.strictEqual(props(oneOfNode).child.value, 'Bound Item Title');
        resolver.dispose();
        surface.dispose();
    });
});
//# sourceMappingURL=node-resolver.test.js.map