/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, beforeEach } from 'node:test';
import { signal, computed, peekValue, getValue, setValue, effect, setSignalImplementation, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, } from '../reactivity/signals.js';
import { z } from 'zod';
import { DataModel } from '../state/data-model.js';
import { SurfaceModel } from '../state/surface-model.js';
import { DataContext, MAX_DYNAMIC_VALUE_DEPTH, getKnownSchemaKeys, validateFunctionArgs, isSingleAtKey, unescapeObjectKey, validateReservedDirectives, } from './data-context.js';
import { withActiveCallCatalogId } from './data-context-internal.js';
import { Catalog, createFunctionImplementation } from '../catalog/types.js';
import { FormatStringImplementation, NotImplementation, PluralizeImplementation, } from '../catalogs/basic/v1/functions/basic_functions.js';
import { MAX_FUNCTION_CALL_ARGS } from '../types/helpers.js';
import { A2uiCatalogError, A2uiExpressionError, A2uiRpcError, A2uiValidationError, } from '../errors.js';
const createTestDataContext = (model, path, functionInvoker = () => null, dispatchError = () => { }) => {
    const mockSurface = {
        dataModel: model,
        defaultCatalog: { invoker: functionInvoker },
        availableCatalogs: new Map(),
        dispatchError,
    };
    return new DataContext(mockSurface, path);
};
describe('DataContext', () => {
    let model;
    let context;
    beforeEach(() => {
        model = new DataModel({
            user: {
                name: 'Alice',
                address: {
                    city: 'Wonderland',
                },
            },
            list: ['a', 'b'],
        });
        context = createTestDataContext(model, '/user');
    });
    it('resolves relative paths', () => {
        assert.strictEqual(context.resolveDynamicValue({ path: 'name' }), 'Alice');
    });
    it('resolves absolute paths', () => {
        assert.strictEqual(context.resolveDynamicValue({ path: '/list/0' }), 'a');
    });
    it('resolves nested paths', () => {
        assert.strictEqual(context.resolveDynamicValue({ path: 'address/city' }), 'Wonderland');
    });
    it('updates data via relative path', () => {
        context.set('name', 'Bob');
        assert.strictEqual(model.get('/user/name'), 'Bob');
    });
    it('stores null on a pre-1.0 surface and removes the entry from v1.0', () => {
        const v09Surface = new SurfaceModel('s09', new Catalog('c09', '0.9', []), null, {}, false, model);
        new DataContext(v09Surface, '/user').set('name', null);
        assert.strictEqual(model.get('/user/name'), null);
        assert.ok('name' in model.get('/user'));
        const v10Surface = new SurfaceModel('s10', new Catalog('c10', '1.0', []), null, {}, false, model);
        new DataContext(v10Surface, '/user').set('name', null);
        assert.ok(!('name' in model.get('/user')));
        model.set('/user/name', 'Alice');
        new DataContext(model, '/user').set('name', null);
        assert.ok(!('name' in model.get('/user')));
    });
    it('creates nested context', () => {
        const addressContext = context.nested('address');
        assert.strictEqual(addressContext.path, '/user/address');
        assert.strictEqual(addressContext.resolveDynamicValue({ path: 'city' }), 'Wonderland');
    });
    it('creates nested context when constructed directly with a DataModel', () => {
        const directContext = new DataContext(model, '/user');
        const addressContext = directContext.nested('address');
        assert.strictEqual(addressContext.path, '/user/address');
        assert.strictEqual(addressContext.resolveDynamicValue({ path: 'city' }), 'Wonderland');
    });
    it('handles root context', () => {
        const rootContext = createTestDataContext(model, '/');
        assert.strictEqual(rootContext.resolveDynamicValue({ path: 'user/name' }), 'Alice');
    });
    it('subscribes relative path', () => {
        let called = false;
        context.subscribeDynamicValue({ path: 'name' }, val => {
            assert.strictEqual(val, 'Charlie');
            called = true;
        });
        context.set('name', 'Charlie');
        assert.strictEqual(called, true, 'Callback was never called');
    });
    it('resolves using resolveDynamicValue() method with literals', () => {
        // Literal
        assert.strictEqual(context.resolveDynamicValue('literal'), 'literal');
        // Path
        assert.strictEqual(context.resolveDynamicValue({ path: 'name' }), 'Alice');
        // Absolute Path
        assert.strictEqual(context.resolveDynamicValue({ path: '/list/0' }), 'a');
    });
    it('resolves literal arrays', () => {
        assert.deepStrictEqual(context.resolveDynamicValue(['literal', 'array']), ['literal', 'array']);
    });
    it('returns fully static arrays as-is without re-allocation', () => {
        const staticArray = ['literal', 1, true, null, [2, 'nested']];
        assert.strictEqual(context.resolveDynamicValue(staticArray), staticArray);
    });
    it('resolves arrays of DynamicValues element-wise', () => {
        assert.deepStrictEqual(context.resolveDynamicValue([{ path: 'name' }, 'literal']), [
            'Alice',
            'literal',
        ]);
    });
    it('resolves DynamicValues nested inside inner arrays', () => {
        assert.deepStrictEqual(context.resolveDynamicValue(['outer', [{ path: 'name' }, 'inner']]), [
            'outer',
            ['Alice', 'inner'],
        ]);
    });
    it('subscribes literal arrays as static', () => {
        let called = false;
        const sub = context.subscribeDynamicValue(['literal', 'array'], () => {
            called = true;
        });
        assert.deepStrictEqual(sub.value, ['literal', 'array']);
        // Simulate some generic path update that shouldn't trigger anything for this static sub
        context.set('name', 'Charlie');
        assert.strictEqual(called, false);
    });
    it('subscribes arrays containing path bindings reactively', () => {
        let latest;
        const sub = context.subscribeDynamicValue([{ path: 'name' }, 'x'], val => {
            latest = val;
        });
        assert.deepStrictEqual(sub.value, ['Alice', 'x']);
        context.set('name', 'Bob');
        assert.deepStrictEqual(latest, ['Bob', 'x']);
        sub.unsubscribe();
    });
    it('resolves nested DynamicValues inside and/or function args', () => {
        const fnInvoker = (name, args) => {
            if (name === 'and')
                return args.values.every((v) => !!v);
            if (name === 'or')
                return args.values.some((v) => !!v);
            if (name === 'required') {
                const val = args.value;
                if (val === null || val === undefined)
                    return false;
                if (typeof val === 'string' && val === '')
                    return false;
                return true;
            }
            return null;
        };
        const root = createTestDataContext(new DataModel({
            formData: { email: '', phone: '', zip: '', agree: false },
        }), '/', fnInvoker);
        const result = root.resolveDynamicValue({
            call: 'and',
            args: {
                values: [
                    { path: '/formData/agree' },
                    {
                        call: 'or',
                        args: {
                            values: [
                                { call: 'required', args: { value: { path: '/formData/email' } } },
                                { call: 'required', args: { value: { path: '/formData/phone' } } },
                            ],
                        },
                    },
                    { call: 'required', args: { value: { path: '/formData/zip' } } },
                ],
            },
            returnType: 'boolean',
        });
        assert.strictEqual(result, false);
        root.set('/formData/agree', true);
        root.set('/formData/email', 'a@b.com');
        root.set('/formData/zip', '12345');
        const valid = root.resolveDynamicValue({
            call: 'and',
            args: {
                values: [
                    { path: '/formData/agree' },
                    {
                        call: 'or',
                        args: {
                            values: [
                                { call: 'required', args: { value: { path: '/formData/email' } } },
                                { call: 'required', args: { value: { path: '/formData/phone' } } },
                            ],
                        },
                    },
                    { call: 'required', args: { value: { path: '/formData/zip' } } },
                ],
            },
            returnType: 'boolean',
        });
        assert.strictEqual(valid, true);
    });
    it('resolves function calls synchronously', () => {
        const fnInvoker = (name, args) => {
            if (name === 'add')
                return args.a + args.b;
            return null;
        };
        const ctx = createTestDataContext(model, '/user', fnInvoker);
        const result = ctx.resolveDynamicValue({
            call: 'add',
            args: { a: 1, b: 2 },
            returnType: 'any',
        });
        assert.strictEqual(result, 3);
    });
    it('dispatches generic error on function call without invoker synchronously', () => {
        let dispatchedError = null;
        const ctx = createTestDataContext(model, '/user', () => {
            throw new Error('Function invoker is not configured');
        }, err => {
            dispatchedError = err;
        });
        const result = ctx.resolveDynamicValue({
            call: 'add',
            args: {},
            returnType: 'any',
        });
        assert.strictEqual(result, undefined);
        assert.ok(dispatchedError);
        assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
    });
    it('resolves arbitrary plain objects and arrays recursively', () => {
        const obj = {
            foo: 'bar',
            nested: { path: 'name' },
            list: [{ path: 'address/city' }, 'literal'],
        };
        const resolved = context.resolveDynamicValue(obj);
        assert.deepStrictEqual(resolved, {
            foo: 'bar',
            nested: 'Alice',
            list: ['Wonderland', 'literal'],
        });
    });
    it('subscribes to plain objects reactively when nested dynamic values change', () => {
        const obj = { foo: 'bar', nested: { path: 'name' } };
        const sig = context.resolveSignal(obj);
        assert.deepStrictEqual(peekValue(sig), { foo: 'bar', nested: 'Alice' });
        context.set('name', 'Bob');
        assert.deepStrictEqual(peekValue(sig), { foo: 'bar', nested: 'Bob' });
    });
    it('subscribes to function calls with no args', () => {
        const fnInvoker = (name) => (name === 'getPi' ? Math.PI : 0);
        const ctx = createTestDataContext(model, '/', fnInvoker);
        let called = false;
        ctx.subscribeDynamicValue({ call: 'getPi', args: {}, returnType: 'any' }, () => {
            called = true;
        });
        assert.strictEqual(called, false);
    });
    it('returns undefined on function call without invoker reactively', () => {
        const ctx = createTestDataContext(model, '/user', () => {
            throw new Error('Function invoker is not configured');
        });
        const sub = ctx.subscribeDynamicValue({ call: 'add', args: {}, returnType: 'any' }, () => { });
        assert.strictEqual(sub.value, undefined);
    });
    it('subscribes to function call returning a signal', () => {
        const fnInvoker = (name) => {
            if (name === 'obs')
                return signal('hello');
            return null;
        };
        const ctx = createTestDataContext(model, '/', fnInvoker);
        let val;
        ctx.subscribeDynamicValue({ call: 'obs', args: {}, returnType: 'any' }, v => {
            val = v;
        });
        assert.ok(true); // Verification occurs by absence of crash, and coverage hits the switch
        assert.equal(val, undefined);
    });
    it('subscribes to invalid dynamic value reactively (falls back to literal signal)', () => {
        const obj = { unknown: 'thing' };
        const sub = context.subscribeDynamicValue(obj, () => { });
        assert.deepStrictEqual(sub.value, obj);
    });
    it('subscribes to function call with arguments reactively', () => {
        const fnInvoker = (name, args) => {
            if (name === 'greet')
                return `Hello ${args.name}`;
            return null;
        };
        const ctx = createTestDataContext(model, '/user', fnInvoker);
        const sub = ctx.subscribeDynamicValue({ call: 'greet', args: { name: { path: 'name' } }, returnType: 'any' }, () => { });
        assert.strictEqual(sub.value, 'Hello Alice');
        // Update inner path
        ctx.set('name', 'Bob');
        assert.strictEqual(sub.value, 'Hello Bob');
        sub.unsubscribe();
    });
    it('does not expose a transient undefined for nested Signal-returning calls when effects are deferred', () => {
        // Emulate a reactivity backend (e.g. Angular) where effects do not run
        // synchronously on creation but are queued until the next flush, in
        // creation order. Effects created during a flush are appended to the
        // same queue, mirroring Angular's root effect scheduler.
        const base = _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION;
        const queue = [];
        const flush = () => {
            while (queue.length > 0) {
                queue.shift()();
            }
        };
        setSignalImplementation({
            ...base,
            effect: fn => {
                let dispose;
                let cancelled = false;
                queue.push(() => {
                    if (!cancelled)
                        dispose = base.effect(fn);
                });
                return () => {
                    cancelled = true;
                    dispose?.();
                };
            },
        });
        try {
            const errors = [];
            const fnInvoker = (name, args) => {
                // Mirrors `areComponentsValid(...)`: takes arguments and returns a Signal.
                if (name === 'isAlice')
                    return computed(() => args.name === 'Alice');
                // Mirrors `not(...)`: rejects an undefined argument with a ZodError.
                if (name === 'not') {
                    z.any()
                        .refine(v => v !== undefined, 'Required')
                        .parse(args.value);
                    return !args.value;
                }
                return null;
            };
            const ctx = createTestDataContext(model, '/user', fnInvoker, e => errors.push(e));
            const observed = [];
            const sub = ctx.subscribeDynamicValue({
                call: 'not',
                args: { value: { call: 'isAlice', args: { name: { path: 'name' } }, returnType: 'any' } },
                returnType: 'any',
            }, v => observed.push(v));
            flush();
            assert.deepStrictEqual(errors, [], 'no spurious EXPRESSION_ERROR expected');
            assert.deepStrictEqual(observed, [false], 'parent must never observe undefined');
            assert.strictEqual(sub.value, false);
            // Reactivity is preserved: the forwarding effect still propagates updates.
            ctx.set('name', 'Bob');
            flush();
            assert.strictEqual(sub.value, true);
            assert.deepStrictEqual(errors, []);
            sub.unsubscribe();
        }
        finally {
            setSignalImplementation(base);
        }
    });
    describe('resolveAction', () => {
        it('resolves event actions and nested context objects recursively', () => {
            const action = {
                event: {
                    name: 'save',
                    context: {
                        id: { path: 'name' },
                        metadata: { nested: { path: 'address/city' } },
                    },
                },
            };
            const resolved = context.resolveAction(action);
            assert.deepStrictEqual(resolved, {
                event: {
                    name: 'save',
                    context: {
                        id: 'Alice',
                        metadata: { nested: 'Wonderland' },
                    },
                },
            });
        });
        it('resolves functionCall actions', () => {
            const fnInvoker = (name, args) => {
                if (name === 'greet')
                    return `Hello ${args.name}`;
                return null;
            };
            const ctx = createTestDataContext(model, '/user', fnInvoker);
            const action = {
                functionCall: {
                    call: 'greet',
                    args: { name: { path: 'name' } },
                },
            };
            const resolved = ctx.resolveAction(action);
            assert.strictEqual(resolved, 'Hello Alice');
        });
    });
    describe('Error Handling', () => {
        it('translates ZodError into A2uiExpressionError and dispatches error', () => {
            const invokerWithZodError = () => {
                throw new z.ZodError([
                    {
                        code: 'invalid_type',
                        expected: 'string',
                        received: 'number',
                        path: ['foo'],
                        message: 'Expected string, received number',
                    },
                ]);
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', invokerWithZodError, err => {
                dispatchedError = err;
            });
            const result = ctx.resolveDynamicValue({
                call: 'fail',
                args: {},
                returnType: 'any',
            });
            assert.strictEqual(result, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.expression, 'fail');
        });
        it('dispatches generic Error as EXPRESSION_ERROR to surface', () => {
            const invokerWithRegularError = () => {
                const err = new Error('Generic failure');
                err.stack = 'Mock stack trace containing secret paths';
                throw err;
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', invokerWithRegularError, err => {
                dispatchedError = err;
            });
            const result = ctx.resolveDynamicValue({
                call: 'fail',
                args: {},
                returnType: 'any',
            });
            assert.strictEqual(result, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.expression, 'fail');
            assert.strictEqual(dispatchedError.message, 'Generic failure');
            // Ensure stack trace is NOT leaked in details (CWE-209 prevention)
            assert.strictEqual(dispatchedError.details, undefined);
        });
        it('does not disclose V8 stack traces in surface error details (Issue #2385)', () => {
            const invokerThrowingRangeError = () => {
                throw new RangeError('toFixed() digits argument must be between 0 and 100');
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', invokerThrowingRangeError, err => {
                dispatchedError = err;
            });
            ctx.resolveDynamicValue({
                call: 'formatNumber',
                args: { value: 123, decimals: 200 },
                returnType: 'string',
            });
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.expression, 'formatNumber');
            assert.strictEqual(dispatchedError.message, 'toFixed() digits argument must be between 0 and 100');
            assert.strictEqual(dispatchedError.details, undefined);
        });
        it('handles null or undefined thrown values gracefully without crashing', () => {
            const invokerThrowingNull = () => {
                throw null;
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', invokerThrowingNull, err => {
                dispatchedError = err;
            });
            ctx.resolveDynamicValue({
                call: 'fail',
                args: {},
                returnType: 'any',
            });
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.message, 'An unexpected error occurred in function fail.');
            assert.strictEqual(dispatchedError.details, undefined);
        });
        it('dispatches A2uiExpressionError to surface', () => {
            const invokerWithExpressionError = () => {
                throw new A2uiExpressionError('Custom expr error', 'custom_func');
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', invokerWithExpressionError, err => {
                dispatchedError = err;
            });
            const result = ctx.resolveDynamicValue({
                call: 'fail',
                args: {},
                returnType: 'any',
            });
            assert.strictEqual(result, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.expression, 'custom_func');
        });
        it('handles errors thrown during reactive argument resolution', () => {
            const trigger = signal(false);
            const fnInvoker = (name) => {
                if (name === 'inner') {
                    return computed(() => {
                        if (getValue(trigger))
                            throw new A2uiExpressionError('Inner failure', 'inner_func');
                        return 'ok';
                    });
                }
                return 'outer-result';
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', fnInvoker, err => {
                dispatchedError = err;
            });
            const sub = ctx.subscribeDynamicValue({
                call: 'outer',
                args: {
                    arg: { call: 'inner', args: {} },
                },
                returnType: 'any',
            }, () => { });
            assert.strictEqual(sub.value, 'outer-result');
            assert.strictEqual(dispatchedError, null);
            setValue(trigger, true);
            // Accessing sub.value or the effect running triggers the catch.
            assert.strictEqual(sub.value, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.message, 'Inner failure');
        });
        it('handles generic errors thrown during reactive execution', () => {
            const trigger = signal(false);
            const fnInvoker = (name) => {
                if (name === 'inner') {
                    return computed(() => {
                        if (getValue(trigger))
                            throw new Error('Generic inner failure');
                        return 'ok';
                    });
                }
                return 'outer-result';
            };
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', fnInvoker, err => {
                dispatchedError = err;
            });
            const sub = ctx.subscribeDynamicValue({
                call: 'outer',
                args: {
                    arg: { call: 'inner', args: {} },
                },
                returnType: 'any',
            }, () => { });
            assert.strictEqual(sub.value, 'outer-result');
            assert.strictEqual(dispatchedError, null);
            setValue(trigger, true);
            assert.strictEqual(sub.value, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.strictEqual(dispatchedError.message, 'Generic inner failure');
        });
        it('guards against excessive recursion in resolveDynamicValue (Issue #2388)', () => {
            assert.strictEqual(MAX_DYNAMIC_VALUE_DEPTH, 1000);
            let nested = { path: '/val' };
            for (let i = 0; i <= MAX_DYNAMIC_VALUE_DEPTH + 10; i++) {
                nested = { call: 'wrap', args: { v: nested } };
            }
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', (_name, args) => args.v, err => {
                dispatchedError = err;
            });
            const result = ctx.resolveDynamicValue(nested);
            assert.strictEqual(result, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.ok(dispatchedError.message.includes('Maximum dynamic value nesting depth exceeded'));
        });
        it('guards against excessive recursion in resolveSignal / subscribeDynamicValue without call stack overflow (Issue #2388)', () => {
            let nested = { path: '/val' };
            for (let i = 0; i <= MAX_DYNAMIC_VALUE_DEPTH + 10; i++) {
                nested = { call: 'wrap', args: { v: nested } };
            }
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', (_name, args) => args.v, err => {
                dispatchedError = err;
            });
            const sub = ctx.subscribeDynamicValue(nested, () => { });
            assert.strictEqual(sub.value, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.ok(dispatchedError.message.includes('Maximum dynamic value nesting depth exceeded'));
            sub.unsubscribe();
        });
        it('evaluates legitimate nested expressions within depth limit correctly', () => {
            let nested = 5;
            for (let i = 0; i < 5; i++) {
                nested = { call: 'inc', args: { v: nested } };
            }
            let dispatchedError = null;
            const ctx = createTestDataContext(model, '/', (_name, args) => (args.v ?? 0) + 1, err => {
                dispatchedError = err;
            });
            const result = ctx.resolveDynamicValue(nested);
            assert.strictEqual(result, 10);
            assert.strictEqual(dispatchedError, null);
        });
    });
    describe('Function Argument Stripping & Resource Consumption (Issue #2384)', () => {
        it('getKnownSchemaKeys extracts keys from ZodObject and ZodEffects', () => {
            const objSchema = z.object({ a: z.string(), b: z.number() });
            assert.deepStrictEqual(getKnownSchemaKeys(objSchema), new Set(['a', 'b']));
            const refinedSchema = z
                .object({ value: z.any(), min: z.number().optional() })
                .refine(data => data.value !== undefined);
            assert.deepStrictEqual(getKnownSchemaKeys(refinedSchema), new Set(['value', 'min']));
            const passthroughSchema = z.object({ a: z.string() }).passthrough();
            assert.strictEqual(getKnownSchemaKeys(passthroughSchema), null);
            const unionSchema = z.union([z.object({ x: z.string() }), z.object({ y: z.number() })]);
            assert.deepStrictEqual(getKnownSchemaKeys(unionSchema), new Set(['x', 'y']));
            const intersectionSchema = z.intersection(z.object({ a: z.string() }), z.object({ b: z.number() }));
            assert.deepStrictEqual(getKnownSchemaKeys(intersectionSchema), new Set(['a', 'b']));
            const intersectionWithPassthrough = z.intersection(z.object({ a: z.string() }), z.object({ b: z.number() }).passthrough());
            assert.strictEqual(getKnownSchemaKeys(intersectionWithPassthrough), null);
        });
        it('validateFunctionArgs allows valid keys when schema is available', () => {
            const catalog = new Catalog('test-cat', '1.0', [], [
                {
                    name: 'testFunc',
                    returnType: 'string',
                    schema: z.object({ name: z.string(), age: z.number().optional() }),
                    execute: (args) => `Hello ${args.name}`,
                },
            ]);
            const validArgs = {
                name: 'Alice',
                age: 30,
            };
            assert.doesNotThrow(() => {
                validateFunctionArgs('testFunc', validArgs, catalog);
            });
        });
        it('validateFunctionArgs throws error on unknown arguments', () => {
            const catalog = new Catalog('test-cat', '1.0', [], [
                {
                    name: 'testFunc',
                    returnType: 'string',
                    schema: z.object({ name: z.string(), age: z.number().optional() }),
                    execute: (args) => `Hello ${args.name}`,
                },
            ]);
            const invalidArgs = {
                name: 'Alice',
                extra: 'junk',
            };
            assert.throws(() => validateFunctionArgs('testFunc', invalidArgs, catalog), (err) => {
                assert.strictEqual(err instanceof A2uiExpressionError, true);
                assert.match(err.message, /Unknown argument 'extra'/);
                return true;
            });
        });
        it('validateFunctionArgs throws error when exceeding maximum argument limits', () => {
            const catalog = new Catalog('test-cat', '1.0', [], [
                {
                    name: 'testFunc',
                    returnType: 'string',
                    schema: z.object({ name: z.string() }),
                    execute: (args) => `Hello ${args.name}`,
                },
            ]);
            const tooManyArgs = { name: 'Alice', extra1: 1, extra2: 2 };
            assert.throws(() => validateFunctionArgs('testFunc', tooManyArgs, catalog), (err) => {
                assert.strictEqual(err instanceof A2uiExpressionError, true);
                return true;
            });
            const excessiveArgs = {};
            for (let i = 0; i <= MAX_FUNCTION_CALL_ARGS + 5; i++)
                excessiveArgs[`k${i}`] = i;
            assert.throws(() => validateFunctionArgs('testFunc', excessiveArgs, catalog), (err) => {
                assert.strictEqual(err instanceof A2uiExpressionError, true);
                assert.match(err.message, /exceeds maximum allowed arguments count/);
                return true;
            });
        });
        it('resolveSignal dispatches error and prevents signal creation on unknown arguments', () => {
            const customModel = new DataModel({
                validVal: 'Alice',
                junkVal: 'Secret',
            });
            const catalog = new Catalog('test-cat', '1.0', [], [
                {
                    name: 'greet',
                    returnType: 'string',
                    schema: z.object({ name: z.string() }),
                    execute: (args) => `Hello ${args.name}`,
                },
            ]);
            let dispatchedError = null;
            const mockSurface = {
                dataModel: customModel,
                defaultCatalog: catalog,
                availableCatalogs: new Map(),
                dispatchError: (err) => {
                    dispatchedError = err;
                },
            };
            const ctx = new DataContext(mockSurface, '/');
            const sig = ctx.resolveSignal({
                '@call': 'greet',
                args: {
                    name: { '@path': '/validVal' },
                    junk: { '@path': '/junkVal' },
                },
                returnType: 'any',
            });
            assert.strictEqual(peekValue(sig), undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.match(dispatchedError.message, /Unknown argument 'junk'/);
        });
        it('resolveDynamicValue dispatches error on unknown arguments', () => {
            const catalog = new Catalog('test-cat', '1.0', [], [
                {
                    name: 'greet',
                    returnType: 'string',
                    schema: z.object({ name: z.string() }),
                    execute: (args) => `Hello ${args.name}`,
                },
            ]);
            let dispatchedError = null;
            const mockSurface = {
                dataModel: new DataModel({}),
                defaultCatalog: catalog,
                availableCatalogs: new Map(),
                dispatchError: (err) => {
                    dispatchedError = err;
                },
            };
            const ctx = new DataContext(mockSurface, '/');
            const res = ctx.resolveDynamicValue({
                '@call': 'greet',
                args: {
                    name: 'Alice',
                    junk: 'extra',
                },
                returnType: 'any',
            });
            assert.strictEqual(res, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.match(dispatchedError.message, /Unknown argument 'junk'/);
        });
    });
    describe('Multi-catalog function resolution', () => {
        const makeCatalog = (id, result) => new Catalog(id, '1.0', [], [
            {
                name: 'greet',
                returnType: 'string',
                schema: z.object({}),
                execute: () => result,
            },
        ]);
        const makeSurface = (defaultCatalog, available) => ({
            dataModel: new DataModel({}),
            defaultCatalog,
            availableCatalogs: new Map(available.map(c => [c.id, c])),
            dispatchError: () => { },
        });
        it('invokes the named catalog rather than the default in v1.0', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const secondary = makeCatalog('cat-secondary', 'from-secondary');
            const ctx = new DataContext(makeSurface(primary, [primary, secondary]), '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': 'greet', args: {}, catalogId: 'cat-secondary' }), 'from-secondary');
        });
        it('falls back to the default catalog when the call names none', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const secondary = makeCatalog('cat-secondary', 'from-secondary');
            const ctx = new DataContext(makeSurface(primary, [primary, secondary]), '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': 'greet', args: {} }), 'from-primary');
        });
        it('evaluates @index without a catalog on a surface without a default catalog', () => {
            const secondary = makeCatalog('cat-secondary', 'from-secondary');
            const surface = new SurfaceModel('no-default', undefined, new Map([[secondary.id, secondary]]), undefined, undefined, undefined, undefined, undefined, '1.0');
            const errors = [];
            surface.onError.subscribe(err => {
                errors.push(err);
            });
            surface.dataModel.set('/items', ['a', 'b', 'c']);
            const ctx = new DataContext(surface, '/items/2');
            const index = { '@call': '@index', args: { offset: 1 } };
            assert.strictEqual(ctx.resolveDynamicValue(index), 3);
            const sub = ctx.subscribeDynamicValue(index, () => { });
            assert.strictEqual(sub.value, 3);
            sub.unsubscribe();
            assert.deepStrictEqual(errors, []);
        });
        it('reports a system function call naming a catalogId as EXPRESSION_ERROR', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const surface = new SurfaceModel('with-default', primary, new Map([[primary.id, primary]]), undefined, undefined, undefined, undefined, undefined, '1.0');
            const errors = [];
            surface.onError.subscribe(err => {
                errors.push(err);
            });
            surface.dataModel.set('/items', ['a', 'b', 'c']);
            const ctx = new DataContext(surface, '/items/2');
            // Any catalogId value names a catalog, even the surface default's.
            for (const catalogId of [primary.id, '', undefined, 7]) {
                errors.length = 0;
                const index = { '@call': '@index', args: {}, catalogId };
                assert.strictEqual(ctx.resolveDynamicValue(index), undefined);
                const sub = ctx.subscribeDynamicValue(index, () => { });
                assert.strictEqual(sub.value, undefined);
                sub.unsubscribe();
                assert.strictEqual(errors.length, 2);
                for (const err of errors) {
                    assert.strictEqual(err.code, 'EXPRESSION_ERROR');
                    assert.match(err.message, /System function '@index' belongs to no catalog and must not name a catalogId/);
                }
            }
        });
        it('reports an unavailable named catalog through the surface error channel', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const surface = makeSurface(primary, [primary]);
            let dispatchedError = null;
            surface.dispatchError = (err) => {
                dispatchedError = err;
            };
            const ctx = new DataContext(surface, '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': 'greet', args: {}, catalogId: 'cat-missing' }), undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'CATALOG_ERROR');
            assert.match(dispatchedError.message, /Catalog not found: cat-missing/);
        });
        it('reports an unavailable named catalog on the reactive path as well', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const surface = makeSurface(primary, [primary]);
            let dispatchedError = null;
            surface.dispatchError = (err) => {
                dispatchedError = err;
            };
            const ctx = new DataContext(surface, '/');
            const sub = ctx.subscribeDynamicValue({ '@call': 'greet', args: {}, catalogId: 'cat-missing' }, () => { });
            assert.strictEqual(sub.value, undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'CATALOG_ERROR');
            assert.match(dispatchedError.message, /Catalog not found: cat-missing/);
            sub.unsubscribe();
        });
        it('reports a call naming no catalog on a surface without a default as CATALOG_ERROR', () => {
            const secondary = makeCatalog('cat-secondary', 'from-secondary');
            const surface = new SurfaceModel('no-default', undefined, new Map([[secondary.id, secondary]]), undefined, undefined, undefined, undefined, undefined, '1.0');
            const errors = [];
            surface.onError.subscribe(err => {
                errors.push(err);
            });
            const ctx = new DataContext(surface, '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': 'greet', args: {} }), undefined);
            assert.strictEqual(errors.length, 1);
            assert.strictEqual(errors[0].code, 'CATALOG_ERROR');
            assert.match(errors[0].message, /has no default catalog/);
        });
        it('reports a function missing from its resolved catalog as EXPRESSION_ERROR', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const secondary = makeCatalog('cat-secondary', 'from-secondary');
            const surface = makeSurface(primary, [primary, secondary]);
            const errors = [];
            surface.dispatchError = (err) => {
                errors.push(err);
            };
            const ctx = new DataContext(surface, '/');
            const call = { '@call': 'missing', args: {}, catalogId: 'cat-secondary' };
            assert.strictEqual(ctx.resolveDynamicValue(call), undefined);
            const sub = ctx.subscribeDynamicValue(call, () => { });
            assert.strictEqual(sub.value, undefined);
            sub.unsubscribe();
            assert.strictEqual(errors.length, 2);
            for (const err of errors) {
                assert.strictEqual(err.code, 'EXPRESSION_ERROR');
                assert.strictEqual(err.expression, 'missing');
                assert.match(err.message, /Function not found in catalog 'cat-secondary': missing/);
            }
        });
        it('reports an unknown system function as EXPRESSION_ERROR', () => {
            const primary = makeCatalog('cat-primary', 'from-primary');
            const surface = makeSurface(primary, [primary]);
            let dispatchedError = null;
            surface.dispatchError = (err) => {
                dispatchedError = err;
            };
            const ctx = new DataContext(surface, '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': '@nope', args: {} }), undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.match(dispatchedError.message, /@nope/);
        });
        it('reports a catalog error thrown while a resolved function runs as EXPRESSION_ERROR', () => {
            const throwing = new Catalog('cat-throwing', '1.0', [], [
                {
                    name: 'greet',
                    returnType: 'string',
                    schema: z.object({}),
                    execute: () => {
                        throw new A2uiCatalogError('thrown from inside the function');
                    },
                },
            ]);
            const surface = makeSurface(throwing, [throwing]);
            let dispatchedError = null;
            surface.dispatchError = (err) => {
                dispatchedError = err;
            };
            const ctx = new DataContext(surface, '/');
            assert.strictEqual(ctx.resolveDynamicValue({ '@call': 'greet', args: {} }), undefined);
            assert.ok(dispatchedError);
            assert.strictEqual(dispatchedError.code, 'EXPRESSION_ERROR');
            assert.match(dispatchedError.message, /thrown from inside the function/);
        });
    });
    describe('Phase 3 resolution parity (deep object recursion, hasPath, onWarning, index scope)', () => {
        it('recursively resolves dynamic bindings inside nested plain objects both synchronously and reactively', () => {
            const cat = new Catalog('cat', '0.9', []);
            const surface = new SurfaceModel('s1', cat);
            surface.dataModel.set('/user', { name: 'Alice', role: 'Admin' });
            const ctx = new DataContext(surface, '/');
            const nestedInput = {
                profile: {
                    displayName: { path: '/user/name' },
                    meta: {
                        roleLabel: { path: '/user/role' },
                        staticFlag: true,
                    },
                },
            };
            const resolved = ctx.resolveDynamicValue(nestedInput);
            assert.deepStrictEqual(resolved, {
                profile: {
                    displayName: 'Alice',
                    meta: {
                        roleLabel: 'Admin',
                        staticFlag: true,
                    },
                },
            });
            const updates = [];
            const sub = ctx.subscribeDynamicValue(nestedInput, val => updates.push(val));
            assert.strictEqual(sub.value.profile.displayName, 'Alice');
            surface.dataModel.set('/user/name', 'Bob');
            assert.strictEqual(updates.length, 1);
            assert.strictEqual(updates[0].profile.displayName, 'Bob');
            sub.unsubscribe();
        });
        it('emits MISSING_DATA_BINDING on surface.onWarning for absent paths but not for explicit null paths', () => {
            const cat = new Catalog('cat', '0.9', []);
            const surface = new SurfaceModel('s1', cat);
            surface.dataModel.set('/', { explicitNull: null });
            assert.strictEqual(surface.dataModel.hasPath('/explicitNull'), true);
            assert.strictEqual(surface.dataModel.hasPath('/missingKey'), false);
            const warnings = [];
            surface.onWarning.subscribe(w => {
                warnings.push(w);
            });
            const ctx = new DataContext(surface, '/');
            assert.strictEqual(ctx.resolveDynamicValue({ path: '/explicitNull' }), null);
            assert.strictEqual(warnings.length, 0);
            assert.strictEqual(ctx.resolveDynamicValue({ path: '/missingKey' }), undefined);
            assert.strictEqual(warnings.length, 1);
            assert.strictEqual(warnings[0].code, 'MISSING_DATA_BINDING');
            assert.strictEqual(warnings[0].path, '/missingKey');
            assert.match(warnings[0].message, /Preflight DataBinding Warning/);
            // Repeated resolution on the same context or a nested child context deduplicates the warning for that path
            assert.strictEqual(ctx.resolveDynamicValue({ path: '/missingKey' }), undefined);
            assert.strictEqual(warnings.length, 1);
            const childCtx = ctx.nested('/sub');
            assert.strictEqual(childCtx.resolveDynamicValue({ path: '/missingKey' }), undefined);
            assert.strictEqual(warnings.length, 1);
        });
        it('resolves getIndex() from explicit index or trailing numeric segment across parent chain', () => {
            const cat = new Catalog('cat', '0.9', []);
            const surface = new SurfaceModel('s1', cat);
            const rootCtx = new DataContext(surface, '/items/7/details');
            assert.strictEqual(rootCtx.getIndex(), undefined);
            const loopItemCtx = new DataContext(surface, '/items/7');
            assert.strictEqual(loopItemCtx.getIndex(), 7);
            const childCtx = loopItemCtx.nested('details/address');
            assert.strictEqual(childCtx.getIndex(), 7);
            const explicitOverrideCtx = loopItemCtx.nested('sub', 42);
            assert.strictEqual(explicitOverrideCtx.getIndex(), 42);
        });
    });
    describe('Reserved protocol prefix (@) and escaping in v1.0', () => {
        it('isSingleAtKey and unescapeObjectKey helper functions operate correctly', () => {
            assert.strictEqual(isSingleAtKey('@path'), true);
            assert.strictEqual(isSingleAtKey('@call'), true);
            assert.strictEqual(isSingleAtKey('@'), true);
            assert.strictEqual(isSingleAtKey('@@path'), false);
            assert.strictEqual(isSingleAtKey('@@@path'), false);
            assert.strictEqual(isSingleAtKey('path'), false);
            assert.strictEqual(isSingleAtKey('call'), false);
            assert.strictEqual(unescapeObjectKey('@@path'), '@path');
            assert.strictEqual(unescapeObjectKey('@@type'), '@type');
            assert.strictEqual(unescapeObjectKey('@@@path'), '@@path');
            assert.strictEqual(unescapeObjectKey('@path'), '@path');
            assert.strictEqual(unescapeObjectKey('path'), 'path');
            assert.doesNotThrow(() => validateReservedDirectives(['@path', '@call', '@@custom', 'normal'], '1.0'));
            assert.throws(() => validateReservedDirectives(['@unknown'], '1.0'), (err) => err instanceof A2uiValidationError && err.code === 'INVALID_RESERVED_KEY');
            assert.doesNotThrow(() => validateReservedDirectives(['@unknown'], '0.9'));
        });
        it('resolves @path and @call in a v1.0 surface context', () => {
            const cat = new Catalog('cat', '1.0', []);
            const surface = new SurfaceModel('s1', cat);
            surface.dataModel.set('/user', { name: 'Alice', role: 'Admin' });
            const ctx = new DataContext(surface, '/');
            const input = {
                profile: {
                    displayName: { '@path': '/user/name' },
                    role: { '@path': '/user/role' },
                },
            };
            const resolved = ctx.resolveDynamicValue(input);
            assert.deepStrictEqual(resolved, {
                profile: {
                    displayName: 'Alice',
                    role: 'Admin',
                },
            });
            const updates = [];
            const sub = ctx.subscribeDynamicValue(input, val => updates.push(val));
            assert.strictEqual(sub.value.profile.displayName, 'Alice');
            surface.dataModel.set('/user/name', 'Bob');
            assert.strictEqual(updates.length, 1);
            assert.strictEqual(updates[0].profile.displayName, 'Bob');
            sub.unsubscribe();
        });
        it('treats plain path and call keys as static literal data in v1.0', () => {
            const cat = new Catalog('cat', '1.0', []);
            const surface = new SurfaceModel('s1', cat);
            surface.dataModel.set('/user/name', 'Alice');
            const warnings = [];
            surface.onWarning.subscribe(w => {
                warnings.push(w);
            });
            const ctx = new DataContext(surface, '/');
            const literalInput = {
                metadata: {
                    path: '/var/log/app.log',
                    call: 'audit',
                },
            };
            const resolved = ctx.resolveDynamicValue(literalInput);
            assert.deepStrictEqual(resolved, {
                metadata: {
                    path: '/var/log/app.log',
                    call: 'audit',
                },
            });
            // No warnings emitted because plain "path" is not a DataBinding in v1.0
            assert.strictEqual(warnings.length, 0);
        });
        it('unescapes doubled @@ keys during dynamic evaluation in v1.0', () => {
            const cat = new Catalog('cat', '1.0', []);
            const surface = new SurfaceModel('s1', cat);
            surface.dataModel.set('/item/title', 'Widget');
            const ctx = new DataContext(surface, '/');
            const inputWithEscaping = {
                '@@path': '/static/file',
                '@@type': 'Card',
                dynamicTitle: { '@path': '/item/title' },
            };
            const resolved = ctx.resolveDynamicValue(inputWithEscaping);
            assert.deepStrictEqual(resolved, {
                '@path': '/static/file',
                '@type': 'Card',
                dynamicTitle: 'Widget',
            });
            const sub = ctx.subscribeDynamicValue(inputWithEscaping, () => { });
            assert.deepStrictEqual(sub.value, {
                '@path': '/static/file',
                '@type': 'Card',
                dynamicTitle: 'Widget',
            });
            sub.unsubscribe();
        });
        it('rejects unrecognized single-@ keys in v1.0 dynamic objects with A2uiValidationError', () => {
            const cat = new Catalog('cat', '1.0', []);
            const surface = new SurfaceModel('s1', cat);
            const ctx = new DataContext(surface, '/');
            assert.throws(() => ctx.resolveDynamicValue({ '@invalid': 123 }), (err) => err instanceof A2uiValidationError && err.code === 'INVALID_RESERVED_KEY');
            assert.throws(() => ctx.resolveDynamicValue({ '@if': true, then: 'yes' }), (err) => err instanceof A2uiValidationError && err.code === 'INVALID_RESERVED_KEY');
            assert.throws(() => ctx.resolveDynamicValue({ '@': 'bare' }), (err) => err instanceof A2uiValidationError && err.code === 'INVALID_RESERVED_KEY');
            // In pre-v1.0 (v0.9), single-@ keys are not rejected as protocol reserved keys
            const v09Cat = new Catalog('cat', '0.9', []);
            const v09Surface = new SurfaceModel('s1', v09Cat);
            const v09Ctx = new DataContext(v09Surface, '/');
            assert.doesNotThrow(() => v09Ctx.resolveDynamicValue({ '@custom': 'allowed in 0.9' }));
        });
    });
});
describe('DataContext asynchronous function arguments', () => {
    /** Resolves on the next macrotask, after every pending microtask has run. */
    const flush = () => new Promise(resolve => setTimeout(resolve, 0));
    const upper = createFunctionImplementation({
        name: 'upper',
        returnType: 'string',
        schema: z.object({ 'value': z.string() }),
    }, args => args.value.toUpperCase());
    const fetchText = createFunctionImplementation({
        name: 'fetchText',
        returnType: 'any',
        schema: z.object({ 'text': z.string() }),
    }, async (args) => {
        await Promise.resolve();
        return args.text;
    });
    const fail = createFunctionImplementation({ name: 'fail', returnType: 'any', schema: z.object({}) }, async () => {
        await Promise.resolve();
        throw new A2uiExpressionError('inner failure', 'fail');
    });
    const wrap = createFunctionImplementation({
        name: 'wrap',
        returnType: 'any',
        schema: z.object({ 'items': z.array(z.string()), 'meta': z.object({ 'label': z.string() }) }),
    }, args => ({ items: args.items, label: args.meta.label }));
    const guarded = createFunctionImplementation({
        name: 'guarded',
        returnType: 'string',
        schema: z.object({ 'value': z.string() }),
        requiresUserActivation: true,
    }, args => `guarded:${args.value}`);
    let surface;
    let ctx;
    let errors;
    beforeEach(() => {
        const catalog = new Catalog('cat', '1.0', [], [upper, fetchText, fail, wrap, guarded]);
        surface = new SurfaceModel('s1', catalog);
        surface.dataModel.set('/name', 'alice');
        ctx = new DataContext(surface, '/');
        errors = [];
        surface.onError.subscribe(e => {
            errors.push(e);
        });
    });
    const call = (name, args) => ({ '@call': name, args });
    it('keeps a synchronous call synchronous', () => {
        assert.strictEqual(ctx.resolveDynamicValue(call('upper', { value: { '@path': '/name' } })), 'ALICE');
        assert.strictEqual(errors.length, 0);
    });
    it('settles an asynchronous inner result before validating the outer call', async () => {
        const result = ctx.resolveDynamicValue(call('upper', { value: call('fetchText', { text: 'hello' }) }));
        assert.strictEqual(typeof result.then, 'function');
        assert.strictEqual(await result, 'HELLO');
        assert.strictEqual(errors.length, 0);
    });
    it('settles Promises nested in arrays and objects of the arguments', async () => {
        const result = await ctx.resolveDynamicValue(call('wrap', {
            items: [call('fetchText', { text: 'a' }), 'b', call('fetchText', { text: 'c' })],
            meta: { label: call('fetchText', { text: 'tag' }) },
        }));
        assert.deepStrictEqual(result, { items: ['a', 'b', 'c'], label: 'tag' });
        assert.strictEqual(errors.length, 0);
    });
    it('reports an inner rejection once, at the top level, and resolves to undefined', async () => {
        const result = await ctx.resolveDynamicValue(call('upper', { value: call('upper', { value: call('fail', {}) }) }));
        assert.strictEqual(result, undefined);
        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0].code, 'EXPRESSION_ERROR');
        assert.strictEqual(errors[0].message, 'inner failure');
        assert.strictEqual(errors[0].expression, 'fail');
    });
    it('reports a validation failure of the outer call after its arguments settle', async () => {
        const result = await ctx.resolveDynamicValue(call('wrap', { items: call('fetchText', { text: 'not an array' }), meta: { label: 'x' } }));
        assert.strictEqual(result, undefined);
        assert.strictEqual(errors.length, 1);
        assert.match(errors[0].message, /Validation failed for function 'wrap'/);
    });
    it('resolves an action whose function call has an asynchronous argument', async () => {
        const result = await ctx.resolveAction({
            functionCall: call('upper', { value: call('fetchText', { text: 'clicked' }) }),
        });
        assert.strictEqual(result, 'CLICKED');
    });
    it('enforces user activation before awaiting an asynchronous argument', async () => {
        const passive = ctx.resolveSignal(call('guarded', { value: call('fetchText', { text: 'x' }) }));
        assert.strictEqual(peekValue(passive), undefined);
        assert.strictEqual(errors.length, 1);
        assert.match(errors[0].message, /requires user activation/);
        passive.unsubscribe?.();
        errors.length = 0;
        const activated = await ctx.resolveAction({
            functionCall: call('guarded', { value: call('fetchText', { text: 'x' }) }),
        });
        assert.strictEqual(activated, 'guarded:x');
        assert.strictEqual(errors.length, 0);
    });
    it('exposes an asynchronous result through a signal once it settles', async () => {
        const sig = ctx.resolveSignal(call('fetchText', { text: { '@path': '/name' } }));
        assert.strictEqual(peekValue(sig), undefined);
        await flush();
        assert.strictEqual(peekValue(sig), 'alice');
        const seen = [];
        const dispose = effect(() => {
            seen.push(getValue(sig));
        });
        surface.dataModel.set('/name', 'bob');
        await flush();
        assert.deepStrictEqual(seen, ['alice', 'bob']);
        dispose();
        sig.unsubscribe?.();
    });
    it('ignores a stale completion that arrives after the subscription ended', async () => {
        let release;
        const slow = createFunctionImplementation({ name: 'slow', returnType: 'any', schema: z.object({ 'value': z.string() }) }, () => new Promise(resolve => (release = resolve)));
        const catalog = new Catalog('cat', '1.0', [], [slow]);
        const slowSurface = new SurfaceModel('s2', catalog);
        slowSurface.dataModel.set('/v', 'first');
        const slowCtx = new DataContext(slowSurface, '/');
        const sub = slowCtx.subscribeDynamicValue(call('slow', { value: { '@path': '/v' } }), () => { });
        assert.strictEqual(sub.value, undefined);
        sub.unsubscribe();
        release('late');
        await flush();
        assert.strictEqual(sub.value, undefined);
    });
    it('ignores a stale completion when the arguments changed before it arrived', async () => {
        const pending = [];
        const slow = createFunctionImplementation({ name: 'slow', returnType: 'any', schema: z.object({ 'value': z.string() }) }, () => new Promise(resolve => pending.push(resolve)));
        const catalog = new Catalog('cat', '1.0', [], [slow]);
        const slowSurface = new SurfaceModel('s2', catalog);
        slowSurface.dataModel.set('/v', 'first');
        const slowCtx = new DataContext(slowSurface, '/');
        const sig = slowCtx.resolveSignal(call('slow', { value: { '@path': '/v' } }));
        slowSurface.dataModel.set('/v', 'second');
        assert.strictEqual(pending.length, 2);
        pending[1]('second');
        await flush();
        assert.strictEqual(peekValue(sig), 'second');
        pending[0]('first');
        await flush();
        assert.strictEqual(peekValue(sig), 'second');
        sig.unsubscribe?.();
    });
    it('reports a rejected signal evaluation as an EXPRESSION_ERROR', async () => {
        const sig = ctx.resolveSignal(call('fail', {}));
        assert.strictEqual(peekValue(sig), undefined);
        assert.strictEqual(errors.length, 0);
        await flush();
        assert.strictEqual(peekValue(sig), null);
        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0].code, 'EXPRESSION_ERROR');
        assert.strictEqual(errors[0].message, 'inner failure');
        sig.unsubscribe?.();
    });
    it('resolves a failed agent binding to null and reports EXPRESSION_ERROR with functionCallId', async () => {
        surface.agentFunctionCaller = () => Promise.reject(new A2uiRpcError('remote failure', 'EXECUTION_ERROR', 'call-99'));
        const sig = ctx.resolveSignal(call('remoteFn', {}));
        assert.strictEqual(peekValue(sig), undefined);
        await flush();
        assert.strictEqual(peekValue(sig), null);
        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0].code, 'EXPRESSION_ERROR');
        assert.strictEqual(errors[0].functionCallId, 'call-99');
        assert.strictEqual(errors[0].surfaceId, undefined);
        sig.unsubscribe?.();
    });
    it('halts an action pipeline on an agent failure while keeping earlier effects', async () => {
        const markStarted = createFunctionImplementation({ name: 'markStarted', returnType: 'boolean', schema: z.object({}) }, (_args, c) => {
            c.set('/started', true);
            return true;
        });
        const finish = createFunctionImplementation({ name: 'finish', returnType: 'boolean', schema: z.object({ 'steps': z.array(z.any()) }) }, (_args, c) => {
            c.set('/finished', true);
            return true;
        });
        const cat = new Catalog('cat', '1.0', [], [markStarted, finish]);
        const actionSurface = new SurfaceModel('s-act', cat);
        actionSurface.agentFunctionCaller = () => Promise.reject(new A2uiRpcError('step failed', 'EXECUTION_ERROR', 'call-step-1'));
        const actionErrors = [];
        actionSurface.onError.subscribe(e => {
            actionErrors.push(e);
        });
        const actionCtx = new DataContext(actionSurface, '/');
        const result = await actionCtx.resolveAction({
            functionCall: call('finish', {
                steps: [call('markStarted', {}), call('remoteStep', {})],
            }),
        });
        assert.strictEqual(result, undefined);
        assert.deepStrictEqual(actionSurface.dataModel.get('/'), { started: true });
        assert.strictEqual(actionErrors.length, 1);
        assert.strictEqual(actionErrors[0].code, 'EXPRESSION_ERROR');
        assert.strictEqual(actionErrors[0].functionCallId, 'call-step-1');
    });
    it('leaves a thenable alone when resolving a value synchronously', () => {
        const pendingValue = Promise.resolve('x');
        assert.strictEqual(ctx.resolveDynamicValue(pendingValue), pendingValue);
        assert.strictEqual(ctx.resolveDynamicValue({ nested: pendingValue }).nested, pendingValue);
    });
    it('inherits formatString catalogId for v1.0 template calls while keeping @index catalogless', () => {
        const basicId = 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json';
        const basicCat = new Catalog(basicId, '1.0', [], [FormatStringImplementation, NotImplementation, PluralizeImplementation]);
        const defaultlessSurface = new SurfaceModel('s-no-default', undefined, new Map([[basicId, basicCat]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const errors = [];
        defaultlessSurface.onError.subscribe(e => {
            errors.push(e);
        });
        const itemCtx = new DataContext(defaultlessSurface, '/items/2', 2);
        const callExpr = {
            '@call': 'formatString',
            catalogId: basicId,
            args: {
                value: "Row ${@index()}: ${pluralize(value: 2, one: 'drop', other: 'drops')} (${not(value: not(value: true))})",
            },
        };
        assert.strictEqual(itemCtx.resolveDynamicValue(callExpr), 'Row 2: drops (true)');
        assert.strictEqual(getValue(itemCtx.resolveSignal(callExpr)), 'Row 2: drops (true)');
        assert.strictEqual(errors.length, 0);
    });
    it('scopes formatString template calls to formatString catalogId even when surface.defaultCatalog differs', () => {
        const basicId = 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json';
        const basicCat = new Catalog(basicId, '1.0', [], [FormatStringImplementation, PluralizeImplementation]);
        const otherDefaultCat = new Catalog('https://example.com/other/catalog.json', '1.0', [], []);
        const mixedSurface = new SurfaceModel('s-mixed', otherDefaultCat, new Map([
            [otherDefaultCat.id, otherDefaultCat],
            [basicId, basicCat],
        ]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const errors = [];
        mixedSurface.onError.subscribe(e => {
            errors.push(e);
        });
        const itemCtx = new DataContext(mixedSurface, '/items/1', 1);
        const callExpr = {
            '@call': 'formatString',
            catalogId: basicId,
            args: {
                value: "Item ${@index()}: ${pluralize(value: 1, one: 'drop', other: 'drops')}",
            },
        };
        assert.strictEqual(itemCtx.resolveDynamicValue(callExpr), 'Item 1: drop');
        assert.strictEqual(getValue(itemCtx.resolveSignal(callExpr)), 'Item 1: drop');
        assert.strictEqual(errors.length, 0);
    });
    it('scopes formatString template calls when invoked directly via Catalog.invoker or over partial surface stand-ins', () => {
        const basicId = 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json';
        const basicCat = new Catalog(basicId, '1.0', [], [FormatStringImplementation, PluralizeImplementation]);
        const extHelper = createFunctionImplementation({
            name: 'extOnly',
            returnType: 'string',
            schema: z.object({}),
        }, () => 'from-ext');
        const extCat = new Catalog('https://example.com/ext/catalog.json', '1.0', [], [FormatStringImplementation, extHelper]);
        // 1. Direct `basicCat.invoker(...)` on a defaultless surface.
        const defaultlessSurface = new SurfaceModel('s-direct-defaultless', undefined, new Map([[basicId, basicCat]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const defaultlessErrors = [];
        defaultlessSurface.onError.subscribe(e => {
            defaultlessErrors.push(e);
        });
        const defaultlessCtx = new DataContext(defaultlessSurface, '/');
        const directRes = basicCat.invoker('formatString', { value: "${pluralize(value: 2, one: 'drop', other: 'drops')}" }, defaultlessCtx);
        assert.strictEqual(getValue(directRes), 'drops');
        assert.strictEqual(defaultlessErrors.length, 0);
        // 2. Direct `extCat.invoker(...)` when `surface.defaultCatalog !== extCat` and `extCat` is standalone.
        const surfaceWithBasicDefault = new SurfaceModel('s-direct-mixed', basicCat, new Map([[basicId, basicCat]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const mixedErrors = [];
        surfaceWithBasicDefault.onError.subscribe(e => {
            mixedErrors.push(e);
        });
        const mixedCtx = new DataContext(surfaceWithBasicDefault, '/');
        const extRes = extCat.invoker('formatString', { value: 'Got ${extOnly()}' }, mixedCtx);
        assert.strictEqual(getValue(extRes), 'Got from-ext');
        assert.strictEqual(mixedErrors.length, 0);
        // 3. Partial surface stand-in with empty `availableCatalogs` and `defaultCatalog: basicCat`.
        const standInErrors = [];
        const standInSurface = {
            id: 'stand-in',
            dataModel: new DataModel(),
            defaultCatalog: basicCat,
            availableCatalogs: new Map(),
            protocolVersion: '1.0',
            dispatchError: (err) => {
                standInErrors.push(err);
            },
        };
        const standInCtx = new DataContext(standInSurface, '/');
        assert.strictEqual(standInCtx.resolveDynamicValue({
            '@call': 'formatString',
            args: { value: "${pluralize(value: 2, one: 'drop', other: 'drops')}" },
        }), 'drops');
        assert.strictEqual(standInErrors.length, 0);
        // 4. Surface-less `new DataContext(new DataModel(), '/')` invoked via `basicCat.invoker(...)`.
        const surfacelessCtx = new DataContext(new DataModel(), '/');
        assert.strictEqual(surfacelessCtx.atLeastV10, false);
        const surfacelessRes = basicCat.invoker('formatString', { value: "Standalone: ${pluralize(value: 1, one: 'item', other: 'items')}" }, surfacelessCtx);
        assert.strictEqual(getValue(surfacelessRes), 'Standalone: item');
        assert.strictEqual(surfacelessCtx.atLeastV10, false);
        // 5. Same-ID negotiated schema-only surface catalog + executable `basicCat.invoker(...)`
        // (including when `ctx` was pre-scoped to `basicId` without `basicCat`).
        const schemaOnlyBasic = Catalog.fromJson({
            catalogId: basicId,
            protocolVersion: '1.0',
            components: {},
            functions: {
                formatString: {
                    returnType: 'string',
                    parameters: { type: 'object', properties: { value: { type: 'string' } } },
                },
                pluralize: {
                    returnType: 'string',
                    parameters: {
                        type: 'object',
                        properties: {
                            value: { type: 'number' },
                            one: { type: 'string' },
                            other: { type: 'string' },
                        },
                    },
                },
            },
        }, '1.0');
        const schemaOnlySurface = new SurfaceModel('s-schema-only-invoker', schemaOnlyBasic, new Map([[basicId, schemaOnlyBasic]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const schemaOnlyErrors = [];
        schemaOnlySurface.onError.subscribe(e => {
            schemaOnlyErrors.push(e);
        });
        const schemaOnlyCtx = new DataContext(schemaOnlySurface, '/');
        const preScopedCtx = withActiveCallCatalogId(schemaOnlyCtx, basicId);
        const schemaOnlyRes = basicCat.invoker('formatString', { value: "Count: ${pluralize(value: 1, one: 'drop', other: 'drops')}" }, preScopedCtx);
        assert.strictEqual(getValue(schemaOnlyRes), 'Count: drop');
        assert.strictEqual(schemaOnlyErrors.length, 0);
        // 6. Nested `DataContext` with an inner catalog scope does not leak an ancestor's standalone catalog.
        const rpcScoped = withActiveCallCatalogId(mixedCtx, extCat.id, extCat);
        const innerScoped = withActiveCallCatalogId(rpcScoped.nested('/items/0', 0), basicId, basicCat);
        assert.strictEqual(innerScoped.resolveDynamicValue({ '@call': 'extOnly', catalogId: extCat.id, args: {} }), undefined);
        assert.strictEqual(mixedErrors.length, 1);
        assert.strictEqual(mixedErrors[0].code, 'CATALOG_ERROR');
    });
    it('rejects __proto__ arguments in formatString template calls as own unknown arguments', () => {
        const basicId = 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json';
        const basicCat = new Catalog(basicId, '1.0', [], [FormatStringImplementation, PluralizeImplementation]);
        const surfaceWithBasic = new SurfaceModel('s-proto', basicCat, new Map([[basicId, basicCat]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        surfaceWithBasic.dataModel.set('/secret', { leaked: true });
        const errors = [];
        surfaceWithBasic.onError.subscribe(e => {
            errors.push(e);
        });
        const protoCtx = new DataContext(surfaceWithBasic, '/');
        const expr = {
            '@call': 'formatString',
            args: {
                value: "Count: ${pluralize(__proto__: /secret, value: 2, one: 'drop', other: 'drops')}",
            },
        };
        assert.strictEqual(protoCtx.resolveDynamicValue(expr), 'Count: ');
        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0].code, 'EXPRESSION_ERROR');
        assert.match(errors[0].message ?? '', /Unknown argument '__proto__'/);
        assert.strictEqual({}['leaked'], undefined);
    });
});
//# sourceMappingURL=data-context.test.js.map