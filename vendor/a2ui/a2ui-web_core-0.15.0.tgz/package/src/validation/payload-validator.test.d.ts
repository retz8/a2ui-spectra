export {};
//# sourceMappingURL=payload-validator.test.d.ts.map