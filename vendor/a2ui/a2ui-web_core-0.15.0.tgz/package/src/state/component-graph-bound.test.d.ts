export {};
//# sourceMappingURL=component-graph-bound.test.d.ts.map