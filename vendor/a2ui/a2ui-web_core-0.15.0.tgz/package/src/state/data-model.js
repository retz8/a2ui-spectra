/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiDataError } from '../errors.js';
import { batchWrite, effect, getValue, peekValue, setValue, signal, } from '../reactivity/signals.js';
function isNumeric(value) {
    return /^(0|[1-9]\d*)$/.test(value);
}
/**
 * The maximum array index that auto-vivification and array mutations will expand to.
 * Prevents OOM and thread hangs from excessively large indices.
 */
export const MAX_ARRAY_INDEX = 10000;
/**
 * Keys forbidden in path resolution to prevent prototype pollution
 * vulnerabilities. Accessing or mutating these keys via object paths can allow
 * attackers to modify Object.prototype or Function.prototype.
 */
const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
function cloneValue(val) {
    if (val === null || val === undefined || typeof val !== 'object') {
        return val;
    }
    if (Array.isArray(val)) {
        return val.map(item => cloneValue(item));
    }
    const proto = Object.getPrototypeOf(val);
    if (proto === Object.prototype || proto === null) {
        const out = {};
        for (const [k, v] of Object.entries(val)) {
            // Define rather than assign, so a JSON-parsed `__proto__` key stays an
            // inert own property instead of becoming the clone's prototype.
            Object.defineProperty(out, k, {
                value: cloneValue(v),
                enumerable: true,
                writable: true,
                configurable: true,
            });
        }
        return out;
    }
    return val;
}
/**
 * Observable data store representing the renderer-side state.
 *
 * Handles JSON Pointer path resolution, mutation, and reactive subscriptions.
 */
export class DataModel {
    /**
     * Initializes a new `DataModel` instance.
     *
     * @param initialData Initial data for the model. Defaults to an empty object.
     */
    constructor(initialData = {}) {
        this.data = {};
        this.signals = new Map();
        this.subscriptions = new Set(); // To track direct subscriptions for dispose
        this.data = cloneValue(initialData);
    }
    /**
     * Retrieves a Preact Signal for a specific data path.
     *
     * This provides a reactive way to access a value. If the value at the path
     * changes via `set()`, the signal will automatically be updated.
     *
     * @param path The JSON pointer path to create or retrieve a signal for.
     * @returns A Preact Signal representing the value at the specified path.
     * @throws {A2uiDataError} If path is null, undefined, or contains forbidden
     *     segments (`__proto__`, `constructor`, `prototype`).
     */
    getSignal(path) {
        const normalizedPath = this.normalizePath(path);
        if (!this.signals.has(normalizedPath)) {
            this.signals.set(normalizedPath, signal(this.get(normalizedPath)));
        }
        return this.signals.get(normalizedPath);
    }
    /**
     * Updates the model at the specific path and notifies all relevant signals.
     * If path is '/' or empty, replaces the entire root.
     *
     * Note on `undefined` values:
     * - For objects: Setting a property to `undefined` removes the key from the
     * object.
     * - For arrays: Setting an index to `undefined` sets that index to
     * `undefined` but preserves the array length (sparse array).
     *
     * @param path The JSON pointer path to set value for.
     * @param value The value to set at the specified path.
     * @param preserveNull Whether to store `null` as a value instead of treating
     *     it like `undefined`. Pre-1.0 data models stored `null`; the v1.0
     *     protocol removes the entry.
     * @returns This `DataModel` instance for chaining.
     * @throws {A2uiDataError} If path is null, undefined, invalid for
     *     arrays/primitives, exceeds max array bounds, or contains forbidden
     *     segments (`__proto__`, `constructor`, `prototype`).
     */
    set(path, value, preserveNull = false) {
        if (path === null || path === undefined) {
            throw new A2uiDataError('Path cannot be null or undefined.');
        }
        const segments = this.parsePath(path);
        if (segments.length === 0) {
            this.data = value === null || value === undefined ? {} : cloneValue(value);
            this.notifyAllSignals();
            return this;
        }
        const lastSegment = segments.pop();
        const removes = value === undefined || (!preserveNull && value === null);
        if (removes && this.get(path) === undefined) {
            return this;
        }
        // Only an absent root is replaced with a container. A primitive root is a
        // value the caller put there, and writing a path through it is the same
        // error as writing through a primitive at any other depth.
        if (this.data === undefined || this.data === null) {
            this.data = {};
        }
        else if (typeof this.data !== 'object') {
            throw new A2uiDataError(`Cannot set path '${path}': the data model root is a primitive value.`, path);
        }
        let current = this.data;
        for (let i = 0; i < segments.length; i++) {
            const segment = segments[i];
            if (Array.isArray(current)) {
                if (!isNumeric(segment)) {
                    throw new A2uiDataError(`Cannot use non-numeric segment '${segment}' on an array in path '${path}'.`, path);
                }
                const index = parseInt(segment, 10);
                if (index > MAX_ARRAY_INDEX) {
                    throw new A2uiDataError(`Cannot set path '${path}': array index '${segment}' exceeds maximum supported index (${MAX_ARRAY_INDEX}).`, path);
                }
                // If we encounter a primitive where a container is expected, we cannot
                // proceed. We allow undefined/null to be overwritten by a new
                // container.
                const val = current[index];
                if (val !== undefined && val !== null && typeof val !== 'object') {
                    throw new A2uiDataError(`Cannot set path '${path}': segment '${segment}' is a primitive value.`, path);
                }
                if (val === undefined || val === null) {
                    const nextSegment = i < segments.length - 1 ? segments[i + 1] : lastSegment;
                    if (isNumeric(nextSegment)) {
                        const nextIdx = parseInt(nextSegment, 10);
                        if (nextIdx > MAX_ARRAY_INDEX) {
                            throw new A2uiDataError(`Cannot set path '${path}': array index '${nextSegment}' exceeds maximum supported index (${MAX_ARRAY_INDEX}).`, path);
                        }
                        current[index] = [];
                    }
                    else {
                        current[index] = {};
                    }
                }
            }
            else {
                // Ensure we only inspect own properties to prevent inherited
                // Object.prototype properties (e.g., toString) from being treated as
                // existing state.
                const hasOwnProp = Object.prototype.hasOwnProperty.call(current, segment);
                if (hasOwnProp) {
                    const propVal = current[segment];
                    // If we encounter a primitive where a container is expected, we
                    // cannot proceed. We allow undefined/null to be overwritten by a new
                    // container.
                    if (propVal !== undefined && propVal !== null && typeof propVal !== 'object') {
                        throw new A2uiDataError(`Cannot set path '${path}': segment '${segment}' is a primitive value.`, path);
                    }
                }
                if (!hasOwnProp || current[segment] === undefined || current[segment] === null) {
                    const nextSegment = i < segments.length - 1 ? segments[i + 1] : lastSegment;
                    if (isNumeric(nextSegment)) {
                        const nextIdx = parseInt(nextSegment, 10);
                        if (nextIdx > MAX_ARRAY_INDEX) {
                            throw new A2uiDataError(`Cannot set path '${path}': array index '${nextSegment}' exceeds maximum supported index (${MAX_ARRAY_INDEX}).`, path);
                        }
                        current[segment] = [];
                    }
                    else {
                        current[segment] = {};
                    }
                }
            }
            current = current[segment];
        }
        if (Array.isArray(current)) {
            if (!isNumeric(lastSegment)) {
                throw new A2uiDataError(`Cannot use non-numeric segment '${lastSegment}' on an array in path '${path}'.`, path);
            }
            const lastIndex = parseInt(lastSegment, 10);
            if (lastIndex > MAX_ARRAY_INDEX) {
                throw new A2uiDataError(`Cannot set path '${path}': array index '${lastSegment}' exceeds maximum supported index (${MAX_ARRAY_INDEX}).`, path);
            }
        }
        if (removes) {
            if (Array.isArray(current)) {
                const idx = parseInt(lastSegment, 10);
                // Deleting an index past the end of the array is a no-op. Assigning
                // here would extend `length` and materialise entries never set.
                if (idx < current.length) {
                    current[idx] = undefined;
                }
            }
            else {
                delete current[lastSegment];
            }
        }
        else {
            current[lastSegment] = cloneValue(value);
        }
        this.notifySignals(path);
        return this;
    }
    /**
     * Deletes the value at the specified JSON pointer path.
     *
     * If `path` is `'/'` or empty, resets the root data model to an empty object.
     *
     * @param path The JSON pointer path to remove.
     * @returns This `DataModel` instance for chaining.
     */
    delete(path) {
        return this.set(path, undefined);
    }
    /**
     * Resolves a relative path against a base context path.
     *
     * @param path The path to resolve.
     * @param contextPath The base path (optional).
     * @returns The resolved absolute path.
     */
    static resolvePath(path, contextPath) {
        if (path.startsWith('/')) {
            return path;
        }
        if (contextPath) {
            const base = contextPath.endsWith('/') ? contextPath : `${contextPath}/`;
            return `${base}${path}`;
        }
        return `/${path}`;
    }
    /**
     * Retrieves data at a specific JSON pointer path.
     *
     * @template T The expected type of the returned value. Defaults to `any`.
     * @param path The JSON pointer path to read from.
     * @returns The value at the specified path, or undefined if not found.
     * @throws {A2uiDataError} If path is null, undefined, or contains forbidden
     *     segments (`__proto__`, `constructor`, `prototype`).
     */
    get(path) {
        if (path === null || path === undefined) {
            throw new A2uiDataError('Path cannot be null or undefined.');
        }
        if (path === '/' || path === '') {
            return this.data;
        }
        const segments = this.parsePath(path);
        let current = this.data;
        for (const segment of segments) {
            if (current === undefined || current === null || typeof current !== 'object') {
                return undefined;
            }
            if (Array.isArray(current)) {
                if (!isNumeric(segment)) {
                    return undefined;
                }
                const index = parseInt(segment, 10);
                if (index < 0 || index >= current.length) {
                    return undefined;
                }
                current = current[index];
            }
            else {
                if (!Object.prototype.hasOwnProperty.call(current, segment)) {
                    return undefined;
                }
                current = current[segment];
            }
        }
        return current;
    }
    /**
     * Checks whether a JSON pointer path physically exists in the data model.
     *
     * Differentiates between a path holding an explicit `null` value (`true`) and
     * a path that is absent from the object or array hierarchy (`false`).
     *
     * @param path Absolute JSON pointer path to check.
     * @returns Whether every segment along `path` exists in the hierarchy.
     */
    hasPath(path) {
        if (path === null || path === undefined) {
            return false;
        }
        return this.get(path) !== undefined;
    }
    /**
     * Subscribes to changes at the specified data path.
     *
     * This is a backwards-compatible layer using Preact Signals internally. It
     * allows listeners to be notified whenever the value at the specified path
     * (or any of its ancestors/descendants) changes.
     *
     * @param path The JSON pointer path to observe.
     * @param onChange A callback fired whenever the value changes.
     * @returns A `DataSubscription` containing the initial value and an
     *     `unsubscribe` method.
     * @throws {A2uiDataError} If path is null, undefined, or contains forbidden
     *     segments (`__proto__`, `constructor`, `prototype`).
     */
    subscribe(path, onChange) {
        const sig = this.getSignal(path);
        let isSync = true;
        let currentValue = peekValue(sig);
        const dispose = effect(() => {
            const val = getValue(sig);
            currentValue = val;
            if (!isSync) {
                onChange(val);
            }
        });
        isSync = false;
        this.subscriptions.add(dispose);
        return {
            get value() {
                return currentValue;
            },
            unsubscribe: () => {
                dispose();
                this.subscriptions.delete(dispose);
            },
        };
    }
    /**
     * Clears all internal subscriptions and active signals.
     */
    dispose() {
        for (const dispose of this.subscriptions) {
            dispose();
        }
        this.subscriptions.clear();
        this.signals.clear();
    }
    normalizePath(path) {
        const segments = path.split('/').filter(p => p.length > 0);
        return segments.length === 0 ? '/' : `/${segments.join('/')}`;
    }
    parsePath(path) {
        return path
            .split('/')
            .filter(p => p.length > 0)
            .map(rawSegment => {
            const segment = rawSegment.replace(/~([01])/g, (_, g) => (g === '1' ? '/' : '~'));
            if (FORBIDDEN_KEYS.has(segment)) {
                throw new A2uiDataError(`Forbidden path segment '${segment}' in path '${path}'.`, path);
            }
            return segment;
        });
    }
    notifySignals(path) {
        const normalizedPath = this.normalizePath(path);
        batchWrite(() => {
            this.updateSignal(normalizedPath);
            // Notify Ancestors
            let parentPath = normalizedPath;
            while (parentPath !== '/' && parentPath !== '') {
                parentPath = parentPath.substring(0, parentPath.lastIndexOf('/')) || '/';
                this.updateSignal(parentPath);
            }
            // Notify Descendants
            for (const subPath of this.signals.keys()) {
                if (this.isDescendant(subPath, normalizedPath)) {
                    this.updateSignal(subPath);
                }
            }
        });
    }
    updateSignal(path) {
        const sig = this.signals.get(path);
        if (sig) {
            const val = this.get(path);
            if (Array.isArray(val)) {
                setValue(sig, val.slice());
            }
            else if (typeof val === 'object' && val !== null) {
                setValue(sig, { ...val });
            }
            else {
                setValue(sig, val);
            }
        }
    }
    notifyAllSignals() {
        batchWrite(() => {
            for (const path of this.signals.keys()) {
                this.updateSignal(path);
            }
        });
    }
    isDescendant(childPath, parentPath) {
        if (parentPath === '/' || parentPath === '') {
            return childPath !== '/';
        }
        return childPath.startsWith(parentPath + '/');
    }
}
//# sourceMappingURL=data-model.js.map