/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { componentPayloadState } from '../catalog/component_envelope.js';
import { A2uiValidationError } from '../errors.js';
import { getComponentReferences, MAX_GLOBAL_DEPTH, } from '../validation/integrity-checker.js';
import { ComponentGraphBound, ComponentsWatcher } from './component-graph-bound.js';
import { ComponentModel } from './component-model.js';
import { SurfaceComponentsModel } from './surface-components-model.js';
/** Whether each catalog declares `allowedParents` or `allowedChildren`. */
const catalogRules = new WeakMap();
/**
 * Checks the composition constraints and, under a `validationConfig`, the
 * topology of the surface a batch of components would leave behind,
 * changing nothing.
 *
 * Under a config that allows dangling references and does not check
 * reachability (it allows orphans or a missing root), as an agent's
 * renderer state configures it, the batch is checked against the
 * components it changes when the last check of the surface left a
 * `ComponentGraphBound` that still holds: cycles and depth through the
 * bound, and composition constraints on the components whose parents,
 * children or types the batch changes. When that cannot show the batch
 * passes, the whole surface is checked, so a batch that fails reports the
 * same error as before. Under any other config every check walks the whole
 * surface.
 *
 * @param surface Surface the batch updates.
 * @param newComponents Components of the batch.
 * @param validationConfig Active validation configuration, if any.
 * @param resolveCatalog Callback resolving each component's catalog on the surface.
 * @param graphBounds Map holding the last recorded bound per surface components model.
 * @returns The bound of the surface with the batch applied, to record once
 *     it is applied, or undefined when there is none to record.
 */
export function validateComponentGraph(surface, newComponents, validationConfig, resolveCatalog, graphBounds) {
    const model = surface.componentsModel;
    const recorded = graphBounds.get(model);
    // A bound changes with the batch, and holds again only once it is applied.
    graphBounds.delete(model);
    if (!validationConfig || !defersGraphChecks(validationConfig)) {
        validateCompositionConstraints(surface, newComponents, resolveCatalog, validationConfig);
        validateCandidateTopology(surface, newComponents, resolveCatalog, validationConfig);
        return undefined;
    }
    const batch = batchGraph(surface, newComponents, resolveCatalog);
    const rootId = validationConfig.rootId ?? surface.rootId;
    if (batch &&
        recorded &&
        recorded.changes === ComponentsWatcher.of(model).changes &&
        (validationConfig.allowMissingRoot || batch.children.has(rootId) || model.has(rootId))) {
        const { bound } = recorded;
        const previousChildren = new Map();
        for (const id of batch.children.keys()) {
            previousChildren.set(id, bound.childrenOf(id));
        }
        const admitted = bound.admits(batch.children, validationConfig.maxDepth ?? MAX_GLOBAL_DEPTH, id => model.has(id));
        if (!compositionHolds(surface, batch, previousChildren, bound, validationConfig)) {
            // Reports the first violation in the order of the whole-surface check.
            validateCompositionConstraints(surface, newComponents, resolveCatalog, validationConfig);
        }
        if (admitted)
            return bound;
        const candidateGraph = validateCandidateTopology(surface, newComponents, resolveCatalog, validationConfig, true);
        return candidateGraph ? ComponentGraphBound.of(candidateGraph) : undefined;
    }
    validateCompositionConstraints(surface, newComponents, resolveCatalog, validationConfig);
    const candidateGraph = validateCandidateTopology(surface, newComponents, resolveCatalog, validationConfig, true);
    return candidateGraph ? ComponentGraphBound.of(candidateGraph) : undefined;
}
/**
 * Records the `ComponentGraphBound` of a surface after its component batch has
 * been applied to `model`.
 */
export function recordComponentGraphBound(model, bound, graphBounds) {
    graphBounds.set(model, { bound, changes: ComponentsWatcher.of(model).changes });
}
/**
 * Whether `validationConfig` allows dangling references and does not
 * check reachability, because it allows orphans or a missing root.
 */
export function defersGraphChecks(validationConfig) {
    return (validationConfig !== undefined &&
        validationConfig.allowDanglingReferences === true &&
        (validationConfig.allowOrphanComponents === true || validationConfig.allowMissingRoot === true));
}
/**
 * Reads a batch of components as `validateCandidateTopology` reads it into
 * its candidate model: each component's type, catalog and child references.
 *
 * @returns The batch, or undefined when a component in it has no type or a
 *     catalog that declares no components, whose references the topology
 *     and composition checks read differently; such a batch is checked
 *     against the whole surface.
 */
function batchGraph(surface, newComponents, resolveCatalog) {
    const batch = { children: new Map(), types: new Map(), catalogs: new Map() };
    for (const comp of newComponents) {
        const { id, component } = comp;
        if (typeof id !== 'string' || !id)
            continue;
        const catalog = resolveCatalog(comp, surface);
        const type = (typeof component === 'string' ? component : surface.componentsModel.get(id)?.type) || '';
        if (!type || catalog.components.size === 0)
            return undefined;
        const { properties } = componentPayloadState(comp, surface.protocolVersion, catalog.components.get(type)?.schema, { defaultCatalogSchema: surface.defaultCatalog?.components.get(type)?.schema });
        const children = Array.from(getComponentReferences({ ...properties, id, component: type }, catalog.componentRefMap), ([childId]) => childId);
        batch.children.set(id, children);
        batch.types.set(id, type);
        batch.catalogs.set(id, catalog);
    }
    return batch;
}
/**
 * Whether the composition constraints hold on the components a batch
 * affects, which are the only ones whose parents, children or types it
 * changes. The rest passed the check of an earlier batch and are unchanged.
 *
 * A component of the batch is checked against its parents and all of its
 * children. A child it references before or after it, outside the batch, may
 * have another parent, so only its parents are checked. A component outside
 * the batch that references a component of the batch keeps its parents and
 * children, but that child may now be of another type, so only the children
 * of the batch it references are checked. A container that holds many
 * children, receiving one per message, is then checked against one child
 * per message rather than all of them.
 */
function compositionHolds(surface, batch, previousChildren, bound, validationConfig) {
    if (!hasCompositionRules(surface, batch.catalogs.values(), validationConfig))
        return true;
    const rootId = compositionRootId(surface, validationConfig);
    const model = surface.componentsModel;
    const typeMap = {
        get: (id) => batch.types.get(id) ?? model.get(id)?.type,
    };
    // Children outside the batch whose parents may have changed.
    const moved = new Set();
    // Components outside the batch that reference components of the batch,
    // with the components of the batch they reference.
    const holding = new Map();
    for (const [id, children] of batch.children) {
        for (const child of children) {
            if (!batch.children.has(child))
                moved.add(child);
        }
        for (const child of previousChildren.get(id) ?? []) {
            if (!batch.children.has(child))
                moved.add(child);
        }
        for (const parent of bound.parentsOf(id)) {
            if (batch.children.has(parent))
                continue;
            const held = holding.get(parent);
            if (held) {
                held.push(id);
            }
            else {
                holding.set(parent, [id]);
            }
        }
    }
    const componentApiOf = (id) => {
        const componentType = typeMap.get(id);
        if (!componentType)
            return undefined;
        const catalog = batch.catalogs.get(id) ?? model.get(id)?.catalog;
        const componentApi = catalog?.components.get(componentType);
        return componentApi ? { componentType, componentApi } : undefined;
    };
    const checkParents = (id) => {
        const entry = componentApiOf(id);
        if (!entry)
            return;
        const { componentType, componentApi } = entry;
        if (componentApi.allowedParents && componentApi.allowedParents.length > 0) {
            const parents = Array.from(bound.parentsOf(id), parentId => ({
                parentId,
                parentType: typeMap.get(parentId) || 'Unknown',
            }));
            validateParentConstraints(id, componentType, componentApi.allowedParents, parents, rootId);
        }
    };
    const checkChildren = (id, children) => {
        const entry = componentApiOf(id);
        if (!entry)
            return;
        const { componentType, componentApi } = entry;
        if (componentApi.allowedChildren && componentApi.allowedChildren.length > 0) {
            validateChildConstraints(id, componentType, componentApi.allowedChildren, children, typeMap);
        }
    };
    try {
        for (const id of batch.children.keys()) {
            checkParents(id);
            checkChildren(id, bound.childrenOf(id));
        }
        for (const id of moved)
            checkParents(id);
        for (const [id, held] of holding)
            checkChildren(id, held);
    }
    catch {
        return false;
    }
    return true;
}
/**
 * Whether any catalog a surface's components may come from declares
 * `allowedParents` or `allowedChildren`. When none does, the composition
 * check has nothing to check.
 */
function hasCompositionRules(surface, batchCatalogs, validationConfig) {
    const declaresRules = (catalog) => {
        let rules = catalogRules.get(catalog);
        if (rules === undefined) {
            rules = Array.from(catalog.components.values()).some(api => (api.allowedParents !== undefined && api.allowedParents.length > 0) ||
                (api.allowedChildren !== undefined && api.allowedChildren.length > 0));
            catalogRules.set(catalog, rules);
        }
        return rules;
    };
    for (const catalog of batchCatalogs) {
        if (declaresRules(catalog))
            return true;
    }
    if (defersGraphChecks(validationConfig)) {
        // An agent's processor follows the components it checks incrementally.
        for (const catalog of ComponentsWatcher.of(surface.componentsModel).catalogs) {
            if (declaresRules(catalog))
                return true;
        }
        return false;
    }
    // A renderer's processor adds no listeners of its own to the surface's
    // components. Components added through the processor resolve their
    // catalogs on the surface, so only one added from outside it can come
    // from another catalog.
    const surfaceCatalogs = new Set(surface.availableCatalogs.values());
    if (surface.defaultCatalog)
        surfaceCatalogs.add(surface.defaultCatalog);
    for (const catalog of surfaceCatalogs) {
        if (declaresRules(catalog))
            return true;
    }
    for (const component of surface.componentsModel.values) {
        if (!surfaceCatalogs.has(component.catalog) && declaresRules(component.catalog)) {
            return true;
        }
    }
    return false;
}
/** The id of the component the surface holds directly, which `allowedParents` checks against `Surface`. */
function compositionRootId(surface, validationConfig) {
    return validationConfig?.rootId ?? surface.rootId ?? 'root';
}
/**
 * Checks a component's `allowedParents` against every parent it is under.
 *
 * Every component that references it is a parent, and the surface is the
 * parent of the root component (`rootId`), which is checked first. A component
 * no other component references is not checked unless it is the root; whether
 * it is reachable is the topology check's concern.
 */
function validateParentConstraints(id, componentType, allowedParents, parents, rootId, surfaceId, compIndex, compIndexMap) {
    if (id === rootId && !allowedParents.includes('Surface')) {
        const path = compIndex !== undefined ? `/components/${compIndex}` : '/components';
        const message = `Component '${id}' (${componentType}) cannot be placed under parent 'Surface' (Surface). Allowed parents: ${JSON.stringify(allowedParents)}.`;
        const details = [
            {
                path,
                code: 'UNALLOWED_PARENT',
                message,
                ...(surfaceId !== undefined ? { surfaceId } : {}),
            },
        ];
        throw new A2uiValidationError(message, details, 'UNALLOWED_PARENT', { path, surfaceId });
    }
    for (const parentInfo of parents ?? []) {
        if (!allowedParents.includes(parentInfo.parentType)) {
            const offendingIndex = compIndex ?? compIndexMap?.get(parentInfo.parentId);
            const path = offendingIndex !== undefined ? `/components/${offendingIndex}` : '/components';
            const message = `Component '${id}' (${componentType}) cannot be placed under parent '${parentInfo.parentId}' (${parentInfo.parentType || 'unknown'}). Allowed parents: ${JSON.stringify(allowedParents)}.`;
            const details = [
                {
                    path,
                    code: 'UNALLOWED_PARENT',
                    message,
                    ...(surfaceId !== undefined ? { surfaceId } : {}),
                },
            ];
            throw new A2uiValidationError(message, details, 'UNALLOWED_PARENT', { path, surfaceId });
        }
    }
}
function validateChildConstraints(id, componentType, allowedChildren, children, typeMap, surfaceId, compIndex, childPathMap, compIndexMap) {
    for (const childId of children) {
        const childType = typeMap.get(childId);
        if (childType && !allowedChildren.includes(childType)) {
            let path;
            if (compIndex !== undefined) {
                const rawField = childPathMap?.get(childId) ?? 'children';
                const normalizedField = rawField
                    .replace(/\[(\d+)\]/g, '/$1')
                    .replace(/\./g, '/')
                    .replace(/^\/+/, '');
                path = `/components/${compIndex}${normalizedField ? `/${normalizedField}` : ''}`;
            }
            else {
                const offendingIndex = compIndexMap?.get(childId);
                path = offendingIndex !== undefined ? `/components/${offendingIndex}` : '/components';
            }
            const message = `Container '${id}' (${componentType}) cannot contain child '${childId}' (${childType}). Allowed children: ${JSON.stringify(allowedChildren)}.`;
            const details = [
                {
                    path,
                    code: 'UNALLOWED_CHILD',
                    message,
                    ...(surfaceId !== undefined ? { surfaceId } : {}),
                },
            ];
            throw new A2uiValidationError(message, details, 'UNALLOWED_CHILD', { path, surfaceId });
        }
    }
}
function buildCompositionTopology(surface, newComponents, resolveCatalog) {
    const typeMap = new Map();
    const compCatalogMap = new Map();
    const childMap = new Map();
    const childPathMap = new Map();
    const compIndexMap = new Map();
    for (const [id, model] of surface.componentsModel.entries) {
        typeMap.set(id, model.type);
        compCatalogMap.set(id, model.catalog);
        const refs = surface.componentsModel.getChildReferences(id);
        if (refs.length > 0) {
            childMap.set(id, refs.map(([childId]) => childId));
            childPathMap.set(id, new Map(refs));
        }
    }
    for (let i = 0; i < newComponents.length; i++) {
        const comp = newComponents[i];
        const { id, component, ...props } = comp;
        if (typeof id !== 'string')
            continue;
        compIndexMap.set(id, i);
        const compCatalog = resolveCatalog(comp, surface);
        compCatalogMap.set(id, compCatalog);
        const existing = surface.componentsModel.get(id);
        const compType = (typeof component === 'string' ? component : existing?.type) ?? '';
        if (compType) {
            typeMap.set(id, compType);
        }
        const compDef = { id, component: compType, ...props };
        const refs = Array.from(getComponentReferences(compDef, compCatalog));
        if (refs.length > 0) {
            childMap.set(id, refs.map(([childId]) => childId));
            childPathMap.set(id, new Map(refs));
        }
        else {
            childMap.delete(id);
            childPathMap.delete(id);
        }
    }
    const parentMap = new Map();
    for (const [parentId, children] of childMap.entries()) {
        const parentType = typeMap.get(parentId) || 'Unknown';
        for (const childId of children) {
            const parents = parentMap.get(childId) ?? [];
            parents.push({ parentId, parentType });
            parentMap.set(childId, parents);
        }
    }
    return { typeMap, compCatalogMap, childMap, childPathMap, parentMap, compIndexMap };
}
/**
 * Validates `allowedParents` and `allowedChildren` composition constraints
 * across the surface with `newComponents` applied.
 */
export function validateCompositionConstraints(surface, newComponents, resolveCatalog, validationConfig) {
    // The components of the batch have resolved their catalogs already, in
    // `validateComponentProperties`.
    const batchCatalogs = newComponents
        .filter(comp => typeof comp.id === 'string')
        .map(comp => resolveCatalog(comp, surface));
    if (!hasCompositionRules(surface, batchCatalogs, validationConfig))
        return;
    const { typeMap, compCatalogMap, childMap, childPathMap, parentMap, compIndexMap } = buildCompositionTopology(surface, newComponents, resolveCatalog);
    const rootId = compositionRootId(surface, validationConfig);
    for (const [id, componentType] of typeMap.entries()) {
        const compCatalog = compCatalogMap.get(id);
        const componentApi = compCatalog?.components.get(componentType);
        if (!componentApi)
            continue;
        if (componentApi.allowedParents && componentApi.allowedParents.length > 0) {
            validateParentConstraints(id, componentType, componentApi.allowedParents, parentMap.get(id), rootId, surface.id, compIndexMap.get(id), compIndexMap);
        }
        if (componentApi.allowedChildren && componentApi.allowedChildren.length > 0) {
            validateChildConstraints(id, componentType, componentApi.allowedChildren, childMap.get(id) || [], typeMap, surface.id, compIndexMap.get(id), childPathMap.get(id), compIndexMap);
        }
    }
}
/**
 * Checks the topology of the surface a batch would leave behind against
 * `validationConfig`, walking the whole surface.
 *
 * @param surface Surface the batch updates.
 * @param newComponents Components of the batch.
 * @param resolveCatalog Callback resolving each component's catalog on the surface.
 * @param validationConfig Active validation configuration, if any.
 * @param collectGraph Whether to return the references of that surface.
 * @returns When `collectGraph` is set, each component of that surface with
 *     the ids it references; otherwise, or without a config, undefined.
 */
export function validateCandidateTopology(surface, newComponents, resolveCatalog, validationConfig, collectGraph = false) {
    if (!validationConfig)
        return undefined;
    const candidateModel = new SurfaceComponentsModel(surface.defaultCatalog);
    for (const [id, comp] of surface.componentsModel.entries) {
        candidateModel.addComponent(new ComponentModel(id, comp.type, comp.properties, comp.catalog));
    }
    for (const comp of newComponents) {
        const { id, component } = comp;
        if (typeof id !== 'string' || !id)
            continue;
        const targetCatalog = resolveCatalog(comp, surface);
        const existing = candidateModel.get(id);
        const componentType = (typeof component === 'string' ? component : existing?.type) || '';
        if (!componentType)
            continue;
        // The properties the component would store: below v1.0 a `metadata` or
        // `catalogId` is an ordinary property, and from v1.0 the envelope mixins
        // are split from the component's own properties.
        const { properties } = componentPayloadState(comp, surface.protocolVersion, targetCatalog.components.get(componentType)?.schema, { defaultCatalogSchema: surface.defaultCatalog?.components.get(componentType)?.schema });
        if (existing) {
            if (componentType !== existing.type || existing.catalog.id !== targetCatalog.id) {
                candidateModel.removeComponent(id);
                candidateModel.addComponent(new ComponentModel(id, componentType, properties, targetCatalog));
            }
            else {
                existing.properties = properties;
            }
        }
        else {
            candidateModel.addComponent(new ComponentModel(id, componentType, properties, targetCatalog));
        }
    }
    candidateModel.validateTopology({
        ...validationConfig,
        rootId: validationConfig.rootId ?? surface.rootId,
    });
    if (!collectGraph)
        return undefined;
    const graph = new Map();
    for (const id of candidateModel.keys) {
        graph.set(id, candidateModel.getChildIds(id));
    }
    return graph;
}
//# sourceMappingURL=validation-helpers.js.map