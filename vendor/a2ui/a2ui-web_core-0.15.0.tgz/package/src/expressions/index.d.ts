/**
 * Expression parser and evaluator for A2UI dynamic bindings.
 */
export { MAX_EXPRESSION_TEMPLATE_LENGTH, MAX_EXPRESSION_PARTS, ExpressionParser, } from './expression_parser.js';
//# sourceMappingURL=index.d.ts.map