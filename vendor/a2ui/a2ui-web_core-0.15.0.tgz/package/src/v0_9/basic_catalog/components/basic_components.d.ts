import { z } from 'zod';
import { ComponentApi } from '../../../catalog/types.js';
export declare const CatalogComponentCommonSchema: z.ZodObject<{
    weight: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    weight?: number | undefined;
}, {
    weight?: number | undefined;
}>;
export declare const ThemeDefSchema: z.ZodObject<{
    primaryColor: z.ZodOptional<z.ZodString>;
    iconUrl: z.ZodOptional<z.ZodString>;
    agentDisplayName: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    primaryColor?: string | undefined;
    iconUrl?: string | undefined;
    agentDisplayName?: string | undefined;
}, {
    primaryColor?: string | undefined;
    iconUrl?: string | undefined;
    agentDisplayName?: string | undefined;
}>;
export declare const TextApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        text: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        variant: z.ZodOptional<z.ZodDefault<z.ZodEnum<["h1", "h2", "h3", "h4", "h5", "caption", "body"]>>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        text: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        variant?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
    }, {
        text: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        variant?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
    }>;
};
export declare const ImageApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        url: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        fit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["contain", "cover", "fill", "none", "scaleDown"]>>>;
        variant: z.ZodOptional<z.ZodDefault<z.ZodEnum<["icon", "avatar", "smallFeature", "mediumFeature", "largeFeature", "header"]>>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
        variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
    }, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
        variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
    }>;
};
export declare const IconApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        name: z.ZodUnion<[z.ZodEnum<["accountCircle", "add", "arrowBack", "arrowForward", "attachFile", "calendarToday", "call", "camera", "check", "close", "delete", "download", "edit", "event", "error", "fastForward", "favorite", "favoriteOff", "folder", "help", "home", "info", "locationOn", "lock", "lockOpen", "mail", "menu", "moreVert", "moreHoriz", "notificationsOff", "notifications", "pause", "payment", "person", "phone", "photo", "play", "print", "refresh", "rewind", "search", "send", "settings", "share", "shoppingCart", "skipNext", "skipPrevious", "star", "starHalf", "starOff", "stop", "upload", "visibility", "visibilityOff", "volumeDown", "volumeMute", "volumeOff", "volumeUp", "warning"]>, z.ZodObject<{
            svgPath: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            svgPath: string;
        }, {
            svgPath: string;
        }>, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>]>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
            path: string;
        } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
            svgPath: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
            path: string;
        } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
            svgPath: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const VideoApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        url: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const AudioPlayerApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        url: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        url: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const RowApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        children: z.ZodUnion<[z.ZodArray<z.ZodString, "many">, z.ZodObject<{
            componentId: z.ZodString;
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
            componentId: string;
        }, {
            path: string;
            componentId: string;
        }>]>;
        justify: z.ZodOptional<z.ZodDefault<z.ZodEnum<["center", "end", "spaceAround", "spaceBetween", "spaceEvenly", "start", "stretch"]>>>;
        align: z.ZodOptional<z.ZodDefault<z.ZodEnum<["start", "center", "end", "stretch"]>>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
    }, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
    }>;
};
export declare const ColumnApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        children: z.ZodUnion<[z.ZodArray<z.ZodString, "many">, z.ZodObject<{
            componentId: z.ZodString;
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
            componentId: string;
        }, {
            path: string;
            componentId: string;
        }>]>;
        justify: z.ZodOptional<z.ZodDefault<z.ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly", "stretch"]>>>;
        align: z.ZodOptional<z.ZodDefault<z.ZodEnum<["center", "end", "start", "stretch"]>>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
    }, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
    }>;
};
export declare const ListApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        children: z.ZodUnion<[z.ZodArray<z.ZodString, "many">, z.ZodObject<{
            componentId: z.ZodString;
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
            componentId: string;
        }, {
            path: string;
            componentId: string;
        }>]>;
        direction: z.ZodOptional<z.ZodDefault<z.ZodEnum<["vertical", "horizontal"]>>>;
        align: z.ZodOptional<z.ZodDefault<z.ZodEnum<["start", "center", "end", "stretch"]>>>;
        listStyle: z.ZodOptional<z.ZodEnum<["ordered", "unordered", "none"]>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        direction?: "horizontal" | "vertical" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
        listStyle?: "none" | "ordered" | "unordered" | undefined;
    }, {
        children: string[] | {
            path: string;
            componentId: string;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        direction?: "horizontal" | "vertical" | undefined;
        align?: "start" | "center" | "end" | "stretch" | undefined;
        listStyle?: "none" | "ordered" | "unordered" | undefined;
    }>;
};
export declare const CardApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        child: z.ZodString;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        child: string;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        child: string;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const TabsApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        tabs: z.ZodArray<z.ZodObject<{
            title: z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            child: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            child: string;
            title: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            child: string;
            title: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        tabs: {
            child: string;
            title: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[];
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        tabs: {
            child: string;
            title: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[];
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const ModalApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        trigger: z.ZodString;
        content: z.ZodString;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        trigger: string;
        content: string;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }, {
        trigger: string;
        content: string;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
    }>;
};
export declare const DividerApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        axis: z.ZodOptional<z.ZodDefault<z.ZodEnum<["horizontal", "vertical"]>>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        axis?: "horizontal" | "vertical" | undefined;
    }, {
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        weight?: number | undefined;
        axis?: "horizontal" | "vertical" | undefined;
    }>;
};
export declare const ButtonApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        child: z.ZodString;
        variant: z.ZodOptional<z.ZodDefault<z.ZodEnum<["default", "primary", "borderless"]>>>;
        action: z.ZodUnion<[z.ZodObject<{
            event: z.ZodObject<{
                name: z.ZodString;
                context: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<import("../../index.js").DynamicValue, z.ZodTypeDef, import("../../index.js").DynamicValue>>>;
            }, "strict", z.ZodTypeAny, {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            }, {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            }>;
        }, "strict", z.ZodTypeAny, {
            event: {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            };
        }, {
            event: {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            };
        }>, z.ZodObject<{
            functionCall: z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>;
        }, "strict", z.ZodTypeAny, {
            functionCall: import("../../index.js").FunctionCall;
        }, {
            functionCall: import("../../index.js").FunctionCall;
        }>]>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        child: string;
        action: {
            event: {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            };
        } | {
            functionCall: import("../../index.js").FunctionCall;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        variant?: "default" | "primary" | "borderless" | undefined;
    }, {
        child: string;
        action: {
            event: {
                name: string;
                context?: Record<string, import("../../index.js").DynamicValue> | undefined;
            };
        } | {
            functionCall: import("../../index.js").FunctionCall;
        };
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        variant?: "default" | "primary" | "borderless" | undefined;
    }>;
};
export declare const TextFieldApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        label: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        value: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        variant: z.ZodOptional<z.ZodDefault<z.ZodEnum<["longText", "number", "shortText", "obscured"]>>>;
        validationRegexp: z.ZodOptional<z.ZodString>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        value?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        validationRegexp?: string | undefined;
        variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
    }, {
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        value?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        validationRegexp?: string | undefined;
        variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
    }>;
};
export declare const CheckBoxApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        label: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        value: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
    }, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
    }>;
};
export declare const ChoicePickerApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        variant: z.ZodOptional<z.ZodDefault<z.ZodEnum<["multipleSelection", "mutuallyExclusive"]>>>;
        options: z.ZodArray<z.ZodObject<{
            label: z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            value: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            value: string;
            label: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            value: string;
            label: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">;
        value: z.ZodUnion<[z.ZodArray<z.ZodString, "many">, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        displayStyle: z.ZodOptional<z.ZodDefault<z.ZodEnum<["checkbox", "chips"]>>>;
        filterable: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        value: string[] | {
            path: string;
        } | import("../../index.js").FunctionCall;
        options: {
            value: string;
            label: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[];
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        filterable?: boolean | undefined;
        variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
        displayStyle?: "checkbox" | "chips" | undefined;
    }, {
        value: string[] | {
            path: string;
        } | import("../../index.js").FunctionCall;
        options: {
            value: string;
            label: string | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[];
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        filterable?: boolean | undefined;
        variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
        displayStyle?: "checkbox" | "chips" | undefined;
    }>;
};
export declare const SliderApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        min: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
        max: z.ZodNumber;
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        max: number;
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        min?: number | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        max: number;
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        min?: number | undefined;
    }>;
};
export declare const DateTimeInputApi: {
    name: string;
    schema: z.ZodObject<{
        accessibility: z.ZodOptional<z.ZodObject<{
            label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
            description: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        }, "strip", z.ZodTypeAny, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }, {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        }>>;
        checks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            condition: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
                path: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                path: string;
            }, {
                path: string;
            }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
            message: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }, {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }>, "many">>;
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        enableDate: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
        enableTime: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
        min: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        max: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        label: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        weight: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        min?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        max?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        enableDate?: boolean | undefined;
        enableTime?: boolean | undefined;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        accessibility?: {
            label?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
            description?: string | {
                path: string;
            } | import("../../index.js").FunctionCall | undefined;
        } | undefined;
        checks?: {
            message: string;
            condition: boolean | {
                path: string;
            } | import("../../index.js").FunctionCall;
        }[] | undefined;
        weight?: number | undefined;
        min?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        max?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        enableDate?: boolean | undefined;
        enableTime?: boolean | undefined;
    }>;
};
export declare const BASIC_COMPONENTS: ComponentApi[];
/**
 * The document-level fields of the published catalog document.
 */
export declare const BASIC_CATALOG_DOCUMENT_OPTIONS: {
    schemaUri: string;
    schemaId: string;
    title: string;
    description: string;
    declaredProtocolVersion: null;
    commonTypesUri: string;
    defModels: z.ZodObject<{
        primaryColor: z.ZodOptional<z.ZodString>;
        iconUrl: z.ZodOptional<z.ZodString>;
        agentDisplayName: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        primaryColor?: string | undefined;
        iconUrl?: string | undefined;
        agentDisplayName?: string | undefined;
    }, {
        primaryColor?: string | undefined;
        iconUrl?: string | undefined;
        agentDisplayName?: string | undefined;
    }>[];
};
//# sourceMappingURL=basic_components.d.ts.map