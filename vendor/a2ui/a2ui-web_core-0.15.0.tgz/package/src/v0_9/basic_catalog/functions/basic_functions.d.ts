/**
 * Function implementations for the v0.9 basic catalog.
 */
import { FunctionImplementation } from '../../../catalog/types.js';
export { isSafeRegex, type SafeRegexOptions } from './safe_regex.js';
export { AddApi, SubtractApi, MultiplyApi, DivideApi, EqualsApi, NotEqualsApi, GreaterThanApi, LessThanApi, ContainsApi, StartsWithApi, EndsWithApi, LEGACY_V09_FUNCTION_APIS, } from './legacy_functions_api.js';
/**
 * Implementation of the legacy `add` function.
 *
 * @deprecated Define `add` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const AddImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `subtract` function.
 *
 * @deprecated Define `subtract` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const SubtractImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `multiply` function.
 *
 * @deprecated Define `multiply` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const MultiplyImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `divide` function.
 *
 * @deprecated Define `divide` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const DivideImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `equals` function.
 *
 * @deprecated Define `equals` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const EqualsImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `not_equals` function.
 *
 * @deprecated Define `not_equals` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const NotEqualsImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `greater_than` function.
 *
 * @deprecated Define `greater_than` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const GreaterThanImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `less_than` function.
 *
 * @deprecated Define `less_than` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const LessThanImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `contains` function.
 *
 * @deprecated Define `contains` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const ContainsImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `starts_with` function.
 *
 * @deprecated Define `starts_with` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const StartsWithImplementation: FunctionImplementation;
/**
 * Implementation of the legacy `ends_with` function.
 *
 * @deprecated Define `ends_with` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const EndsWithImplementation: FunctionImplementation;
/**
 * The legacy function implementations, in the order `@a2ui/web_core` 0.9.x
 * listed them.
 *
 * @deprecated See `legacy_functions_api.ts`.
 */
export declare const LEGACY_V09_FUNCTIONS: FunctionImplementation[];
export declare const AndImplementation: FunctionImplementation;
export declare const OrImplementation: FunctionImplementation;
export declare const NotImplementation: FunctionImplementation;
export declare const RequiredImplementation: FunctionImplementation;
export declare const RegexImplementation: FunctionImplementation;
export declare const LengthImplementation: FunctionImplementation;
export declare const NumericImplementation: FunctionImplementation;
export declare const EmailImplementation: FunctionImplementation;
export declare const FormatStringImplementation: FunctionImplementation;
export declare function createFormatNumberImplementation(locale?: string): FunctionImplementation;
export declare const FormatNumberImplementation: FunctionImplementation;
export declare function createFormatCurrencyImplementation(locale?: string): FunctionImplementation;
export declare const FormatCurrencyImplementation: FunctionImplementation;
export declare function createFormatDateImplementation(locale?: string): FunctionImplementation;
export declare const FormatDateImplementation: FunctionImplementation;
export declare function createPluralizeImplementation(locale?: string): FunctionImplementation;
export declare const PluralizeImplementation: FunctionImplementation;
export declare const OpenUrlImplementation: FunctionImplementation;
/**
 * Creates the function implementations defined by the published v0.9 basic
 * catalog document.
 *
 * @param options Configuration options containing optional locale.
 * @returns Array of function implementations.
 */
export declare function createV09SpecFunctions(options?: {
    locale?: string;
}): FunctionImplementation[];
/**
 * Function implementations defined by the published v0.9 basic catalog
 * document. This is what `basicCatalog` registers.
 */
export declare const V09_SPEC_FUNCTIONS: FunctionImplementation[];
/**
 * Creates standard function implementations for the Basic Catalog.
 *
 * Includes the legacy functions of `@a2ui/web_core` 0.9.x ahead of the ones
 * the v0.9 specification defines, so a catalog composed from this list
 * behaves as it did before 1.0. The legacy entries are deprecated; a catalog
 * that should match the published document uses {@link createV09SpecFunctions}.
 *
 * @param options Configuration options containing optional locale.
 * @returns Array of function implementations.
 */
export declare function createBasicCatalogFunctions(options?: {
    locale?: string;
}): FunctionImplementation[];
/**
 * Standard function implementations for the Basic Catalog.
 *
 * Includes arithmetic, comparison, string, logical, validation, formatting,
 * and action functions. The arithmetic, comparison, and string entries are
 * the deprecated legacy functions of 0.9.x; {@link V09_SPEC_FUNCTIONS} holds
 * only the functions the v0.9 specification defines.
 */
export declare const BASIC_FUNCTIONS: FunctionImplementation[];
//# sourceMappingURL=basic_functions.d.ts.map