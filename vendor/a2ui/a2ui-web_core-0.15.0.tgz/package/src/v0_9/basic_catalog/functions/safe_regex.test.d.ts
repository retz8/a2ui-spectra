export {};
//# sourceMappingURL=safe_regex.test.d.ts.map