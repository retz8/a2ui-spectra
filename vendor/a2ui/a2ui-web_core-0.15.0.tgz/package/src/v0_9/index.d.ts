/**
 * Core rendering and state management logic for A2UI v0.9.
 *
 * This module exports the fundamental building blocks for building web-based A2UI renderers,
 * including the data model, component model, and expression parsing logic.
 */
export type { FunctionInvoker } from '../catalog/function_invoker.js';
export { createFunctionImplementation, type ComponentChildRefs, AgentFunction, isAgentFunction, type AgentFunctionContext, type AgentFunctionHandler, type AgentFunctionInit, type A2uiReturnTypeMap, type A2uiReturnType, type InferA2uiReturnType, type FunctionApi, type JsonSchemaObject, type FunctionImplementation, type ResolvedDynamic, type ResolvedFunctionArgs, type ComponentApi, type InferredComponentApiSchemaType, type CatalogUnions, type CatalogDocumentOptions, type CatalogOptions, type CopyWithCatalogOptions, type DeriveCatalogOptions, type CatalogInterface, Catalog, type CatalogApi, } from '../catalog/types.js';
export { type Subscription, type EventListener, type EventSource, EventEmitter, } from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, type A2uiMetadata, type Extensions, type ActionDispatchOptions, } from '../common/metadata.js';
export { type ProcessableMessage, type ProcessableMessagePayload, type RendererCapabilities, type ClientCapabilities, type ValidationConfig, type OutboundActionMessage, type OutboundMessageListener, type CallOptions, STRICT_VALIDATION, RELAXED_VALIDATION, A2uiRpcError, RpcErrorCode, type ExecutionContext, type CapabilitiesOptions, type MessageProcessorOptions, formatZodIssue, MessageProcessor, } from '../processing/message-processor.js';
export { mapErrorToRendererMessage, extractEnvelopeErrorContext, normalizeJsonPointer, type RendererErrorMessage, type A2uiRendererError, type ValidationFailedErrorBody, type GenericErrorBody, type ErrorEnvelopeContext, } from '../processing/message-error-mapper.js';
export { PLACEHOLDER_TYPE, isComponentNode, type ComponentNode, type NodeAction, type NodeProps, type NodeState, type MarkdownRenderer, type MarkdownRendererOptions, type MarkdownRendererTagClassMap, ComponentContext, getKnownSchemaKeys, validateFunctionArgs, isSingleAtKey, unescapeObjectKey, validateReservedDirectives, resolveContextIndex, MAX_DYNAMIC_VALUE_DEPTH, DataContext, scrapeComponentBehavior, scrapeSchemaBehavior, getSafeChildList, type BehaviorNode, type ResolveA2uiProp, type GenerateSetters, type ResolveA2uiProps, MAX_DYNAMIC_CHILD_LIST_SIZE, GenericBinder, NodeResolver, extractRefFields, type RefKind, type RefFields, isWritable, sameBinding, ResolvedBinding, WritableBinding, } from '../resolution/index.js';
export { type JsonSchema, FunctionDefinitionSchema, type FunctionDefinition, InlineCatalogSchema, type InlineCatalog, A2uiVersionCapabilitiesSchema, type A2uiVersionCapabilities, A2uiClientActionSchema, type A2uiClientAction, A2uiValidationErrorSchema, A2uiGenericErrorSchema, A2uiClientErrorSchema, type A2uiClientError, A2uiClientMessageSchema, type A2uiClientMessage, A2uiClientDataModelSchema, type A2uiClientDataModel, A2uiClientMessageListSchema, type A2uiClientMessageList, A2uiClientMessageListWrapperSchema, type A2uiClientMessageListWrapper, ComponentIdSchema, type ComponentId, DataBindingSchema, type DataBinding, type DynamicValue, DynamicValueSchema, type FunctionCall, FunctionCallSchema, DynamicStringSchema, type DynamicString, AccessibilityAttributesSchema, type AccessibilityAttributes, ComponentCommonSchema, type ComponentCommon, ChildListSchema, type ChildList, DynamicNumberSchema, type DynamicNumber, DynamicBooleanSchema, type DynamicBoolean, DynamicStringListSchema, type DynamicStringList, CheckRuleSchema, type CheckRule, CheckableSchema, type Checkable, ActionSchema, type Action, CommonSchemas, CreateSurfaceMessageSchema, type CreateSurfaceMessage, UpdateComponentsMessageSchema, type UpdateComponentsMessage, UpdateDataModelMessageSchema, type UpdateDataModelMessage, DeleteSurfaceMessageSchema, type DeleteSurfaceMessage, A2uiMessageSchema, type A2uiMessage, A2uiMessageListSchema, type A2uiMessageList, A2uiMessageListWrapperSchema, type A2uiMessageListWrapper, type ChildRefKind, type RefSchemaOptions, markChildRef, childRefKindOf, TemplateChildListSchema, type TemplateChildList, componentId, dynamicString, dynamicNumber, dynamicBoolean, dynamicValue, dynamicStringList, childList, AnyComponentSchema, type AnyComponent, type A2uiClientCapabilities, } from './schema/index.js';
export { V09_CHILD_REF_OPTIONS, V09_STANDARD_DEFS } from './standard_defs.js';
export { ComponentModel } from '../state/component-model.js';
export { type DataSubscription, MAX_ARRAY_INDEX, DataModel } from '../state/data-model.js';
export { SurfaceComponentsModel } from '../state/surface-components-model.js';
export { SurfaceGroupModel } from '../state/surface-group-model.js';
export { type ActionPayload, type A2uiErrorPayload, type A2uiWarningPayload, type ActionListener, type AgentFunctionCall, type AgentFunctionCallOptions, type AgentFunctionCaller, SurfaceModel, } from '../state/surface-model.js';
export { type A2uiErrorDetail, type A2uiErrorContext, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiCatalogError, A2uiIntegrityError, A2uiRecursionError, } from '../errors.js';
export type { ResolvedChildRef } from '../resolution/index.js';
export type { DataBindingType, FunctionCallType } from '../types/common-types.js';
export { MAX_FUNCTION_CALL_ARGS } from '../types/helpers.js';
export { basicCatalog, Context, markdown, setMarkdownRenderer, getMarkdownRenderer, ThemeSchema, A2uiAudioPlayer, A2uiButton, A2uiCard, A2uiCheckBox, A2uiChoicePicker, A2uiColumn, A2uiDateTimeInput, A2uiDivider, A2uiIcon, A2uiImage, A2uiList, A2uiModal, A2uiRow, A2uiSlider, A2uiTabs, A2uiText, A2uiTextField, A2uiVideo, BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, MAX_EXPRESSION_TEMPLATE_LENGTH, MAX_EXPRESSION_PARTS, ExpressionParser, createFormatNumberImplementation, createFormatCurrencyImplementation, createFormatDateImplementation, createPluralizeImplementation, createV09SpecFunctions, createBasicCatalogFunctions, isSafeRegex, type SafeRegexOptions, AddImplementation, SubtractImplementation, MultiplyImplementation, DivideImplementation, EqualsImplementation, NotEqualsImplementation, GreaterThanImplementation, LessThanImplementation, ContainsImplementation, StartsWithImplementation, EndsWithImplementation, LEGACY_V09_FUNCTIONS, AndImplementation, OrImplementation, NotImplementation, RequiredImplementation, RegexImplementation, LengthImplementation, NumericImplementation, EmailImplementation, FormatStringImplementation, FormatNumberImplementation, FormatCurrencyImplementation, FormatDateImplementation, PluralizeImplementation, OpenUrlImplementation, V09_SPEC_FUNCTIONS, BASIC_FUNCTIONS, AddApi, SubtractApi, MultiplyApi, DivideApi, EqualsApi, NotEqualsApi, GreaterThanApi, LessThanApi, ContainsApi, StartsWithApi, EndsWithApi, LEGACY_V09_FUNCTION_APIS, RequiredApi, RegexApi, LengthApi, NumericApi, EmailApi, FormatStringApi, FormatNumberApi, FormatCurrencyApi, FormatDateApi, PluralizeApi, OpenUrlApi, AndApi, OrApi, NotApi, BASIC_FUNCTION_APIS, V09_SPEC_FUNCTION_APIS, isValidCssColor, HEX_COLOR_REGEX, BasicCatalogThemeSchema, type BasicCatalogTheme, } from './basic_catalog/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, type AnchorKind, type CodePointRange, type RegexAnalysisResult, type RegexNode, type RegexRejection, } from '../common/regex_subset.js';
export { getComponentReferences, validateRecursionAndPaths, MAX_GLOBAL_DEPTH, MAX_FUNC_CALL_DEPTH, RELAXED_PATH_PATTERN, type ChildRefAnalysis, type ChildRefAnalysisOptions, type ComponentRefMap, analyzeChildRefSchema, assertUax31Identifier, buildComponentRefMap, isChildListSchema, isChildOrChildListSchema, isChildSchema, isValidUax31Identifier, V08_CHILD_REF_OPTIONS, V10_CHILD_REF_OPTIONS, type TopologyOptions, } from '../validation/integrity-checker.js';
export { 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
injectBasicCatalogStyles, 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
computeColorVariant, } from '../universal/basic_catalog/styles/default.js';
export type { 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
ColorVariantLightDarkOptions, 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
ColorVariantHoverOptions, } from '../universal/basic_catalog/styles/default.js';
export { type Signal, effect, signal, computed, getValue, peekValue, batchWrite, isSignal, setValue, setSignalImplementation, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, type SignalImplementations, } from '../reactivity/signals.js';
export declare const Schemas: {
    A2uiMessageSchemaRaw: {
        $schema: string;
        $id: string;
        title: string;
        description: string;
        type: string;
        oneOf: {
            $ref: string;
        }[];
        $defs: {
            CreateSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    createSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            catalogId: {
                                type: string;
                                description: string;
                            };
                            theme: {
                                $ref: string;
                                description: string;
                            };
                            sendDataModel: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateComponentsMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateComponents: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            components: {
                                type: string;
                                description: string;
                                minItems: number;
                                items: {
                                    $ref: string;
                                };
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateDataModelMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateDataModel: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            path: {
                                type: string;
                                description: string;
                            };
                            value: {
                                description: string;
                                additionalProperties: boolean;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            DeleteSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    deleteSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
};
//# sourceMappingURL=index.d.ts.map