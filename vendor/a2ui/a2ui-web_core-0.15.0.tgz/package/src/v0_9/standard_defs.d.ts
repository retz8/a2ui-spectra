import type { ChildRefAnalysisOptions } from '../catalog/reference-map.js';
/**
 * Child reference analysis configuration for A2UI v0.9 and v0.9.1 schemas.
 */
export declare const V09_CHILD_REF_OPTIONS: ChildRefAnalysisOptions;
/**
 * Standard $defs dictionary for A2UI v0.9 and v0.9.1 catalog JSON schemas.
 */
export declare const V09_STANDARD_DEFS: Record<string, unknown>;
//# sourceMappingURL=standard_defs.d.ts.map