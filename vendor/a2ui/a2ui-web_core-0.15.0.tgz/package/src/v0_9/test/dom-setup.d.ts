export { setupTestDom, teardownTestDom, asyncUpdate } from '../../test/dom-setup.js';
//# sourceMappingURL=dom-setup.d.ts.map