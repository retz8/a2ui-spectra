/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export { createFunctionImplementation, AgentFunction, isAgentFunction, Catalog, } from '../catalog/types.js';
export { EventEmitter, } from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, } from '../common/metadata.js';
export { STRICT_VALIDATION, RELAXED_VALIDATION, A2uiRpcError, RpcErrorCode, formatZodIssue, MessageProcessor, } from '../processing/message-processor.js';
export { mapErrorToRendererMessage, extractEnvelopeErrorContext, normalizeJsonPointer, } from '../processing/message-error-mapper.js';
export { PLACEHOLDER_TYPE, isComponentNode, ComponentContext, getKnownSchemaKeys, validateFunctionArgs, isSingleAtKey, unescapeObjectKey, validateReservedDirectives, resolveContextIndex, MAX_DYNAMIC_VALUE_DEPTH, DataContext, scrapeComponentBehavior, scrapeSchemaBehavior, getSafeChildList, MAX_DYNAMIC_CHILD_LIST_SIZE, GenericBinder, NodeResolver, extractRefFields, isWritable, sameBinding, ResolvedBinding, WritableBinding, } from '../resolution/index.js';
export { FunctionDefinitionSchema, InlineCatalogSchema, A2uiVersionCapabilitiesSchema, A2uiClientActionSchema, A2uiValidationErrorSchema, A2uiGenericErrorSchema, A2uiClientErrorSchema, A2uiClientMessageSchema, A2uiClientDataModelSchema, A2uiClientMessageListSchema, A2uiClientMessageListWrapperSchema, ComponentIdSchema, DataBindingSchema, DynamicValueSchema, FunctionCallSchema, DynamicStringSchema, AccessibilityAttributesSchema, ComponentCommonSchema, ChildListSchema, DynamicNumberSchema, DynamicBooleanSchema, DynamicStringListSchema, CheckRuleSchema, CheckableSchema, ActionSchema, CommonSchemas, CreateSurfaceMessageSchema, UpdateComponentsMessageSchema, UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema, A2uiMessageSchema, A2uiMessageListSchema, A2uiMessageListWrapperSchema, markChildRef, childRefKindOf, TemplateChildListSchema, componentId, dynamicString, dynamicNumber, dynamicBoolean, dynamicValue, dynamicStringList, childList, AnyComponentSchema, } from './schema/index.js';
export { V09_CHILD_REF_OPTIONS, V09_STANDARD_DEFS } from './standard_defs.js';
export { ComponentModel } from '../state/component-model.js';
export { MAX_ARRAY_INDEX, DataModel } from '../state/data-model.js';
export { SurfaceComponentsModel } from '../state/surface-components-model.js';
export { SurfaceGroupModel } from '../state/surface-group-model.js';
export { SurfaceModel, } from '../state/surface-model.js';
export { A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiCatalogError, A2uiIntegrityError, A2uiRecursionError, } from '../errors.js';
export { MAX_FUNCTION_CALL_ARGS } from '../types/helpers.js';
export { basicCatalog, Context, markdown, setMarkdownRenderer, getMarkdownRenderer, ThemeSchema, A2uiAudioPlayer, A2uiButton, A2uiCard, A2uiCheckBox, A2uiChoicePicker, A2uiColumn, A2uiDateTimeInput, A2uiDivider, A2uiIcon, A2uiImage, A2uiList, A2uiModal, A2uiRow, A2uiSlider, A2uiTabs, A2uiText, A2uiTextField, A2uiVideo, BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, MAX_EXPRESSION_TEMPLATE_LENGTH, MAX_EXPRESSION_PARTS, ExpressionParser, createFormatNumberImplementation, createFormatCurrencyImplementation, createFormatDateImplementation, createPluralizeImplementation, createV09SpecFunctions, createBasicCatalogFunctions, isSafeRegex, AddImplementation, SubtractImplementation, MultiplyImplementation, DivideImplementation, EqualsImplementation, NotEqualsImplementation, GreaterThanImplementation, LessThanImplementation, ContainsImplementation, StartsWithImplementation, EndsWithImplementation, LEGACY_V09_FUNCTIONS, AndImplementation, OrImplementation, NotImplementation, RequiredImplementation, RegexImplementation, LengthImplementation, NumericImplementation, EmailImplementation, FormatStringImplementation, FormatNumberImplementation, FormatCurrencyImplementation, FormatDateImplementation, PluralizeImplementation, OpenUrlImplementation, V09_SPEC_FUNCTIONS, BASIC_FUNCTIONS, AddApi, SubtractApi, MultiplyApi, DivideApi, EqualsApi, NotEqualsApi, GreaterThanApi, LessThanApi, ContainsApi, StartsWithApi, EndsWithApi, LEGACY_V09_FUNCTION_APIS, RequiredApi, RegexApi, LengthApi, NumericApi, EmailApi, FormatStringApi, FormatNumberApi, FormatCurrencyApi, FormatDateApi, PluralizeApi, OpenUrlApi, AndApi, OrApi, NotApi, BASIC_FUNCTION_APIS, V09_SPEC_FUNCTION_APIS, isValidCssColor, HEX_COLOR_REGEX, BasicCatalogThemeSchema, } from './basic_catalog/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, } from '../common/regex_subset.js';
export { getComponentReferences, validateRecursionAndPaths, MAX_GLOBAL_DEPTH, MAX_FUNC_CALL_DEPTH, RELAXED_PATH_PATTERN, analyzeChildRefSchema, assertUax31Identifier, buildComponentRefMap, isChildListSchema, isChildOrChildListSchema, isChildSchema, isValidUax31Identifier, V08_CHILD_REF_OPTIONS, V10_CHILD_REF_OPTIONS, } from '../validation/integrity-checker.js';
export { 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
injectBasicCatalogStyles, 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
computeColorVariant, } from '../universal/basic_catalog/styles/default.js';
export { effect, signal, computed, getValue, peekValue, batchWrite, isSignal, setValue, setSignalImplementation, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, } from '../reactivity/signals.js';
import A2uiMessageSchemaRaw from './schemas/server_to_client.json' with { type: 'json' };
export const Schemas = {
    A2uiMessageSchemaRaw,
};
//# sourceMappingURL=index.js.map