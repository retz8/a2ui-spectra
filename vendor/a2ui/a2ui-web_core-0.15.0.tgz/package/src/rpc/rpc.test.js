/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it } from 'node:test';
import * as assert from 'node:assert';
import { z } from 'zod';
import { Catalog, createFunctionImplementation } from '../catalog/types.js';
import { FormatStringImplementation, PluralizeImplementation, } from '../catalogs/basic/v1/functions/basic_functions.js';
import { A2uiError } from '../errors.js';
import { isSignal, peekValue, signal } from '../reactivity/signals.js';
import { DataContext } from '../resolution/data-context.js';
import { SurfaceModel } from '../state/surface-model.js';
import { IndexImplementation } from '../v1_0/functions/system_functions.js';
import { A2uiRpcError, RpcErrorCode, RpcHandler } from './rpc-handler.js';
describe('Stage 3 (Sauce-TS) Bidirectional RPC & @index Function Verification', () => {
    const customRpcApi = {
        name: 'customRpc',
        returnType: 'string',
        schema: z.object({ text: z.string() }),
        allowedCallers: 'rendererOrAgent',
    };
    const customRpcImpl = createFunctionImplementation(customRpcApi, args => `Processed: ${args.text}`);
    const rendererOnlyApi = {
        name: 'internalRenderer',
        returnType: 'void',
        schema: z.object({}),
        allowedCallers: 'rendererOnly',
    };
    const rendererOnlyImpl = createFunctionImplementation(rendererOnlyApi, () => { });
    const restrictedApi = {
        name: 'userActionOnly',
        returnType: 'boolean',
        schema: z.object({}),
        allowedCallers: 'rendererOrAgent',
        requiresUserActivation: true,
    };
    const restrictedImpl = createFunctionImplementation(restrictedApi, () => true);
    const signalApi = {
        name: 'signalFunc',
        returnType: 'number',
        schema: z.object({}),
        allowedCallers: 'rendererOrAgent',
    };
    const signalImpl = createFunctionImplementation(signalApi, () => signal(42));
    const agentOnlyApi = {
        name: 'agentOnlyFunc',
        returnType: 'string',
        schema: z.object({ text: z.string() }),
        allowedCallers: 'agentOnly',
    };
    const agentOnlyImpl = createFunctionImplementation(agentOnlyApi, args => `Agent: ${args.text}`);
    const mockCatalog = new Catalog('basic', '1.0', [], [
        customRpcImpl,
        rendererOnlyImpl,
        restrictedImpl,
        signalImpl,
        agentOnlyImpl,
        IndexImplementation,
    ]);
    it('instantiates via options bag RpcHandlerOptions', () => {
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            defaultTimeoutMs: 5000,
        });
        assert.strictEqual(handler.disposed, false);
    });
    it('emits RendererFunctionResponseMessage to outboundListener when handleCallRendererFunction completes', async () => {
        const emittedMessages = [];
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: msg => {
                emittedMessages.push(msg);
            },
        });
        const surface = new SurfaceModel('s1', mockCatalog);
        const context = new DataContext(surface, '/');
        const message = {
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-listener-1',
                callFunction: {
                    call: 'customRpc',
                    catalogId: 'basic',
                    args: { text: 'Streaming test' },
                },
            },
        };
        const response = await handler.handleCallRendererFunction(message, context, false);
        assert.strictEqual(response.rendererFunctionResponse.value, 'Processed: Streaming test');
        assert.strictEqual(emittedMessages.length, 1);
        assert.strictEqual(emittedMessages[0].version, '1.0');
        assert.strictEqual(emittedMessages[0].rendererFunctionResponse?.functionCallId, 'rpc-listener-1');
        assert.strictEqual(emittedMessages[0].rendererFunctionResponse?.value, 'Processed: Streaming test');
    });
    it('tracks outbound callAgentFunction and resolves promise via handleAgentFunctionResponse', async () => {
        let emittedMessage;
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: msg => {
                emittedMessage = msg;
            },
        });
        const callPromise = handler.callAgentFunction('surface-1', {
            call: 'fetchRemoteData',
            catalogId: 'basic',
            args: { query: 'test' },
        }, { functionCallId: 'agent-call-100', version: '1.0' });
        assert.strictEqual(emittedMessage.version, '1.0');
        assert.strictEqual(emittedMessage.callAgentFunction.functionCallId, 'agent-call-100');
        assert.deepStrictEqual(emittedMessage.callAgentFunction.callFunction, {
            '@call': 'fetchRemoteData',
            catalogId: 'basic',
            args: { query: 'test' },
        });
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'agent-call-100',
                value: { items: [1, 2, 3] },
            },
        });
        const result = await callPromise;
        assert.deepStrictEqual(result, { items: [1, 2, 3] });
    });
    it('evaluates @index function returning loop index from nested DataContext parent chain and rejects non-trailing root numeric segments', () => {
        const surface = new SurfaceModel('s1', mockCatalog);
        const itemContext = new DataContext(surface, '/items/3');
        const context = itemContext.nested('user/address');
        const indexValue = IndexImplementation.execute({ offset: 1 }, context);
        assert.strictEqual(indexValue, 4);
        // Without a parent template scope, a non-trailing numeric segment is not an index
        const unparentedContext = new DataContext(surface, '/items/3/user/address');
        assert.throws(() => IndexImplementation.execute({ offset: 0 }, unparentedContext));
        // Alphanumeric segment starting with digit should be ignored; trailing numeric segment used
        const context2 = new DataContext(surface, '/order_99/items/2');
        const indexValue2 = IndexImplementation.execute({ offset: 0 }, context2);
        assert.strictEqual(indexValue2, 2);
        // Schema coercion parses string offsets and falls back safely on NaN
        const parsedArgs = IndexImplementation.schema?.parse({ offset: '5' });
        const indexValue3 = IndexImplementation.execute(parsedArgs, context2);
        assert.strictEqual(indexValue3, 7);
    });
    it('generates fallback call function ID when globalThis.crypto is unavailable', async () => {
        const originalCrypto = Object.getOwnPropertyDescriptor(globalThis, 'crypto');
        try {
            Object.defineProperty(globalThis, 'crypto', {
                value: undefined,
                configurable: true,
                writable: true,
            });
            let emittedMsg;
            const handler = new RpcHandler({
                catalogs: [mockCatalog],
                outboundListener: msg => {
                    emittedMsg = msg;
                },
            });
            const callPromise = handler.callAgentFunction('s1', { call: 'testFunc' });
            assert.ok(emittedMsg.callAgentFunction.functionCallId.startsWith('call-'));
            handler.dispose();
            await assert.rejects(callPromise, /CANCELLED/);
        }
        finally {
            if (originalCrypto) {
                Object.defineProperty(globalThis, 'crypto', originalCrypto);
            }
        }
    });
    it('rejects pending agent function calls when RpcHandler is disposed', async () => {
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: () => { },
        });
        const promise = handler.callAgentFunction('surface-1', { call: 'slowFunc' }, { functionCallId: 'pending-1' });
        handler.dispose();
        assert.strictEqual(handler.disposed, true);
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.ok(err instanceof A2uiError);
            assert.strictEqual(err.code, RpcErrorCode.CANCELLED);
            return true;
        });
    });
    it('dispose(reason) cancels pending calls with the reason and drops the outbound listener', async () => {
        const sent = [];
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: msg => {
                sent.push(msg);
            },
        });
        const promise = handler.callAgentFunction('surface-1', { call: 'slowFunc' }, { functionCallId: 'pending-reason' });
        assert.strictEqual(sent.length, 1);
        handler.dispose('session ended');
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.CANCELLED);
            assert.ok(err.message.endsWith(': session ended'), err.message);
            assert.ok(err.message.includes("'pending-reason'"));
            return true;
        });
        assert.strictEqual(handler.outboundListener, undefined);
        await assert.rejects(handler.callAgentFunction('surface-1', { call: 'test' }), (err) => {
            assert.strictEqual(err.code, RpcErrorCode.DISPOSED);
            return true;
        });
        assert.strictEqual(sent.length, 1);
    });
    it('dispose() without a reason ends the cancellation message with a period', async () => {
        const handler = new RpcHandler({ catalogs: [mockCatalog], outboundListener: () => { } });
        const promise = handler.callAgentFunction('surface-1', { call: 'slowFunc' }, { functionCallId: 'p' });
        handler.dispose('');
        await assert.rejects(promise, (err) => {
            assert.strictEqual(err.code, RpcErrorCode.CANCELLED);
            assert.ok(err.message.endsWith("call 'p' was pending."), err.message);
            return true;
        });
    });
    it('fails fast on post-disposal calls', async () => {
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: () => { },
        });
        handler.dispose();
        const surface = new SurfaceModel('s1', mockCatalog);
        const context = new DataContext(surface, '/');
        const response = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'call-post-dispose',
                callFunction: { call: 'customRpc', catalogId: 'basic', args: { text: 'hi' } },
            },
        }, context, true);
        assert.strictEqual(response.rendererFunctionResponse.error?.code, RpcErrorCode.DISPOSED);
        await assert.rejects(handler.callAgentFunction('surface-1', { call: 'test' }), (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.DISPOSED);
            return true;
        });
    });
    it('fails fast when calling callAgentFunction without outboundListener', async () => {
        const handler = new RpcHandler({ catalogs: [mockCatalog] });
        await assert.rejects(handler.callAgentFunction('surface-1', { call: 'test' }), (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.NO_LISTENER);
            return true;
        });
    });
    it('times out callAgentFunction when timeoutMs is exceeded', async () => {
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: () => { },
        });
        const promise = handler.callAgentFunction('surface-1', { call: 'timeoutFunc' }, { functionCallId: 'pending-timeout', timeoutMs: 10 });
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.TIMEOUT);
            return true;
        });
    });
    it('cleans up pending agent call when outboundListener throws', async () => {
        const handler = new RpcHandler([mockCatalog], () => {
            throw new Error('Connection failed');
        });
        await assert.rejects(handler.callAgentFunction('surface-1', { call: 'testFunc' }, { functionCallId: 'fail-outbound' }), /Connection failed/);
    });
    it('rejects callAgentFunction when function call or call name is missing', async () => {
        const handler = new RpcHandler([mockCatalog], () => { });
        await assert.rejects(handler.callAgentFunction('surface-1', undefined), (err) => err instanceof A2uiRpcError && err.code === RpcErrorCode.INVALID_FUNCTION_CALL);
    });
    it('handles null/undefined message gracefully in handleCallRendererFunction', async () => {
        const handler = new RpcHandler([mockCatalog]);
        const surface = new SurfaceModel('s1', mockCatalog);
        const dataContext = new DataContext(surface, '/');
        const res = await handler.handleCallRendererFunction(null, dataContext);
        assert.strictEqual(res.rendererFunctionResponse.error?.code, RpcErrorCode.INVALID_FUNCTION_CALL);
    });
    it('handles null/undefined message gracefully in handleAgentFunctionResponse', () => {
        const handler = new RpcHandler([mockCatalog]);
        assert.doesNotThrow(() => {
            handler.handleAgentFunctionResponse(null);
        });
    });
    it('handles null/undefined options in RpcHandler constructor', () => {
        const handler = new RpcHandler(null);
        assert.strictEqual(handler.disposed, false);
    });
    it('rejects callAgentFunction promise when agentFunctionResponse contains error', async () => {
        const handler = new RpcHandler({ catalogs: [mockCatalog], outboundListener: () => { } });
        const promise = handler.callAgentFunction('s1', { call: 'remoteFunc' }, { functionCallId: 'err-call-1' });
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'err-call-1',
                error: { code: 'SERVER_FAULT', message: 'Internal server failure' },
            },
        });
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, 'SERVER_FAULT');
            assert.strictEqual(err.functionCallId, 'err-call-1');
            return true;
        });
    });
    it('defaults error.code and error.message when agentFunctionResponse contains partial error', async () => {
        const handler = new RpcHandler({ catalogs: [mockCatalog], outboundListener: () => { } });
        const promise = handler.callAgentFunction('s1', { call: 'remoteFunc' }, { functionCallId: 'err-call-partial' });
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'err-call-partial',
                error: {},
            },
        });
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.UNKNOWN_ERROR);
            assert.match(err.message, /\[UNKNOWN_ERROR\] Agent function execution failed/);
            return true;
        });
    });
    it('rejects duplicate pending functionCallId with DUPLICATE error code', async () => {
        const handler = new RpcHandler({ catalogs: [mockCatalog], outboundListener: () => { } });
        const promise1 = handler.callAgentFunction('s1', { call: 'func1' }, { functionCallId: 'dup-1' });
        await assert.rejects(handler.callAgentFunction('s1', { call: 'func2' }, { functionCallId: 'dup-1' }), (err) => err instanceof A2uiRpcError && err.code === RpcErrorCode.DUPLICATE);
        handler.dispose();
        await assert.rejects(promise1, (err) => err instanceof A2uiRpcError && err.code === RpcErrorCode.CANCELLED);
    });
    it('invokes callAgentFunction using modern options bag overload', async () => {
        let emittedMsg;
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: msg => {
                emittedMsg = msg;
            },
        });
        const promise = handler.callAgentFunction('s1', { call: 'fetchData', catalogId: 'basic' }, { functionCallId: 'custom-id-99', timeoutMs: 10000 });
        assert.strictEqual(emittedMsg.callAgentFunction.functionCallId, 'custom-id-99');
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'custom-id-99',
                value: { data: 'payload' },
            },
        });
        const res = await promise;
        assert.deepStrictEqual(res, { data: 'payload' });
    });
    it('unwraps signal value returned by renderer function', async () => {
        const handler = new RpcHandler([mockCatalog]);
        const surface = new SurfaceModel('s1', mockCatalog);
        const dataContext = new DataContext(surface, '/');
        const res = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'call-signal-1',
                callFunction: {
                    call: 'signalFunc',
                    catalogId: 'basic',
                },
            },
        }, dataContext, true);
        assert.strictEqual(res.rendererFunctionResponse.value, 42);
    });
    it('runs an agentOnly function for an agent-initiated callRendererFunction', async () => {
        const handler = new RpcHandler([mockCatalog]);
        const surface = new SurfaceModel('s1', mockCatalog);
        const dataContext = new DataContext(surface, '/');
        const res = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'call-agent-only-1',
                callFunction: {
                    call: 'agentOnlyFunc',
                    catalogId: 'basic',
                    args: { text: 'hi' },
                },
            },
        }, dataContext, false);
        assert.strictEqual(res.rendererFunctionResponse.error, undefined);
        assert.strictEqual(res.rendererFunctionResponse.value, 'Agent: hi');
    });
    it('rejects callRendererFunction when catalogId is omitted, with or without surface context', async () => {
        const handler = new RpcHandler([mockCatalog]);
        const emptyContext = {};
        const res = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'call-no-surface-default',
                callFunction: {
                    call: 'customRpc',
                    args: { text: 'hi' },
                },
            },
        }, emptyContext, true);
        assert.ok(res.rendererFunctionResponse.error);
        assert.strictEqual(res.rendererFunctionResponse.error.code, RpcErrorCode.INVALID_FUNCTION_CALL);
        assert.ok(res.rendererFunctionResponse.error.message.includes('No catalog available for function resolution'));
        const surface = new SurfaceModel('s1', mockCatalog);
        const surfaceContext = new DataContext(surface, '/');
        const resWithSurface = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                surfaceId: 's1',
                functionCallId: 'call-with-surface-no-catalog',
                callFunction: {
                    call: 'customRpc',
                    args: { text: 'hi' },
                },
            },
        }, surfaceContext, true);
        assert.ok(resWithSurface.rendererFunctionResponse.error);
        assert.strictEqual(resWithSurface.rendererFunctionResponse.error.code, RpcErrorCode.INVALID_FUNCTION_CALL);
        assert.ok(resWithSurface.rendererFunctionResponse.error.message.includes('No catalog available for function resolution'));
    });
    it('awaits an asynchronous nested call in the arguments before validating a callRendererFunction', async () => {
        const asyncEchoImpl = createFunctionImplementation({
            name: 'asyncEcho',
            returnType: 'any',
            schema: z.object({ value: z.string() }),
            allowedCallers: 'rendererOrAgent',
        }, async (args) => {
            await Promise.resolve();
            return args.value;
        });
        const catalog = new Catalog('basic', '1.0', [], [customRpcImpl, asyncEchoImpl]);
        const handler = new RpcHandler({ catalogs: [catalog] });
        const surface = new SurfaceModel('s1', catalog);
        const context = new DataContext(surface, '/');
        const response = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-async-arg',
                callFunction: {
                    '@call': 'customRpc',
                    catalogId: 'basic',
                    args: { text: { '@call': 'asyncEcho', args: { value: 'settled' } } },
                },
            },
        }, context, false);
        assert.strictEqual(response.rendererFunctionResponse.error, undefined);
        assert.strictEqual(response.rendererFunctionResponse.value, 'Processed: settled');
    });
    it('answers with an error when an asynchronous nested argument rejects', async () => {
        const asyncFailImpl = createFunctionImplementation({
            name: 'asyncFail',
            returnType: 'any',
            schema: z.object({}),
            allowedCallers: 'rendererOrAgent',
        }, async () => {
            await Promise.resolve();
            throw new Error('upstream failed');
        });
        const catalog = new Catalog('basic', '1.0', [], [customRpcImpl, asyncFailImpl]);
        const handler = new RpcHandler({ catalogs: [catalog] });
        const surface = new SurfaceModel('s1', catalog);
        const context = new DataContext(surface, '/');
        const response = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-async-fail',
                callFunction: {
                    '@call': 'customRpc',
                    catalogId: 'basic',
                    args: { text: { '@call': 'asyncFail', args: {} } },
                },
            },
        }, context, false);
        assert.strictEqual(response.rendererFunctionResponse.error?.code, RpcErrorCode.EXECUTION_ERROR);
        assert.match(response.rendererFunctionResponse.error?.message ?? '', /upstream failed/);
        assert.strictEqual(response.rendererFunctionResponse.value, undefined);
    });
    it('formats A2uiRpcError with the blueprint-standard (message, code, functionCallId, details) signature', () => {
        const standardErr = new A2uiRpcError('Something failed', RpcErrorCode.TIMEOUT, 'call-1');
        assert.strictEqual(standardErr.code, 'TIMEOUT');
        assert.strictEqual(standardErr.message, '[TIMEOUT] Something failed');
        assert.strictEqual(standardErr.functionCallId, 'call-1');
        const defaultCodeErr = new A2uiRpcError('Default code error');
        assert.strictEqual(defaultCodeErr.code, RpcErrorCode.UNKNOWN_ERROR);
        assert.strictEqual(defaultCodeErr.message, '[UNKNOWN_ERROR] Default code error');
        const customCodeErr = new A2uiRpcError('Server blew up', 'SERVER_FAULT', 'call-2', {
            status: 500,
        });
        assert.strictEqual(customCodeErr.code, 'SERVER_FAULT');
        assert.strictEqual(customCodeErr.message, '[SERVER_FAULT] Server blew up');
        assert.strictEqual(customCodeErr.functionCallId, 'call-2');
        assert.deepStrictEqual(customCodeErr.details, { status: 500 });
    });
    it('enforces the default 30s timeout when timeoutMs is omitted', async (t) => {
        t.mock.timers.enable({ apis: ['setTimeout'] });
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: () => { },
        });
        const pendingMap = handler
            .pendingAgentCalls;
        const promise = handler.callAgentFunction('surface-1', { call: 'defaultTimeoutFunc' }, { functionCallId: 'default-timeout-1' });
        assert.strictEqual(pendingMap.size, 1);
        t.mock.timers.tick(29999);
        assert.strictEqual(pendingMap.size, 1);
        t.mock.timers.tick(1);
        await assert.rejects(promise, (err) => {
            assert.ok(err instanceof A2uiRpcError);
            assert.strictEqual(err.code, RpcErrorCode.TIMEOUT);
            assert.strictEqual(err.functionCallId, 'default-timeout-1');
            assert.match(err.message, /timed out after 30000ms/);
            return true;
        });
        assert.strictEqual(pendingMap.size, 0);
        // A late response for the timed-out call ID is ignored and leaves the pending map empty.
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'default-timeout-1',
                value: 'too-late',
            },
        });
        assert.strictEqual(pendingMap.size, 0);
    });
    it('cleans up pending call when outbound listener rejects asynchronously and ignores late response', async () => {
        let rejectSend;
        const handler = new RpcHandler({
            catalogs: [mockCatalog],
            outboundListener: () => new Promise((_resolve, reject) => {
                rejectSend = reject;
            }),
        });
        const pendingMap = handler
            .pendingAgentCalls;
        const promise = handler.callAgentFunction('surface-1', { call: 'abortableFunc' }, { functionCallId: 'abort-call-1' });
        assert.strictEqual(pendingMap.size, 1);
        const thrown = new Error('transport aborted');
        rejectSend(thrown);
        await assert.rejects(promise, (err) => {
            assert.strictEqual(err, thrown);
            return true;
        });
        assert.strictEqual(pendingMap.size, 0);
        // A later response for the rejected functionCallId is ignored and leaves the map empty.
        handler.handleAgentFunctionResponse({
            version: '1.0',
            agentFunctionResponse: {
                functionCallId: 'abort-call-1',
                value: { ignored: true },
            },
        });
        assert.strictEqual(pendingMap.size, 0);
    });
    it('scopes formatString template calls to resolved.catalog.id across concurrent async calls and standalone RpcHandler catalogs', async () => {
        const catAId = 'https://example.com/cat-a/catalog.json';
        const catBId = 'https://example.com/cat-b/catalog.json';
        const standaloneId = 'https://example.com/standalone/catalog.json';
        const labelA = createFunctionImplementation({ name: 'label', returnType: 'string', schema: z.object({}) }, () => 'from-A');
        const labelB = createFunctionImplementation({ name: 'label', returnType: 'string', schema: z.object({}) }, () => 'from-B');
        const labelStandalone = createFunctionImplementation({ name: 'label', returnType: 'string', schema: z.object({}) }, () => 'from-standalone');
        let releaseA;
        const gateA = new Promise(resolve => {
            releaseA = resolve;
        });
        const asyncFormatA = createFunctionImplementation({
            name: 'asyncFormat',
            returnType: 'any',
            schema: z.object({ value: z.string() }),
            allowedCallers: 'rendererOrAgent',
        }, async (args, ctx) => {
            await gateA;
            const sigOrStr = FormatStringImplementation.execute({ value: args.value }, ctx);
            return isSignal(sigOrStr) ? peekValue(sigOrStr) : sigOrStr;
        });
        const asyncFormatB = createFunctionImplementation({
            name: 'asyncFormat',
            returnType: 'any',
            schema: z.object({ value: z.string() }),
            allowedCallers: 'rendererOrAgent',
        }, async (args, ctx) => {
            const sigOrStr = FormatStringImplementation.execute({ value: args.value }, ctx);
            return isSignal(sigOrStr) ? peekValue(sigOrStr) : sigOrStr;
        });
        const rpcFormatString = {
            ...FormatStringImplementation,
            allowedCallers: 'rendererOrAgent',
        };
        const catA = new Catalog(catAId, '1.0', [], [rpcFormatString, PluralizeImplementation, labelA, asyncFormatA]);
        const catB = new Catalog(catBId, '1.0', [], [rpcFormatString, labelB, asyncFormatB]);
        const standaloneCat = new Catalog(standaloneId, '1.0', [], [rpcFormatString, PluralizeImplementation, labelStandalone]);
        const surface = new SurfaceModel('s-rpc-defaultless', undefined, new Map([
            [catAId, catA],
            [catBId, catB],
        ]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const surfaceErrors = [];
        surface.onError.subscribe(err => {
            surfaceErrors.push(err);
        });
        const sharedCtx = new DataContext(surface, '/items/0', 0);
        const handler = new RpcHandler({
            catalogs: [catA, catB, standaloneCat],
        });
        // Launch slow call A, let fast call B run and finish on the same DataContext while A waits, then release A.
        const pendingA = handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-cat-a',
                callFunction: {
                    '@call': 'asyncFormat',
                    catalogId: catAId,
                    args: {
                        value: "Row ${@index()}: ${label()} (${pluralize(value: 2, one: 'drop', other: 'drops')})",
                    },
                },
            },
        }, sharedCtx);
        const resB = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-cat-b',
                callFunction: {
                    '@call': 'asyncFormat',
                    catalogId: catBId,
                    args: { value: 'Row ${@index()}: ${label()}' },
                },
            },
        }, sharedCtx);
        releaseA();
        const resA = await pendingA;
        assert.strictEqual(resB.rendererFunctionResponse.value, 'Row 0: from-B');
        assert.strictEqual(resA.rendererFunctionResponse.value, 'Row 0: from-A (drops)');
        // Standalone catalog registered only in `RpcHandler.catalogs` (absent from `surface.availableCatalogs`).
        const resStandalone = await handler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-standalone',
                callFunction: {
                    '@call': 'formatString',
                    catalogId: standaloneId,
                    args: {
                        value: "Row ${@index()}: ${label()} (${pluralize(value: 1, one: 'drop', other: 'drops')})",
                    },
                },
            },
        }, sharedCtx);
        assert.strictEqual(resStandalone.rendererFunctionResponse.value, 'Row 0: from-standalone (drop)');
        assert.strictEqual(surface.availableCatalogs.has(standaloneId), false);
        assert.strictEqual(surfaceErrors.length, 0);
        // Dynamic `@call` inside `callFunction.args` targeting `standaloneId` resolves cleanly,
        // while targeting an unnegotiated catalog fails with `EXECUTION_ERROR`.
        const makeLabelHelper = (text) => createFunctionImplementation({ name: 'label', returnType: 'string', schema: z.object({}) }, () => text);
        const echoLabelImpl = createFunctionImplementation({
            name: 'echoLabel',
            returnType: 'string',
            schema: z.object({ label: z.string() }),
            allowedCallers: 'agentOnly',
        }, args => args.label);
        const echoStandaloneCat = new Catalog('https://example.com/rpc-echo-standalone/catalog.json', '1.0', [], [echoLabelImpl, FormatStringImplementation, makeLabelHelper('arg-standalone')]);
        const otherUnnegotiatedCat = new Catalog('https://example.com/rpc-other-unnegotiated/catalog.json', '1.0', [], [makeLabelHelper('leaked')]);
        const argHandler = new RpcHandler({
            catalogs: [echoStandaloneCat, otherUnnegotiatedCat],
        });
        const argRes = await argHandler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-standalone-arg',
                callFunction: {
                    '@call': 'echoLabel',
                    catalogId: echoStandaloneCat.id,
                    args: {
                        label: {
                            '@call': 'formatString',
                            catalogId: echoStandaloneCat.id,
                            args: { value: 'Arg: ${label()}' },
                        },
                    },
                },
            },
        }, sharedCtx);
        assert.strictEqual(argRes.rendererFunctionResponse.value, 'Arg: arg-standalone');
        const badArgRes = await argHandler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-unnegotiated-arg',
                callFunction: {
                    '@call': 'echoLabel',
                    catalogId: echoStandaloneCat.id,
                    args: {
                        label: {
                            '@call': 'label',
                            catalogId: otherUnnegotiatedCat.id,
                            args: {},
                        },
                    },
                },
            },
        }, sharedCtx);
        assert.strictEqual(badArgRes.rendererFunctionResponse.error?.code, 'EXECUTION_ERROR');
        // Same-ID negotiated schema-only surface catalog + executable `RpcHandler` catalog.
        const sharedId = 'https://example.com/rpc-shared-schema-only/catalog.json';
        const schemaOnlySurfaceCat = Catalog.fromJson({
            catalogId: sharedId,
            protocolVersion: '1.0',
            components: {},
            functions: {
                formatString: {
                    returnType: 'string',
                    allowedCallers: 'rendererOrAgent',
                    parameters: { type: 'object', properties: { value: { type: 'string' } } },
                },
                label: {
                    returnType: 'string',
                    parameters: { type: 'object', properties: {} },
                },
            },
        }, '1.0');
        const execRpcCat = new Catalog(sharedId, '1.0', [], [rpcFormatString, makeLabelHelper('from-exec-rpc')]);
        const schemaOnlySurface = new SurfaceModel('s-rpc-schema-only', schemaOnlySurfaceCat, new Map([[sharedId, schemaOnlySurfaceCat]]), undefined, undefined, undefined, undefined, undefined, '1.0');
        const schemaOnlyCtx = new DataContext(schemaOnlySurface, '/');
        const sharedHandler = new RpcHandler({ catalogs: [execRpcCat] });
        const sharedRes = await sharedHandler.handleCallRendererFunction({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'rpc-same-id-schema-only',
                callFunction: {
                    '@call': 'formatString',
                    catalogId: sharedId,
                    args: { value: 'Resolved: ${label()}' },
                },
            },
        }, schemaOnlyCtx);
        assert.strictEqual(sharedRes.rendererFunctionResponse.value, 'Resolved: from-exec-rpc');
    });
});
//# sourceMappingURL=rpc.test.js.map