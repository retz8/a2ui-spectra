import type { WebComponentImplementation } from './web_component_implementation.js';
/**
 * Registers a Web Component's custom element in the browser's `customElements` registry.
 *
 * This operation is idempotent: if the custom element is already registered with the
 * identical constructor, this function safely no-ops. If a different constructor is
 * already registered for the same tag name, this function throws an error.
 *
 * In environments without `customElements` (for example SSR) it returns without registering
 * and reports the problem once via `console.error`.
 *
 * @param component The WebComponentImplementation defining the custom element.
 */
export declare function registerUniversalElement(component: WebComponentImplementation): void;
//# sourceMappingURL=register_universal_element.d.ts.map