export { setMarkdownRenderer, getMarkdownRenderer, resetMarkdownWarningLoggedForTesting, markdown, } from './markdown.js';
//# sourceMappingURL=directives.d.ts.map