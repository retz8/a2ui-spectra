import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { CardSupportedApis } from './supported_apis.js';
export declare class A2uiCardElement extends BasicCatalogA2uiLitElement<CardSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-card";
    /**
     * The styles of the card can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-card-border`: The styling for the card border. Defaults to `--a2ui-border-width` width and `--a2ui-color-border` color.
     * - `--a2ui-card-border-radius`: The border radius of the card. Defaults to `--a2ui-border-radius`.
     * - `--a2ui-card-padding`: The padding of the card. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-card-box-shadow`: The box shadow of the card. Defaults to `0 2px 4px rgba(0,0,0,0.1)`.
     * - `--a2ui-card-margin`: The outer margin of the card. Defaults to `--a2ui-spacing-m`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Card.d.ts.map