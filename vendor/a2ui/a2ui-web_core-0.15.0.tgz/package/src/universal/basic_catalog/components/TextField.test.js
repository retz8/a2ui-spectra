/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('TextField Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'field_name',
                            component: 'TextField',
                            label: 'Username',
                            value: { path: '/user/name' },
                        },
                        {
                            id: 'field_long',
                            component: 'TextField',
                            label: 'Bio',
                            value: 'Initial Bio',
                            variant: 'longText',
                        },
                        {
                            id: 'field_invalid',
                            component: 'TextField',
                            label: 'Email',
                            value: '',
                            checks: [
                                {
                                    condition: false,
                                    message: 'Email is required',
                                },
                                {
                                    condition: false,
                                    message: 'Email must contain @',
                                },
                            ],
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
        surface.dataModel.set('/user/name', 'Bob');
    });
    afterEach(() => {
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render input field with label and initial value', async () => {
        const el = document.createElement('a2ui-basic-textfield');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'field_name');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const label = el.querySelector('label');
        assert.notStrictEqual(label, null);
        assert.strictEqual(label?.textContent?.trim(), 'Username');
        const input = el.querySelector('input');
        assert.notStrictEqual(input, null);
        assert.strictEqual(input?.value, 'Bob');
    });
    it('should update the data model value on input event', async () => {
        const el = document.createElement('a2ui-basic-textfield');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'field_name');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const input = el.querySelector('input');
        assert.notStrictEqual(input, null);
        input.value = 'Alice';
        input.dispatchEvent(new Event('input'));
        await asyncUpdate(el, () => { });
        // Check that the value is updated in the data model
        assert.strictEqual(surface.dataModel.get('/user/name'), 'Alice');
    });
    it('should render textarea for longText variant', async () => {
        const el = document.createElement('a2ui-basic-textfield');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'field_long');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const textarea = el.querySelector('textarea');
        assert.notStrictEqual(textarea, null);
        assert.strictEqual(textarea?.value, 'Initial Bio');
        const input = el.querySelector('input');
        assert.strictEqual(input, null);
    });
    it('should render all validation error messages when invalid', async () => {
        const el = document.createElement('a2ui-basic-textfield');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'field_invalid');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const errors = el.querySelectorAll('.a2ui-error-message');
        assert.strictEqual(errors.length, 2);
        assert.strictEqual(errors[0].textContent?.trim(), 'Email is required');
        assert.strictEqual(errors[1].textContent?.trim(), 'Email must contain @');
        const input = el.querySelector('input');
        assert.notStrictEqual(input, null);
        assert.strictEqual(input?.classList.contains('a2ui-invalid'), true);
        const errorContainer = el.querySelector('.a2ui-validation-errors');
        assert.strictEqual(errorContainer?.hasAttribute('role'), false);
        assert.strictEqual(input?.getAttribute('aria-invalid'), 'true');
        assert.strictEqual(input?.getAttribute('aria-describedby'), errorContainer?.id);
    });
    it('associates <label for> with <input> and <textarea> using distinct IDs and applies accessibility props', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'field_a11y',
                            component: 'TextField',
                            label: 'Phone',
                            value: '',
                            accessibility: {
                                label: 'Contact phone number',
                                description: 'Include country code',
                            },
                        },
                    ],
                },
            },
        ]);
        const firstEl = document.createElement('a2ui-basic-textfield');
        firstEl.context = new ComponentContext(surface, 'field_a11y');
        document.body.appendChild(firstEl);
        await asyncUpdate(firstEl);
        const secondEl = document.createElement('a2ui-basic-textfield');
        secondEl.context = new ComponentContext(surface, 'field_long');
        document.body.appendChild(secondEl);
        await asyncUpdate(secondEl);
        assert.strictEqual(firstEl.hasAttribute('aria-label'), false);
        const firstLabel = firstEl.querySelector('label');
        const firstInput = firstEl.querySelector('input');
        assert.ok(firstInput?.id);
        assert.strictEqual(firstLabel?.getAttribute('for'), firstInput?.id);
        assert.strictEqual(firstInput?.getAttribute('aria-label'), 'Contact phone number');
        assert.strictEqual(firstInput?.getAttribute('aria-description'), 'Include country code');
        assert.strictEqual(firstInput?.hasAttribute('aria-invalid'), false);
        assert.strictEqual(firstInput?.hasAttribute('aria-describedby'), false);
        const secondLabel = secondEl.querySelector('label');
        const secondTextarea = secondEl.querySelector('textarea');
        assert.ok(secondTextarea?.id);
        assert.notStrictEqual(secondTextarea?.id, firstInput?.id);
        assert.strictEqual(secondLabel?.getAttribute('for'), secondTextarea?.id);
        firstEl.remove();
        secondEl.remove();
    });
});
//# sourceMappingURL=TextField.test.js.map