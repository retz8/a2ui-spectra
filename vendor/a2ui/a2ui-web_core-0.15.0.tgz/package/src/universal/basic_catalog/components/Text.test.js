/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
import { setMarkdownRenderer } from '../directives/markdown.js';
describe('Text Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 't_static',
                            component: 'Text',
                            text: 'Hello static text',
                        },
                        {
                            id: 't_dynamic',
                            component: 'Text',
                            text: { path: '/dynamic_msg' },
                        },
                        {
                            id: 't_caption',
                            component: 'Text',
                            text: 'Caption text',
                            variant: 'caption',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
        surface.dataModel.set('/dynamic_msg', 'Hello dynamic text');
    });
    afterEach(() => {
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render static text content', async () => {
        const el = document.createElement('a2ui-basic-text');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 't_static');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const span = el.querySelector('.no-markdown-renderer');
        assert.notStrictEqual(span, null);
        assert.strictEqual(span?.textContent?.trim(), 'Hello static text');
    });
    it('should render reactive dynamic text content', async () => {
        const el = document.createElement('a2ui-basic-text');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 't_dynamic');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const span = el.querySelector('.no-markdown-renderer');
        assert.notStrictEqual(span, null);
        assert.strictEqual(span?.textContent?.trim(), 'Hello dynamic text');
        // Update the data model value
        surface.dataModel.set('/dynamic_msg', 'Updated dynamic text');
        await asyncUpdate(el, () => { });
        assert.strictEqual(span?.textContent?.trim(), 'Updated dynamic text');
    });
    it('should render formatted markdown when a markdown renderer is configured', async () => {
        setMarkdownRenderer(async (text) => `<strong>${text}</strong>`);
        const el = document.createElement('a2ui-basic-text');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 't_static');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        await new Promise(r => setTimeout(r, 20));
        const strong = el.querySelector('strong');
        assert.notStrictEqual(strong, null);
        assert.strictEqual(strong?.textContent?.trim(), 'Hello static text');
        setMarkdownRenderer(undefined);
    });
    it('should apply caption variant styling structure', async () => {
        const el = document.createElement('a2ui-basic-text');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 't_caption');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const captionSpan = el.querySelector('span.a2ui-text.a2ui-text-caption');
        assert.notStrictEqual(captionSpan, null);
        const em = captionSpan?.querySelector('em');
        assert.notStrictEqual(em, null);
        assert.strictEqual(em?.textContent?.trim(), 'Caption text');
        assert.strictEqual(captionSpan?.hasAttribute('role'), false);
    });
    it('places accessibility attributes on semantic headings and role="note" spans', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 't_h2',
                            component: 'Text',
                            text: 'Mott 32',
                            variant: 'h2',
                            accessibility: {
                                label: 'Mott 32 restaurant heading',
                                description: 'Chinese fine dining',
                            },
                        },
                        {
                            id: 't_caption_a11y',
                            component: 'Text',
                            text: '$$$$',
                            variant: 'caption',
                            accessibility: {
                                label: 'Price tier 4 out of 4',
                                description: 'Fine dining price range',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-basic-text');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 't_h2');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        const h2 = el.querySelector('h2');
        assert.notStrictEqual(h2, null);
        assert.strictEqual(h2?.getAttribute('aria-label'), 'Mott 32 restaurant heading');
        assert.strictEqual(h2?.getAttribute('aria-description'), 'Chinese fine dining');
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 't_caption_a11y');
        });
        const captionSpan = el.querySelector('span.a2ui-text.a2ui-text-caption');
        assert.strictEqual(captionSpan?.getAttribute('role'), 'note');
        assert.strictEqual(captionSpan?.getAttribute('aria-label'), 'Price tier 4 out of 4');
        assert.strictEqual(captionSpan?.getAttribute('aria-description'), 'Fine dining price range');
    });
});
//# sourceMappingURL=Text.test.js.map