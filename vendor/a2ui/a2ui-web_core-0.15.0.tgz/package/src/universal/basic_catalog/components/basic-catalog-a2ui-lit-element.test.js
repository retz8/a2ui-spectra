/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, beforeEach, after, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { z } from 'zod';
import { ComponentContext, MessageProcessor, Catalog, peekValue, } from '../../../v0_9/index.js';
import { CheckableSchema } from '../../../v0_9/schema/common-types.js';
import { NodeResolver } from '../../../resolution/node-resolver.js';
describe('BasicCatalogA2uiLitElement', () => {
    let customCatalog;
    before(async () => {
        setupTestDom();
        const { BasicCatalogA2uiLitElement } = await import('./basic-catalog-a2ui-lit-element.js');
        const { renderValidationErrors } = await import('./accessibility.js');
        const { css, html } = await import('lit');
        const TestComponentSchema = z.object({
            text: z.string().optional(),
            weight: z.number().optional(),
            checks: CheckableSchema.shape.checks,
            accessibility: z
                .object({
                label: z.string().optional(),
                description: z.string().optional(),
                live: z.enum(['off', 'polite', 'assertive']).optional(),
                hidden: z.boolean().optional(),
            })
                .optional(),
        });
        const TestComponentApi = {
            name: 'TestComponent',
            schema: TestComponentSchema,
        };
        class TestBasicElement extends BasicCatalogA2uiLitElement {
            constructor() {
                super(...arguments);
                this.api = TestComponentApi;
            }
            render() {
                return html `
          <div class="inner">${this.controller?.props?.text ?? ''}</div>
          ${renderValidationErrors(this.domId, this.controller?.props)}
        `;
            }
        }
        TestBasicElement.styles = css `
        :host {
          display: block;
          color: red;
        }
        .inner {
          font-size: 14px;
        }
      `;
        if (!customElements.get('a2ui-test-basic-element')) {
            customElements.define('a2ui-test-basic-element', TestBasicElement);
        }
        customCatalog = new Catalog('https://test.catalog', '0.9', [TestComponentApi]);
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([customCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: customCatalog.id,
                    theme: {
                        primaryColor: '#ff0055',
                    },
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'TestComponent',
                            text: 'Hello',
                            weight: 2,
                        },
                        {
                            id: 'comp2',
                            component: 'TestComponent',
                            text: 'Themed',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('renders into light DOM (createRenderRoot returns this)', () => {
        element = document.createElement('a2ui-test-basic-element');
        assert.strictEqual(element.createRenderRoot(), element);
        assert.strictEqual(element.shadowRoot, null);
    });
    it('adopts and scopes component styles into document on connection', () => {
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        const styleEl = document.head.querySelector('style');
        if (document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0) {
            assert.ok(document.adoptedStyleSheets.length > 0);
        }
        else {
            assert.notStrictEqual(styleEl, null);
            assert.ok(styleEl?.textContent?.includes('a2ui-test-basic-element'));
        }
    });
    it('applies flex weight when props.weight is provided and removes when undefined', async () => {
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.ok(element.style.flex.startsWith('2'));
        // Update weight to undefined
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'TestComponent',
                            text: 'Hello',
                            weight: undefined,
                        },
                    ],
                },
            },
        ]);
        await asyncUpdate(element, () => { });
        assert.strictEqual(element.style.flex, '');
    });
    it('sets theme primaryColor CSS variables and computes variants', async () => {
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        const context = new ComponentContext(surface, 'comp2');
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary'), '#ff0055');
        assert.ok(element.style.getPropertyValue('--a2ui-color-primary-light').length > 0);
        assert.ok(element.style.getPropertyValue('--a2ui-color-primary-dark').length > 0);
        assert.ok(element.style.getPropertyValue('--a2ui-color-primary-hover').length > 0);
    });
    it('clears theme primaryColor CSS variables when primaryColor is absent', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'no-theme-surface',
                    catalogId: customCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'no-theme-surface',
                    components: [
                        {
                            id: 'comp3',
                            component: 'TestComponent',
                            text: 'Un-themed',
                        },
                    ],
                },
            },
        ]);
        const noThemeSurface = processor.model.getSurface('no-theme-surface');
        const context = new ComponentContext(noThemeSurface, 'comp3');
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-light'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-dark'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-hover'), '');
    });
    it('should ignore invalid primaryColor value from theme', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'invalid-theme-surface',
                    catalogId: customCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'invalid-theme-surface',
                    components: [
                        {
                            id: 'comp4',
                            component: 'TestComponent',
                            text: 'Invalid Themed',
                        },
                    ],
                },
            },
        ]);
        const invalidThemeSurface = processor.model.getSurface('invalid-theme-surface');
        invalidThemeSurface.theme = {
            primaryColor: 'url(https://attacker.example/beacon)',
        };
        const context = new ComponentContext(invalidThemeSurface, 'comp4');
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-light'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-dark'), '');
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary-hover'), '');
    });
    it('sets theme primaryColor CSS variables for named color', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'named-color-surface',
                    catalogId: customCatalog.id,
                    theme: { primaryColor: 'red' },
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'named-color-surface',
                    components: [{ id: 'comp-named', component: 'TestComponent' }],
                },
            },
        ]);
        const namedSurface = processor.model.getSurface('named-color-surface');
        const context = new ComponentContext(namedSurface, 'comp-named');
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary'), 'red');
        assert.ok(element.style.getPropertyValue('--a2ui-color-primary-light').length > 0);
    });
    it('sets theme primaryColor CSS variables for rgb color', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'rgb-color-surface',
                    catalogId: customCatalog.id,
                    theme: { primaryColor: 'rgb(255, 0, 0)' },
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'rgb-color-surface',
                    components: [{ id: 'comp-rgb', component: 'TestComponent' }],
                },
            },
        ]);
        const rgbSurface = processor.model.getSurface('rgb-color-surface');
        const context = new ComponentContext(rgbSurface, 'comp-rgb');
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.context = context;
        });
        assert.strictEqual(element.style.getPropertyValue('--a2ui-color-primary'), 'rgb(255, 0, 0)');
        assert.ok(element.style.getPropertyValue('--a2ui-color-primary-light').length > 0);
    });
    it('applies only aria-live and aria-hidden on host by default and clears them when unset', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp-a11y',
                            component: 'TestComponent',
                            text: 'Live announcement',
                            accessibility: {
                                label: 'Inner label only',
                                description: 'Inner description only',
                                live: 'assertive',
                                hidden: false,
                            },
                        },
                    ],
                },
            },
        ]);
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.context = new ComponentContext(surface, 'comp-a11y');
        });
        assert.strictEqual(element.hasAttribute('aria-label'), false);
        assert.strictEqual(element.hasAttribute('aria-description'), false);
        assert.strictEqual(element.getAttribute('aria-live'), 'assertive');
        assert.strictEqual(element.getAttribute('aria-hidden'), 'false');
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp-a11y',
                            component: 'TestComponent',
                            text: 'Cleared',
                            accessibility: undefined,
                        },
                    ],
                },
            },
        ]);
        await asyncUpdate(element, () => { });
        assert.strictEqual(element.hasAttribute('aria-live'), false);
        assert.strictEqual(element.hasAttribute('aria-hidden'), false);
    });
    it('uses ComponentNode.id for domId when rendered with a node and falls back to nextNodeId otherwise', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'root',
                            component: 'TestComponent',
                            text: 'Invalid',
                            checks: [{ condition: false, message: 'Required' }],
                        },
                    ],
                },
            },
        ]);
        const resolver = new NodeResolver(surface);
        const rootNode = peekValue(resolver.rootNode);
        assert.ok(rootNode);
        element = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(element);
        await asyncUpdate(element, (e) => {
            e.node = rootNode;
        });
        const nodeErrorEl = element.querySelector('.a2ui-validation-errors');
        assert.strictEqual(nodeErrorEl?.id, `${rootNode.id}-error`);
        const contextOnlyEl = document.createElement('a2ui-test-basic-element');
        document.body.appendChild(contextOnlyEl);
        try {
            await asyncUpdate(contextOnlyEl, (e) => {
                e.context = new ComponentContext(surface, 'root');
            });
            const fallbackErrorEl = contextOnlyEl.querySelector('.a2ui-validation-errors');
            assert.ok(fallbackErrorEl?.id.startsWith('a2ui-n'));
            assert.notStrictEqual(fallbackErrorEl?.id, `${rootNode.id}-error`);
        }
        finally {
            contextOnlyEl.remove();
            resolver.dispose();
        }
    });
});
//# sourceMappingURL=basic-catalog-a2ui-lit-element.test.js.map