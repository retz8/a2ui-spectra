/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('Card Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Card',
                            child: 'txt1',
                        },
                        {
                            id: 'txt1',
                            component: 'Text',
                            text: 'hello',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render and display child content', async () => {
        const el = document.createElement('a2ui-card');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const cardDiv = el.querySelector('.a2ui-card');
        assert.notStrictEqual(cardDiv, null);
        const textEl = el.querySelector('a2ui-basic-text');
        assert.notStrictEqual(textEl, null);
        assert.strictEqual(el.textContent?.includes('hello'), true);
        assert.strictEqual(cardDiv?.hasAttribute('role'), false);
        assert.strictEqual(cardDiv?.hasAttribute('aria-label'), false);
    });
    it('sets role="region", aria-label, and aria-description on .a2ui-card when labeled', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'card_a11y',
                            component: 'Card',
                            child: 'txt1',
                            accessibility: {
                                label: 'Mott 32',
                                description: 'Featured restaurant card',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-card');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'card_a11y');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        assert.strictEqual(el.hasAttribute('aria-description'), false);
        const cardDiv = el.querySelector('.a2ui-card');
        assert.notStrictEqual(cardDiv, null);
        assert.strictEqual(cardDiv?.getAttribute('role'), 'region');
        assert.strictEqual(cardDiv?.getAttribute('aria-label'), 'Mott 32');
        assert.strictEqual(cardDiv?.getAttribute('aria-description'), 'Featured restaurant card');
    });
});
//# sourceMappingURL=Card.test.js.map