import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { DividerSupportedApis } from './supported_apis.js';
export declare class A2uiDividerElement extends BasicCatalogA2uiLitElement<DividerSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-divider";
    /**
     * The styles of the divider can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-divider-border`: The styling for the divider border. Defaults to `--a2ui-border-width` solid `--a2ui-color-border`.
     * - `--a2ui-divider-spacing`: The spacing around the divider. Defaults to `--a2ui-spacing-m`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Divider.d.ts.map