import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { CheckBoxSupportedApis } from './supported_apis.js';
export declare class A2uiCheckBoxElement extends BasicCatalogA2uiLitElement<CheckBoxSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-checkbox";
    /**
     * The styles of the checkbox can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-checkbox-size`: Size of the box. Defaults to `1rem`.
     * - `--a2ui-checkbox-border-radius`: Default corner rounding of the box.
     * - `--a2ui-checkbox-gap`: Spacing between the checkbox and its label. Defaults to `8px`.
     * - `--a2ui-checkbox-margin`: Outer margin of the component. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-checkbox-color-error`: Color for invalid state. Defaults to `red`.
     * - `--a2ui-checkbox-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
     * - `--a2ui-checkbox-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=CheckBox.d.ts.map