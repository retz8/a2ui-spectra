/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('Modal Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Modal',
                            trigger: 'txt1',
                            content: 'txt2',
                        },
                        { id: 'txt1', component: 'Text', text: 'Open Modal' },
                        { id: 'txt2', component: 'Text', text: 'Modal Dialog Content' },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render trigger initially and open modal on click to render content', async () => {
        const el = document.createElement('a2ui-modal');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const trigger = el.querySelector('.a2ui-modal-trigger');
        assert.notStrictEqual(trigger, null);
        assert.strictEqual(trigger?.textContent?.includes('Open Modal'), true);
        // Initially closed
        assert.strictEqual(el.querySelector('.a2ui-modal-overlay'), null);
        // Click trigger to open
        trigger.click();
        await asyncUpdate(el, () => { });
        const overlay = el.querySelector('.a2ui-modal-overlay');
        assert.notStrictEqual(overlay, null);
        const modalContent = el.querySelector('.a2ui-modal-content');
        assert.notStrictEqual(modalContent, null);
        assert.strictEqual(modalContent?.textContent?.includes('Modal Dialog Content'), true);
    });
    it('should close when clicking the close button', async () => {
        const el = document.createElement('a2ui-modal');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const trigger = el.querySelector('.a2ui-modal-trigger');
        trigger.click();
        await asyncUpdate(el, () => { });
        assert.notStrictEqual(el.querySelector('.a2ui-modal-overlay'), null);
        const closeBtn = el.querySelector('button.a2ui-modal-close');
        assert.notStrictEqual(closeBtn, null);
        closeBtn.click();
        await asyncUpdate(el, () => { });
        assert.strictEqual(el.querySelector('.a2ui-modal-overlay'), null);
    });
    it('should close when clicking the outside backdrop', async () => {
        const el = document.createElement('a2ui-modal');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const trigger = el.querySelector('.a2ui-modal-trigger');
        trigger.click();
        await asyncUpdate(el, () => { });
        assert.notStrictEqual(el.querySelector('.a2ui-modal-overlay'), null);
        const overlay = el.querySelector('.a2ui-modal-overlay');
        overlay.click();
        await asyncUpdate(el, () => { });
        assert.strictEqual(el.querySelector('.a2ui-modal-overlay'), null);
    });
    it('should not close when clicking inside', async () => {
        const el = document.createElement('a2ui-modal');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const trigger = el.querySelector('.a2ui-modal-trigger');
        trigger.click();
        await asyncUpdate(el, () => { });
        assert.notStrictEqual(el.querySelector('.a2ui-modal-overlay'), null);
        const content = el.querySelector('.a2ui-modal-content');
        content.click();
        await asyncUpdate(el, () => { });
        // Modal overlay should remain open because inner content click event stops propagation
        assert.notStrictEqual(el.querySelector('.a2ui-modal-overlay'), null);
    });
    it('places aria-label and aria-description onto the role="dialog" container when open', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'modal_a11y',
                            component: 'Modal',
                            trigger: 'txt1',
                            content: 'txt2',
                            accessibility: {
                                label: 'Confirm Reservation',
                                description: 'Review party size and date before booking',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-modal');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'modal_a11y');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        const trigger = el.querySelector('.a2ui-modal-trigger');
        trigger.click();
        await asyncUpdate(el, () => { });
        const dialog = el.querySelector('.a2ui-modal-content');
        assert.notStrictEqual(dialog, null);
        assert.strictEqual(dialog?.getAttribute('role'), 'dialog');
        assert.strictEqual(dialog?.getAttribute('aria-modal'), 'true');
        assert.strictEqual(dialog?.getAttribute('aria-label'), 'Confirm Reservation');
        assert.strictEqual(dialog?.getAttribute('aria-description'), 'Review party size and date before booking');
    });
});
//# sourceMappingURL=Modal.test.js.map