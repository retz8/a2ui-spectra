/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('Divider Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Divider',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render an hr element', async () => {
        const el = document.createElement('a2ui-divider');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const hr = el.querySelector('hr');
        assert.notStrictEqual(hr, null);
        assert.strictEqual(hr?.classList.contains('a2ui-divider'), true);
        assert.strictEqual(hr?.classList.contains('a2ui-divider-horizontal'), true);
        assert.strictEqual(hr?.hasAttribute('aria-orientation'), false);
    });
    it('sets aria-orientation="vertical" and accessibility attributes on inner hr', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'div_vert',
                            component: 'Divider',
                            axis: 'vertical',
                            accessibility: {
                                label: 'Column separator',
                                description: 'Separates sidebar from content',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-divider');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'div_vert');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        const hr = el.querySelector('hr');
        assert.notStrictEqual(hr, null);
        assert.strictEqual(hr?.getAttribute('aria-orientation'), 'vertical');
        assert.strictEqual(hr?.getAttribute('aria-label'), 'Column separator');
        assert.strictEqual(hr?.getAttribute('aria-description'), 'Separates sidebar from content');
    });
});
//# sourceMappingURL=Divider.test.js.map