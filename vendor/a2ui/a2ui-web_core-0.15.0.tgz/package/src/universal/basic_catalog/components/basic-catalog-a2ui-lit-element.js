/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiLitElement } from '../../index.js';
import { computeColorVariant, injectBasicCatalogStyles } from '../styles/default.js';
import { isValidCssColor } from '../theme.js';
import { setHostAccessibilityAttributes, } from './accessibility.js';
/**
 * Internal base class for the built-in Basic Catalog components.
 *
 * Extends `A2uiLitElement` to inject global basic catalog CSS, map `props.weight` to flex,
 * and calculate `--a2ui-color-primary` CSS variables from the surface theme.
 *
 * @template Api The component API, or a union of the APIs of every protocol
 *     version the element supports. Props are inferred from each API's schema.
 * @internal
 */
export class BasicCatalogA2uiLitElement extends A2uiLitElement {
    /**
     * Lifecycle hook invoked when the element is connected to the DOM.
     * Injects global basic catalog CSS.
     */
    connectedCallback() {
        super.connectedCallback();
        injectBasicCatalogStyles();
    }
    /**
     * Lifecycle hook invoked before rendering.
     * Resolves the component flex weight and calculates theme color CSS variables.
     *
     * @param changedProperties Map of changed properties with their previous values.
     */
    willUpdate(changedProperties) {
        super.willUpdate(changedProperties);
        const props = this.controller?.props;
        if (props && props.weight !== undefined) {
            this.style.flex = String(props.weight);
        }
        else {
            this.style.removeProperty('flex');
        }
        const primaryColor = this.context?.theme?.primaryColor;
        if (typeof primaryColor === 'string' && isValidCssColor(primaryColor)) {
            this.style.setProperty('--a2ui-color-primary', primaryColor);
            this.style.setProperty('--a2ui-color-primary-light', computeColorVariant('light', { colorVar: '--a2ui-color-primary' }));
            this.style.setProperty('--a2ui-color-primary-dark', computeColorVariant('dark', { colorVar: '--a2ui-color-primary' }));
            this.style.setProperty('--a2ui-color-primary-hover', computeColorVariant('hover', {
                darkVar: '--a2ui-color-primary-dark',
                lightVar: '--a2ui-color-primary-light',
            }));
        }
        else {
            this.style.removeProperty('--a2ui-color-primary');
            this.style.removeProperty('--a2ui-color-primary-light');
            this.style.removeProperty('--a2ui-color-primary-dark');
            this.style.removeProperty('--a2ui-color-primary-hover');
        }
    }
    /**
     * Built-in Basic Catalog components bind `accessibility.label`,
     * `accessibility.description`, and validation attributes directly in their
     * `render()` templates (or via `setContainerAccessibilityAttributes` on
     * `Column` and `Row`), so only host-level `aria-live` and `aria-hidden`
     * are applied on the host when `accessibilityTarget()` is not overridden.
     */
    applyAccessibilityAttributes(accessibility, checkable) {
        if (this.accessibilityTarget() !== null) {
            super.applyAccessibilityAttributes(accessibility, checkable);
            return;
        }
        setHostAccessibilityAttributes(this, accessibility);
    }
}
//# sourceMappingURL=basic-catalog-a2ui-lit-element.js.map