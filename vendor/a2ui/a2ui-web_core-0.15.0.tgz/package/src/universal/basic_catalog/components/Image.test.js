/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
import { ImageApi } from '../../../v0_9/basic_catalog/components/basic_components.js';
describe('Image Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Image',
                            url: 'http://example.com/image.png',
                            description: 'An example image',
                            variant: 'avatar',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render img element with correct attributes and classes', async () => {
        const el = document.createElement('a2ui-image');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const img = el.querySelector('img');
        assert.notStrictEqual(img, null);
        assert.strictEqual(img?.getAttribute('src'), 'http://example.com/image.png');
        assert.strictEqual(img?.getAttribute('alt'), 'An example image');
        assert.strictEqual(img?.classList.contains('a2ui-image'), true);
        assert.strictEqual(img?.classList.contains('a2ui-image-avatar'), true);
    });
    it('should map fit="scaleDown" to valid CSS object-fit: scale-down', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'img_scaledown',
                            component: 'Image',
                            url: 'http://example.com/image.png',
                            fit: 'scaleDown',
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-image');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'img_scaledown');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const img = el.querySelector('img');
        assert.notStrictEqual(img, null);
        assert.strictEqual(img.style.objectFit, 'scale-down');
    });
    it('should allow data: URLs for inline images', async () => {
        const dataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Image',
                            url: dataUrl,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-image');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const img = el.querySelector('img');
        assert.notStrictEqual(img, null);
        assert.strictEqual(img?.getAttribute('src'), dataUrl);
    });
    it('should omit src when url uses a disallowed scheme', async () => {
        const disallowedUrls = [
            'javascript:alert(1)',
            'vbscript:msgbox(1)',
            'file:///etc/passwd',
            'blob:https://example.com/123',
            '//evil.example.com/pixel.png',
            '/\\evil.example.com/pixel.png',
            '/\t/evil.example.com/pixel.png',
            'http:evil.example.com/pixel.png',
            'https:evil.example.com/pixel.png',
        ];
        const el = document.createElement('a2ui-image');
        element = el;
        document.body.appendChild(el);
        for (const badUrl of disallowedUrls) {
            processor.processMessages([
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 'test-surface',
                        components: [
                            {
                                id: 'comp1',
                                component: 'Image',
                                url: badUrl,
                            },
                        ],
                    },
                },
            ]);
            const context = new ComponentContext(surface, 'comp1');
            await asyncUpdate(el, e => {
                e.context = context;
            });
            const img = el.querySelector('img');
            assert.notStrictEqual(img, null);
            assert.strictEqual(img?.getAttribute('src'), null, `Expected src to be omitted for ${badUrl}`);
        }
    });
    describe('ImageApi schema validation', () => {
        it('should parse valid image with description', () => {
            const validImage = {
                url: 'https://example.com/image.png',
                description: 'An example image',
            };
            const parsed = ImageApi.schema.parse(validImage);
            assert.strictEqual(parsed.url, 'https://example.com/image.png');
            assert.strictEqual(parsed.description, 'An example image');
        });
        it('should parse valid image without description', () => {
            const validImage = {
                url: 'https://example.com/image.png',
            };
            const parsed = ImageApi.schema.parse(validImage);
            assert.strictEqual(parsed.url, 'https://example.com/image.png');
            assert.strictEqual(parsed.description, undefined);
        });
        it('should throw on invalid image', () => {
            const invalidImage = {
                url: 123, // Invalid type
            };
            assert.throws(() => ImageApi.schema.parse(invalidImage));
        });
    });
    it('resolves alt from accessibility.label with ?? so explicit empty string stays decorative', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'img_override',
                            component: 'Image',
                            url: 'https://example.com/photo.jpg',
                            description: 'Fallback description',
                            accessibility: {
                                label: 'Accessible photo title',
                                description: 'Detailed visual description',
                            },
                        },
                        {
                            id: 'img_decorative',
                            component: 'Image',
                            url: 'https://example.com/divider.jpg',
                            description: 'Fallback description',
                            accessibility: {
                                label: '',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-image');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'img_override');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        let img = el.querySelector('img');
        assert.strictEqual(img?.getAttribute('alt'), 'Accessible photo title');
        assert.strictEqual(img?.hasAttribute('aria-label'), false);
        assert.strictEqual(img?.getAttribute('aria-description'), 'Detailed visual description');
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'img_decorative');
        });
        img = el.querySelector('img');
        assert.strictEqual(img?.getAttribute('alt'), '');
        assert.strictEqual(img?.hasAttribute('aria-label'), false);
        assert.strictEqual(img?.hasAttribute('aria-description'), false);
    });
});
//# sourceMappingURL=Image.test.js.map