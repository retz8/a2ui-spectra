import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { AudioPlayerSupportedApis } from './supported_apis.js';
export declare class A2uiAudioPlayerElement extends BasicCatalogA2uiLitElement<AudioPlayerSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-audioplayer";
    /** @nocollapse */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=AudioPlayer.d.ts.map