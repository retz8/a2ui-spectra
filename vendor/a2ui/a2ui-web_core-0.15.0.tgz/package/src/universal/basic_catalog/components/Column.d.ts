import { nothing, PropertyValues } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ColumnSupportedApis } from './supported_apis.js';
export declare class A2uiBasicColumnElement extends BasicCatalogA2uiLitElement<ColumnSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-column";
    /**
     * The styles of the column can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-column-gap`: The gap between items in the column. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-column-width`: The width of the column. Defaults to `100%`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    updated(changedProperties: PropertyValues): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Column.d.ts.map