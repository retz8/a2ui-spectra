/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, ComponentModel, MessageProcessor, } from '../../../v0_9/index.js';
import { NodeResolver } from '../../../resolution/node-resolver.js';
import { getValue } from '../../../reactivity/signals.js';
import { registerUniversalElement, } from '../../index.js';
import { ListApi } from '../../../v0_9/basic_catalog/components/basic_components.js';
import { PayloadValidator } from '../../../validation/payload-validator.js';
describe('List Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    let resolver = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'List',
                            children: ['txt1', 'txt2'],
                        },
                        {
                            id: 'txt1',
                            component: 'Text',
                            text: 'List Item 1',
                        },
                        {
                            id: 'txt2',
                            component: 'Text',
                            text: 'List Item 2',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        // Disposed here so that a failed assertion doesn't leave it subscribed to the surface.
        resolver?.dispose();
        resolver = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render children in list container', async () => {
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const listDiv = el.querySelector('.a2ui-list');
        assert.notStrictEqual(listDiv, null);
        const textElements = el.querySelectorAll('a2ui-basic-text');
        assert.strictEqual(textElements.length, 2);
        assert.strictEqual(el.textContent?.includes('List Item 1'), true);
        assert.strictEqual(el.textContent?.includes('List Item 2'), true);
    });
    /**
     * Mounts a List over `root`, whose `late` child has not arrived, and checks it gets no item;
     * then runs `sendLate` and checks the item appears in order.
     */
    async function expectNoItemUntilArrival(root, sendLate) {
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.node = root;
        });
        const items = () => el.querySelectorAll('.a2ui-list-item-none');
        // `late` has not arrived: no empty item (box, gap) stands in for it.
        assert.strictEqual(items().length, 2);
        assert.strictEqual(el.querySelectorAll('a2ui-basic-text').length, 2);
        sendLate();
        await el.updateComplete;
        assert.strictEqual(items().length, 3);
        assert.deepStrictEqual([...el.querySelectorAll('a2ui-basic-text')].map(t => t.node?.componentId), ['a', 'late', 'b']);
    }
    it('emits no item for a child that has not resolved, then adds it on arrival (v0.9)', async () => {
        const nodeProcessor = new MessageProcessor([basicCatalog]);
        nodeProcessor.processMessages([
            {
                version: 'v0.9',
                createSurface: { surfaceId: 'node-surface', catalogId: basicCatalog.id },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'node-surface',
                    components: [
                        { id: 'root', component: 'List', children: ['a', 'late', 'b'] },
                        { id: 'a', component: 'Text', text: 'A' },
                        { id: 'b', component: 'Text', text: 'B' },
                    ],
                },
            },
        ]);
        resolver = new NodeResolver(nodeProcessor.model.getSurface('node-surface'), basicCatalog);
        await expectNoItemUntilArrival(getValue(resolver.rootNode), () => nodeProcessor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'node-surface',
                    components: [{ id: 'late', component: 'Text', text: 'Late' }],
                },
            },
        ]));
    });
    it('emits no item for a child that has not resolved, then adds it on arrival (v1.0)', async () => {
        // v1.0 uses the same universal List as v0.9.
        const v1Catalog = (await import('../../../catalogs/basic/v1/index.js')).basicCatalog;
        const nodeProcessor = new MessageProcessor([v1Catalog]);
        nodeProcessor.processMessages([
            {
                version: '1.0',
                createSurface: { surfaceId: 'node-surface', catalogId: v1Catalog.id },
            },
            {
                version: '1.0',
                updateComponents: {
                    surfaceId: 'node-surface',
                    components: [
                        { id: 'root', component: 'List', children: ['a', 'late', 'b'] },
                        { id: 'a', component: 'Text', text: 'A' },
                        { id: 'b', component: 'Text', text: 'B' },
                    ],
                },
            },
        ]);
        resolver = new NodeResolver(nodeProcessor.model.getSurface('node-surface'), v1Catalog);
        await expectNoItemUntilArrival(getValue(resolver.rootNode), () => nodeProcessor.processMessages([
            {
                version: '1.0',
                updateComponents: {
                    surfaceId: 'node-surface',
                    components: [{ id: 'late', component: 'Text', text: 'Late' }],
                },
            },
        ]));
    });
    it('emits no item for an unknown-type child when rendered from a context alone', async () => {
        // Without a node tree, renderNode builds a ComponentContext and renders nothing for a type
        // the catalog doesn't implement. The List must agree and leave that child out.
        surface.componentsModel.addComponent(new ComponentModel('weird', 'StarRating', {}, basicCatalog));
        surface.componentsModel.addComponent(new ComponentModel('list2', 'List', { children: ['txt1', 'weird', 'txt2'] }, basicCatalog));
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'list2');
        });
        assert.strictEqual(el.querySelectorAll('.a2ui-list-item-none').length, 2);
        assert.strictEqual(el.querySelectorAll('a2ui-basic-text').length, 2);
    });
    it('should track and reuse child elements during a reordering operation', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'list-reorder',
                            component: 'List',
                            children: ['item1', 'item2', 'item3'],
                        },
                        { id: 'item1', component: 'Text', text: 'First Item' },
                        { id: 'item2', component: 'Text', text: 'Second Item' },
                        { id: 'item3', component: 'Text', text: 'Third Item' },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        const context1 = new ComponentContext(surface, 'list-reorder');
        await asyncUpdate(el, e => {
            e.context = context1;
        });
        const initialNodes = Array.from(el.querySelectorAll('a2ui-basic-text'));
        assert.strictEqual(initialNodes.length, 3);
        const node1 = initialNodes[0];
        const node2 = initialNodes[1];
        const node3 = initialNodes[2];
        node1.__marker = 'marker-1';
        node2.__marker = 'marker-2';
        node3.__marker = 'marker-3';
        // Reorder children to ['item3', 'item1', 'item2']
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'list-reorder',
                            component: 'List',
                            children: ['item3', 'item1', 'item2'],
                        },
                    ],
                },
            },
        ]);
        const context2 = new ComponentContext(surface, 'list-reorder');
        await asyncUpdate(el, e => {
            e.context = context2;
        });
        const reorderedNodes = Array.from(el.querySelectorAll('a2ui-basic-text'));
        assert.strictEqual(reorderedNodes.length, 3);
        // Assert that the exact DOM element instances were moved/reused based on tracking
        assert.strictEqual(reorderedNodes[0], node3);
        assert.strictEqual(reorderedNodes[1], node1);
        assert.strictEqual(reorderedNodes[2], node2);
        assert.strictEqual(reorderedNodes[0].__marker, 'marker-3');
        assert.strictEqual(reorderedNodes[1].__marker, 'marker-1');
        assert.strictEqual(reorderedNodes[2].__marker, 'marker-2');
    });
    it('should apply align property to list container', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'list-aligned',
                            component: 'List',
                            children: ['txt1', 'txt2'],
                            align: 'center',
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'list-aligned');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const listDiv = el.querySelector('.a2ui-list');
        assert.notStrictEqual(listDiv, null);
        assert.strictEqual(listDiv.style.alignItems, 'center');
    });
    it('applies list semantics and accessibility attributes across default, ordered, and unordered lists', async () => {
        const v1Catalog = (await import('../../../catalogs/basic/v1/index.js')).basicCatalog;
        const v1Processor = new MessageProcessor([v1Catalog]);
        v1Processor.processMessages([
            {
                version: '1.0',
                createSurface: { surfaceId: 's-list-a11y', catalogId: v1Catalog.id },
            },
            {
                version: '1.0',
                updateComponents: {
                    surfaceId: 's-list-a11y',
                    components: [
                        { id: 't1', component: 'Text', text: 'First' },
                        { id: 't2', component: 'Text', text: 'Second' },
                        {
                            id: 'list_none',
                            component: 'List',
                            children: ['t1', 't2'],
                            accessibility: {
                                label: 'Plain list',
                                description: 'Two items',
                            },
                        },
                    ],
                },
            },
        ]);
        const v1Surface = v1Processor.model.getSurface('s-list-a11y');
        v1Surface.componentsModel.addComponent(new ComponentModel('list_ordered', 'List', {
            listStyle: 'ordered',
            children: ['t1', 't2'],
            accessibility: { label: 'Ranked steps' },
        }, v1Catalog));
        v1Surface.componentsModel.addComponent(new ComponentModel('list_unordered', 'List', {
            listStyle: 'unordered',
            children: ['t1', 't2'],
            accessibility: { label: 'Bullet points' },
        }, v1Catalog));
        const el = document.createElement('a2ui-list');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(v1Surface, 'list_none');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        const divList = el.querySelector('div.a2ui-list');
        assert.strictEqual(divList?.getAttribute('role'), 'list');
        assert.strictEqual(divList?.getAttribute('aria-label'), 'Plain list');
        assert.strictEqual(divList?.getAttribute('aria-description'), 'Two items');
        const items = el.querySelectorAll('.a2ui-list-item-none');
        assert.strictEqual(items.length, 2);
        assert.strictEqual(items[0].getAttribute('role'), 'listitem');
        assert.strictEqual(items[1].getAttribute('role'), 'listitem');
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(v1Surface, 'list_ordered');
        });
        const ol = el.querySelector('ol.a2ui-list');
        assert.strictEqual(ol?.getAttribute('aria-label'), 'Ranked steps');
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(v1Surface, 'list_unordered');
        });
        const ul = el.querySelector('ul.a2ui-list');
        assert.strictEqual(ul?.getAttribute('aria-label'), 'Bullet points');
    });
    describe('ListApi schema validation', () => {
        it('should parse valid list with listStyle', () => {
            const parsed = ListApi.schema.parse({
                children: [],
                listStyle: 'none',
            });
            assert.strictEqual(parsed.listStyle, 'none');
        });
        it('should parse valid listStyle variants', () => {
            assert.strictEqual(ListApi.schema.parse({ children: [], listStyle: 'ordered' }).listStyle, 'ordered');
            assert.strictEqual(ListApi.schema.parse({ children: [], listStyle: 'unordered' }).listStyle, 'unordered');
            assert.strictEqual(ListApi.schema.parse({ children: [], listStyle: 'none' }).listStyle, 'none');
        });
        it('should reject invalid listStyle', () => {
            assert.throws(() => ListApi.schema.parse({
                children: [],
                listStyle: 'invalid',
            }));
        });
        it('should validate list component with listStyle via PayloadValidator', () => {
            const validator = new PayloadValidator(basicCatalog);
            assert.doesNotThrow(() => {
                validator.validateComponent({
                    id: 'list-style-test',
                    component: 'List',
                    children: [],
                    listStyle: 'none',
                });
            });
        });
    });
});
//# sourceMappingURL=List.test.js.map