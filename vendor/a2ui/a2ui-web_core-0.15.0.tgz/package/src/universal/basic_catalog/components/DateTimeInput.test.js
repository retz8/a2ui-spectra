/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('DateTimeInput Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'DateTimeInput',
                            label: 'Birthday',
                            value: '2023-01-01',
                            enableDate: true,
                            enableTime: false,
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render date and label value', async () => {
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const label = el.querySelector('.a2ui-date-time-label');
        assert.notStrictEqual(label, null);
        assert.strictEqual(label?.textContent?.trim(), 'Birthday');
        const input = el.querySelector('input[type="date"]');
        assert.notStrictEqual(input, null);
        assert.strictEqual(input?.value, '2023-01-01');
    });
    it('should update bound data model when date is selected', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 'test-surface',
                    path: '/selectedDate',
                    value: '2023-01-01',
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_bound',
                            component: 'DateTimeInput',
                            label: 'Event Date',
                            value: { path: '/selectedDate' },
                            enableDate: true,
                            enableTime: false,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_bound');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const input = el.querySelector('input[type="date"]');
        assert.notStrictEqual(input, null);
        assert.strictEqual(input?.value, '2023-01-01');
        input.value = '2024-05-20';
        input.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.strictEqual(surface.dataModel.get('/selectedDate'), '2024-05-20');
    });
    it('should render and update correctly in time-only mode', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 'test-surface',
                    path: '/timeVal',
                    value: '09:30',
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_time_only',
                            component: 'DateTimeInput',
                            label: 'Meeting Time',
                            value: { path: '/timeVal' },
                            enableDate: false,
                            enableTime: true,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_time_only');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        // Date input should not be present
        assert.strictEqual(el.querySelector('input[type="date"]'), null);
        const timeInput = el.querySelector('input[type="time"]');
        assert.notStrictEqual(timeInput, null);
        assert.strictEqual(timeInput.value, '09:30');
        // Changing time in time-only mode must update to '14:00', NOT '09:30T14:00:00'
        timeInput.value = '14:00';
        timeInput.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.strictEqual(surface.dataModel.get('/timeVal'), '14:00');
    });
    it('should preserve date and time components when editing in datetime mode', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 'test-surface',
                    path: '/appointment',
                    value: '2024-06-15T10:00:00',
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_combined',
                            component: 'DateTimeInput',
                            label: 'Appointment',
                            value: { path: '/appointment' },
                            enableDate: true,
                            enableTime: true,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_combined');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const dateInput = el.querySelector('input[type="date"]');
        const timeInput = el.querySelector('input[type="time"]');
        assert.notStrictEqual(dateInput, null);
        assert.notStrictEqual(timeInput, null);
        assert.strictEqual(dateInput.value, '2024-06-15');
        assert.strictEqual(timeInput.value, '10:00');
        // Changing time should update time part while preserving date part
        timeInput.value = '15:30';
        timeInput.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.strictEqual(surface.dataModel.get('/appointment'), '2024-06-15T15:30:00');
        // Changing date should update date part while preserving time part
        dateInput.value = '2025-01-20';
        dateInput.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.strictEqual(surface.dataModel.get('/appointment'), '2025-01-20T15:30:00');
    });
    it('should fallback to local calendar date when choosing time first in datetime mode', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 'test-surface',
                    path: '/new_event',
                    value: '',
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_empty',
                            component: 'DateTimeInput',
                            label: 'New Event',
                            value: { path: '/new_event' },
                            enableDate: true,
                            enableTime: true,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_empty');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const timeInput = el.querySelector('input[type="time"]');
        timeInput.value = '11:00';
        timeInput.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        const now = new Date();
        const expectedLocalDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
        assert.strictEqual(surface.dataModel.get('/new_event'), `${expectedLocalDate}T11:00:00`);
    });
    it('should render only a time picker when enableTime is true and enableDate is omitted', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 'test-surface',
                    path: '/t',
                    value: '09:15',
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_time_implicit',
                            component: 'DateTimeInput',
                            value: { path: '/t' },
                            enableTime: true,
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_time_implicit');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.strictEqual(el.querySelector('input[type="date"]'), null);
        const timeInput = el.querySelector('input[type="time"]');
        assert.notStrictEqual(timeInput, null);
        assert.strictEqual(timeInput.value, '09:15');
        timeInput.value = '10:45';
        timeInput.dispatchEvent(new Event('change'));
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.strictEqual(surface.dataModel.get('/t'), '10:45');
    });
    it('should pass min and max attributes to date and time inputs', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_minmax',
                            component: 'DateTimeInput',
                            value: '2026-01-15T12:00:00Z',
                            enableDate: true,
                            enableTime: true,
                            min: '2026-01-01T09:00:00Z',
                            max: '2026-01-31T17:00:00Z',
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-datetimeinput');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'dt_minmax');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const dateInput = el.querySelector('input[type="date"]');
        const timeInput = el.querySelector('input[type="time"]');
        assert.notStrictEqual(dateInput, null);
        assert.notStrictEqual(timeInput, null);
        assert.strictEqual(dateInput.getAttribute('min'), '2026-01-01');
        assert.strictEqual(dateInput.getAttribute('max'), '2026-01-31');
        assert.strictEqual(timeInput.getAttribute('min'), '09:00');
        assert.strictEqual(timeInput.getAttribute('max'), '17:00');
    });
    it('associates labels, group semantics, and validation ARIA across date, time, and combined modes', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'dt_time_a11y',
                            component: 'DateTimeInput',
                            label: 'Check-in Time',
                            value: '15:00',
                            enableDate: false,
                            enableTime: true,
                            accessibility: {
                                description: 'Hotel local time',
                            },
                        },
                        {
                            id: 'dt_combined_invalid',
                            component: 'DateTimeInput',
                            label: 'Reservation',
                            value: '',
                            enableDate: true,
                            enableTime: true,
                            checks: [
                                {
                                    condition: false,
                                    message: 'Reservation date and time required',
                                },
                            ],
                        },
                    ],
                },
            },
        ]);
        const dateOnlyEl = document.createElement('a2ui-datetimeinput');
        dateOnlyEl.context = new ComponentContext(surface, 'comp1');
        document.body.appendChild(dateOnlyEl);
        await asyncUpdate(dateOnlyEl);
        const timeOnlyEl = document.createElement('a2ui-datetimeinput');
        timeOnlyEl.context = new ComponentContext(surface, 'dt_time_a11y');
        document.body.appendChild(timeOnlyEl);
        await asyncUpdate(timeOnlyEl);
        const combinedEl = document.createElement('a2ui-datetimeinput');
        combinedEl.context = new ComponentContext(surface, 'dt_combined_invalid');
        document.body.appendChild(combinedEl);
        await asyncUpdate(combinedEl);
        // Date-only mode links <label for> to <input type="date"> and omits group role
        const dateOnlyLabel = dateOnlyEl.querySelector('label');
        const dateOnlyInput = dateOnlyEl.querySelector('input[type="date"]');
        assert.ok(dateOnlyInput?.id);
        assert.strictEqual(dateOnlyLabel?.getAttribute('for'), dateOnlyInput?.id);
        assert.strictEqual(dateOnlyEl.querySelector('.a2ui-date-time-inputs')?.hasAttribute('role'), false);
        // Time-only mode links <label for> to <input type="time"> with distinct ID
        const timeOnlyLabel = timeOnlyEl.querySelector('label');
        const timeOnlyInput = timeOnlyEl.querySelector('input[type="time"]');
        assert.ok(timeOnlyInput?.id);
        assert.notStrictEqual(timeOnlyInput?.id, dateOnlyInput?.id);
        assert.strictEqual(timeOnlyLabel?.getAttribute('for'), timeOnlyInput?.id);
        assert.strictEqual(timeOnlyInput?.getAttribute('aria-description'), 'Hotel local time');
        // Combined mode wraps both inputs in role="group", labels both inputs, and wires validation errors
        const combinedLabel = combinedEl.querySelector('label');
        const combinedGroup = combinedEl.querySelector('.a2ui-date-time-inputs');
        const combinedDate = combinedEl.querySelector('input[type="date"]');
        const combinedTime = combinedEl.querySelector('input[type="time"]');
        const errorContainer = combinedEl.querySelector('.a2ui-validation-errors');
        assert.ok(combinedLabel?.id);
        assert.strictEqual(combinedLabel?.getAttribute('for'), combinedDate?.id);
        assert.strictEqual(combinedGroup?.getAttribute('role'), 'group');
        assert.strictEqual(combinedGroup?.getAttribute('aria-labelledby'), combinedLabel?.id);
        assert.strictEqual(combinedTime?.getAttribute('aria-labelledby'), combinedLabel?.id);
        assert.strictEqual(errorContainer?.hasAttribute('role'), false);
        assert.strictEqual(combinedDate?.getAttribute('aria-invalid'), 'true');
        assert.strictEqual(combinedDate?.getAttribute('aria-describedby'), errorContainer?.id);
        assert.strictEqual(combinedTime?.getAttribute('aria-invalid'), 'true');
        assert.strictEqual(combinedTime?.getAttribute('aria-describedby'), errorContainer?.id);
        dateOnlyEl.remove();
        timeOnlyEl.remove();
        combinedEl.remove();
    });
});
//# sourceMappingURL=DateTimeInput.test.js.map