import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { DateTimeInputSupportedApis } from './supported_apis.js';
export declare class A2uiDateTimeInputElement extends BasicCatalogA2uiLitElement<DateTimeInputSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-datetimeinput";
    /**
     * The styles of the datetime input can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-datetimeinput-width`: Width of the component. Defaults to `100%`.
     * - `--a2ui-datetimeinput-background`: Controls the background of inputs.
     * - `--a2ui-datetimeinput-color`: Controls the text color of inputs.
     * - `--a2ui-datetimeinput-border`: Controls the border of inputs.
     * - `--a2ui-datetimeinput-border-radius`: Controls the border radius of inputs.
     * - `--a2ui-datetimeinput-padding`: Controls the padding of inputs.
     * - `--a2ui-datetimeinput-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
     * - `--a2ui-datetimeinput-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=DateTimeInput.d.ts.map