/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('Tabs Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'comp1',
                            component: 'Tabs',
                            tabs: [
                                { title: 'Tab 1', child: 'txt1' },
                                { title: 'Tab 2', child: 'txt2' },
                            ],
                        },
                        { id: 'txt1', component: 'Text', text: 'Content 1' },
                        { id: 'txt2', component: 'Text', text: 'Content 2' },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render tab headers with first tab active and display first tab content', async () => {
        const el = document.createElement('a2ui-tabs');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        assert.notStrictEqual(el, null);
        const buttons = el.querySelectorAll('button.a2ui-tab-button');
        assert.strictEqual(buttons.length, 2);
        assert.strictEqual(buttons[0].textContent?.trim(), 'Tab 1');
        assert.strictEqual(buttons[1].textContent?.trim(), 'Tab 2');
        assert.strictEqual(buttons[0].classList.contains('a2ui-tab-button-active'), true);
        assert.strictEqual(buttons[1].classList.contains('a2ui-tab-button-active'), false);
        const content = el.querySelector('.a2ui-tab-content');
        assert.notStrictEqual(content, null);
        assert.strictEqual(content?.textContent?.includes('Content 1'), true);
        assert.strictEqual(content?.textContent?.includes('Content 2'), false);
    });
    it('should switch active tab and render corresponding content when tab header is clicked', async () => {
        const el = document.createElement('a2ui-tabs');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'comp1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const buttons = el.querySelectorAll('button.a2ui-tab-button');
        assert.strictEqual(buttons.length, 2);
        // Click Tab 2
        buttons[1].click();
        await asyncUpdate(el, () => { });
        assert.strictEqual(buttons[0].classList.contains('a2ui-tab-button-active'), false);
        assert.strictEqual(buttons[1].classList.contains('a2ui-tab-button-active'), true);
        const content = el.querySelector('.a2ui-tab-content');
        assert.notStrictEqual(content, null);
        assert.strictEqual(content?.textContent?.includes('Content 2'), true);
        assert.strictEqual(content?.textContent?.includes('Content 1'), false);
    });
    it('should not throw if update cycle occurs before context is assigned', async () => {
        const el = document.createElement('a2ui-tabs');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, () => {
            el.requestUpdate();
        });
    });
    it('wires WAI-ARIA tablist, tab, and tabpanel roles and attributes across tab switches', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'tabs_a11y',
                            component: 'Tabs',
                            tabs: [
                                { title: 'Menu', child: 'txt1' },
                                { title: 'Reviews', child: 'txt2' },
                            ],
                            accessibility: {
                                label: 'Restaurant sections',
                                description: 'Switch between menu and reviews',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-tabs');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'tabs_a11y');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        const tabList = el.querySelector('.a2ui-tab-bar');
        assert.strictEqual(tabList?.getAttribute('role'), 'tablist');
        assert.strictEqual(tabList?.getAttribute('aria-label'), 'Restaurant sections');
        assert.strictEqual(tabList?.getAttribute('aria-description'), 'Switch between menu and reviews');
        const tabs = el.querySelectorAll('button.a2ui-tab-button');
        const panel = el.querySelector('.a2ui-tab-content');
        assert.strictEqual(panel?.getAttribute('role'), 'tabpanel');
        assert.ok(panel?.id);
        assert.strictEqual(tabs[0].getAttribute('role'), 'tab');
        assert.strictEqual(tabs[1].getAttribute('role'), 'tab');
        assert.strictEqual(tabs[0].getAttribute('aria-selected'), 'true');
        assert.strictEqual(tabs[1].getAttribute('aria-selected'), 'false');
        assert.strictEqual(tabs[0].getAttribute('aria-controls'), panel?.id);
        assert.strictEqual(tabs[1].getAttribute('aria-controls'), panel?.id);
        assert.strictEqual(panel?.getAttribute('aria-labelledby'), tabs[0].id);
        tabs[1].click();
        await asyncUpdate(el, () => { });
        assert.strictEqual(tabs[0].getAttribute('aria-selected'), 'false');
        assert.strictEqual(tabs[1].getAttribute('aria-selected'), 'true');
        assert.strictEqual(panel?.getAttribute('aria-labelledby'), tabs[1].id);
    });
});
//# sourceMappingURL=Tabs.test.js.map