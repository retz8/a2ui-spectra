/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { html, nothing, css } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { getAccessibilityDescription, getAccessibilityLabel, getValidationErrorId, renderValidationErrors, } from './accessibility.js';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
export class A2uiCheckBoxElement extends BasicCatalogA2uiLitElement {
    render() {
        const props = this.controller.props;
        if (!props)
            return nothing;
        const isInvalid = props.isValid === false;
        const labelClasses = { 'a2ui-checkbox': true, 'a2ui-invalid': isInvalid };
        const inputClasses = { 'a2ui-invalid': isInvalid };
        return html `
      <div class="a2ui-checkbox-container">
        <label class=${classMap(labelClasses)}>
          <input
            type="checkbox"
            class=${classMap(inputClasses)}
            .checked=${props.value || false}
            aria-label=${getAccessibilityLabel(props.accessibility)}
            aria-description=${getAccessibilityDescription(props.accessibility)}
            aria-invalid=${isInvalid ? 'true' : nothing}
            aria-describedby=${getValidationErrorId(this.domId, props)}
            @change=${(e) => props.setValue?.(e.target.checked)}
          />
          <span class="a2ui-check-box-text">${props.label}</span>
        </label>
        ${renderValidationErrors(this.domId, props)}
      </div>
    `;
    }
}
/** @nocollapse */
A2uiCheckBoxElement.tagName = 'a2ui-checkbox';
/**
 * The styles of the checkbox can be customized by redefining the following
 * CSS variables:
 *
 * - `--a2ui-checkbox-size`: Size of the box. Defaults to `1rem`.
 * - `--a2ui-checkbox-border-radius`: Default corner rounding of the box.
 * - `--a2ui-checkbox-gap`: Spacing between the checkbox and its label. Defaults to `8px`.
 * - `--a2ui-checkbox-margin`: Outer margin of the component. Defaults to `--a2ui-spacing-m`.
 * - `--a2ui-checkbox-color-error`: Color for invalid state. Defaults to `red`.
 * - `--a2ui-checkbox-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
 * - `--a2ui-checkbox-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
 *
 * @nocollapse
 */
A2uiCheckBoxElement.styles = css `
    :host,
    a2ui-checkbox {
      display: block;
    }
    .a2ui-checkbox-container {
      display: flex;
      flex-direction: column;
      margin: var(--a2ui-checkbox-margin, var(--a2ui-spacing-m));
    }
    label.a2ui-checkbox {
      display: inline-flex;
      align-items: center;
      gap: var(--a2ui-checkbox-gap, var(--a2ui-spacing-s, 0.5rem));
      font-size: var(
        --a2ui-checkbox-label-font-size,
        var(--a2ui-label-font-size, var(--a2ui-font-size-s))
      );
      font-weight: var(--a2ui-checkbox-label-font-weight, var(--a2ui-label-font-weight, bold));
      cursor: pointer;
    }
    label.a2ui-invalid {
      color: var(--a2ui-checkbox-color-error, red);
    }
    input {
      width: var(--a2ui-checkbox-size, 1rem);
      height: var(--a2ui-checkbox-size, 1rem);
      background: var(--a2ui-checkbox-background, inherit);
      border: var(--a2ui-checkbox-border, var(--a2ui-border));
      border-radius: var(--a2ui-checkbox-border-radius, 4px);
    }
    input.a2ui-invalid {
      outline: 1px solid var(--a2ui-checkbox-color-error, red);
    }
    .a2ui-error-message {
      color: var(--a2ui-checkbox-color-error, red);
      font-size: var(--a2ui-font-size-xs, 0.75rem);
      margin-top: 4px;
    }
  `;
//# sourceMappingURL=CheckBox.js.map