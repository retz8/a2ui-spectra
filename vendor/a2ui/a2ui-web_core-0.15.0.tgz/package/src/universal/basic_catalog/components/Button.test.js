/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';
import { setupTestDom, teardownTestDom, asyncUpdate } from '../../../test/dom-setup.js';
import { ComponentContext, MessageProcessor, } from '../../../v0_9/index.js';
import { registerUniversalElement, } from '../../index.js';
describe('Button Component', () => {
    let basicCatalog;
    before(async () => {
        setupTestDom();
        basicCatalog = (await import('../../../v0_9/basic_catalog/index.js')).basicCatalog;
        basicCatalog.components.forEach(c => registerUniversalElement(c));
        // Ensure components are registered
    });
    after(teardownTestDom);
    let processor;
    let surface;
    let element = null;
    let subscription = null;
    beforeEach(() => {
        processor = new MessageProcessor([basicCatalog]);
        processor.processMessages([
            {
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'test-surface',
                    catalogId: basicCatalog.id,
                },
            },
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'btn1',
                            component: 'Button',
                            child: 'txt1',
                            action: { event: { name: 'submit_clicked' } },
                        },
                        {
                            id: 'btn_disabled',
                            component: 'Button',
                            child: 'txt1',
                            checks: [
                                {
                                    condition: false,
                                    message: 'Disabled',
                                },
                            ],
                            action: { event: { name: 'ignored' } },
                        },
                        {
                            id: 'txt1',
                            component: 'Text',
                            text: 'Click Me',
                        },
                    ],
                },
            },
        ]);
        surface = processor.model.getSurface('test-surface');
    });
    afterEach(() => {
        subscription?.unsubscribe();
        subscription = null;
        if (element) {
            element.remove();
            element = null;
        }
    });
    it('should render and dispatch action on click', async () => {
        const el = document.createElement('a2ui-basic-button');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'btn1');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const button = el.querySelector('button');
        assert.notStrictEqual(button, null);
        assert.strictEqual(button?.disabled, false);
        assert.deepStrictEqual(Array.from(button.classList), ['a2ui-button', 'a2ui-button-default']);
        const dispatched = { action: null };
        subscription = surface.onAction.subscribe((action) => {
            dispatched.action = action;
        });
        button?.click();
        await new Promise(resolve => setTimeout(resolve, 0));
        assert.notStrictEqual(dispatched.action, null);
        assert.strictEqual(dispatched.action?.name, 'submit_clicked');
    });
    it('should be disabled when isValid is false', async () => {
        const el = document.createElement('a2ui-basic-button');
        element = el;
        document.body.appendChild(el);
        const context = new ComponentContext(surface, 'btn_disabled');
        await asyncUpdate(el, e => {
            e.context = context;
        });
        const button = el.querySelector('button');
        assert.notStrictEqual(button, null);
        assert.strictEqual(button?.disabled, true);
        let dispatchedAction = false;
        subscription = surface.onAction.subscribe(() => {
            dispatchedAction = true;
        });
        button?.click();
        assert.strictEqual(dispatchedAction, false);
    });
    it('places aria-label and aria-description on inner button rather than host', async () => {
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'btn_a11y',
                            component: 'Button',
                            child: 'txt1',
                            action: { event: { name: 'book' } },
                            accessibility: {
                                label: 'Book Mott 32 now',
                                description: 'Opens reservation form',
                            },
                        },
                    ],
                },
            },
        ]);
        const el = document.createElement('a2ui-basic-button');
        element = el;
        document.body.appendChild(el);
        await asyncUpdate(el, e => {
            e.context = new ComponentContext(surface, 'btn_a11y');
        });
        assert.strictEqual(el.hasAttribute('aria-label'), false);
        assert.strictEqual(el.hasAttribute('aria-description'), false);
        const button = el.querySelector('button');
        assert.notStrictEqual(button, null);
        assert.strictEqual(button?.getAttribute('aria-label'), 'Book Mott 32 now');
        assert.strictEqual(button?.getAttribute('aria-description'), 'Opens reservation form');
        // Clearing accessibility removes inner button attributes
        processor.processMessages([
            {
                version: 'v0.9',
                updateComponents: {
                    surfaceId: 'test-surface',
                    components: [
                        {
                            id: 'btn_a11y',
                            component: 'Button',
                            child: 'txt1',
                            action: { event: { name: 'book' } },
                            accessibility: undefined,
                        },
                    ],
                },
            },
        ]);
        await asyncUpdate(el, () => { });
        assert.strictEqual(button?.hasAttribute('aria-label'), false);
        assert.strictEqual(button?.hasAttribute('aria-description'), false);
    });
});
//# sourceMappingURL=Button.test.js.map