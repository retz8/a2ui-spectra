/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { html, nothing, css } from 'lit';
import { getAccessibilityDescription, getAccessibilityLabel, getValidationErrorId, hasAttributeValue, renderValidationErrors, } from './accessibility.js';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
/**
 * Returns the current date formatted as YYYY-MM-DD in the user's local timezone.
 */
function getLocalIsoDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}
/**
 * Normalizes an incoming ISO or partial date/time value into a format accepted by HTML5 inputs.
 *
 * HTML5 input elements (like type="date", type="time", and type="datetime-local") strictly reject
 * timezone indicators (like "Z" or "+00:00") and trailing seconds/milliseconds in their .value property.
 * If these are present, the browser will reset the input to an empty string. This function strips
 * those specifiers using string splitting and substring manipulation without shifting timezones.
 */
function normalizeDateTimeValue(value, type) {
    if (!value)
        return '';
    const hasT = value.includes('T');
    if (hasT) {
        const [datePart, timePart] = value.split('T');
        switch (type) {
            case 'date':
                return datePart?.substring(0, 10) ?? '';
            case 'time':
                return timePart?.substring(0, 5) ?? '';
            case 'datetime-local':
                return `${datePart?.substring(0, 10) ?? ''}T${timePart?.substring(0, 5) ?? ''}`;
        }
    }
    // Not ISO with 'T': value might be just date ('YYYY-MM-DD') or just time ('HH:MM')
    if (type === 'date') {
        return value.includes('-') ? value.substring(0, 10) : '';
    }
    if (type === 'time') {
        return value.includes(':') ? value.substring(0, 5) : '';
    }
    return '';
}
export class A2uiDateTimeInputElement extends BasicCatalogA2uiLitElement {
    render() {
        const props = this.controller.props;
        if (!props)
            return nothing;
        const enableTime = props.enableTime ?? false;
        const enableDate = props.enableDate ?? !enableTime;
        const rawValue = typeof props.value === 'string' ? props.value : props.value ? String(props.value) : '';
        const rawMin = typeof props.min === 'string' ? props.min : props.min ? String(props.min) : '';
        const rawMax = typeof props.max === 'string' ? props.max : props.max ? String(props.max) : '';
        const dateValue = normalizeDateTimeValue(rawValue, 'date');
        const timeValue = normalizeDateTimeValue(rawValue, 'time');
        const minDate = normalizeDateTimeValue(rawMin, 'date');
        const maxDate = normalizeDateTimeValue(rawMax, 'date');
        const minTime = normalizeDateTimeValue(rawMin, 'time');
        const maxTime = normalizeDateTimeValue(rawMax, 'time');
        const handleDateChange = (event) => {
            const date = event.target.value;
            if (enableTime) {
                const time = rawValue.includes('T')
                    ? rawValue.split('T')[1]
                    : rawValue.includes(':')
                        ? rawValue
                        : '00:00:00';
                props.setValue?.(`${date}T${time}`);
            }
            else {
                props.setValue?.(date);
            }
        };
        const handleTimeChange = (event) => {
            const time = event.target.value;
            if (enableDate) {
                const date = rawValue.includes('T')
                    ? rawValue.split('T')[0]
                    : rawValue.includes('-')
                        ? rawValue
                        : getLocalIsoDate();
                props.setValue?.(`${date}T${time}:00`);
            }
            else {
                props.setValue?.(time);
            }
        };
        const isInvalid = props.isValid === false;
        const isCombined = enableDate && enableTime;
        const labelId = `${this.domId}-label`;
        const dateInputId = `${this.domId}-date`;
        const timeInputId = `${this.domId}-time`;
        const primaryInputId = enableDate ? dateInputId : timeInputId;
        const hasVisibleLabel = hasAttributeValue(props.label);
        const a11yLabel = getAccessibilityLabel(props.accessibility);
        const a11yDescription = getAccessibilityDescription(props.accessibility);
        const errorId = getValidationErrorId(this.domId, props);
        return html `
      <div class="a2ui-date-time-container">
        ${hasVisibleLabel
            ? html `<label id=${labelId} class="a2ui-date-time-label" for=${primaryInputId}
              >${props.label}</label
            >`
            : nothing}
        <div
          class="a2ui-date-time-inputs"
          role=${isCombined ? 'group' : nothing}
          aria-label=${isCombined ? a11yLabel : nothing}
          aria-labelledby=${isCombined && a11yLabel === nothing && hasVisibleLabel
            ? labelId
            : nothing}
          aria-description=${isCombined ? a11yDescription : nothing}
        >
          ${enableDate
            ? html `
                <input
                  id=${dateInputId}
                  type="date"
                  min=${minDate || nothing}
                  max=${maxDate || nothing}
                  aria-label=${a11yLabel}
                  aria-description=${!isCombined ? a11yDescription : nothing}
                  aria-invalid=${isInvalid ? 'true' : nothing}
                  aria-describedby=${errorId}
                  .value=${dateValue}
                  @change=${handleDateChange}
                  class="a2ui-date-time-input"
                />
              `
            : nothing}
          ${enableTime
            ? html `
                <input
                  id=${timeInputId}
                  type="time"
                  min=${minTime || nothing}
                  max=${maxTime || nothing}
                  aria-label=${a11yLabel}
                  aria-labelledby=${isCombined && a11yLabel === nothing && hasVisibleLabel
                ? labelId
                : nothing}
                  aria-description=${!isCombined ? a11yDescription : nothing}
                  aria-invalid=${isInvalid ? 'true' : nothing}
                  aria-describedby=${errorId}
                  .value=${timeValue}
                  @change=${handleTimeChange}
                  class="a2ui-date-time-input"
                />
              `
            : nothing}
        </div>
        ${renderValidationErrors(this.domId, props)}
      </div>
    `;
    }
}
/** @nocollapse */
A2uiDateTimeInputElement.tagName = 'a2ui-datetimeinput';
/**
 * The styles of the datetime input can be customized by redefining the following
 * CSS variables:
 *
 * - `--a2ui-datetimeinput-width`: Width of the component. Defaults to `100%`.
 * - `--a2ui-datetimeinput-background`: Controls the background of inputs.
 * - `--a2ui-datetimeinput-color`: Controls the text color of inputs.
 * - `--a2ui-datetimeinput-border`: Controls the border of inputs.
 * - `--a2ui-datetimeinput-border-radius`: Controls the border radius of inputs.
 * - `--a2ui-datetimeinput-padding`: Controls the padding of inputs.
 * - `--a2ui-datetimeinput-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
 * - `--a2ui-datetimeinput-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
 *
 * @nocollapse
 */
A2uiDateTimeInputElement.styles = css `
    .a2ui-date-time-container {
      display: flex;
      flex-direction: column;
      gap: var(--a2ui-spacing-xs, 4px);
      width: var(--a2ui-datetimeinput-width, 100%);
    }
    input {
      box-sizing: border-box;
      width: 100%;
    }
    .a2ui-date-time-label {
      font-size: var(
        --a2ui-datetimeinput-label-font-size,
        var(--a2ui-label-font-size, var(--a2ui-font-size-s, 14px))
      );
      font-weight: var(--a2ui-datetimeinput-label-font-weight, bold);
      color: var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333));
    }
    .a2ui-date-time-inputs {
      display: flex;
      gap: var(--a2ui-spacing-s, 8px);
      width: 100%;
    }
    .a2ui-date-time-input {
      padding: var(--a2ui-datetimeinput-padding, 8px);
      border-radius: var(--a2ui-datetimeinput-border-radius, 4px);
      border: var(--a2ui-datetimeinput-border, 1px solid var(--a2ui-color-border, #ccc));
      background-color: var(--a2ui-datetimeinput-background, var(--a2ui-color-input, #fff));
      color: var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333));
      font-family: inherit;
      flex: 1;
    }
    .a2ui-date-time-input::-webkit-datetime-edit,
    .a2ui-date-time-input::-webkit-datetime-edit-fields-wrapper {
      color: var(--a2ui-datetimeinput-color, var(--a2ui-color-on-input, #333));
    }
    .a2ui-error-message {
      color: var(--a2ui-datetimeinput-color-error, red);
      font-size: var(--a2ui-font-size-xs, 0.75rem);
    }
  `;
//# sourceMappingURL=DateTimeInput.js.map