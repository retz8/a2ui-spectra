import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ListSupportedApis } from './supported_apis.js';
export declare class A2uiListElement extends BasicCatalogA2uiLitElement<ListSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-list";
    /** @nocollapse */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=List.d.ts.map