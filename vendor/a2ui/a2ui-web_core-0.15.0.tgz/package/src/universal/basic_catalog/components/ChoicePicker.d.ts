import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ChoicePickerSupportedApis } from './supported_apis.js';
export declare class A2uiChoicePickerElement extends BasicCatalogA2uiLitElement<ChoicePickerSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-choicepicker";
    /**
     * The styles of the choice picker can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-choicepicker-label-color`: Color of all labels.
     * - `--a2ui-choicepicker-label-font-size`: Font size of all labels. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s` for the main label.
     * - `--a2ui-choicepicker-label-font-weight`: Font weight of the main label. Defaults to `--a2ui-label-font-weight` then `bold`.
     * - `--a2ui-choicepicker-gap`: Spacing between options.
     * - `--a2ui-choicepicker-filter-padding`: Padding for the filter input. Defaults to `--a2ui-spacing-xs` and `--a2ui-spacing-s` (4px 8px).
     * - `--a2ui-choicepicker-chip-padding`: Padding for chips. Defaults to `--a2ui-spacing-s` and `--a2ui-spacing-m` (4px 8px).
     * - `--a2ui-choicepicker-chip-border-radius`: Border radius for chips. Defaults to `999px`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    filter: string;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=ChoicePicker.d.ts.map