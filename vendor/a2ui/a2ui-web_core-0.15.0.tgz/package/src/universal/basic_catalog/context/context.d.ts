/**
 * Contexts used to inject dependencies into the Lit renderer.
 */
export declare const Context: {
    markdown: {
        __context__: import("./markdown.js").MarkdownRenderer | undefined;
    };
};
//# sourceMappingURL=context.d.ts.map