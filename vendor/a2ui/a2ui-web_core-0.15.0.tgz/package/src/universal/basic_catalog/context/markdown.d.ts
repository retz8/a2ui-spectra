import type { MarkdownRenderer } from '../../../common/markdown.js';
export type { MarkdownRenderer, MarkdownRendererOptions, MarkdownRendererTagClassMap, } from '../../../common/markdown.js';
/**
 * The markdown renderer context.
 *
 * This is used by the Text widget to render markdown content.
 */
export declare const markdown: {
    __context__: MarkdownRenderer | undefined;
};
//# sourceMappingURL=markdown.d.ts.map