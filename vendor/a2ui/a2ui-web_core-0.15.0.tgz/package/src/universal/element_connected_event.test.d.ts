export {};
//# sourceMappingURL=element_connected_event.test.d.ts.map