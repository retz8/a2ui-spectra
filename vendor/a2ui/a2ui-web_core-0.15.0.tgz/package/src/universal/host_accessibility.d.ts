/**
 * How a framework adapter's host element (the custom element a React or
 * Angular component renders inside) applies its node's `accessibility`
 * attributes and validation state.
 *
 * The host sets `aria-live`, `aria-hidden` and `inert` on itself. `label` and
 * `description` go to the target, the element the component marks for them;
 * without one, the host labels itself as a `role="group"`. The target also
 * gets `aria-invalid` while a check fails, and, while there are errors,
 * `aria-describedby` pointing at the element the component marks as showing
 * them.
 */
import type { z } from 'zod';
import { type Signal } from '../reactivity/signals.js';
import type { ComponentNode } from '../resolution/component-node.js';
import type { ResolveA2uiProp } from '../resolution/generic-binder.js';
import type { AccessibilityAttributesSchema as AccessibilityAttributesSchema0_9 } from '../v0_9/schema/common-types.js';
import type { AccessibilityAttributesSchema as AccessibilityAttributesSchema1_0 } from '../v1_0/schema/common-types.js';
type ResolvedUnionMember<T> = T extends unknown ? Partial<ResolveA2uiProp<T>> : never;
type SupportedAccessibilityAttributes = z.infer<typeof AccessibilityAttributesSchema0_9 | typeof AccessibilityAttributesSchema1_0>;
/** Resolved accessibility attributes inferred across supported protocol versions. */
export type ResolvedAccessibilityAttributes = ResolvedUnionMember<SupportedAccessibilityAttributes>;
/** Sets host-level `aria-live`, `aria-hidden`, and `inert` attributes on a custom element. */
export declare function setHostAccessibilityAttributes(host: HTMLElement, a11y?: ResolvedAccessibilityAttributes): void;
/** The elements a component marks for its host's accessibility attributes. */
export interface AccessibilityTargets {
    /** The element for the label, description and validation state, or `null`. */
    readonly target: Signal<Element | null>;
    /** The element that shows the validation errors, or `null`. */
    readonly errors: Signal<Element | null>;
}
/** Creates {@link AccessibilityTargets} with no elements marked. */
export declare function createAccessibilityTargets(): AccessibilityTargets;
/**
 * Keeps the ARIA attributes of `host`, and of the elements in `targets`, in
 * step with `node` until the returned function is called. That function also
 * removes every attribute the binding set, and gives an attribute the
 * component had set back its value.
 */
export declare function bindHostAccessibility(host: HTMLElement, node: ComponentNode, targets: AccessibilityTargets): () => void;
/** Props that the binder adds to components with validation checks. */
export interface CheckableResolvedProps {
    isValid?: boolean;
    validationErrors?: string[];
}
/** Whether `props` carries a failed validation check and at least one error message. */
export declare function hasValidationErrors(props?: CheckableResolvedProps): boolean;
/** What a host reads from its node's props. */
export interface HostAccessibilityState extends CheckableResolvedProps {
    accessibility?: ResolvedAccessibilityAttributes;
}
/**
 * Returns the accessibility attributes in a component's resolved props: the
 * v1.0 `@accessibility`, or else `accessibility` (below v1.0, or a legacy
 * v1.0 payload).
 *
 * A v1.0 component may declare its own property named `accessibility`, which
 * `@accessibility` leaves free, so a value that is not an attributes object
 * is ignored.
 *
 * @param props The component's resolved props.
 * @returns The accessibility attributes, or `undefined` if there are none.
 */
export declare function resolveAccessibilityProps(props: unknown): ResolvedAccessibilityAttributes | undefined;
/** The ARIA attributes of one host and of the elements its component marks. */
export declare class HostAccessibility {
    private readonly host;
    /** Where the label and description went last: the target, or the host. */
    private labelled?;
    /**
     * Per element, each attribute `apply` set: the value it had before, so that
     * removing it gives the component's own value back, and the value `apply`
     * wrote.
     */
    private readonly written;
    /** The token `apply` added to the target's `aria-describedby`. */
    private describedBy?;
    /** The errors element `apply` gave an `id`, so the `id` can be taken back. */
    private namedErrors?;
    constructor(host: HTMLElement);
    /**
     * Sets the attributes for `state` and removes the ones a previous call set
     * that no longer apply.
     *
     * @param target The element for the label, description and validation
     *     state, or `null` to label the host.
     * @param errors The element showing the validation errors, or `null`.
     * @param errorsId The `id` given to `errors` when it has none.
     */
    apply(state: HostAccessibilityState, target: Element | null, errors: Element | null, errorsId: string): void;
    /**
     * Sets an attribute, or with `undefined` gives it back the value it had
     * before this binding first set it. An attribute it never set is left alone,
     * and so is one that someone else changed since.
     */
    private write;
    /** Whether `name` on `element` still has the value this binding wrote. */
    private owns;
    /**
     * Adds `id` to the target's `aria-describedby`, or with `undefined` removes
     * the token added before, keeping the tokens the component set.
     */
    private describe;
    private idOf;
    /** Takes back every attribute this binding set on `element`. */
    private clear;
    private releaseErrorsId;
}
export {};
//# sourceMappingURL=host_accessibility.d.ts.map