/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { effect, getValue, signal } from '../reactivity/signals.js';
import { ResolvedBinding } from '../resolution/resolved-binding.js';
// Quoted keys survive minification and enforce completeness across AccessibilityAttributeKey.
const HOST_ACCESSIBILITY_SETTERS = {
    // Forwarded to inner semantic controls or container groups by components.
    'label': () => { },
    'description': () => { },
    'live': (host, a11y) => {
        const live = a11y && 'live' in a11y ? a11y.live : undefined;
        setOrRemove(host, 'aria-live', live != null ? String(live) : undefined);
    },
    'hidden': (host, a11y) => {
        const hidden = a11y && Object.hasOwn(a11y, 'hidden') ? a11y.hidden : undefined;
        setOrRemove(host, 'aria-hidden', typeof hidden === 'boolean' ? String(hidden) : undefined);
        // aria-hidden alone leaves focusable descendants in the tab order, so a
        // hidden subtree is also made inert.
        const isHidden = hidden === true;
        if (host.inert !== isHidden) {
            host.inert = isHidden;
        }
        host.toggleAttribute('inert', isHidden);
    },
};
const HOST_ACCESSIBILITY_SETTER_LIST = Object.values(HOST_ACCESSIBILITY_SETTERS);
/** Sets host-level `aria-live`, `aria-hidden`, and `inert` attributes on a custom element. */
export function setHostAccessibilityAttributes(host, a11y) {
    for (const setAttribute of HOST_ACCESSIBILITY_SETTER_LIST) {
        setAttribute(host, a11y);
    }
}
/** Creates {@link AccessibilityTargets} with no elements marked. */
export function createAccessibilityTargets() {
    return { target: signal(null), errors: signal(null) };
}
/**
 * Keeps the ARIA attributes of `host`, and of the elements in `targets`, in
 * step with `node` until the returned function is called. That function also
 * removes every attribute the binding set, and gives an attribute the
 * component had set back its value.
 */
export function bindHostAccessibility(host, node, targets) {
    const accessibility = new HostAccessibility(host);
    const stop = effect(() => {
        accessibility.apply(hostAccessibilityState(getValue(node.props)), getValue(targets.target), getValue(targets.errors), `${node.id}-error`);
    });
    return () => {
        stop();
        accessibility.apply({}, null, null, '');
    };
}
/** Whether `props` carries a failed validation check and at least one error message. */
export function hasValidationErrors(props) {
    return props?.isValid === false && Boolean(props.validationErrors?.length);
}
function unwrap(value) {
    return value instanceof ResolvedBinding ? value.value : value;
}
/**
 * Returns the accessibility attributes in a component's resolved props: the
 * v1.0 `@accessibility`, or else `accessibility` (below v1.0, or a legacy
 * v1.0 payload).
 *
 * A v1.0 component may declare its own property named `accessibility`, which
 * `@accessibility` leaves free, so a value that is not an attributes object
 * is ignored.
 *
 * @param props The component's resolved props.
 * @returns The accessibility attributes, or `undefined` if there are none.
 */
export function resolveAccessibilityProps(props) {
    if (!props || typeof props !== 'object')
        return undefined;
    const record = props;
    for (const key of ['@accessibility', 'accessibility']) {
        const value = unwrap(record[key]);
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            return value;
        }
    }
    return undefined;
}
/** The accessibility and validation props of a node, with their bindings unwrapped. */
function hostAccessibilityState(props) {
    const accessibility = resolveAccessibilityProps(props);
    const validationErrors = unwrap(props['validationErrors']);
    return {
        accessibility: accessibility !== undefined
            ? Object.fromEntries(Object.entries(accessibility).map(([key, value]) => [key, unwrap(value)]))
            : undefined,
        isValid: unwrap(props['isValid']),
        validationErrors: Array.isArray(validationErrors) ? validationErrors : undefined,
    };
}
/** `undefined` for a missing or empty value, which leaves the attribute out. */
function attributeText(value) {
    return value === undefined || value === null || value === '' ? undefined : String(value);
}
/** Sets or removes an attribute, without touching the DOM when it already has that state. */
function setOrRemove(element, name, value) {
    if (value === undefined) {
        if (element.hasAttribute(name)) {
            element.removeAttribute(name);
        }
    }
    else if (element.getAttribute(name) !== value) {
        element.setAttribute(name, value);
    }
}
/** The ARIA attributes of one host and of the elements its component marks. */
export class HostAccessibility {
    constructor(host) {
        this.host = host;
        /**
         * Per element, each attribute `apply` set: the value it had before, so that
         * removing it gives the component's own value back, and the value `apply`
         * wrote.
         */
        this.written = new Map();
    }
    /**
     * Sets the attributes for `state` and removes the ones a previous call set
     * that no longer apply.
     *
     * @param target The element for the label, description and validation
     *     state, or `null` to label the host.
     * @param errors The element showing the validation errors, or `null`.
     * @param errorsId The `id` given to `errors` when it has none.
     */
    apply(state, target, errors, errorsId) {
        const { accessibility } = state;
        setHostAccessibilityAttributes(this.host, accessibility);
        const labelled = target ?? this.host;
        if (this.labelled && this.labelled !== labelled) {
            this.clear(this.labelled);
        }
        this.labelled = labelled;
        const label = attributeText(accessibility?.label);
        const description = attributeText(accessibility?.description);
        if (labelled === this.host) {
            // A generic element's `aria-label` is ignored; a group's is announced.
            // A role the app gave the host is kept.
            const named = label !== undefined || description !== undefined;
            const keepsRole = this.host.hasAttribute('role') && !this.owns(this.host, 'role');
            this.write(this.host, 'role', named && !keepsRole ? 'group' : undefined);
        }
        this.write(labelled, 'aria-label', label);
        this.write(labelled, 'aria-description', description);
        const showsErrors = target !== null &&
            errors !== null &&
            state.isValid === false &&
            Boolean(state.validationErrors?.length);
        if (this.namedErrors && (this.namedErrors !== errors || !showsErrors)) {
            this.releaseErrorsId();
        }
        if (!target) {
            return;
        }
        // As on `A2uiLitElement`, only a target carries the validation state:
        // `aria-invalid` is not supported on a group.
        this.write(target, 'aria-invalid', state.isValid === false ? 'true' : undefined);
        this.describe(target, showsErrors ? this.idOf(errors, errorsId) : undefined);
    }
    /**
     * Sets an attribute, or with `undefined` gives it back the value it had
     * before this binding first set it. An attribute it never set is left alone,
     * and so is one that someone else changed since.
     */
    write(element, name, value) {
        let attributes = this.written.get(element);
        const previous = attributes?.get(name);
        const current = element.getAttribute(name);
        if (value === undefined) {
            if (!previous)
                return;
            if (current === previous.value) {
                setOrRemove(element, name, previous.original ?? undefined);
            }
            attributes.delete(name);
            if (attributes.size === 0) {
                this.written.delete(element);
            }
            return;
        }
        if (!attributes) {
            attributes = new Map();
            this.written.set(element, attributes);
        }
        // A value someone else set since is the one to give back later.
        const original = previous && current === previous.value ? previous.original : current;
        attributes.set(name, { original, value });
        setOrRemove(element, name, value);
    }
    /** Whether `name` on `element` still has the value this binding wrote. */
    owns(element, name) {
        const previous = this.written.get(element)?.get(name);
        return previous !== undefined && element.getAttribute(name) === previous.value;
    }
    /**
     * Adds `id` to the target's `aria-describedby`, or with `undefined` removes
     * the token added before, keeping the tokens the component set.
     */
    describe(target, id) {
        const tokens = (target.getAttribute('aria-describedby') ?? '')
            .split(/\s+/)
            .filter(token => token !== '' && token !== this.describedBy);
        this.describedBy = id !== undefined && !tokens.includes(id) ? id : undefined;
        if (this.describedBy !== undefined) {
            tokens.push(this.describedBy);
        }
        setOrRemove(target, 'aria-describedby', tokens.length ? tokens.join(' ') : undefined);
    }
    idOf(errors, errorsId) {
        if (!errors.id) {
            errors.id = errorsId;
            this.namedErrors = errors;
        }
        return errors.id;
    }
    /** Takes back every attribute this binding set on `element`. */
    clear(element) {
        for (const name of [...(this.written.get(element)?.keys() ?? [])]) {
            this.write(element, name, undefined);
        }
        if (element !== this.host) {
            this.describe(element, undefined);
        }
    }
    releaseErrorsId() {
        this.namedErrors?.removeAttribute('id');
        this.namedErrors = undefined;
    }
}
//# sourceMappingURL=host_accessibility.js.map