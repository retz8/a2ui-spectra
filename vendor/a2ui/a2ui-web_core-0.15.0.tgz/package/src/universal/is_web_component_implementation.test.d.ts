export {};
//# sourceMappingURL=is_web_component_implementation.test.d.ts.map