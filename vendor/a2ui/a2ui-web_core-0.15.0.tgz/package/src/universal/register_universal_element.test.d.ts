export {};
//# sourceMappingURL=register_universal_element.test.d.ts.map