import { LitElement, nothing, type PropertyValues, type TemplateResult } from 'lit';
import { ComponentApi, type InferredComponentApiSchemaType } from '../catalog/types.js';
import { type A2uiMetadata, type Extensions } from '../common/metadata.js';
import { ComponentContext } from '../resolution/component-context.js';
import { type ComponentNode } from '../resolution/component-node.js';
import type { ResolveA2uiProps } from '../resolution/generic-binder.js';
import { type ComponentId } from '../types/common-types.js';
import { A2uiController } from './a2ui-controller.js';
import { type CheckableResolvedProps, type ResolvedAccessibilityAttributes } from './host_accessibility.js';
export type { CheckableResolvedProps, ResolvedAccessibilityAttributes };
/**
 * A reference to a child component to render. Either a string ID, or an object
 * pairing an ID with an explicit data context path.
 */
export type A2uiChildRef = ComponentId | {
    id: ComponentId;
    basePath: string;
};
export type ResolvedChildRef = A2uiChildRef;
export type ResolvedChildList = A2uiChildRef[];
/**
 * A base class for A2UI Lit elements that manages the A2uiController lifecycle
 * and provides Light DOM style adoption and scoping.
 *
 * Elements render into Light DOM by default (`createRenderRoot()` returns `this`), and
 * `adoptLightDomStyles()` scopes `static styles` to the element's tag name and adopts
 * them into the enclosing `Document` or `ShadowRoot`. Subclasses that require Shadow DOM
 * can override `createRenderRoot()` (for example `return this.attachShadow({mode: 'open'})`).
 *
 * @template Api The specific A2UI component API defining the schema for this element.
 * @experimental This class is experimental and subject to change as A2UI transitions
 * to the unified Node Layer resolution pipeline.
 */
export declare abstract class A2uiLitElement<Api extends ComponentApi = ComponentApi, Props = ResolveA2uiProps<InferredComponentApiSchemaType<Api>>> extends LitElement {
    /**
     * The component context for the node this element renders.
     *
     * @deprecated Assign `node` instead.
     */
    context: ComponentContext;
    /**
     * The resolved node this element renders, when its parent resolves the
     * surface through a `NodeResolver`. Assigning it also assigns `context`
     * (`node.context`), and `renderNode` then renders the node's own children.
     */
    node?: ComponentNode;
    /**
     * Component API specification for automatic controller instantiation.
     */
    protected readonly api?: Api;
    private _controller?;
    private _controllerContext?;
    private _controllerNode?;
    private fallbackDomId?;
    private readonly _hostAccessibility;
    /**
     * Document-unique ID prefix for associating internal labels, controls, and error messages.
     *
     * Reads `ComponentNode.id` when rendered through a `NodeResolver`; an element mounted
     * with only a `ComponentContext` draws one lazily from the same ID sequence.
     */
    protected get domId(): string;
    /**
     * Returns the inner semantic element that should receive `accessibility.label`,
     * `accessibility.description`, and validation error attributes (`aria-invalid` and
     * `aria-describedby`), or `null` when no inner control targets those attributes.
     *
     * When this method returns `null` and an accessibility `label` or `description` is
     * present, `applyAccessibilityAttributes` falls back to setting `role="group"` on the
     * host element (unless an explicit `role` attribute is already set) along with
     * `aria-label` and `aria-description`.
     */
    protected accessibilityTarget(): Element | null;
    /**
     * Renders the validation error messages block (`#${this.domId}-error`) when the
     * component fails one or more validation checks, or `nothing` when valid.
     *
     * @param props Optional resolved checkable props; defaults to `this.controller?.props`.
     */
    protected renderValidationErrors(props?: CheckableResolvedProps): TemplateResult | typeof nothing;
    /**
     * Applies host-level and target-level accessibility and validation attributes after render.
     *
     * Sets `aria-live`, `aria-hidden`, and `inert` on the host element. When
     * `accessibilityTarget()` returns an element, applies `aria-label`, `aria-description`,
     * `aria-invalid`, and `aria-describedby` (merging `#${this.domId}-error` when the error
     * element is rendered) onto that element while preserving component-authored attributes.
     * When `accessibilityTarget()` returns `null` and a `label` or `description` is present,
     * sets `role="group"` on the host (preserving any existing `role` attribute) together
     * with `aria-label` and `aria-description`.
     */
    protected applyAccessibilityAttributes(accessibility?: ResolvedAccessibilityAttributes, checkable?: CheckableResolvedProps): void;
    /**
     * The reactive controller instance managing property bindings and state subscriptions.
     */
    get controller(): A2uiController<Api, Props>;
    /**
     * The component's current metadata envelope, lazily subscribing on first read.
     */
    get metadata(): A2uiMetadata | undefined;
    /**
     * The component's current `extensions` map, lazily subscribing on first read.
     */
    get extensions(): Extensions | undefined;
    /**
     * The containing surface's metadata envelope, lazily subscribing on first read.
     */
    get surfaceMetadata(): A2uiMetadata | undefined;
    /**
     * The containing surface's `extensions` map, lazily subscribing on first read.
     */
    get surfaceExtensions(): Extensions | undefined;
    /**
     * Renders into Light DOM by default. Subclasses that require Shadow DOM can override
     * this method (for example `return this.attachShadow({mode: 'open'})`).
     */
    protected createRenderRoot(): HTMLElement | DocumentFragment;
    /**
     * Adopts and scopes component CSS rules into the containing document or host shadow root.
     *
     * Because `A2uiLitElement` renders into Light DOM by default (`createRenderRoot()`
     * returning `this`), it has no shadow root of its own, so this method locates the nearest
     * enclosing `Document` or `ShadowRoot` and adopts the stylesheet once per root, scoping
     * `:host` and descendant selectors to the element's `tagName`.
     *
     * Does nothing when a subclass opts into Shadow DOM (for example by overriding
     * `createRenderRoot()` to return `this.attachShadow({mode: 'open'})`), because Lit already
     * adopts `static styles` into that `ShadowRoot`.
     */
    protected adoptLightDomStyles(): void;
    /**
     * Lifecycle hook invoked when the element is connected to the DOM.
     * Scopes and adopts component styles into the document or host shadow root.
     */
    connectedCallback(): void;
    /**
     * Instantiates the controller for this element's specific bound API.
     *
     * Uses the instance `api` property when a subclass defines it. Otherwise it
     * uses the API of the catalog entry the component was rendered from (see
     * `findCatalogApi`). Subclasses can override this method if custom
     * controller initialization is required.
     *
     * @returns A new instance of `A2uiController` matching the component API.
     */
    protected createController(): A2uiController<Api, Props>;
    /**
     * Finds the API of the catalog entry this element was rendered from.
     *
     * Version-agnostic elements, such as the basic catalog's, leave `api` unset:
     * one element class is registered in the catalogs of several protocol
     * versions, and the props schema has to match the catalog the component
     * came from. That entry is the resolved node's implementation, or the
     * component's entry in its own catalog.
     */
    private findCatalogApi;
    /**
     * Helper method to render a child A2UI node.
     * Abstracts away the need to manually create a ComponentContext.
     *
     * @param childRef The reference to the child component to render. Either a string ID
     *                 or a reference object containing `{id, basePath}`.
     * @param customPath An explicit data model path to bind the child to. If provided,
     *                   this overrides any path defined in the `childRef` object. If omitted,
     *                   falls back to the `childRef`'s `basePath`, or the current component's path.
     *
     * @returns A Lit template result containing the rendered child component, or `nothing` if the reference is empty.
     */
    protected renderNode(childRef?: ComponentNode | A2uiChildRef, customPath?: string): import("lit-html/directive.js").DirectiveResult<import("lit-html/directive.js").DirectiveClass>;
    /**
     * Whether the child `renderNode(childRef, customPath)` would render has resolved: its
     * component has arrived and its type has an implementation. An unresolved child (pending,
     * unknown type or cyclic) renders nothing.
     *
     * Containers that give each child a slot of their own (an `<li>`, an item `div`) use this to
     * leave unresolved children out entirely, wrapper included, so they take no marker or gap.
     * It shares `renderNode`'s lookup, so the two always agree.
     */
    protected isChildResolved(childRef?: ComponentNode | A2uiChildRef, customPath?: string): boolean;
    /**
     * Finds what `renderNode` renders for a child reference: the child's `ComponentNode` when the
     * node tree has one, otherwise the surface, component id and data path to build a context
     * from. Returns `undefined` when there is nothing to render.
     */
    private resolveChild;
    /**
     * Reacts to changes in the component's properties.
     *
     * Specifically, when the `node` or `context` property changes or is initialized,
     * this method cleans up any existing controller and invokes `createController()`
     * to bind to the new node or context.
     *
     * @param changedProperties Map of changed properties with their previous values.
     */
    willUpdate(changedProperties: PropertyValues): void;
    protected update(changedProperties: PropertyValues): void;
    protected updated(changedProperties: PropertyValues): void;
}
//# sourceMappingURL=a2ui-lit-element.d.ts.map