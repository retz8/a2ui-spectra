import { ReactiveController } from 'lit';
import { A2uiMetadata, Extensions } from '../common/metadata.js';
import { ResolveA2uiProps } from '../resolution/generic-binder.js';
import { type ComponentNode } from '../resolution/component-node.js';
import { ComponentApi, InferredComponentApiSchemaType } from '../catalog/types.js';
import { A2uiLitElement } from './a2ui-lit-element.js';
/**
 * Converts `ComponentNode.props` into the controller `Props` shape expected by
 * `A2uiLitElement` views: unwraps each `ResolvedBinding` into its value and a
 * `set<CapitalizedKey>` callback, and converts child `ComponentNode` instances
 * into component IDs or `{id, basePath}` pairs.
 *
 * @internal
 */
export declare function nodePropsToControllerProps(parent: ComponentNode, props: Record<string, unknown>): Record<string, unknown>;
/**
 * A Lit ReactiveController that binds an A2UI component node or context to its API schema.
 *
 * When the host element carries a resolved `ComponentNode` (`host.node`), this
 * controller reads directly from `node.props` without allocating a duplicate
 * `GenericBinder`. Otherwise, it falls back to managing a `GenericBinder`
 * subscription against `host.context`.
 *
 * @template Api The specific A2UI component API interface this controller is bound to.
 * @internal
 */
export declare class A2uiController<Api extends ComponentApi = ComponentApi, Props = ResolveA2uiProps<InferredComponentApiSchemaType<Api>>> implements ReactiveController {
    private host;
    private _props;
    /**
     * The current reactive properties of the A2UI component, matching the expected output schema.
     */
    get props(): Props;
    /**
     * The current envelope metadata of the A2UI component, lazily subscribing
     * to metadata changes on first access so standard components that do not
     * read metadata skip metadata-only re-renders.
     */
    get metadata(): A2uiMetadata | undefined;
    /**
     * The current `extensions` map of the A2UI component's metadata envelope,
     * lazily subscribing to metadata changes on first access.
     */
    get extensions(): Extensions | undefined;
    /**
     * The current surface-level metadata envelope of the containing surface,
     * lazily subscribing to surface metadata changes on first access.
     */
    get surfaceMetadata(): A2uiMetadata | undefined;
    /**
     * The current surface-level `extensions` map of the containing surface,
     * lazily subscribing to surface metadata changes on first access.
     */
    get surfaceExtensions(): Extensions | undefined;
    private binder?;
    private subscription?;
    private componentsSubscription?;
    private nodeEffectCleanup?;
    private metadataSubscribed;
    private metadataEffectCleanup?;
    private metadataSubscription?;
    private surfaceMetadataSubscribed;
    private surfaceMetadataSubscription?;
    /**
     * Initializes the controller, binding it to the given Lit element and API schema.
     *
     * @param host The A2uiLitElement acting as the component host.
     * @param api The A2UI component API defining the schema for this element.
     */
    constructor(host: A2uiLitElement<any, any>, api: Api);
    /**
     * Subscribes to `host.node.props` (or `GenericBinder` when no node is set)
     * when the host connects, triggering `requestUpdate()` on changes.
     */
    hostConnected(): void;
    private ensureMetadataSubscription;
    private ensureSurfaceMetadataSubscription;
    /**
     * Unsubscribes from `node.props` or `GenericBinder` updates when the host disconnects.
     */
    hostDisconnected(): void;
    /**
     * Unsubscribes host listeners and disposes the underlying GenericBinder, if any.
     */
    dispose(): void;
}
//# sourceMappingURL=a2ui-controller.d.ts.map