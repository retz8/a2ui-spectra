import type { A2uiWebComponentElement } from './a2ui_web_component_element.js';
/**
 * Name of the event a universal element dispatches the first time it is connected to the DOM with
 * a `node` or `context`. It bubbles and is composed, so host renderers can observe every element of
 * a surface, including the ones universal containers create, from a single ancestor. Listeners
 * outside the element's shadow tree see a retargeted `event.target`, so read the element from
 * `event.composedPath()[0]`.
 *
 * `A2uiLitElement` dispatches it from its own lifecycle, and the renderers dispatch it for the
 * elements they create through `dispatchA2uiElementConnected`.
 */
export declare const A2UI_ELEMENT_CONNECTED_EVENT = "a2ui-element-connected";
/**
 * Dispatches {@link A2UI_ELEMENT_CONNECTED_EVENT} from `element`, at most once per element.
 *
 * It does nothing until `element` is connected and has a `context` (or a `node` with one), and
 * nothing after it has dispatched, so callers can invoke it from every place the element might
 * become ready. Custom containers that create child elements by hand, without `renderA2uiNode`,
 * call it after inserting each child so hosts observe children of any base class.
 */
export declare function dispatchA2uiElementConnected(element: A2uiWebComponentElement): void;
//# sourceMappingURL=element_connected_event.d.ts.map