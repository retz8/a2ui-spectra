/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, after, beforeEach, afterEach } from 'node:test';
import * as assert from 'node:assert';
import { z } from 'zod';
import { setupTestDom, teardownTestDom } from '../test/dom-setup.js';
import { registerUniversalElement } from './register_universal_element.js';
// The mock classes below extend HTMLElement, so the DOM globals have to be in place before this
// module's class declarations are evaluated.
setupTestDom();
describe('registerUniversalElement', () => {
    class MockElementA extends HTMLElement {
    }
    class MockElementB extends HTMLElement {
    }
    let registry;
    let originalCustomElements;
    after(teardownTestDom);
    beforeEach(() => {
        originalCustomElements = globalThis.customElements;
        registry = new Map();
        globalThis.customElements = {
            get: (tag) => registry.get(tag),
            define: (tag, constructor) => {
                registry.set(tag, constructor);
            },
        };
    });
    afterEach(() => {
        if (originalCustomElements !== undefined) {
            globalThis.customElements = originalCustomElements;
        }
        else {
            delete globalThis.customElements;
        }
    });
    it('registers a custom element when not yet defined', () => {
        const comp = {
            name: 'Test',
            schema: z.object({}),
            tagName: 'a2ui-test',
            element: MockElementA,
        };
        registerUniversalElement(comp);
        assert.strictEqual(registry.get('a2ui-test'), MockElementA);
    });
    it('no-ops safely when already registered with the same constructor', () => {
        const comp = {
            name: 'Test',
            schema: z.object({}),
            tagName: 'a2ui-test',
            element: MockElementA,
        };
        registerUniversalElement(comp);
        assert.doesNotThrow(() => {
            registerUniversalElement(comp);
        });
        assert.strictEqual(registry.get('a2ui-test'), MockElementA);
    });
    it('throws an error when registered with a conflicting constructor', () => {
        const compA = {
            name: 'TestA',
            schema: z.object({}),
            tagName: 'a2ui-test',
            element: MockElementA,
        };
        const compB = {
            name: 'TestB',
            schema: z.object({}),
            tagName: 'a2ui-test',
            element: MockElementB,
        };
        registerUniversalElement(compA);
        assert.throws(() => {
            registerUniversalElement(compB);
        }, /Custom element tag name collision for "a2ui-test"/);
    });
    it('no-ops safely if customElements is undefined and logs console.error once per module load', async () => {
        delete globalThis.customElements;
        const compA = {
            name: 'TestA',
            schema: z.object({}),
            tagName: 'a2ui-test-a',
            element: MockElementA,
        };
        const compB = {
            name: 'TestB',
            schema: z.object({}),
            tagName: 'a2ui-test-b',
            element: MockElementB,
        };
        const { registerUniversalElement: freshRegister } = await import(`./register_universal_element.js?fresh=${Date.now()}`);
        const errorCalls = [];
        const originalConsoleError = console.error;
        console.error = (...args) => {
            errorCalls.push(args);
        };
        try {
            assert.doesNotThrow(() => {
                freshRegister(compA);
                freshRegister(compB);
            });
            assert.strictEqual(errorCalls.length, 1);
            assert.match(String(errorCalls[0][0]), /Cannot register "a2ui-test-a"/);
        }
        finally {
            console.error = originalConsoleError;
        }
    });
});
//# sourceMappingURL=register_universal_element.test.js.map