import { nothing } from 'lit';
import { type DirectiveResult } from 'lit/directive.js';
import { ComponentContext } from '../resolution/component-context.js';
import { type ComponentNode } from '../resolution/component-node.js';
import { Catalog } from '../catalog/types.js';
import type { WebComponentImplementation } from './web_component_implementation.js';
/**
 * Pure function that acts as a generic container for A2UI components.
 *
 * It dynamically resolves and renders the specific Lit component implementation
 * based on the component type provided in the context, returning a TemplateResult directly
 * to avoid duplicate DOM node wrapping.
 *
 * @param context The component context defining the data model and type to render.
 * @param catalog The catalog of component implementations.
 * @returns A Lit directive result rendering the component's custom element, or `nothing` if the component is invalid or unresolvable.
 */
export declare function renderA2uiNode(context: ComponentContext, catalog: Catalog<WebComponentImplementation>): DirectiveResult | typeof nothing;
/**
 * Renders a resolved node as its implementation's custom element, handing
 * the element the resolved `ComponentNode`.
 *
 * @param node The resolved node to render.
 * @returns A Lit directive result rendering the component's custom element,
 * or `nothing` for a placeholder, a disposed node, or an implementation that
 * is not a Web Component.
 */
export declare function renderA2uiNode(node: ComponentNode): DirectiveResult | typeof nothing;
/** A node `renderA2uiNode` renders as an element: resolved, with a context and a tag name. */
type RenderableNode = ComponentNode & {
    context: ComponentContext;
    impl: Partial<WebComponentImplementation> & {
        tagName: string;
    };
};
/**
 * Whether `renderA2uiNode(node)` renders an element for `node`: it has resolved, is not
 * disposed, has a context, and its implementation is a custom element with a tag name.
 * Containers use this (through `A2uiLitElement.isChildResolved`) to agree with it exactly.
 */
export declare function canRenderA2uiNode(node: ComponentNode): node is RenderableNode;
export {};
//# sourceMappingURL=render-a2ui-node.d.ts.map