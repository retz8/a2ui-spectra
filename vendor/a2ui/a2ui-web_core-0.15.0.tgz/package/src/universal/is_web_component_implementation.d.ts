import type { WebComponentImplementation } from './web_component_implementation.js';
/**
 * Type guard to check if a component API or implementation is a WebComponentImplementation.
 *
 * @param api The object to check
 * @returns true if the object implements WebComponentImplementation
 */
export declare function isWebComponentImplementation(api: unknown): api is WebComponentImplementation;
//# sourceMappingURL=is_web_component_implementation.d.ts.map