import { z } from 'zod';
export declare const StringValueSchema: z.ZodEffects<z.ZodObject<{
    path: z.ZodOptional<z.ZodString>;
    literalString: z.ZodOptional<z.ZodString>;
    literal: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    path?: string | undefined;
    literalString?: string | undefined;
    literal?: string | undefined;
}, {
    path?: string | undefined;
    literalString?: string | undefined;
    literal?: string | undefined;
}>, {
    path?: string | undefined;
    literalString?: string | undefined;
    literal?: string | undefined;
}, {
    path?: string | undefined;
    literalString?: string | undefined;
    literal?: string | undefined;
}>;
export type StringValue = z.infer<typeof StringValueSchema>;
export declare function createDataValueSchema(options?: {
    maxDepth?: number;
}): z.ZodEffects<z.ZodType<any, z.ZodTypeDef, any>, any, any>;
export declare const DataValueSchema: z.ZodEffects<z.ZodType<any, z.ZodTypeDef, any>, any, any>;
export declare const NumberValueSchema: z.ZodEffects<z.ZodObject<{
    path: z.ZodOptional<z.ZodString>;
    literalNumber: z.ZodOptional<z.ZodNumber>;
    literal: z.ZodOptional<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    path?: string | undefined;
    literal?: number | undefined;
    literalNumber?: number | undefined;
}, {
    path?: string | undefined;
    literal?: number | undefined;
    literalNumber?: number | undefined;
}>, {
    path?: string | undefined;
    literal?: number | undefined;
    literalNumber?: number | undefined;
}, {
    path?: string | undefined;
    literal?: number | undefined;
    literalNumber?: number | undefined;
}>;
export type NumberValue = z.infer<typeof NumberValueSchema>;
export declare const BooleanValueSchema: z.ZodEffects<z.ZodObject<{
    path: z.ZodOptional<z.ZodString>;
    literalBoolean: z.ZodOptional<z.ZodBoolean>;
    literal: z.ZodOptional<z.ZodBoolean>;
}, "strict", z.ZodTypeAny, {
    path?: string | undefined;
    literal?: boolean | undefined;
    literalBoolean?: boolean | undefined;
}, {
    path?: string | undefined;
    literal?: boolean | undefined;
    literalBoolean?: boolean | undefined;
}>, {
    path?: string | undefined;
    literal?: boolean | undefined;
    literalBoolean?: boolean | undefined;
}, {
    path?: string | undefined;
    literal?: boolean | undefined;
    literalBoolean?: boolean | undefined;
}>;
export type BooleanValue = z.infer<typeof BooleanValueSchema>;
/**
 * Action Schema for components that trigger user actions
 */
export declare const ActionSchema: z.ZodObject<{
    name: z.ZodString;
    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        value: z.ZodEffects<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
            literalString: z.ZodOptional<z.ZodString>;
            literalNumber: z.ZodOptional<z.ZodNumber>;
            literalBoolean: z.ZodOptional<z.ZodBoolean>;
        }, "strict", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        }>, {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        }>;
    }, "strip", z.ZodTypeAny, {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        };
        key: string;
    }, {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        };
        key: string;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    name: string;
    context?: {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        };
        key: string;
    }[] | undefined;
}, {
    name: string;
    context?: {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
            literalNumber?: number | undefined;
            literalBoolean?: boolean | undefined;
        };
        key: string;
    }[] | undefined;
}>;
/**
 * Component Properties Schemas
 */
export declare const TextSchema: z.ZodObject<{
    text: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    usageHint: z.ZodOptional<z.ZodEnum<["h1", "h2", "h3", "h4", "h5", "caption", "body"]>>;
}, "strip", z.ZodTypeAny, {
    text: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    usageHint?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
}, {
    text: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    usageHint?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
}>;
export declare const ImageSchema: z.ZodObject<{
    url: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    usageHint: z.ZodOptional<z.ZodEnum<["icon", "avatar", "smallFeature", "mediumFeature", "largeFeature", "header"]>>;
    fit: z.ZodOptional<z.ZodEnum<["contain", "cover", "fill", "none", "scale-down"]>>;
    altText: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    usageHint?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
    fit?: "fill" | "none" | "contain" | "cover" | "scale-down" | undefined;
    altText?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
}, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    usageHint?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
    fit?: "fill" | "none" | "contain" | "cover" | "scale-down" | undefined;
    altText?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
}>;
export declare const IconSchema: z.ZodObject<{
    name: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    name: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}, {
    name: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}>;
export declare const VideoSchema: z.ZodObject<{
    url: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}>;
export declare const AudioPlayerSchema: z.ZodObject<{
    url: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    description: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    description?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
}, {
    url: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    description?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
}>;
export declare const TabsSchema: z.ZodObject<{
    tabItems: z.ZodArray<z.ZodEffects<z.ZodObject<{
        title: z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
            literalString: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        child: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }, {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }>, {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }, {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    tabItems: {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }[];
}, {
    tabItems: {
        child: string;
        title: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }[];
}>;
export declare const DividerSchema: z.ZodObject<{
    axis: z.ZodOptional<z.ZodEnum<["horizontal", "vertical"]>>;
    color: z.ZodOptional<z.ZodString>;
    thickness: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    axis?: "horizontal" | "vertical" | undefined;
    color?: string | undefined;
    thickness?: number | undefined;
}, {
    axis?: "horizontal" | "vertical" | undefined;
    color?: string | undefined;
    thickness?: number | undefined;
}>;
export declare const ModalSchema: z.ZodObject<{
    entryPointChild: z.ZodString;
    contentChild: z.ZodString;
}, "strip", z.ZodTypeAny, {
    entryPointChild: string;
    contentChild: string;
}, {
    entryPointChild: string;
    contentChild: string;
}>;
export declare const ButtonSchema: z.ZodObject<{
    child: z.ZodString;
    action: z.ZodObject<{
        name: z.ZodString;
        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            value: z.ZodEffects<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
                literalString: z.ZodOptional<z.ZodString>;
                literalNumber: z.ZodOptional<z.ZodNumber>;
                literalBoolean: z.ZodOptional<z.ZodBoolean>;
            }, "strict", z.ZodTypeAny, {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            }, {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            }>, {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            }, {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            }>;
        }, "strip", z.ZodTypeAny, {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }, {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }>, "many">>;
    }, "strip", z.ZodTypeAny, {
        name: string;
        context?: {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }[] | undefined;
    }, {
        name: string;
        context?: {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }[] | undefined;
    }>;
    primary: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    child: string;
    action: {
        name: string;
        context?: {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }[] | undefined;
    };
    primary?: boolean | undefined;
}, {
    child: string;
    action: {
        name: string;
        context?: {
            value: {
                path?: string | undefined;
                literalString?: string | undefined;
                literalNumber?: number | undefined;
                literalBoolean?: boolean | undefined;
            };
            key: string;
        }[] | undefined;
    };
    primary?: boolean | undefined;
}>;
export declare const CheckboxSchema: z.ZodObject<{
    label: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    value: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalBoolean: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    }, {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    }>, {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    }, {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    value: {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    };
    label: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}, {
    value: {
        path?: string | undefined;
        literalBoolean?: boolean | undefined;
    };
    label: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
}>;
export declare const TextFieldSchema: z.ZodObject<{
    text: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>>;
    label: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    textFieldType: z.ZodOptional<z.ZodEnum<["shortText", "number", "date", "longText", "obscured"]>>;
    validationRegexp: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    label: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    text?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
    textFieldType?: "number" | "date" | "shortText" | "longText" | "obscured" | undefined;
    validationRegexp?: string | undefined;
}, {
    label: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    text?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
    textFieldType?: "number" | "date" | "shortText" | "longText" | "obscured" | undefined;
    validationRegexp?: string | undefined;
}>;
export declare const DateTimeInputSchema: z.ZodObject<{
    value: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>;
    enableDate: z.ZodOptional<z.ZodBoolean>;
    enableTime: z.ZodOptional<z.ZodBoolean>;
    outputFormat: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    value: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
    outputFormat?: string | undefined;
}, {
    value: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    };
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
    outputFormat?: string | undefined;
}>;
export declare const MultipleChoiceSchema: z.ZodObject<{
    selections: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalArray: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    }, {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    }>, {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    }, {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    }>;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodEffects<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
            literalString: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }, {
        value: string;
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }>, "many">>;
    maxAllowedSelections: z.ZodOptional<z.ZodNumber>;
    type: z.ZodOptional<z.ZodEnum<["checkbox", "chips"]>>;
    filterable: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    selections: {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    };
    type?: "checkbox" | "chips" | undefined;
    options?: {
        value: string;
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }[] | undefined;
    maxAllowedSelections?: number | undefined;
    filterable?: boolean | undefined;
}, {
    selections: {
        path?: string | undefined;
        literalArray?: string[] | undefined;
    };
    type?: "checkbox" | "chips" | undefined;
    options?: {
        value: string;
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }[] | undefined;
    maxAllowedSelections?: number | undefined;
    filterable?: boolean | undefined;
}>;
export declare const SliderSchema: z.ZodObject<{
    value: z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalNumber: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalNumber?: number | undefined;
    }, {
        path?: string | undefined;
        literalNumber?: number | undefined;
    }>, {
        path?: string | undefined;
        literalNumber?: number | undefined;
    }, {
        path?: string | undefined;
        literalNumber?: number | undefined;
    }>;
    minValue: z.ZodOptional<z.ZodNumber>;
    maxValue: z.ZodOptional<z.ZodNumber>;
    label: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
        literalString: z.ZodOptional<z.ZodString>;
        literal: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }, {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    value: {
        path?: string | undefined;
        literalNumber?: number | undefined;
    };
    label?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
}, {
    value: {
        path?: string | undefined;
        literalNumber?: number | undefined;
    };
    label?: {
        path?: string | undefined;
        literalString?: string | undefined;
        literal?: string | undefined;
    } | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
}>;
export declare const ComponentArrayTemplateSchema: z.ZodObject<{
    componentId: z.ZodString;
    dataBinding: z.ZodString;
}, "strip", z.ZodTypeAny, {
    componentId: string;
    dataBinding: string;
}, {
    componentId: string;
    dataBinding: string;
}>;
export declare const ComponentArrayReferenceSchema: z.ZodEffects<z.ZodObject<{
    explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    template: z.ZodOptional<z.ZodObject<{
        componentId: z.ZodString;
        dataBinding: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        componentId: string;
        dataBinding: string;
    }, {
        componentId: string;
        dataBinding: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    explicitList?: string[] | undefined;
    template?: {
        componentId: string;
        dataBinding: string;
    } | undefined;
}, {
    explicitList?: string[] | undefined;
    template?: {
        componentId: string;
        dataBinding: string;
    } | undefined;
}>, {
    explicitList?: string[] | undefined;
    template?: {
        componentId: string;
        dataBinding: string;
    } | undefined;
}, {
    explicitList?: string[] | undefined;
    template?: {
        componentId: string;
        dataBinding: string;
    } | undefined;
}>;
export declare const RowSchema: z.ZodObject<{
    children: z.ZodEffects<z.ZodObject<{
        explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        template: z.ZodOptional<z.ZodObject<{
            componentId: z.ZodString;
            dataBinding: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            componentId: string;
            dataBinding: string;
        }, {
            componentId: string;
            dataBinding: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>;
    distribution: z.ZodOptional<z.ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly"]>>;
    alignment: z.ZodOptional<z.ZodEnum<["start", "center", "end", "stretch"]>>;
}, "strip", z.ZodTypeAny, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
}>;
export declare const ColumnSchema: z.ZodObject<{
    children: z.ZodEffects<z.ZodObject<{
        explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        template: z.ZodOptional<z.ZodObject<{
            componentId: z.ZodString;
            dataBinding: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            componentId: string;
            dataBinding: string;
        }, {
            componentId: string;
            dataBinding: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>;
    distribution: z.ZodOptional<z.ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly"]>>;
    alignment: z.ZodOptional<z.ZodEnum<["start", "center", "end", "stretch"]>>;
}, "strip", z.ZodTypeAny, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
}>;
export declare const ListSchema: z.ZodObject<{
    children: z.ZodEffects<z.ZodObject<{
        explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        template: z.ZodOptional<z.ZodObject<{
            componentId: z.ZodString;
            dataBinding: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            componentId: string;
            dataBinding: string;
        }, {
            componentId: string;
            dataBinding: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }, {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    }>;
    direction: z.ZodOptional<z.ZodEnum<["vertical", "horizontal"]>>;
    alignment: z.ZodOptional<z.ZodEnum<["start", "center", "end", "stretch"]>>;
}, "strip", z.ZodTypeAny, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
    direction?: "horizontal" | "vertical" | undefined;
}, {
    children: {
        explicitList?: string[] | undefined;
        template?: {
            componentId: string;
            dataBinding: string;
        } | undefined;
    };
    alignment?: "start" | "center" | "end" | "stretch" | undefined;
    direction?: "horizontal" | "vertical" | undefined;
}>;
export declare const CardSchema: z.ZodObject<{
    child: z.ZodString;
}, "strip", z.ZodTypeAny, {
    child: string;
}, {
    child: string;
}>;
//# sourceMappingURL=common-types.d.ts.map