export {};
//# sourceMappingURL=common-types.test.d.ts.map