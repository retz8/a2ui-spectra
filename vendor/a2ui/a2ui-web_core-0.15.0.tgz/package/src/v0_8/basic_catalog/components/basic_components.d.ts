import { z } from 'zod';
import { ComponentApi } from '../../../catalog/types.js';
export declare const TextApi: {
    name: string;
    schema: z.ZodObject<{
        text: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        usageHint: z.ZodOptional<z.ZodEnum<["h1", "h2", "h3", "h4", "h5", "caption", "body"]>>;
    }, "strict", z.ZodTypeAny, {
        text: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        usageHint?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
    }, {
        text: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        usageHint?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
    }>;
};
export declare const ImageApi: {
    name: string;
    schema: z.ZodObject<{
        url: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        altText: z.ZodOptional<z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>>;
        fit: z.ZodOptional<z.ZodEnum<["contain", "cover", "fill", "none", "scale-down"]>>;
        usageHint: z.ZodOptional<z.ZodEnum<["icon", "avatar", "smallFeature", "mediumFeature", "largeFeature", "header"]>>;
    }, "strict", z.ZodTypeAny, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        usageHint?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
        fit?: "fill" | "none" | "contain" | "cover" | "scale-down" | undefined;
        altText?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
    }, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        usageHint?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
        fit?: "fill" | "none" | "contain" | "cover" | "scale-down" | undefined;
        altText?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
    }>;
};
export declare const IconApi: {
    name: string;
    schema: z.ZodObject<{
        name: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodEnum<["accountCircle", "add", "arrowBack", "arrowForward", "attachFile", "calendarToday", "call", "camera", "check", "close", "delete", "download", "edit", "event", "error", "favorite", "favoriteOff", "folder", "help", "home", "info", "locationOn", "lock", "lockOpen", "mail", "menu", "moreVert", "moreHoriz", "notificationsOff", "notifications", "payment", "person", "phone", "photo", "print", "refresh", "search", "send", "settings", "share", "shoppingCart", "star", "starHalf", "starOff", "upload", "visibility", "visibilityOff", "warning"]>>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | undefined;
        }, {
            path?: string | undefined;
            literalString?: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        name: {
            path?: string | undefined;
            literalString?: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | undefined;
        };
    }, {
        name: {
            path?: string | undefined;
            literalString?: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | undefined;
        };
    }>;
};
export declare const VideoApi: {
    name: string;
    schema: z.ZodObject<{
        url: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }>;
};
export declare const AudioPlayerApi: {
    name: string;
    schema: z.ZodObject<{
        url: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        description?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
    }, {
        url: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        description?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
    }>;
};
export declare const RowApi: {
    name: string;
    schema: z.ZodObject<{
        children: z.ZodObject<{
            explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            template: z.ZodOptional<z.ZodObject<{
                componentId: z.ZodString;
                dataBinding: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                componentId: string;
                dataBinding: string;
            }, {
                componentId: string;
                dataBinding: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }>;
        distribution: z.ZodOptional<z.ZodEnum<["center", "end", "spaceAround", "spaceBetween", "spaceEvenly", "start"]>>;
        alignment: z.ZodOptional<z.ZodEnum<["start", "center", "end", "stretch"]>>;
    }, "strict", z.ZodTypeAny, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
    }, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
    }>;
};
export declare const ColumnApi: {
    name: string;
    schema: z.ZodObject<{
        children: z.ZodObject<{
            explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            template: z.ZodOptional<z.ZodObject<{
                componentId: z.ZodString;
                dataBinding: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                componentId: string;
                dataBinding: string;
            }, {
                componentId: string;
                dataBinding: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }>;
        distribution: z.ZodOptional<z.ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly"]>>;
        alignment: z.ZodOptional<z.ZodEnum<["center", "end", "start", "stretch"]>>;
    }, "strict", z.ZodTypeAny, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
    }, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        distribution?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | undefined;
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
    }>;
};
export declare const ListApi: {
    name: string;
    schema: z.ZodObject<{
        children: z.ZodObject<{
            explicitList: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            template: z.ZodOptional<z.ZodObject<{
                componentId: z.ZodString;
                dataBinding: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                componentId: string;
                dataBinding: string;
            }, {
                componentId: string;
                dataBinding: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }, {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        }>;
        direction: z.ZodOptional<z.ZodEnum<["vertical", "horizontal"]>>;
        alignment: z.ZodOptional<z.ZodEnum<["start", "center", "end", "stretch"]>>;
    }, "strict", z.ZodTypeAny, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
        direction?: "horizontal" | "vertical" | undefined;
    }, {
        children: {
            explicitList?: string[] | undefined;
            template?: {
                componentId: string;
                dataBinding: string;
            } | undefined;
        };
        alignment?: "start" | "center" | "end" | "stretch" | undefined;
        direction?: "horizontal" | "vertical" | undefined;
    }>;
};
export declare const CardApi: {
    name: string;
    schema: z.ZodObject<{
        child: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        child: string;
    }, {
        child: string;
    }>;
};
export declare const TabsApi: {
    name: string;
    schema: z.ZodObject<{
        tabItems: z.ZodArray<z.ZodObject<{
            title: z.ZodObject<{
                literalString: z.ZodOptional<z.ZodString>;
                path: z.ZodOptional<z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                path?: string | undefined;
                literalString?: string | undefined;
            }, {
                path?: string | undefined;
                literalString?: string | undefined;
            }>;
            child: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            child: string;
            title: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }, {
            child: string;
            title: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        tabItems: {
            child: string;
            title: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }[];
    }, {
        tabItems: {
            child: string;
            title: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }[];
    }>;
};
export declare const DividerApi: {
    name: string;
    schema: z.ZodObject<{
        axis: z.ZodOptional<z.ZodEnum<["horizontal", "vertical"]>>;
    }, "strict", z.ZodTypeAny, {
        axis?: "horizontal" | "vertical" | undefined;
    }, {
        axis?: "horizontal" | "vertical" | undefined;
    }>;
};
export declare const ModalApi: {
    name: string;
    schema: z.ZodObject<{
        entryPointChild: z.ZodString;
        contentChild: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        entryPointChild: string;
        contentChild: string;
    }, {
        entryPointChild: string;
        contentChild: string;
    }>;
};
export declare const ButtonApi: {
    name: string;
    schema: z.ZodObject<{
        child: z.ZodString;
        primary: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodObject<{
            name: z.ZodString;
            context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                value: z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                    literalString: z.ZodOptional<z.ZodString>;
                    literalNumber: z.ZodOptional<z.ZodNumber>;
                    literalBoolean: z.ZodOptional<z.ZodBoolean>;
                }, "strip", z.ZodTypeAny, {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                }, {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                }>;
            }, "strip", z.ZodTypeAny, {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }, {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }>, "many">>;
        }, "strip", z.ZodTypeAny, {
            name: string;
            context?: {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }[] | undefined;
        }, {
            name: string;
            context?: {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }[] | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        child: string;
        action: {
            name: string;
            context?: {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }[] | undefined;
        };
        primary?: boolean | undefined;
    }, {
        child: string;
        action: {
            name: string;
            context?: {
                value: {
                    path?: string | undefined;
                    literalString?: string | undefined;
                    literalNumber?: number | undefined;
                    literalBoolean?: boolean | undefined;
                };
                key: string;
            }[] | undefined;
        };
        primary?: boolean | undefined;
    }>;
};
export declare const CheckBoxApi: {
    name: string;
    schema: z.ZodObject<{
        label: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        value: z.ZodObject<{
            literalBoolean: z.ZodOptional<z.ZodBoolean>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalBoolean?: boolean | undefined;
        }, {
            path?: string | undefined;
            literalBoolean?: boolean | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        value: {
            path?: string | undefined;
            literalBoolean?: boolean | undefined;
        };
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }, {
        value: {
            path?: string | undefined;
            literalBoolean?: boolean | undefined;
        };
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
    }>;
};
export declare const TextFieldApi: {
    name: string;
    schema: z.ZodObject<{
        label: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        text: z.ZodOptional<z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>>;
        textFieldType: z.ZodOptional<z.ZodEnum<["date", "longText", "number", "shortText", "obscured"]>>;
        validationRegexp: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        text?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
        textFieldType?: "number" | "date" | "shortText" | "longText" | "obscured" | undefined;
        validationRegexp?: string | undefined;
    }, {
        label: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        text?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
        textFieldType?: "number" | "date" | "shortText" | "longText" | "obscured" | undefined;
        validationRegexp?: string | undefined;
    }>;
};
export declare const DateTimeInputApi: {
    name: string;
    schema: z.ZodObject<{
        value: z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>;
        enableDate: z.ZodOptional<z.ZodBoolean>;
        enableTime: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        enableDate?: boolean | undefined;
        enableTime?: boolean | undefined;
    }, {
        value: {
            path?: string | undefined;
            literalString?: string | undefined;
        };
        enableDate?: boolean | undefined;
        enableTime?: boolean | undefined;
    }>;
};
export declare const MultipleChoiceApi: {
    name: string;
    schema: z.ZodObject<{
        selections: z.ZodObject<{
            literalArray: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalArray?: string[] | undefined;
        }, {
            path?: string | undefined;
            literalArray?: string[] | undefined;
        }>;
        options: z.ZodArray<z.ZodObject<{
            label: z.ZodObject<{
                literalString: z.ZodOptional<z.ZodString>;
                path: z.ZodOptional<z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                path?: string | undefined;
                literalString?: string | undefined;
            }, {
                path?: string | undefined;
                literalString?: string | undefined;
            }>;
            value: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            value: string;
            label: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }, {
            value: string;
            label: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }>, "many">;
        maxAllowedSelections: z.ZodOptional<z.ZodNumber>;
        variant: z.ZodOptional<z.ZodEnum<["checkbox", "chips"]>>;
        filterable: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        options: {
            value: string;
            label: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }[];
        selections: {
            path?: string | undefined;
            literalArray?: string[] | undefined;
        };
        maxAllowedSelections?: number | undefined;
        filterable?: boolean | undefined;
        variant?: "checkbox" | "chips" | undefined;
    }, {
        options: {
            value: string;
            label: {
                path?: string | undefined;
                literalString?: string | undefined;
            };
        }[];
        selections: {
            path?: string | undefined;
            literalArray?: string[] | undefined;
        };
        maxAllowedSelections?: number | undefined;
        filterable?: boolean | undefined;
        variant?: "checkbox" | "chips" | undefined;
    }>;
};
export declare const SliderApi: {
    name: string;
    schema: z.ZodObject<{
        label: z.ZodOptional<z.ZodObject<{
            literalString: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalString?: string | undefined;
        }, {
            path?: string | undefined;
            literalString?: string | undefined;
        }>>;
        value: z.ZodObject<{
            literalNumber: z.ZodOptional<z.ZodNumber>;
            path: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            path?: string | undefined;
            literalNumber?: number | undefined;
        }, {
            path?: string | undefined;
            literalNumber?: number | undefined;
        }>;
        minValue: z.ZodOptional<z.ZodNumber>;
        maxValue: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        value: {
            path?: string | undefined;
            literalNumber?: number | undefined;
        };
        label?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
        minValue?: number | undefined;
        maxValue?: number | undefined;
    }, {
        value: {
            path?: string | undefined;
            literalNumber?: number | undefined;
        };
        label?: {
            path?: string | undefined;
            literalString?: string | undefined;
        } | undefined;
        minValue?: number | undefined;
        maxValue?: number | undefined;
    }>;
};
/**
 * The theme of the v0.8 basic catalog, which its document declares under
 * `styles`.
 */
export declare const ThemeSchema: z.ZodObject<{
    font: z.ZodOptional<z.ZodString>;
    primaryColor: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    font?: string | undefined;
    primaryColor?: string | undefined;
}, {
    font?: string | undefined;
    primaryColor?: string | undefined;
}>;
export declare const BASIC_COMPONENTS: ComponentApi[];
/**
 * The document-level fields of the published catalog document, which
 * declares neither a protocol version nor a catalog ID, writes its theme
 * under `styles` and has no `$defs`.
 */
export declare const BASIC_CATALOG_DOCUMENT_OPTIONS: {
    declaredProtocolVersion: null;
    declaresCatalogId: false;
    unions: {
        anyComponent: false;
        anyFunction: false;
    };
    themeLocation: "styles";
};
//# sourceMappingURL=basic_components.d.ts.map