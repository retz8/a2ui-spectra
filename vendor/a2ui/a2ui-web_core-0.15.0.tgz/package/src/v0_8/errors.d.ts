/**
 * Base class for all A2UI v0.8 specific errors.
 */
export declare class A2uiError extends Error {
    /** Machine-readable string identifying the error category. */
    readonly code: string;
    /**
     * Initializes a new `A2uiError` instance.
     *
     * @param message Human-readable error description.
     * @param code Machine-readable error category code.
     */
    constructor(message: string, code?: string);
}
/**
 * Error thrown when JSON validation fails or schemas are mismatched.
 */
export declare class A2uiValidationError extends A2uiError {
    readonly details?: any | undefined;
    /**
     * Initializes a new `A2uiValidationError` instance.
     *
     * @param message Human-readable error description.
     * @param details Additional error details or issues.
     */
    constructor(message: string, details?: any | undefined);
}
/**
 * Error thrown during DataModel mutations (invalid paths, type mismatches).
 */
export declare class A2uiDataError extends A2uiError {
    readonly path?: string | undefined;
    /**
     * Initializes a new `A2uiDataError` instance.
     *
     * @param message Human-readable error description.
     * @param path Target data path.
     */
    constructor(message: string, path?: string | undefined);
}
/**
 * Error thrown during string interpolation and function evaluation.
 */
export declare class A2uiExpressionError extends A2uiError {
    readonly expression?: string | undefined;
    /**
     * Initializes a new `A2uiExpressionError` instance.
     *
     * @param message Human-readable error description.
     * @param expression Evaluated expression string.
     */
    constructor(message: string, expression?: string | undefined);
}
/**
 * Error thrown for structural issues in the UI tree (missing surfaces, duplicate components).
 */
export declare class A2uiStateError extends A2uiError {
    /**
     * Initializes a new `A2uiStateError` instance.
     *
     * @param message Human-readable error description.
     */
    constructor(message: string);
}
//# sourceMappingURL=errors.d.ts.map