import { ServerToClientMessage, AnyComponentNode, DataValue, Surface, MessageProcessor } from '../types/types.js';
/**
 * Processes and consolidates A2UI v0.8 protocol messages into a structured model of UI surfaces.
 */
export declare class A2uiMessageProcessor implements MessageProcessor {
    readonly opts: {
        mapCtor: MapConstructor;
        arrayCtor: ArrayConstructor;
        setCtor: SetConstructor;
        objCtor: ObjectConstructor;
    };
    static readonly DEFAULT_SURFACE_ID = "@default";
    private mapCtor;
    private arrayCtor;
    private setCtor;
    private objCtor;
    private surfaces;
    constructor(opts?: {
        mapCtor: MapConstructor;
        arrayCtor: ArrayConstructor;
        setCtor: SetConstructor;
        objCtor: ObjectConstructor;
    });
    /**
     * Retrieves a map of all visible surfaces with root components.
     *
     * @returns Readonly map of active surfaces keyed by surface ID.
     */
    getSurfaces(): ReadonlyMap<string, Surface>;
    /**
     * Clears all surface records from memory.
     */
    clearSurfaces(): void;
    /**
     * Processes an array of server-to-client messages and applies state mutations.
     *
     * @param messages Array of v0.8 server-to-client messages.
     */
    processMessages(messages: ServerToClientMessage[]): void;
    /**
     * Retrieves data for a given component node and relative path string.
     *
     * @param node Component node providing data context.
     * @param relativePath Relative or absolute JSON pointer path.
     * @param surfaceId Surface identifier.
     * @returns Resolved data value, or null if not found.
     */
    getData(node: AnyComponentNode, relativePath: string, surfaceId?: string): DataValue | null;
    /**
     * Updates data at a path relative to a component node.
     *
     * @param node Component node providing data context.
     * @param relativePath Relative or absolute JSON pointer path.
     * @param value New value to assign.
     * @param surfaceId Surface identifier.
     */
    setData(node: AnyComponentNode | null, relativePath: string, value: DataValue, surfaceId?: string): void;
    /**
     * Resolves a path relative to a base data context path.
     *
     * @param path Target path string.
     * @param dataContextPath Base context path.
     * @returns Resolved absolute path string.
     */
    resolvePath(path: string, dataContextPath?: string): string;
    private parseIfJsonString;
    /**
     * Converts a specific array format [{key: "...", value_string: "..."}, ...]
     * into a standard Map. It also attempts to parse any string values that
     * appear to be stringified JSON.
     */
    private convertKeyValueArrayToMap;
    private setDataByPath;
    /**
     * Normalizes a path string into a consistent, slash-delimited format.
     * Converts bracket notation and dot notation in a two-pass.
     * e.g., "bookRecommendations[0].title" -> "/bookRecommendations/0/title"
     * e.g., "book.0.title" -> "/book/0/title"
     */
    private normalizePath;
    private getDataByPath;
    private getOrCreateSurface;
    private handleBeginRendering;
    private handleSurfaceUpdate;
    private handleDataModelUpdate;
    private handleDeleteSurface;
    /**
     * Starts at the root component of the surface and builds out the tree
     * recursively. This process involves resolving all properties of the child
     * components, and expanding on any explicit children lists or templates
     * found in the structure.
     *
     * @param surface The surface to be built.
     */
    private rebuildComponentTree;
    /** Finds a value key in a map. */
    private findValueKey;
    /**
     * Builds out the nodes recursively.
     */
    private buildNodeRecursive;
    /**
     * Recursively resolves an individual property value. If a property indicates
     * a child node (a string that matches a component ID), an explicitList of
     * children, or a template, these will be built out here.
     */
    private resolvePropertyValue;
}
//# sourceMappingURL=model-processor.d.ts.map