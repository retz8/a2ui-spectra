import { ComponentArrayReference, ResolvedAudioPlayer, ResolvedButton, ResolvedCard, ResolvedCheckbox, ResolvedColumn, ResolvedDateTimeInput, ResolvedDivider, ResolvedIcon, ResolvedImage, ResolvedList, ResolvedModal, ResolvedMultipleChoice, ResolvedRow, ResolvedSlider, ResolvedTabs, ResolvedText, ResolvedTextField, ResolvedVideo, ValueMap } from '../types/types';
/**
 * Checks whether a value is a valid v0.8 ValueMap object.
 *
 * @param value Value to test.
 * @returns Whether the value is a ValueMap.
 */
export declare function isValueMap(value: unknown): value is ValueMap;
/**
 * Checks whether a key and value represent a valid JSON path reference.
 *
 * @param key Property key name.
 * @param value Property value.
 * @returns Whether the key is 'path' and the value is a string.
 */
export declare function isPath(key: string, value: unknown): value is string;
/**
 * Checks whether a value is a non-null, non-array object record.
 *
 * @param value Value to test.
 * @returns Whether the value is a Record object.
 */
export declare function isObject(value: unknown): value is Record<string, unknown>;
/**
 * Checks whether a value is a ComponentArrayReference (explicit list or template).
 *
 * @param value Value to test.
 * @returns Whether the value is a ComponentArrayReference.
 */
export declare function isComponentArrayReference(value: unknown): value is ComponentArrayReference;
/**
 * Checks whether a props object conforms to ResolvedAudioPlayer.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedAudioPlayer.
 */
export declare function isResolvedAudioPlayer(props: unknown): props is ResolvedAudioPlayer;
/**
 * Checks whether a props object conforms to ResolvedButton.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedButton.
 */
export declare function isResolvedButton(props: unknown): props is ResolvedButton;
/**
 * Checks whether a props object conforms to ResolvedCard.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedCard.
 */
export declare function isResolvedCard(props: unknown): props is ResolvedCard;
/**
 * Checks whether a props object conforms to ResolvedCheckbox.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedCheckbox.
 */
export declare function isResolvedCheckbox(props: unknown): props is ResolvedCheckbox;
/**
 * Checks whether a props object conforms to ResolvedColumn.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedColumn.
 */
export declare function isResolvedColumn(props: unknown): props is ResolvedColumn;
/**
 * Checks whether a props object conforms to ResolvedDateTimeInput.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedDateTimeInput.
 */
export declare function isResolvedDateTimeInput(props: unknown): props is ResolvedDateTimeInput;
/**
 * Checks whether a props object conforms to ResolvedDivider.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedDivider.
 */
export declare function isResolvedDivider(props: unknown): props is ResolvedDivider;
/**
 * Checks whether a props object conforms to ResolvedImage.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedImage.
 */
export declare function isResolvedImage(props: unknown): props is ResolvedImage;
/**
 * Checks whether a props object conforms to ResolvedIcon.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedIcon.
 */
export declare function isResolvedIcon(props: unknown): props is ResolvedIcon;
/**
 * Checks whether a props object conforms to ResolvedList.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedList.
 */
export declare function isResolvedList(props: unknown): props is ResolvedList;
/**
 * Checks whether a props object conforms to ResolvedModal.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedModal.
 */
export declare function isResolvedModal(props: unknown): props is ResolvedModal;
/**
 * Checks whether a props object conforms to ResolvedMultipleChoice.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedMultipleChoice.
 */
export declare function isResolvedMultipleChoice(props: unknown): props is ResolvedMultipleChoice;
/**
 * Checks whether a props object conforms to ResolvedRow.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedRow.
 */
export declare function isResolvedRow(props: unknown): props is ResolvedRow;
/**
 * Checks whether a props object conforms to ResolvedSlider.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedSlider.
 */
export declare function isResolvedSlider(props: unknown): props is ResolvedSlider;
/**
 * Checks whether a props object conforms to ResolvedTabs.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedTabs.
 */
export declare function isResolvedTabs(props: unknown): props is ResolvedTabs;
/**
 * Checks whether a props object conforms to ResolvedText.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedText.
 */
export declare function isResolvedText(props: unknown): props is ResolvedText;
/**
 * Checks whether a props object conforms to ResolvedTextField.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedTextField.
 */
export declare function isResolvedTextField(props: unknown): props is ResolvedTextField;
/**
 * Checks whether a props object conforms to ResolvedVideo.
 *
 * @param props Properties object to test.
 * @returns Whether the props match ResolvedVideo.
 */
export declare function isResolvedVideo(props: unknown): props is ResolvedVideo;
//# sourceMappingURL=guards.d.ts.map