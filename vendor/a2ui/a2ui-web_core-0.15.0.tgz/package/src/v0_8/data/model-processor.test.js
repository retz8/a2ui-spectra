/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, beforeEach } from 'node:test';
import { A2uiMessageProcessor } from './model-processor.js';
describe('A2uiMessageProcessor', () => {
    let processor;
    beforeEach(() => {
        processor = new A2uiMessageProcessor();
    });
    it('handles beginRendering', () => {
        processor.processMessages([
            {
                beginRendering: {
                    surfaceId: 's1',
                    root: 'root',
                    styles: { font: 'Arial' },
                },
            },
        ]);
        const surfaces = processor.getSurfaces();
        const surface = surfaces.get('s1');
        assert.ok(surface);
        assert.strictEqual(surface.rootComponentId, 'root');
        assert.deepStrictEqual(surface.styles, { font: 'Arial' });
        // The component tree remains null until components are added via surfaceUpdate.
        assert.strictEqual(surface.componentTree, null);
    });
    it('handles surfaceUpdate', () => {
        processor.processMessages([
            {
                beginRendering: { surfaceId: 's1', root: 'root' },
            },
        ]);
        processor.processMessages([
            {
                surfaceUpdate: {
                    surfaceId: 's1',
                    components: [
                        {
                            id: 'root',
                            component: {
                                Text: { text: { literal: 'Hello' }, usageHint: 'body' },
                            },
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        assert.ok(surface);
        assert.ok(surface.componentTree);
        const root = surface.componentTree;
        assert.strictEqual(root.id, 'root');
        assert.strictEqual(root.type, 'Text');
        // The property preserves the literal wrapper
        assert.deepStrictEqual(root.properties.text, { literal: 'Hello' });
    });
    it('handles dataModelUpdate', () => {
        processor.processMessages([
            {
                beginRendering: { surfaceId: 's1', root: 'root' },
            },
            {
                dataModelUpdate: {
                    surfaceId: 's1',
                    contents: [{ key: 'message', valueString: 'World' }],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        assert.strictEqual(surface?.dataModel.get('message'), 'World');
    });
    it('handles deleteSurface', () => {
        processor.processMessages([
            {
                beginRendering: { surfaceId: 's1', root: 'root' },
            },
        ]);
        assert.ok(processor.getSurfaces().has('s1'));
        processor.processMessages([
            {
                deleteSurface: { surfaceId: 's1' },
            },
        ]);
        assert.ok(!processor.getSurfaces().has('s1'));
    });
    it('resolves component references (children)', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's1', root: 'row' } },
            {
                surfaceUpdate: {
                    surfaceId: 's1',
                    components: [
                        {
                            id: 'row',
                            component: {
                                Row: { children: { explicitList: ['t1', 't2'] } },
                            },
                        },
                        {
                            id: 't1',
                            component: {
                                Text: { text: { literal: 'One' }, usageHint: 'body' },
                            },
                        },
                        {
                            id: 't2',
                            component: {
                                Text: { text: { literal: 'Two' }, usageHint: 'body' },
                            },
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        const root = surface?.componentTree;
        assert.strictEqual(root.type, 'Row');
        assert.strictEqual(root.properties.children.length, 2);
        assert.deepStrictEqual(root.properties.children[0].properties.text, {
            literal: 'One',
        });
        assert.deepStrictEqual(root.properties.children[1].properties.text, {
            literal: 'Two',
        });
    });
    it('resolves templates', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's1', root: 'row' } },
            {
                dataModelUpdate: {
                    surfaceId: 's1',
                    contents: [
                        {
                            key: 'items',
                            valueMap: [
                                { key: '0', valueString: 'Item A' },
                                { key: '1', valueString: 'Item B' },
                            ],
                        },
                    ],
                },
            },
            {
                surfaceUpdate: {
                    surfaceId: 's1',
                    components: [
                        {
                            id: 'row',
                            component: {
                                Row: {
                                    children: {
                                        template: {
                                            componentId: 'item',
                                            dataBinding: '/items',
                                        },
                                    },
                                },
                            },
                        },
                        {
                            id: 'item',
                            component: {
                                Text: { text: { path: '.' }, usageHint: 'body' },
                            },
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        const root = surface?.componentTree;
        assert.strictEqual(root.type, 'Row');
        assert.strictEqual(root.properties.children.length, 2);
        // Verify template expansion
        const child0 = root.properties.children[0];
        const child1 = root.properties.children[1];
        // Check that binding paths are correct (processor does NOT resolve the value, just the binding path context)
        assert.deepStrictEqual(child0.properties.text, { path: '.' });
        // Now verify we can resolve the data using the node's context
        const textProp0 = child0.properties.text;
        const resolvedValue0 = processor.getData(child0, textProp0.path, 's1');
        assert.strictEqual(resolvedValue0, 'Item A');
        const textProp1 = child1.properties.text;
        const resolvedValue1 = processor.getData(child1, textProp1.path, 's1');
        assert.strictEqual(resolvedValue1, 'Item B');
    });
    it('getData resolves paths relative to node context', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's1', root: 'root' } },
            {
                dataModelUpdate: {
                    surfaceId: 's1',
                    contents: [{ key: 'user', valueMap: [{ key: 'name', valueString: 'Alice' }] }],
                },
            },
        ]);
        processor.getSurfaces().get('s1');
        const node = { id: 'test', dataContextPath: '/user' };
        const name = processor.getData(node, 'name', 's1');
        assert.strictEqual(name, 'Alice');
        const self = processor.getData(node, '.', 's1');
        assert.ok(self instanceof Map);
        assert.strictEqual(self.get('name'), 'Alice');
        const rootData = processor.getData(node, '/user/name', 's1');
        assert.strictEqual(rootData, 'Alice');
    });
    it('setData updates data model', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's1', root: 'root' } }]);
        const surface = processor.getSurfaces().get('s1');
        const node = { id: 'test', dataContextPath: '/' };
        processor.setData(node, 'count', 42, 's1');
        assert.strictEqual(surface?.dataModel.get('count'), 42);
        processor.setData(node, '/nested/value', 'foo', 's1');
        const nested = surface?.dataModel.get('nested');
        assert.strictEqual(nested.get('value'), 'foo');
    });
    it('normalizes paths correctly', () => {
        const p = processor.normalizePath('users[0].name');
        assert.strictEqual(p, '/users/0/name');
    });
    it('parses JSON strings in data', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's1', root: 'root' } }]);
        // Explicitly testing private/internal parsing logic via public update
        processor.processMessages([
            {
                dataModelUpdate: {
                    surfaceId: 's1',
                    contents: [{ key: 'config', valueString: '{"theme":"dark"}' }],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        const config = surface?.dataModel.get('config');
        assert.deepStrictEqual(config, { theme: 'dark' });
    });
    it('test basic edge cases and internal fallbacks', () => {
        // 1. clearSurfaces
        processor.processMessages([{ beginRendering: { surfaceId: 's1', root: 'root' } }]);
        assert.strictEqual(processor.getSurfaces().size, 1);
        processor.clearSurfaces();
        assert.strictEqual(processor.getSurfaces().size, 0);
        // 2. setData with null node
        processor.processMessages([{ beginRendering: { surfaceId: 's1', root: 'root' } }]);
        // Shouldn't throw
        processor.setData(null, 'foo', 'bar');
        // 3. setData with default data context (default to /)
        const node = { id: 'test', dataContextPath: undefined };
        processor.setData(node, '.', 'value');
        const surface = processor.getSurfaces().get('s1');
        assert.strictEqual(surface.dataModel.get('.'), undefined); // Normal setDataByPath logic when root=/
        // 4. parseIfJsonString with invalid JSON layout
        processor.processMessages([
            {
                dataModelUpdate: {
                    surfaceId: 's1',
                    contents: [{ key: 'badJson', valueString: '{bad" }' }],
                },
            },
        ]);
        assert.strictEqual(surface.dataModel.get('badJson'), '{bad" }'); // Returns original
        // 5. convertKeyValueArrayToMap with missing valueKey
        // Explicit array pass directly to internal mapping simulation
        processor.setDataByPath(surface.dataModel, 'malformed', [
            { key: 'foo', unknownKey: 'bar' }, // missing value map/string etc
        ]);
        const malformed = surface.dataModel.get('malformed');
        assert.strictEqual(malformed.has('foo'), false); // Skips processing
        // 6. object normalization at root
        processor.setDataByPath(surface.dataModel, '/', {
            plain: 'object',
        });
        assert.strictEqual(surface.dataModel.get('plain'), 'object');
        // 7. non-map/object root fails gracefully
        processor.setDataByPath(surface.dataModel, '/', 'stringroot');
        // Doesn't explode, just prints error internally
    });
    it('test array set operations and invalid primitive traversal', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's1', root: 'root' } }]);
        const surface = processor.getSurfaces().get('s1');
        // Manually set an array to avoid empty array being converted to Map
        surface.dataModel.set('list', ['dummy']);
        // Now it's an array at /list, set something deep inside it
        processor.setDataByPath(surface.dataModel, '/list/0/name', 'Alice');
        // Also test setting a value directly on an array index
        processor.setDataByPath(surface.dataModel, '/list/1', 'Bob');
        const list = surface.dataModel.get('list');
        assert.strictEqual(list[0].get('name'), 'Alice'); // It creates a Map for `name`
        assert.strictEqual(list[1], 'Bob');
        // Test getDataByPath failing traversal over a primitive
        processor.setDataByPath(surface.dataModel, '/primitive', 'hello');
        const result = processor.getDataByPath(surface.dataModel, '/primitive/invalid');
        assert.strictEqual(result, null);
    });
    it('test tree rebuilding edge cases', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's_tree', root: 'root' } }]);
        const surface = processor.getSurfaces().get('s_tree');
        // 1. rebuildComponentTree without rootComponentId
        surface.rootComponentId = null;
        processor.rebuildComponentTree(surface);
        assert.strictEqual(surface.componentTree, null);
        // 2. Circular dependency
        surface.rootComponentId = 'circleA';
        surface.components.set('circleA', {
            id: 'circleA',
            component: { Row: { children: ['circleB'] } },
        });
        surface.components.set('circleB', {
            id: 'circleB',
            component: { Row: { children: ['circleA'] } },
        });
        assert.throws(() => {
            processor.rebuildComponentTree(surface);
        }, /Circular dependency/);
    });
    it('throws A2uiValidationError for malformed components', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's_bad_comp', root: 'bad' } }]);
        const surface = processor.getSurfaces().get('s_bad_comp');
        surface.rootComponentId = 'bad';
        // Divider is omitted here because it has no required fields, so `{}` is valid.
        const types = [
            'Text',
            'Image',
            'Icon',
            'Video',
            'AudioPlayer',
            'Row',
            'Column',
            'List',
            'Card',
            'Tabs',
            'Modal',
            'Button',
            'CheckBox',
            'TextField',
            'DateTimeInput',
            'MultipleChoice',
            'Slider',
        ];
        for (const type of types) {
            assert.throws(() => {
                surface.components.set('bad', {
                    id: 'bad',
                    component: {
                        [type]: {
                        /* missing required fields */
                        },
                    },
                });
                processor.rebuildComponentTree(surface);
            }, /Invalid data; expected/);
        }
        // Default catch-all (doesn't throw, just passes it through)
        surface.components.set('bad', {
            id: 'bad',
            component: { CustomWidget: { foo: 'bar' } },
        });
        processor.rebuildComponentTree(surface);
        assert.strictEqual(surface.componentTree.type, 'CustomWidget');
    });
    it('resolves Template with Array data', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's3_arr', root: 'list' } },
            {
                dataModelUpdate: {
                    surfaceId: 's3_arr',
                    path: '/items',
                    contents: [
                        { key: '0', valueString: 'a' },
                        { key: '1', valueString: 'b' },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s3_arr');
        surface.components.set('list', {
            id: 'list',
            component: {
                List: {
                    children: {
                        template: { dataBinding: '/items', componentId: 'item' },
                    },
                },
            },
        });
        surface.components.set('item', {
            id: 'item',
            component: {
                Text: { text: { literalString: 'hello' }, usageHint: 'body' },
            },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(root.properties.children.length, 2);
        assert.strictEqual(root.properties.children[0].id, 'item:0');
        assert.strictEqual(root.properties.children[0].dataContextPath, '/items/0');
        assert.strictEqual(root.properties.children[1].id, 'item:1');
        assert.strictEqual(root.properties.children[1].dataContextPath, '/items/1');
    });
    it('resolves Template with undefined/null data as empty array', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's3_null', root: 'list' } }]);
        const surface = processor.getSurfaces().get('s3_null');
        surface.components.set('list', {
            id: 'list',
            component: {
                List: {
                    children: {
                        template: { dataBinding: '/missingItems', componentId: 'item' },
                    },
                },
            },
        });
        surface.components.set('item', {
            id: 'item',
            component: {
                Text: { text: { literalString: 'hello' }, usageHint: 'body' },
            },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.deepStrictEqual(root.properties.children, []);
    });
    it('sets primitive at path via single array element with dot key', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's1_prim', root: 'list' } },
            {
                dataModelUpdate: {
                    surfaceId: 's1_prim',
                    path: '/nested/item',
                    contents: [{ key: '.', valueString: 'hello' }],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1_prim');
        surface.components.set('list', {
            id: 'list',
            component: { Row: { children: { explicitList: [] } } },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(processor.getData(root, '/nested/item', 's1_prim'), 'hello');
        // Test the fallback where valueString is absent but we pass something anyway
        assert.throws(() => {
            processor.processMessages([
                {
                    dataModelUpdate: {
                        surfaceId: 's1_prim',
                        path: '/nested/malformed',
                        contents: [{ key: '.' }],
                    },
                },
            ]);
        }, /must have exactly one value property/);
    });
    it('path resolves through primitive objects and arrays', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's1_path', root: 'list' } }]);
        const surface = processor.getSurfaces().get('s1_path');
        surface.dataModel.set('obj', {
            nestedMap: new Map([['index', [1, 2, { val: 'hi' }]]]),
        });
        surface.components.set('list', {
            id: 'list',
            component: { Row: { children: { explicitList: [] } } },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(processor.getData(root, '/obj/nestedMap/index/2/val', 's1_path'), 'hi');
        assert.strictEqual(processor.getData(root, '/obj/nestedMap/index/2/val/deeper', 's1_path'), null);
    });
    it('builds all component types correctly', () => {
        const surfaceId = 's_all';
        processor.processMessages([{ beginRendering: { surfaceId, root: 'col' } }]);
        const surface = processor.getSurfaces().get(surfaceId);
        const components = {
            col: { Column: { children: ['row'] } },
            row: { Row: { children: ['card'] } },
            card: { Card: { child: 'tabs' } },
            tabs: {
                Tabs: {
                    tabItems: [{ title: { literalString: 'T1' }, child: 'modal' }],
                },
            },
            modal: { Modal: { entryPointChild: 'list', contentChild: 'div' } },
            list: { List: { children: ['btn'] } },
            btn: { Button: { child: 'btn_txt', action: 'act' } },
            btn_txt: { Text: { text: { literalString: 'Click' } } },
            div: { Divider: {} },
            chk: {
                CheckBox: {
                    label: { literalString: 'Chk' },
                    value: { literalBoolean: true },
                },
            },
            txt: { TextField: { label: { literalString: 'Txt' } } },
            dt: { DateTimeInput: { value: { literalString: '2022-01-01' } } },
            mc: { MultipleChoice: { selections: { literal: ['a'] } } },
            sl: { Slider: { value: { literalNumber: 50 } } },
            img: { Image: { url: { literalString: 'http://img' } } },
            icon: { Icon: { name: { literalString: 'home' } } },
            vid: { Video: { url: { literalString: 'http://vid' } } },
            aud: { AudioPlayer: { url: { literalString: 'http://aud' } } },
        };
        for (const [id, comp] of Object.entries(components)) {
            surface.components.set(id, { id, component: comp });
        }
        surface.components.set('root_all', {
            id: 'root_all',
            component: {
                Column: {
                    children: ['col', 'chk', 'txt', 'dt', 'mc', 'sl', 'img', 'icon', 'vid', 'aud'],
                },
            },
        });
        surface.rootComponentId = 'root_all';
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(root.type, 'Column');
        assert.strictEqual(root.properties.children.length, 10);
    });
    it('handles recursive valueMap in convertKeyValueArrayToMap', () => {
        // We need to bypass private check or use a method that calls it.
        // setData calls setDataByPath which calls convertKeyValueArrayToMap.
        const update = {
            surfaceId: 's_rec',
            contents: [
                {
                    key: 'nested',
                    valueMap: [{ key: 'inner', valueString: 'val' }],
                },
            ], // Recursive generic type difficult to construct in TS literal
        };
        // We can use processMessages with dataModelUpdate.
        processor.processMessages([{ beginRendering: { surfaceId: 's_rec', root: 'root' } }]);
        // Set root to Map first
        const surface = processor.getSurfaces().get('s_rec');
        surface.dataModel.set('junk', 'ignored');
        processor.processMessages([{ dataModelUpdate: update }]);
        // Verify data
        const nested = surface.dataModel.get('nested');
        assert.strictEqual(nested instanceof Map, true);
        assert.strictEqual(nested.get('inner'), 'val');
    });
    it('resolves Template with Map data', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's3_map', root: 'list' } },
            {
                dataModelUpdate: {
                    surfaceId: 's3_map',
                    contents: [
                        {
                            key: 'items',
                            valueMap: [
                                { key: 'a', valueString: 'valA' },
                                { key: 'b', valueString: 'valB' },
                            ],
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s3_map');
        // Define components
        surface.components.set('list', {
            id: 'list',
            component: {
                List: {
                    children: {
                        template: {
                            dataBinding: '/items',
                            componentId: 'item',
                        },
                    },
                },
            },
        });
        surface.components.set('item', {
            id: 'item',
            component: {
                Text: { text: { path: '.' } },
            },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(root.type, 'List');
        // Map entries should be processed.
        assert.strictEqual(root.properties.children.length, 2);
    });
    it('handles Object-to-Map normalization in handleDataModelUpdate (direct call)', () => {
        const surfaceId = 's_norm';
        processor.processMessages([{ beginRendering: { surfaceId, root: 'root' } }]);
        const surface = processor.getSurfaces().get(surfaceId);
        // Direct call to bypass Zod validation in processMessages
        processor.handleDataModelUpdate({
            surfaceId,
            contents: { normalized: 'value' },
        }, surfaceId);
        assert.strictEqual(surface.dataModel.get('normalized'), 'value');
    });
    it('throws validation error for invalid List', () => {
        const surfaceId = 's_bad_list';
        processor.processMessages([{ beginRendering: { surfaceId, root: 'badList' } }]);
        const surface = processor.getSurfaces().get(surfaceId);
        surface.components.set('badList', {
            id: 'badList',
            component: { List: { children: 'not-array' } },
        });
        assert.throws(() => {
            processor.rebuildComponentTree(surface);
        }, /Invalid data; expected List/);
    });
    it('handles recursive valueMap in convertKeyValueArrayToMap with dot key', () => {
        const surfaceId = 's_dot_rec';
        const surface = processor.getOrCreateSurface(surfaceId);
        const value = [
            {
                key: '.',
                valueMap: [{ key: 'inner', valueString: 'val' }],
            },
        ];
        // Calling setDataByPath directly (private)
        processor.setDataByPath(surface.dataModel, '/target', value);
        const target = surface.dataModel.get('target');
        assert.strictEqual(target instanceof Map, true);
        assert.strictEqual(target.get('inner'), 'val');
    });
    it('resolves Template with Array data (via direct setData)', () => {
        const surfaceId = 's_direct_arr';
        processor.processMessages([{ beginRendering: { surfaceId, root: 'list' } }]);
        const surface = processor.getSurfaces().get(surfaceId);
        // Setup components
        surface.components.set('list', {
            id: 'list',
            component: {
                List: {
                    children: {
                        template: {
                            dataBinding: '/items',
                            componentId: 'item',
                        },
                    },
                },
            },
        });
        surface.components.set('item', {
            id: 'item',
            component: {
                Text: { text: { path: '.' } },
            },
        });
        // Direct set array to bypass normalization/schema
        const itemsArray = ['A', 'B'];
        surface.dataModel.set('items', itemsArray);
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(root.type, 'List');
        assert.strictEqual(root.properties.children.length, 2);
    });
    it('ignores non-strings when trying to parse JSON', () => {
        const result = processor.parseIfJsonString(123);
        assert.strictEqual(result, 123);
    });
    it('does not resolve component references inside action context', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's1', root: 'btn' } },
            {
                surfaceUpdate: {
                    surfaceId: 's1',
                    components: [
                        {
                            id: 'btn',
                            component: {
                                Button: {
                                    child: 'btn_txt',
                                    action: {
                                        name: 'send-feedback',
                                        context: [{ key: 'comments', value: { path: '/comments' } }],
                                    },
                                },
                            },
                        },
                        {
                            id: 'comments',
                            component: {
                                TextField: { label: { literalString: 'Feedback' } },
                            },
                        },
                        {
                            id: 'btn_txt',
                            component: {
                                Text: { text: { literalString: 'Click' } },
                            },
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s1');
        const root = surface?.componentTree;
        const action = root.properties.action;
        assert.strictEqual(action.context[0].key, 'comments');
    });
    it('does not resolve Object.prototype inherited properties on ordinary objects', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's_proto', root: 'root' } }]);
        const surface = processor.getSurfaces().get('s_proto');
        surface.dataModel.set('user', {
            name: 'Alice',
            profile: { bio: 'Developer' },
        });
        surface.components.set('root', {
            id: 'root',
            component: { Row: { children: { explicitList: [] } } },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        // Valid own properties resolve normally
        assert.strictEqual(processor.getData(root, '/user/name', 's_proto'), 'Alice');
        assert.strictEqual(processor.getData(root, '/user/profile/bio', 's_proto'), 'Developer');
        // Inherited Object.prototype properties must resolve to null, not functions or prototype objects
        assert.strictEqual(processor.getData(root, '/user/toString', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/valueOf', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/constructor', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/__proto__', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/hasOwnProperty', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/isPrototypeOf', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/propertyIsEnumerable', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/toLocaleString', 's_proto'), null);
        // Deep prototype chain traversal must also fail and return null
        assert.strictEqual(processor.getData(root, '/user/__proto__/toString', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/constructor/prototype', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/profile/toString', 's_proto'), null);
        assert.strictEqual(processor.getData(root, '/user/profile/__proto__', 's_proto'), null);
    });
    it('allows reading own properties that match prototype property names on objects', () => {
        processor.processMessages([{ beginRendering: { surfaceId: 's_own_proto', root: 'root' } }]);
        const surface = processor.getSurfaces().get('s_own_proto');
        surface.dataModel.set('custom', {
            toString: 'custom-to-string',
            constructor: 'custom-constructor',
            valueOf: 12345,
        });
        surface.components.set('root', {
            id: 'root',
            component: { Row: { children: { explicitList: [] } } },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(processor.getData(root, '/custom/toString', 's_own_proto'), 'custom-to-string');
        assert.strictEqual(processor.getData(root, '/custom/constructor', 's_own_proto'), 'custom-constructor');
        assert.strictEqual(processor.getData(root, '/custom/valueOf', 's_own_proto'), 12345);
    });
    it('does not resolve prototype properties on objects in arrays or parsed JSON', () => {
        processor.processMessages([
            { beginRendering: { surfaceId: 's_json', root: 'root' } },
            {
                dataModelUpdate: {
                    surfaceId: 's_json',
                    path: '/',
                    contents: [
                        {
                            key: 'items',
                            valueString: JSON.stringify([
                                { id: 1, label: 'one' },
                                { id: 2, label: 'two' },
                            ]),
                        },
                    ],
                },
            },
        ]);
        const surface = processor.getSurfaces().get('s_json');
        surface.components.set('root', {
            id: 'root',
            component: { Row: { children: { explicitList: [] } } },
        });
        processor.rebuildComponentTree(surface);
        const root = surface.componentTree;
        assert.strictEqual(processor.getData(root, '/items/0/label', 's_json'), 'one');
        assert.strictEqual(processor.getData(root, '/items/0/toString', 's_json'), null);
        assert.strictEqual(processor.getData(root, '/items/0/__proto__', 's_json'), null);
        assert.strictEqual(processor.getData(root, '/items/0/constructor', 's_json'), null);
        assert.strictEqual(processor.getData(root, '/items/1/valueOf', 's_json'), null);
    });
});
//# sourceMappingURL=model-processor.test.js.map