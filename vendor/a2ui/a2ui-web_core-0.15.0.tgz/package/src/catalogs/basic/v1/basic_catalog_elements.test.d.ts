export {};
//# sourceMappingURL=basic_catalog_elements.test.d.ts.map