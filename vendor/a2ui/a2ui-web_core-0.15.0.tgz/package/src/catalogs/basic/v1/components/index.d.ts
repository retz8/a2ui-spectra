export declare const A2uiAudioPlayer: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    description?: any;
    weight?: number | undefined;
    url?: any;
}, {
    description?: any;
    weight?: number | undefined;
    url?: any;
}>>;
export declare const A2uiButton: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    child: import("zod").ZodString;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["default", "primary", "borderless"]>>>;
    action: import("zod").ZodUnion<[import("zod").ZodObject<{
        event: import("zod").ZodObject<{
            name: import("zod").ZodString;
            userMessage: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
                '@path': import("zod").ZodOptional<import("zod").ZodString>;
                path: import("zod").ZodOptional<import("zod").ZodString>;
            }, "strip", import("zod").ZodTypeAny, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }>, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
                '@call': import("zod").ZodOptional<import("zod").ZodString>;
                call: import("zod").ZodOptional<import("zod").ZodString>;
                catalogId: import("zod").ZodOptional<import("zod").ZodString>;
            }, "strip", import("zod").ZodTypeAny, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }>, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }>, import("zod").ZodAny>>]>>;
            context: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodNumber, import("zod").ZodBoolean, import("zod").ZodArray<import("zod").ZodAny, "many">, import("zod").ZodEffects<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>, Record<string, unknown>, Record<string, unknown>>, import("zod").ZodEffects<import("zod").ZodObject<{
                '@path': import("zod").ZodOptional<import("zod").ZodString>;
                path: import("zod").ZodOptional<import("zod").ZodString>;
            }, "strip", import("zod").ZodTypeAny, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }>, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }, {
                path?: string | undefined;
                '@path'?: string | undefined;
            }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
                '@call': import("zod").ZodOptional<import("zod").ZodString>;
                call: import("zod").ZodOptional<import("zod").ZodString>;
                catalogId: import("zod").ZodOptional<import("zod").ZodString>;
            }, "strip", import("zod").ZodTypeAny, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }>, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }, {
                call?: string | undefined;
                '@call'?: string | undefined;
                catalogId?: string | undefined;
            }>, import("zod").ZodAny>>]>>>;
        }, "strict", import("zod").ZodTypeAny, {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        }, {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        }>;
    }, "strict", import("zod").ZodTypeAny, {
        event: {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        };
    }, {
        event: {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        };
    }>, import("zod").ZodObject<{
        functionCall: import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>;
    }, "strict", import("zod").ZodTypeAny, {
        functionCall?: any;
    }, {
        functionCall?: any;
    }>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    child: string;
    action: {
        event: {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        };
    } | {
        functionCall?: any;
    };
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "default" | "primary" | "borderless" | undefined;
}, {
    child: string;
    action: {
        event: {
            name: string;
            context?: Record<string, any> | undefined;
            userMessage?: any;
        };
    } | {
        functionCall?: any;
    };
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "default" | "primary" | "borderless" | undefined;
}>>;
export declare const A2uiCard: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    child: import("zod").ZodString;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    child: string;
    weight?: number | undefined;
}, {
    child: string;
    weight?: number | undefined;
}>>;
export declare const A2uiCheckBox: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    value: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
}, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiChoicePicker: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["multipleSelection", "mutuallyExclusive"]>>>;
    options: import("zod").ZodArray<import("zod").ZodObject<{
        label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        value: import("zod").ZodString;
    }, "strip", import("zod").ZodTypeAny, {
        value: string;
        label?: any;
    }, {
        value: string;
        label?: any;
    }>, "many">;
    value: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    displayStyle: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["checkbox", "chips"]>>>;
    filterable: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    options: {
        value: string;
        label?: any;
    }[];
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    filterable?: boolean | undefined;
    variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
    displayStyle?: "checkbox" | "chips" | undefined;
}, {
    options: {
        value: string;
        label?: any;
    }[];
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    filterable?: boolean | undefined;
    variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
    displayStyle?: "checkbox" | "chips" | undefined;
}>>;
export declare const A2uiColumn: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    justify: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly", "stretch"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["center", "end", "start", "stretch"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}>>;
export declare const A2uiDateTimeInput: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    value: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    enableDate: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    enableTime: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    min: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    max: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    min?: any;
    max?: any;
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
}, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    min?: any;
    max?: any;
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
}>>;
export declare const A2uiDivider: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    axis: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["horizontal", "vertical"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    weight?: number | undefined;
    axis?: "horizontal" | "vertical" | undefined;
}, {
    weight?: number | undefined;
    axis?: "horizontal" | "vertical" | undefined;
}>>;
export declare const A2uiIcon: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    name: import("zod").ZodUnion<[import("zod").ZodEnum<["accountCircle", "add", "arrowBack", "arrowForward", "attachFile", "calendarToday", "call", "camera", "check", "close", "delete", "download", "edit", "event", "error", "fastForward", "favorite", "favoriteOff", "folder", "help", "home", "info", "locationOn", "lock", "lockOpen", "mail", "menu", "moreVert", "moreHoriz", "notificationsOff", "notifications", "pause", "payment", "person", "phone", "photo", "play", "print", "refresh", "rewind", "search", "send", "settings", "share", "shoppingCart", "skipNext", "skipPrevious", "star", "starHalf", "starOff", "stop", "upload", "visibility", "visibilityOff", "volumeDown", "volumeMute", "volumeOff", "volumeUp", "warning"]>, import("zod").ZodObject<{
        svgPath: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
    }, "strip", import("zod").ZodTypeAny, {
        svgPath?: any;
    }, {
        svgPath?: any;
    }>, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
        path?: string | undefined;
        '@path'?: string | undefined;
    } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
        svgPath?: any;
    };
    weight?: number | undefined;
}, {
    name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
        path?: string | undefined;
        '@path'?: string | undefined;
    } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
        svgPath?: any;
    };
    weight?: number | undefined;
}>>;
export declare const A2uiImage: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    fit: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["contain", "cover", "fill", "none", "scaleDown"]>>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["icon", "avatar", "smallFeature", "mediumFeature", "largeFeature", "header"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    description?: any;
    weight?: number | undefined;
    url?: any;
    fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
    variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
}, {
    description?: any;
    weight?: number | undefined;
    url?: any;
    fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
    variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
}>>;
export declare const A2uiList: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    direction: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["vertical", "horizontal"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "stretch"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    direction?: "horizontal" | "vertical" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    direction?: "horizontal" | "vertical" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}>>;
export declare const A2uiModal: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    trigger: import("zod").ZodString;
    content: import("zod").ZodString;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    trigger: string;
    content: string;
    weight?: number | undefined;
}, {
    trigger: string;
    content: string;
    weight?: number | undefined;
}>>;
export declare const A2uiRow: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    justify: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["center", "end", "spaceAround", "spaceBetween", "spaceEvenly", "start", "stretch"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "stretch"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}>>;
export declare const A2uiSlider: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    min: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodNumber>>;
    max: import("zod").ZodNumber;
    value: import("zod").ZodUnion<[import("zod").ZodNumber, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    steps: import("zod").ZodOptional<import("zod").ZodNumber>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    max: number;
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    min?: number | undefined;
    steps?: number | undefined;
}, {
    max: number;
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    min?: number | undefined;
    steps?: number | undefined;
}>>;
export declare const A2uiTabs: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    tabs: import("zod").ZodArray<import("zod").ZodObject<{
        title: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        child: import("zod").ZodString;
    }, "strip", import("zod").ZodTypeAny, {
        child: string;
        title?: any;
    }, {
        child: string;
        title?: any;
    }>, "many">;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    tabs: {
        child: string;
        title?: any;
    }[];
    weight?: number | undefined;
}, {
    tabs: {
        child: string;
        title?: any;
    }[];
    weight?: number | undefined;
}>>;
export declare const A2uiText: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    text: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["caption", "body"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    weight?: number | undefined;
    text?: any;
    variant?: "caption" | "body" | undefined;
}, {
    weight?: number | undefined;
    text?: any;
    variant?: "caption" | "body" | undefined;
}>>;
export declare const A2uiTextField: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    '@checks': import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodEffects<import("zod").ZodObject<{
            '@path': import("zod").ZodOptional<import("zod").ZodString>;
            path: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }, {
            path?: string | undefined;
            '@path'?: string | undefined;
        }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
            '@call': import("zod").ZodOptional<import("zod").ZodString>;
            call: import("zod").ZodOptional<import("zod").ZodString>;
            catalogId: import("zod").ZodOptional<import("zod").ZodString>;
        }, "strip", import("zod").ZodTypeAny, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }, {
            call?: string | undefined;
            '@call'?: string | undefined;
            catalogId?: string | undefined;
        }>, import("zod").ZodAny>>]>;
        message: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strict", import("zod").ZodTypeAny, {
        message?: string | undefined;
        condition?: any;
    }, {
        message?: string | undefined;
        condition?: any;
    }>, "many">>;
    label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    value: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    placeholder: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["longText", "number", "shortText", "obscured"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
    placeholder?: any;
}, {
    value?: any;
    label?: any;
    '@checks'?: {
        message?: string | undefined;
        condition?: any;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
    placeholder?: any;
}>>;
export declare const A2uiVideo: import("../../../../universal/web_component_implementation.js").WebComponentImplementation<import("zod").ZodObject<{
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>;
    posterUrl: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodEffects<import("zod").ZodObject<{
        '@path': import("zod").ZodOptional<import("zod").ZodString>;
        path: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }, {
        path?: string | undefined;
        '@path'?: string | undefined;
    }>, import("zod").ZodIntersection<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>, import("zod").ZodIntersection<import("zod").ZodEffects<import("zod").ZodObject<{
        '@call': import("zod").ZodOptional<import("zod").ZodString>;
        call: import("zod").ZodOptional<import("zod").ZodString>;
        catalogId: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }, {
        call?: string | undefined;
        '@call'?: string | undefined;
        catalogId?: string | undefined;
    }>, import("zod").ZodAny>>]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    weight?: number | undefined;
    url?: any;
    posterUrl?: any;
}, {
    weight?: number | undefined;
    url?: any;
    posterUrl?: any;
}>>;
export { BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, WeightSchema, } from './basic_components.js';
//# sourceMappingURL=index.d.ts.map