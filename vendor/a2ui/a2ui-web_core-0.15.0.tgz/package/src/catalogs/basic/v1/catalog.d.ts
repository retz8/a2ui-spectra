import { Catalog } from '../../../catalog/types.js';
import type { WebComponentImplementation } from '../../../universal/index.js';
/**
 * The v1 basic catalog of A2UI components implemented via Web Components
 * (Custom Elements).
 *
 * Its components and functions are the models generated from the published
 * catalog document (see scripts/generate-catalog-schemas.mjs), listed in the
 * document's order, and its document-level fields are those the generated
 * models carry, so `toJson` computes the published document from the models
 * and `validationSchema` is built from it.
 */
export declare const basicCatalog: Catalog<WebComponentImplementation<import("zod").ZodTypeAny>, import("../../../index.js").FunctionImplementation>;
//# sourceMappingURL=catalog.d.ts.map