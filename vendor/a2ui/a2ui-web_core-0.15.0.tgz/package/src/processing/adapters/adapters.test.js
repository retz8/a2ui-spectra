/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it } from 'node:test';
import { z } from 'zod';
import { Catalog } from '../../catalog/types.js';
import { A2uiValidationError } from '../../errors.js';
import { MessageProcessor } from '../message-processor.js';
import { DEFAULT_CATALOG_COMPATIBILITY, isCatalogVersionCompatible, SUPPORTED_PROTOCOL_VERSIONS, } from './base.js';
import { VersionAdapterFactory } from './factory.js';
import { V0Point8Adapter } from './v0_8.js';
import { V0Point9Adapter } from './v0_9.js';
import { V1Point0Adapter } from './v1_0.js';
describe('VersionAdapterFactory', () => {
    it('resolves v1.0 adapter and extracts operations with initial state and surface properties', () => {
        const payload = {
            version: '1.0',
            createSurface: {
                surfaceId: 's1',
                catalogId: 'basic',
                sendDataModel: true,
                components: [{ id: 'root', component: 'Column' }],
                dataModel: {
                    key: 'value',
                },
            },
        };
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, '1.0');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 1);
        const op = ops[0];
        assert.strictEqual(op.type, 'createSurface');
        assert.strictEqual(op.surfaceId, 's1');
        assert.strictEqual(op.theme, undefined);
        assert.strictEqual(op.sendDataModel, true);
        assert.deepStrictEqual(op.components, [{ id: 'root', component: 'Column' }]);
        assert.deepStrictEqual(op.dataModel, { key: 'value' });
    });
    it('drops theme on v1.0 createSurface in permissive mode and rejects it in strict mode', () => {
        const adapter = new V1Point0Adapter();
        const payloadWithTheme = {
            version: '1.0',
            createSurface: {
                surfaceId: 's1',
                catalogId: 'basic',
                theme: { primaryColor: '#FF0000' },
            },
        };
        const defaultOps = adapter.extractOperations(payloadWithTheme);
        assert.strictEqual(defaultOps.length, 1);
        const defaultOp = defaultOps[0];
        assert.strictEqual(defaultOp.type, 'createSurface');
        assert.strictEqual(defaultOp.surfaceId, 's1');
        assert.strictEqual(defaultOp.theme, undefined);
        const permissiveOps = adapter.extractOperations(payloadWithTheme, {
            allowUnknownElements: true,
        });
        assert.strictEqual(permissiveOps.length, 1);
        assert.strictEqual(permissiveOps[0].theme, undefined);
        assert.throws(() => adapter.extractOperations(payloadWithTheme, { allowUnknownElements: false }), (err) => err instanceof A2uiValidationError && /theme/.test(err.message));
        assert.throws(() => adapter.extractOperations(payloadWithTheme, {}), (err) => err instanceof A2uiValidationError && /theme/.test(err.message));
    });
    it('rejects array v1.0 createSurface payloads cleanly without mutating array values', () => {
        const adapter = new V1Point0Adapter();
        assert.throws(() => adapter.extractOperations({ version: '1.0', createSurface: [] }, { allowUnknownElements: true }), (err) => err instanceof A2uiValidationError);
    });
    it('drops v1.0 createSurface.theme in default MessageProcessor and rejects it in strict validationConfig', () => {
        const catalog = new Catalog('basic', '1.0', [], []);
        const payloadWithTheme = {
            version: '1.0',
            createSurface: {
                surfaceId: 's1',
                catalogId: 'basic',
                theme: { primaryColor: '#FF0000' },
            },
        };
        const permissiveProcessor = new MessageProcessor([catalog]);
        permissiveProcessor.processMessages(payloadWithTheme);
        const surface = permissiveProcessor.getSurface('s1');
        assert.ok(surface);
        assert.deepStrictEqual(surface.theme, {});
        const strictProcessor = new MessageProcessor([catalog], undefined, {
            validationConfig: { allowUnknownElements: false },
        });
        assert.throws(() => strictProcessor.processMessages(payloadWithTheme), (err) => err instanceof A2uiValidationError && /theme/.test(err.message));
    });
    it('resolves v0.9 adapter and extracts createSurface operations', () => {
        const payload = {
            version: 'v0.9',
            createSurface: {
                surfaceId: 's1',
                catalogId: 'basic',
                theme: { primaryColor: '#FF0000' },
            },
        };
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, 'v0.9');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 1);
        const op = ops[0];
        assert.strictEqual(op.surfaceId, 's1');
        assert.deepStrictEqual(op.theme, { primaryColor: '#FF0000' });
    });
    it('resolves v0.8 adapter and normalizes beginRendering into createSurface operation', () => {
        const payload = {
            version: 'v0.8',
            beginRendering: {
                surfaceId: 's1',
                root: 'root',
                styles: { primaryColor: '#FF0000' },
            },
        };
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, 'v0.8');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 1);
        const op = ops[0];
        assert.strictEqual(op.type, 'createSurface');
        assert.strictEqual(op.surfaceId, 's1');
        assert.deepStrictEqual(op.theme, { primaryColor: '#FF0000' });
    });
    it('resolves unversioned deleteSurface to v0.8 adapter', () => {
        const payload = {
            deleteSurface: {
                surfaceId: 's1',
            },
        };
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, 'v0.8');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 1);
        assert.strictEqual(ops[0].type, 'deleteSurface');
        assert.strictEqual(ops[0].surfaceId, 's1');
    });
    it('extracts surfaceUpdate and dataModelUpdate operations in v0.8 adapter', () => {
        const adapter = VersionAdapterFactory.getAdapter('v0.8');
        const surfaceOps = adapter.extractOperations({
            surfaceUpdate: {
                surfaceId: 's1',
                components: [{ id: 'txt1', component: { Text: { text: { literalString: 'Click' } } } }],
            },
        });
        assert.strictEqual(surfaceOps.length, 1);
        assert.strictEqual(surfaceOps[0].type, 'updateComponents');
        assert.strictEqual(surfaceOps[0].surfaceId, 's1');
        const dataOps = adapter.extractOperations({
            dataModelUpdate: {
                surfaceId: 's1',
                path: '/count',
                contents: [{ key: 'count', valueNumber: 42 }],
            },
        });
        assert.strictEqual(dataOps.length, 1);
        assert.strictEqual(dataOps[0].type, 'updateDataModel');
        assert.strictEqual(dataOps[0].surfaceId, 's1');
    });
    it('throws A2uiValidationError in v0.8 and v0.9 adapters when payload contains no update action', () => {
        const v08Adapter = VersionAdapterFactory.getAdapter('v0.8');
        const v09Adapter = VersionAdapterFactory.getAdapter('v0.9');
        assert.throws(() => v08Adapter.extractOperations({}), err => err instanceof A2uiValidationError && /Invalid v0.8 message/.test(err.message));
        assert.throws(() => v09Adapter.extractOperations({}), err => err instanceof A2uiValidationError && /Invalid v0.9 message/.test(err.message));
    });
    it('throws A2uiValidationError in adapters when payload version is invalid', () => {
        const v09Adapter = VersionAdapterFactory.getAdapter('v0.9');
        assert.throws(() => v09Adapter.extractOperations({
            version: '1.0',
            createSurface: { surfaceId: 's1', catalogId: 'c1' },
        }), err => err instanceof A2uiValidationError && /Invalid v0.9 message/.test(err.message));
        const v10Adapter = VersionAdapterFactory.getAdapter('v1.0');
        assert.throws(() => v10Adapter.extractOperations({
            version: 'v0.9',
            createSurface: { surfaceId: 's1', catalogId: 'c1' },
        }), err => err instanceof A2uiValidationError && /Invalid 1.0 message/.test(err.message));
    });
    it('supports dynamic registration of custom version adapters', () => {
        const customAdapter = {
            version: 'v2.0',
            extractOperations: () => [
                {
                    type: 'createSurface',
                    surfaceId: 's_custom',
                    catalogId: 'custom',
                },
            ],
        };
        VersionAdapterFactory.registerAdapter(customAdapter);
        const resolved = VersionAdapterFactory.getAdapter('v2.0');
        assert.strictEqual(resolved.version, 'v2.0');
        // Verify format-tolerant retrieval of dynamically registered adapters
        assert.strictEqual(VersionAdapterFactory.getAdapter('2.0').version, 'v2.0');
        assert.strictEqual(VersionAdapterFactory.getAdapter('2.0.0').version, 'v2.0');
        assert.strictEqual(VersionAdapterFactory.getAdapter('v2.0.0').version, 'v2.0');
        assert.strictEqual(VersionAdapterFactory.getAdapter('V2.0').version, 'v2.0');
        const ops = resolved.extractOperations({});
        assert.strictEqual(ops.length, 1);
        assert.strictEqual(ops[0].type, 'createSurface');
        assert.strictEqual(ops[0].surfaceId, 's_custom');
    });
    it('throws an A2uiValidationError for unrecognized or missing version strings', () => {
        assert.throws(() => VersionAdapterFactory.getAdapter('v99.0'), err => err instanceof A2uiValidationError &&
            /Unsupported protocol version 'v99\.0'/.test(err.message) &&
            /Supported versions: .*v2\.0/.test(err.message));
        assert.throws(() => VersionAdapterFactory.resolveFromPayload({}), err => err instanceof A2uiValidationError && /missing a valid 'version' string/.test(err.message));
        assert.throws(() => VersionAdapterFactory.resolveFromPayload({ version: 123 }), err => err instanceof A2uiValidationError &&
            /'version' property must be a string, got number/.test(err.message));
    });
    it('resolves v0.9.1 version string to v0.9 adapter', () => {
        const adapter = VersionAdapterFactory.getAdapter('v0.9.1');
        assert.strictEqual(adapter.version, 'v0.9');
        const fromPayload = VersionAdapterFactory.resolveFromPayload({ version: 'v0.9.1' });
        assert.strictEqual(fromPayload.version, 'v0.9');
    });
    it('resolves adapter and extracts operations from batch array payloads', () => {
        const payload = [
            { version: '1.0', createSurface: { surfaceId: 's1', catalogId: 'basic' } },
            { version: '1.0', deleteSurface: { surfaceId: 's1' } },
        ];
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, '1.0');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 2);
        assert.strictEqual(ops[0].type, 'createSurface');
        assert.strictEqual(ops[1].type, 'deleteSurface');
    });
    it('resolves adapter and extracts operations from wrapped { messages: [...] } payload', () => {
        const payload = {
            messages: [
                { version: '1.0', createSurface: { surfaceId: 's1' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's1',
                        components: [{ id: 'root', component: 'Column' }],
                    },
                },
            ],
        };
        const adapter = VersionAdapterFactory.resolveFromPayload(payload);
        assert.strictEqual(adapter.version, '1.0');
        const ops = adapter.extractOperations(payload);
        assert.strictEqual(ops.length, 2);
        assert.strictEqual(ops[0].type, 'createSurface');
        assert.strictEqual(ops[1].type, 'updateComponents');
    });
    it('extracts updateComponents, updateDataModel, and deleteSurface operations', () => {
        const adapter = VersionAdapterFactory.getAdapter('v1.0');
        const ucOps = adapter.extractOperations({
            version: '1.0',
            updateComponents: {
                surfaceId: 's1',
                components: [{ id: 'c1', component: 'Text', text: 'Hi' }],
            },
        });
        assert.strictEqual(ucOps.length, 1);
        const ucOp = ucOps[0];
        assert.strictEqual(ucOp.type, 'updateComponents');
        assert.strictEqual(ucOp.surfaceId, 's1');
        assert.deepStrictEqual(ucOp.components, [{ id: 'c1', component: 'Text', text: 'Hi' }]);
        const udOps = adapter.extractOperations({
            version: '1.0',
            updateDataModel: {
                surfaceId: 's1',
                path: '/user/name',
                value: 'Alice',
            },
        });
        assert.strictEqual(udOps.length, 1);
        const udOp = udOps[0];
        assert.strictEqual(udOp.type, 'updateDataModel');
        assert.strictEqual(udOp.surfaceId, 's1');
        assert.strictEqual(udOp.path, '/user/name');
        assert.strictEqual(udOp.value, 'Alice');
        const dsOps = adapter.extractOperations({
            version: '1.0',
            deleteSurface: {
                surfaceId: 's1',
            },
        });
        assert.strictEqual(dsOps.length, 1);
        const dsOp = dsOps[0];
        assert.strictEqual(dsOp.type, 'deleteSurface');
        assert.strictEqual(dsOp.surfaceId, 's1');
    });
    it('throws A2uiValidationError for null, undefined, primitive, or non-object payloads in resolveFromPayload', () => {
        const invalidPayloads = [null, undefined, 42, 'v1.0', [], { version: 123 }, { version: null }];
        for (const invalid of invalidPayloads) {
            assert.throws(() => VersionAdapterFactory.resolveFromPayload(invalid), err => err instanceof A2uiValidationError &&
                /missing a valid 'version' string/.test(err.message));
        }
    });
    it('returns empty array when extractOperations is called with non-object/null values', () => {
        const adapter = VersionAdapterFactory.getAdapter('v1.0');
        assert.deepStrictEqual(adapter.extractOperations(null), []);
        assert.deepStrictEqual(adapter.extractOperations(undefined), []);
        assert.deepStrictEqual(adapter.extractOperations('not-an-object'), []);
        assert.deepStrictEqual(adapter.extractOperations(123), []);
    });
});
describe('MessageProcessor Dependency Injection', () => {
    it('uses custom injected adapterRegistry when provided in MessageProcessorOptions', () => {
        let customRegistryInvoked = false;
        const customRegistry = {
            getAdapter: () => ({
                version: 'vCustom',
                extractOperations: () => [
                    {
                        type: 'createSurface',
                        surfaceId: 'injected_surface',
                        catalogId: 'basic',
                    },
                ],
            }),
            resolveFromPayload: () => {
                customRegistryInvoked = true;
                return {
                    version: 'vCustom',
                    extractOperations: () => [
                        {
                            type: 'createSurface',
                            surfaceId: 'injected_surface',
                            catalogId: 'basic',
                        },
                    ],
                };
            },
        };
        const processor = new MessageProcessor([new Catalog('basic', '0.9', [])], undefined, {
            adapterRegistry: customRegistry,
        });
        processor.processMessages({ version: 'vCustom' });
        assert.strictEqual(customRegistryInvoked, true);
        assert.notStrictEqual(processor.getSurface('injected_surface'), undefined);
    });
    it('merges existing properties on partial updateComponents operations', () => {
        const textApi = {
            name: 'Text',
            schema: z.object({
                text: z.string(),
                color: z.string().optional(),
            }),
        };
        const catalog = new Catalog('basic', '1.0', [textApi]);
        const processor = new MessageProcessor([catalog]);
        processor.processMessages({
            version: '1.0',
            createSurface: {
                surfaceId: 's1',
                catalogId: 'basic',
                components: [{ id: 't1', component: 'Text', text: 'Hello', color: 'red' }],
            },
        });
        processor.processMessages({
            version: '1.0',
            updateComponents: {
                surfaceId: 's1',
                components: [{ id: 't1', component: 'Text', text: 'Hello', color: 'blue' }],
            },
        });
        const surface = processor.getSurface('s1');
        const comp = surface?.componentsModel.get('t1');
        assert.strictEqual(comp?.properties.text, 'Hello');
        assert.strictEqual(comp?.properties.color, 'blue');
    });
    it('validates SUPPORTED_PROTOCOL_VERSIONS and DEFAULT_CATALOG_COMPATIBILITY', () => {
        assert.ok(SUPPORTED_PROTOCOL_VERSIONS.has('1.0'));
        assert.ok(SUPPORTED_PROTOCOL_VERSIONS.has('0.9.1'));
        assert.ok(SUPPORTED_PROTOCOL_VERSIONS.has('0.9'));
        assert.ok(SUPPORTED_PROTOCOL_VERSIONS.has('0.8'));
        assert.strictEqual(SUPPORTED_PROTOCOL_VERSIONS.has('1.1'), false);
        assert.ok(DEFAULT_CATALOG_COMPATIBILITY['0.9.1']?.has('0.9'));
    });
    it('evaluates isCatalogVersionCompatible correctly with supported sets', () => {
        // Exact canonical matches across formatting variations
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('V1.0', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'V1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('1.0', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0.0', '1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1_0', '1.0.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.9', 'v0.9'), true);
        assert.strictEqual(isCatalogVersionCompatible('V0.9', '0.9'), true);
        assert.strictEqual(isCatalogVersionCompatible('0.9', 'V0.9'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0_9', '0.9'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.9.1', '0.9.1'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0_9_1', '0.9.1'), true);
        // Backward compatibility between 0.9 and 0.9.1
        assert.strictEqual(isCatalogVersionCompatible('v0.9', 'v0.9.1'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.9.1', 'v0.9'), true);
        // Unsupported future or cross-major versions are rejected
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v1.1'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.1', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v2.0'), false);
        assert.strictEqual(isCatalogVersionCompatible('v0.9', 'v1.0'), false);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v0.9'), false);
        // Custom compatibility map override
        const customMap = {
            '1.1': new Set(['1.0', '1.1']),
        };
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v1.1', customMap), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.9', 'v1.1', customMap), false);
        // Custom non-semver fallback
        assert.strictEqual(isCatalogVersionCompatible('Vcustom', 'vcustom'), true);
        assert.strictEqual(isCatalogVersionCompatible('custom', 'Vcustom'), true);
        assert.strictEqual(isCatalogVersionCompatible('custom', 'other'), false);
        // v0.8 matches
        assert.strictEqual(isCatalogVersionCompatible('v0.8', 'v0.8'), true);
        assert.strictEqual(isCatalogVersionCompatible('0.8', 'v0.8'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.8', '0.8.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v0.8', 'v0.9'), false);
        // SemVer object inputs
        const v10Obj = { major: 1, minor: 0, patch: 0, prerelease: [], build: [] };
        const v09Obj = { major: 0, minor: 9, patch: 0, prerelease: [], build: [] };
        const v091Obj = { major: 0, minor: 9, patch: 1, prerelease: [], build: [] };
        assert.strictEqual(isCatalogVersionCompatible(v10Obj, '1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('1.0', v10Obj), true);
        assert.strictEqual(isCatalogVersionCompatible(v09Obj, v091Obj), true);
        // Patch and pre-release version compatibility for SemVer >= 1.0.0
        assert.strictEqual(isCatalogVersionCompatible('v1.0.1', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', 'v1.0.1'), true);
        assert.strictEqual(isCatalogVersionCompatible('1.0.2', '1.0.1'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0.1-alpha', 'v1.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0.0-beta.1', 'v1.0.0-rc.2'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.2.0-beta', 'v1.0.0'), true);
        assert.strictEqual(isCatalogVersionCompatible('v1.0.0-alpha', 'v2.0.0-alpha'), false);
        assert.strictEqual(isCatalogVersionCompatible('v1.1.0', 'v1.0.0'), true);
        // Falsy / invalid inputs
        assert.strictEqual(isCatalogVersionCompatible(undefined, 'v1.0'), false);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', undefined), false);
        assert.strictEqual(isCatalogVersionCompatible(null, 'v1.0'), false);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', null), false);
        assert.strictEqual(isCatalogVersionCompatible(null, null), false);
        assert.strictEqual(isCatalogVersionCompatible('', ''), false);
        assert.strictEqual(isCatalogVersionCompatible('', 'v1.0'), false);
        assert.strictEqual(isCatalogVersionCompatible('v1.0', ''), false);
        assert.strictEqual(isCatalogVersionCompatible(null, 'None'), false);
        assert.strictEqual(isCatalogVersionCompatible('None', null), false);
        assert.strictEqual(isCatalogVersionCompatible({}, {}), false);
        assert.strictEqual(isCatalogVersionCompatible([], []), false);
    });
    it('evaluates compatibleCatalogVersions and isCatalogCompatible on adapter instances', () => {
        const v08 = new V0Point8Adapter();
        assert.ok(v08.compatibleCatalogVersions.has('0.8'));
        assert.strictEqual(v08.isCatalogCompatible('v0.8'), true);
        assert.strictEqual(v08.isCatalogCompatible('0.8'), true);
        assert.strictEqual(v08.isCatalogCompatible('v0.9'), false);
        const v09 = new V0Point9Adapter();
        assert.ok(v09.compatibleCatalogVersions.has('0.9'));
        assert.ok(v09.compatibleCatalogVersions.has('0.9.1'));
        assert.strictEqual(v09.isCatalogCompatible('v0.9'), true);
        assert.strictEqual(v09.isCatalogCompatible('v0.9.1'), true);
        assert.strictEqual(v09.isCatalogCompatible('0.9'), true);
        assert.strictEqual(v09.isCatalogCompatible('0.9.1'), true);
        assert.strictEqual(v09.isCatalogCompatible('v1.0'), false);
        const v10 = new V1Point0Adapter();
        assert.ok(v10.compatibleCatalogVersions.has('1.0'));
        assert.strictEqual(v10.isCatalogCompatible('v1.0'), true);
        assert.strictEqual(v10.isCatalogCompatible('1.0.0'), true);
        assert.strictEqual(v10.isCatalogCompatible('v1_0'), true);
        assert.strictEqual(v10.isCatalogCompatible('v0.9'), false);
        assert.strictEqual(v10.isCatalogCompatible('v1.1'), true);
        assert.strictEqual(v10.isCatalogCompatible('v2.0'), false);
        assert.strictEqual(v10.isCatalogCompatible(undefined), false);
    });
    it('resolves adapters by canonical and formatted version strings', () => {
        const factory = new VersionAdapterFactory();
        assert.strictEqual(factory.getAdapter('v1.0').version, '1.0');
        assert.strictEqual(factory.getAdapter('1.0').version, '1.0');
        assert.strictEqual(factory.getAdapter('1.0.0').version, '1.0');
        assert.strictEqual(factory.getAdapter('v1_0').version, '1.0');
        assert.strictEqual(factory.getAdapter('V1.0').version, '1.0');
        assert.strictEqual(factory.getAdapter('v0.9.1').version, 'v0.9');
        assert.strictEqual(factory.getAdapter('0.9.1').version, 'v0.9');
        assert.strictEqual(factory.getAdapter('v0.9').version, 'v0.9');
        assert.strictEqual(factory.getAdapter('0.9').version, 'v0.9');
        assert.strictEqual(factory.getAdapter('v0.8').version, 'v0.8');
        assert.strictEqual(factory.getAdapter('0.8').version, 'v0.8');
        assert.throws(() => factory.getAdapter('v1.1'), (err) => err instanceof A2uiValidationError && err.message.includes('Unsupported protocol version'));
    });
    it('aggregates all known actions across registered adapters', () => {
        const factory = new VersionAdapterFactory();
        const actions = factory.getAllKnownActions();
        assert.ok(actions instanceof Set);
        assert.strictEqual(actions.has('beginRendering'), true);
        assert.strictEqual(actions.has('surfaceUpdate'), true);
        assert.strictEqual(actions.has('dataModelUpdate'), true);
        assert.strictEqual(actions.has('createSurface'), true);
        assert.strictEqual(actions.has('updateComponents'), true);
        assert.strictEqual(actions.has('updateDataModel'), true);
        assert.strictEqual(actions.has('deleteSurface'), true);
        const staticActions = VersionAdapterFactory.getAllKnownActions();
        assert.strictEqual(staticActions.has('createSurface'), true);
        assert.strictEqual(staticActions.has('beginRendering'), true);
    });
    it('rejects cross-version actions with A2uiValidationError', () => {
        const v09 = VersionAdapterFactory.getAdapter('v0.9');
        assert.throws(() => v09.extractOperations({
            version: 'v0.9',
            beginRendering: { surfaceId: 's1' },
        }), (err) => err instanceof A2uiValidationError &&
            /action 'beginRendering' is not supported in protocol version v0.9/.test(err.message));
        const v10 = VersionAdapterFactory.getAdapter('v1.0');
        assert.throws(() => v10.extractOperations({
            version: '1.0',
            beginRendering: { surfaceId: 's1' },
        }), (err) => err instanceof A2uiValidationError &&
            /action 'beginRendering' is not supported in protocol version 1.0/.test(err.message));
        const v08 = VersionAdapterFactory.getAdapter('v0.8');
        assert.throws(() => v08.extractOperations({
            createSurface: { surfaceId: 's1' },
        }), (err) => err instanceof A2uiValidationError &&
            /action 'createSurface' is not supported in protocol version v0.8/.test(err.message));
        // Completely unknown action
        assert.throws(() => v09.extractOperations({
            version: 'v0.9',
            completelyUnknownAction: { surfaceId: 's1' },
        }), (err) => err instanceof A2uiValidationError &&
            /message must contain exactly one update action/.test(err.message));
    });
    it('scopes union validation errors to the active action branch without dumping unrelated branches', () => {
        const v10 = VersionAdapterFactory.getAdapter('v1.0');
        assert.throws(() => v10.extractOperations({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'f1',
                callFunction: { '@call': 'formatString', args: { value: 'x' } },
            },
        }), (err) => {
            assert.ok(err instanceof A2uiValidationError);
            assert.strictEqual(err.message, 'Invalid 1.0 message: callRendererFunction.callFunction.catalogId: Expected string, received undefined');
            assert.strictEqual(err.functionCallId, 'f1');
            return true;
        });
        assert.throws(() => v10.extractOperations({
            version: 'v1.0',
            callRendererFunction: {
                functionCallId: 'f1',
                callFunction: { '@call': 'formatString', args: { value: 'x' } },
            },
        }), (err) => {
            assert.ok(err instanceof A2uiValidationError);
            assert.strictEqual(err.message, 'Invalid 1.0 message: version: Invalid literal value, expected "1.0"; callRendererFunction.callFunction.catalogId: Expected string, received undefined');
            return true;
        });
        assert.throws(() => v10.extractOperations({
            version: '1.0',
            callRendererFunction: {
                functionCallId: 'f1',
                callFunction: { '@call': 'formatString', catalogId: 'cat-1', args: { value: 'x' } },
            },
            extraField: true,
        }), (err) => {
            assert.ok(err instanceof A2uiValidationError);
            assert.strictEqual(err.message, "Invalid 1.0 message: root: Unrecognized key(s) in object: 'extraField'");
            return true;
        });
        const v09 = VersionAdapterFactory.getAdapter('v0.9');
        assert.throws(() => v09.extractOperations({
            version: 'v0.9',
            createSurface: { surfaceId: 's1' },
        }), (err) => {
            assert.ok(err instanceof A2uiValidationError);
            assert.strictEqual(err.message, 'Invalid v0.9 message: createSurface.catalogId: Expected string, received undefined');
            return true;
        });
    });
});
//# sourceMappingURL=adapters.test.js.map