export {};
//# sourceMappingURL=outbound-envelope.test.d.ts.map