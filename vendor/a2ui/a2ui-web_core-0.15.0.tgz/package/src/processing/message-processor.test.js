/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it, beforeEach } from 'node:test';
import { MessageProcessor, formatZodIssue, STRICT_VALIDATION, RpcErrorCode, } from './message-processor.js';
import { extractEnvelopeErrorContext, mapErrorToRendererMessage, } from './message-error-mapper.js';
import { Catalog, createFunctionImplementation } from '../catalog/types.js';
import { CardApi, RowApi, TabsApi } from '../v0_9/basic_catalog/components/basic_components.js';
import { BasicCatalogThemeSchema } from '../universal/basic_catalog/theme.js';
import { BASIC_COMPONENTS } from '../catalogs/basic/v1/components/basic_components.js';
import { BASIC_FUNCTIONS } from '../catalogs/basic/v1/functions/basic_functions.js';
import { A2uiCatalogError, A2uiIntegrityError, A2uiValidationError } from '../errors.js';
import { DataContext } from '../resolution/data-context.js';
import { NodeResolver } from '../resolution/node-resolver.js';
import { ResolvedBinding } from '../resolution/resolved-binding.js';
import { SurfaceModel } from '../state/surface-model.js';
import { validateCompositionConstraints } from '../state/validation-helpers.js';
import { peekValue } from '../reactivity/signals.js';
import { z } from 'zod';
/**
 * Turns validation on while relaxing every topology rule, so a test exercises
 * only the check it is about.
 */
const THEME_ONLY_VALIDATION = {
    allowOrphanComponents: true,
    allowDanglingReferences: true,
    allowMissingRoot: true,
    allowUnknownElements: true,
};
/**
 * Asserts the constraints `specification/v1_0/json/catalog_definition.json`
 * places on an inline catalog. web_core has no JSON Schema validator
 * dependency, so the schema's rules are checked structurally.
 */
function assertConformsToV10CatalogDefinition(doc) {
    const allowedKeys = [
        '$schema',
        '$id',
        'protocolVersion',
        '$defs',
        'title',
        'description',
        'catalogId',
        'metadata',
        'instructions',
        'components',
        'functions',
    ];
    for (const key of Object.keys(doc)) {
        assert.ok(allowedKeys.includes(key), `Unexpected top-level key '${key}'`);
    }
    assert.strictEqual(typeof doc.catalogId, 'string');
    if (doc.protocolVersion !== undefined) {
        assert.match(doc.protocolVersion, /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(\.(0|[1-9][0-9]*))?$/);
    }
    assert.ok('anyComponent' in (doc.$defs ?? {}), 'Expected $defs.anyComponent');
    assert.ok('anyFunction' in (doc.$defs ?? {}), 'Expected $defs.anyFunction');
    assert.ok(!('Surface' in (doc.components ?? {})), "'Surface' is not a valid component name");
    const returnTypes = [
        'string',
        'number',
        'boolean',
        'array',
        'object',
        'validationResult',
        'any',
        'void',
    ];
    const functionKeys = [
        'type',
        'description',
        'properties',
        'required',
        'returnType',
        'allowedCallers',
        'requiresUserActivation',
    ];
    for (const [name, fn] of Object.entries(doc.functions ?? {})) {
        for (const key of Object.keys(fn)) {
            assert.ok(functionKeys.includes(key), `Function '${name}' has unexpected key '${key}'`);
        }
        assert.strictEqual(fn.type, 'object');
        assert.ok(returnTypes.includes(fn.returnType), `Function '${name}' has no valid returnType`);
        assert.strictEqual(typeof fn.properties['@call'].const, 'string');
        for (const key of Object.keys(fn.properties)) {
            assert.ok(['@call', 'args'].includes(key), `Function '${name}' has property '${key}'`);
        }
        assert.ok(fn.required.includes('@call'));
    }
}
describe('MessageProcessor', () => {
    let processor;
    let testCatalog;
    let actions = [];
    beforeEach(() => {
        actions = [];
        testCatalog = new Catalog('test-catalog', '0.9', []);
        processor = new MessageProcessor([testCatalog], async (a) => {
            actions.push(a);
        });
    });
    describe('getRendererCapabilities', () => {
        it('throws when no protocol versions are provided', () => {
            assert.throws(() => processor.getRendererCapabilities(), /At least one protocol version must be provided/);
            assert.throws(() => processor.getRendererCapabilities({}), /At least one protocol version must be provided/);
        });
        it('supports custom componentEnvelopeRef for inline catalogs', () => {
            const strictComp = {
                name: 'CustomButton',
                schema: z.object({ label: z.string() }),
            };
            const proc = new MessageProcessor([new Catalog('cat-custom', '1.0', [strictComp])]);
            const caps = proc.getRendererCapabilities({
                versions: ['v0.9'],
                includeInlineCatalogs: true,
                componentEnvelopeRef: 'https://example.com/schema.json#/$defs/Base',
            });
            const inlineCat = caps['v0.9'].inlineCatalogs?.[0];
            assert.strictEqual(inlineCat.components.CustomButton.allOf[0].$ref, 'https://example.com/schema.json#/$defs/Base');
        });
        it('keeps $ref on basic catalog child references despite per-usage descriptions', () => {
            const cat = new Catalog('cat-basic', '1.0', [CardApi, RowApi, TabsApi]);
            const proc = new MessageProcessor([cat]);
            const caps = proc.getRendererCapabilities({
                versions: ['v0.9'],
                includeInlineCatalogs: true,
            });
            const inlineCat = caps['v0.9'].inlineCatalogs?.[0];
            const components = inlineCat?.components;
            assert.ok(components);
            const cardChild = components.Card.allOf[1].properties.child;
            assert.strictEqual(cardChild.$ref, '#/$defs/ComponentId');
            assert.strictEqual(cardChild.type, undefined);
            const rowChildren = components.Row.allOf[1].properties.children;
            assert.strictEqual(rowChildren.$ref, '#/$defs/ChildList');
            const tabItems = components.Tabs.allOf[1].properties.tabs.items;
            assert.strictEqual(tabItems.properties.child.$ref, '#/$defs/ComponentId');
        });
        it('sends each catalog toJson() document as a v1.0 inline catalog', () => {
            const cat = new Catalog('https://example.com/cat', '1.0', BASIC_COMPONENTS, BASIC_FUNCTIONS, {
                themeSchema: BasicCatalogThemeSchema,
            });
            const proc = new MessageProcessor([cat]);
            const caps = proc.getRendererCapabilities({ versions: ['1.0'], includeInlineCatalogs: true });
            const inlineCat = caps['1.0'].inlineCatalogs?.[0];
            assertConformsToV10CatalogDefinition(inlineCat);
            assert.deepStrictEqual(Object.keys(inlineCat.$defs).sort(), [
                'Weight',
                'anyComponent',
                'anyFunction',
            ]);
            assert.strictEqual(inlineCat.protocolVersion, '1.0');
            assert.strictEqual(inlineCat.theme, undefined);
            assert.strictEqual(inlineCat.components.Text.properties.text.$ref, 'common_types.json#/$defs/DynamicString');
            assert.deepStrictEqual(inlineCat, cat.toJson());
        });
        it('sends a loaded v1.0 catalog as the document it was loaded from', () => {
            const document = {
                $schema: 'https://json-schema.org/draft/2020-12/schema',
                protocolVersion: '1.0',
                catalogId: 'https://example.com/loaded',
                components: {
                    Label: {
                        type: 'object',
                        allOf: [
                            { $ref: 'common_types.json#/$defs/Checkable' },
                            {
                                type: 'object',
                                properties: {
                                    component: { const: 'Label' },
                                    text: { $ref: 'common_types.json#/$defs/DynamicString' },
                                },
                                required: ['component', 'text'],
                            },
                        ],
                        unevaluatedProperties: false,
                    },
                },
                $defs: {
                    anyComponent: {
                        oneOf: [{ $ref: '#/components/Label' }],
                        discriminator: { propertyName: 'component' },
                    },
                    anyFunction: { oneOf: [{ $ref: '#/functions/noop' }] },
                },
                functions: {
                    noop: {
                        type: 'object',
                        returnType: 'void',
                        properties: { '@call': { const: 'noop' }, args: { type: 'object', properties: {} } },
                        required: ['@call', 'args'],
                    },
                },
            };
            const proc = new MessageProcessor([Catalog.fromJson(document)]);
            const caps = proc.getRendererCapabilities({ versions: ['1.0'], includeInlineCatalogs: true });
            const inlineCat = caps['1.0'].inlineCatalogs?.[0];
            assert.deepStrictEqual(inlineCat, document);
            assertConformsToV10CatalogDefinition(inlineCat);
        });
        const unionsOnly = {
            anyComponent: {
                oneOf: [{ $ref: '#/components/Label' }],
                discriminator: { propertyName: 'component' },
            },
            anyFunction: { not: {} },
        };
        const label = {
            type: 'object',
            properties: { component: { const: 'Label' } },
            required: ['component'],
        };
        function inlineV10Catalog(catalog) {
            const proc = new MessageProcessor([catalog]);
            const caps = proc.getRendererCapabilities({ versions: ['1.0'], includeInlineCatalogs: true });
            return caps['1.0'].inlineCatalogs[0];
        }
        it('gives a v1.0 inline catalog the catalogId and bare protocolVersion of a $id-only document', () => {
            const document = {
                $id: 'https://example.com/by-id.json',
                protocolVersion: '1.0',
                components: { Label: label },
                $defs: unionsOnly,
            };
            const inlineCat = inlineV10Catalog(Catalog.fromJson(document));
            assert.strictEqual(inlineCat.catalogId, 'https://example.com/by-id.json');
            assert.strictEqual(inlineCat.protocolVersion, '1.0');
            assertConformsToV10CatalogDefinition(inlineCat);
        });
        it('gives a v1.0 inline catalog the catalogId a catalog was loaded with', () => {
            for (const document of [
                { catalogId: 'https://example.com/original', components: { Label: label }, $defs: unionsOnly },
                { components: { Label: label }, $defs: unionsOnly },
            ]) {
                const catalog = Catalog.fromJson(document, '1.0', 'https://example.com/override');
                const inlineCat = inlineV10Catalog(catalog);
                assert.strictEqual(inlineCat.catalogId, 'https://example.com/override');
                assert.strictEqual(inlineCat.protocolVersion, '1.0');
                assertConformsToV10CatalogDefinition(inlineCat);
            }
        });
    });
    describe('surface lifecycle events', () => {
        it('fires onSurfaceCreated and onSurfaceDeleted callbacks', () => {
            let createdId = '';
            let deletedId = '';
            processor.onSurfaceCreated(s => {
                createdId = s.id;
            });
            processor.onSurfaceDeleted(id => {
                deletedId = id;
            });
            processor.processMessages({
                version: 'v0.9',
                createSurface: { surfaceId: 's1', catalogId: 'test-catalog' },
            });
            assert.strictEqual(createdId, 's1');
            processor.processMessages({
                version: 'v0.9',
                deleteSurface: { surfaceId: 's1' },
            });
            assert.strictEqual(deletedId, 's1');
            assert.strictEqual(processor.getSurface('s1'), undefined);
        });
    });
    describe('processMessages operation handling', () => {
        it('exposes only version-compatible catalogs on the new surface', () => {
            const v09 = new Catalog('cat-0-9', '0.9', []);
            const alsoV09 = new Catalog('cat-0-9-b', '0.9', []);
            const v10 = new Catalog('cat-1-0', '1.0', []);
            const proc = new MessageProcessor([v09, alsoV09, v10]);
            proc.processMessages({
                version: 'v0.9',
                createSurface: { surfaceId: 's1', catalogId: 'cat-0-9' },
            });
            const surface = proc.model.getSurface('s1');
            assert.strictEqual(surface.defaultCatalog, v09);
            assert.deepStrictEqual([...surface.availableCatalogs.keys()].sort(), [
                'cat-0-9',
                'cat-0-9-b',
            ]);
        });
        it('directly processes InternalOperation objects passed to processMessages', () => {
            processor.processMessages({
                type: 'createSurface',
                surfaceId: 's_direct',
                catalogId: 'test-catalog',
                dataModel: { foo: 'bar' },
            });
            assert.ok(processor.getSurface('s_direct'));
            assert.strictEqual(processor.getSurface('s_direct')?.dataModel.get('/foo'), 'bar');
        });
    });
    describe('formatZodIssue and error formatting', () => {
        it('formats unrecognized keys with exact property names', () => {
            const issue = {
                code: 'unrecognized_keys',
                keys: ['color', 'gap'],
                path: ['header'],
                message: 'Unrecognized key(s) in object: color, gap',
            };
            assert.strictEqual(formatZodIssue(issue), "header: Unrecognized key(s) in object: 'color', 'gap'");
        });
        it('formats unrecognized keys at root level', () => {
            const issue = {
                code: 'unrecognized_keys',
                keys: ['color'],
                path: [],
                message: 'Expected undefined, received undefined',
            };
            assert.strictEqual(formatZodIssue(issue), "root: Unrecognized key(s) in object: 'color'");
        });
        it('formats invalid enum values', () => {
            const issue = {
                code: 'invalid_enum_value',
                options: ['primary', 'secondary'],
                received: 'invalid',
                path: ['variant'],
                message: 'Invalid enum value',
            };
            assert.strictEqual(formatZodIssue(issue), "variant: Invalid enum value. Expected primary | secondary, received 'invalid'");
        });
        it('falls back to expected/received when message is corrupted with undefined', () => {
            const issue = {
                code: 'invalid_type',
                expected: 'string',
                received: 'number',
                path: ['label'],
                message: 'Expected undefined, received undefined',
            };
            assert.strictEqual(formatZodIssue(issue), 'label: Expected string, received number');
        });
        it('surfaces unrecognized property validation error when processing component updates', () => {
            const strictButtonApi = {
                name: 'MaterialButton',
                schema: z
                    .object({
                    label: z.string(),
                })
                    .strict(),
            };
            const proc = new MessageProcessor([new Catalog('cat-m3', '0.9', [strictButtonApi])]);
            proc.processMessages([
                {
                    version: 'v0.9',
                    createSurface: { surfaceId: 's1', catalogId: 'cat-m3' },
                },
            ]);
            assert.throws(() => {
                proc.processMessages([
                    {
                        version: 'v0.9',
                        updateComponents: {
                            surfaceId: 's1',
                            components: [
                                {
                                    id: 'btn1',
                                    component: 'MaterialButton',
                                    label: 'Submit',
                                    color: 'primary',
                                },
                            ],
                        },
                    },
                ]);
            }, (err) => {
                assert.ok(err instanceof A2uiValidationError);
                assert.strictEqual(err.message, "Validation failed for component 'MaterialButton' (btn1): root: Unrecognized key(s) in object: 'color'");
                return true;
            });
        });
    });
    describe('ValidationConfig', () => {
        it('validates surface theme against the basic catalog themeSchema', () => {
            const themedCatalog = new Catalog('themed-cat', '0.9', [], [], BasicCatalogThemeSchema);
            const proc = new MessageProcessor([themedCatalog], undefined, {
                validationConfig: THEME_ONLY_VALIDATION,
            });
            // Valid: 6-char hex, 3-char hex, 8-char hex (with alpha), named and functional colors.
            const validColors = {
                '6char': '#00BFFF',
                '3char': '#17e',
                '8char': '#00BFFF80',
                'named': 'red',
                'rgb': 'rgb(255, 0, 0)',
                'hsl': 'hsl(120, 100%, 50%)',
            };
            for (const [label, primaryColor] of Object.entries(validColors)) {
                proc.processMessages({
                    version: 'v0.9',
                    createSurface: {
                        surfaceId: `valid-${label}`,
                        catalogId: 'themed-cat',
                        theme: label === '6char'
                            ? { primaryColor, agentDisplayName: 'Test Agent', customExtra: 'passthrough' }
                            : { primaryColor },
                    },
                });
                const surface = proc.model.getSurface(`valid-${label}`);
                assert.ok(surface, `expected surface for ${label}`);
                assert.strictEqual(surface.theme?.primaryColor, primaryColor);
            }
            assert.strictEqual(proc.model.getSurface('valid-6char')?.theme?.agentDisplayName, 'Test Agent');
            // Invalid: malformed hex, non-colors, and CSS injection attempts.
            const invalidColors = [
                'url(https://attacker.example/beacon)',
                '#12',
                '#12345',
                '#1234567',
                '#gggggg',
                'not-a-color',
                'red; url(x)',
                123,
            ];
            for (const primaryColor of invalidColors) {
                const surfaceId = `invalid-${String(primaryColor)}`;
                assert.throws(() => {
                    proc.processMessages({
                        version: 'v0.9',
                        createSurface: { surfaceId, catalogId: 'themed-cat', theme: { primaryColor } },
                    });
                }, (err) => {
                    assert.ok(err instanceof A2uiValidationError);
                    assert.ok(err.message.includes(`Validation failed for theme on surface '${surfaceId}'`));
                    return true;
                }, `expected ${String(primaryColor)} to be rejected`);
                assert.strictEqual(proc.model.getSurface(surfaceId), undefined);
            }
        });
        it('applies themeSchema transforms and defaults to the stored theme', () => {
            const transformSchema = z.object({
                primaryColor: z.string().transform(c => c.toUpperCase()),
                defaultedField: z.string().default('default-val'),
            });
            const proc = new MessageProcessor([new Catalog('transform-cat', '0.9', [], [], transformSchema)], undefined, {
                validationConfig: THEME_ONLY_VALIDATION,
            });
            proc.processMessages({
                version: 'v0.9',
                createSurface: {
                    surfaceId: 'transform-surface',
                    catalogId: 'transform-cat',
                    theme: { primaryColor: '#abcdef' },
                },
            });
            const surface = proc.model.getSurface('transform-surface');
            assert.ok(surface);
            assert.strictEqual(surface.theme?.primaryColor, '#ABCDEF');
            assert.strictEqual(surface.theme?.defaultedField, 'default-val');
        });
        describe('maxAgentCallCacheEntries', () => {
            const catalog = new Catalog('cat', '1.0', BASIC_COMPONENTS);
            const create = { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'cat' } };
            it('applies to the surfaces the processor creates', () => {
                const proc = new MessageProcessor([catalog], undefined, { maxAgentCallCacheEntries: 2 });
                proc.processMessages(create);
                assert.strictEqual(proc.model.getSurface('s').maxAgentCallCacheEntries, 2);
                const defaulted = new MessageProcessor([catalog]);
                defaulted.processMessages(create);
                assert.strictEqual(defaulted.model.getSurface('s').maxAgentCallCacheEntries, 256);
            });
            it('rejects a value that is not a positive integer', () => {
                for (const value of [0, -1, 1.5, Number.NaN]) {
                    assert.throws(() => new MessageProcessor([catalog], undefined, { maxAgentCallCacheEntries: value }), RangeError, String(value));
                }
            });
        });
        describe('per call', () => {
            const catalog = new Catalog('cat', '1.0', BASIC_COMPONENTS);
            const create = { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'cat' } };
            const danglingChild = {
                version: '1.0',
                updateComponents: {
                    surfaceId: 's',
                    components: [{ id: 'root', component: 'Column', children: ['later'] }],
                },
            };
            const unknownComponent = {
                version: '1.0',
                updateComponents: { surfaceId: 's', components: [{ id: 'root', component: 'Unknown' }] },
            };
            it("replaces the processor's own config for the call", () => {
                const proc = new MessageProcessor([catalog], undefined, {
                    validationConfig: STRICT_VALIDATION,
                });
                proc.processMessages(create);
                assert.throws(() => proc.processMessages(danglingChild), A2uiValidationError);
                proc.processMessages(danglingChild, {
                    validationConfig: {
                        allowDanglingReferences: true,
                        allowMissingRoot: true,
                        allowOrphanComponents: true,
                    },
                });
                assert.strictEqual(proc.model.getSurface('s')?.componentsModel.get('root')?.type, 'Column');
            });
            it('validates a processor that has no config of its own', () => {
                const proc = new MessageProcessor([catalog]);
                proc.processMessages(create);
                assert.throws(() => proc.processMessages(unknownComponent, { validationConfig: {} }), A2uiValidationError);
                assert.strictEqual(proc.model.getSurface('s')?.componentsModel.size, 0);
            });
            it("restores the processor's own config after the call", () => {
                const proc = new MessageProcessor([catalog]);
                proc.processMessages(create);
                assert.throws(() => proc.processMessages(unknownComponent, { validationConfig: {} }), A2uiValidationError);
                proc.processMessages(unknownComponent);
                assert.strictEqual(proc.model.getSurface('s')?.componentsModel.get('root')?.type, 'Unknown');
            });
            it('applies to each operation of an asynchronous call', async () => {
                const proc = new MessageProcessor([catalog]);
                proc.processMessages(create);
                await assert.rejects(proc.processMessagesAsync([unknownComponent], { validationConfig: {} }), A2uiValidationError);
            });
        });
    });
    describe('catalogs', () => {
        it('returns the catalogs the processor was created with, in order', () => {
            const first = new Catalog('first', '1.0', []);
            const second = new Catalog('second', '1.0', []);
            const proc = new MessageProcessor([first, second]);
            assert.deepStrictEqual(proc.catalogs, [first, second]);
        });
        it('returns a copy', () => {
            const proc = new MessageProcessor([testCatalog]);
            proc.catalogs.push(new Catalog('other', '0.9', []));
            assert.deepStrictEqual(proc.catalogs, [testCatalog]);
        });
    });
    describe('Mixed Catalogs Support', () => {
        const basicCat = new Catalog('cat-basic', '1.0', [
            {
                name: 'Box',
                schema: z.object({ child: z.string().describe('ChildComponentId').optional() }),
            },
            {
                name: 'Text',
                schema: z.object({ text: z.string() }),
            },
        ]);
        it('resolves callRendererFunction against a secondary catalog in availableCatalogs', async () => {
            const fnCatalog = new Catalog('cat-fn', '1.0', [], [
                {
                    name: 'computeGreeting',
                    returnType: 'string',
                    allowedCallers: 'rendererOrAgent',
                    schema: z.object({ user: z.string() }),
                    execute: args => `Hi ${args.user}`,
                },
            ]);
            const processor = new MessageProcessor([basicCat, fnCatalog]);
            processor.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 'surface-1', catalogId: 'cat-basic' },
            });
            const responses = await processor.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-1',
                    callFunction: {
                        call: 'computeGreeting',
                        catalogId: 'cat-fn',
                        args: { user: 'Alice' },
                    },
                },
            });
            assert.strictEqual(responses.length, 1);
            assert.strictEqual(responses[0].rendererFunctionResponse.value, 'Hi Alice');
        });
    });
    describe('MessageProcessor Full Pipeline & Validation Integration', () => {
        const basicCatalog = new Catalog('https://a2ui.org/catalog', '1.0', BASIC_COMPONENTS);
        it('leaves componentsModel untouched when updateComponents fails topology validation', () => {
            const proc = new MessageProcessor([basicCatalog], undefined, {
                validationConfig: STRICT_VALIDATION,
            });
            // 1. Initial valid surface
            proc.processMessages({
                version: '1.0',
                createSurface: {
                    surfaceId: 's_atomic',
                    catalogId: 'https://a2ui.org/catalog',
                    components: [
                        { id: 'root', component: 'Column', children: ['c1'] },
                        { id: 'c1', component: 'Text', text: 'Initial Child' },
                    ],
                },
            });
            const surface = proc.getSurface('s_atomic');
            assert.strictEqual(surface.componentsModel.size, 2);
            // Track whether any update/create events are fired
            let eventFired = false;
            surface.componentsModel.onCreated.subscribe(() => {
                eventFired = true;
            });
            // 2. Send update that introduces an orphan component (failing topology validation)
            assert.throws(() => proc.processMessages({
                version: '1.0',
                updateComponents: {
                    surfaceId: 's_atomic',
                    components: [
                        { id: 'root', component: 'Column', children: ['c1'] },
                        { id: 'c1', component: 'Text', text: 'Updated Child' },
                        { id: 'orphan_comp', component: 'Text', text: 'Unreachable' },
                    ],
                },
            }), (err) => err instanceof A2uiIntegrityError && err.message.includes('not reachable'));
            // 3. Verify that componentsModel was NOT mutated and no events fired
            assert.strictEqual(surface.componentsModel.size, 2);
            assert.strictEqual(surface.componentsModel.has('orphan_comp'), false);
            assert.strictEqual(surface.componentsModel.get('c1')?.properties.text, 'Initial Child');
            assert.strictEqual(eventFired, false);
        });
        it('leaves componentsModel untouched when updateComponents contains a valid component followed by an untyped new component', () => {
            const proc = new MessageProcessor([basicCatalog]);
            proc.processMessages({
                version: '1.0',
                createSurface: {
                    surfaceId: 's_untyped',
                    catalogId: 'https://a2ui.org/catalog',
                    components: [{ id: 'root', component: 'Text', text: 'Initial' }],
                },
            });
            const surface = proc.getSurface('s_untyped');
            // Batch contains valid update to 'root' followed by an invalid new component 'new_comp' without type
            assert.throws(() => proc.processOperation({
                type: 'updateComponents',
                surfaceId: 's_untyped',
                components: [
                    { id: 'root', component: 'Text', text: 'Updated Text' },
                    { id: 'new_comp', text: 'Missing component field' },
                ],
            }), (err) => err instanceof A2uiValidationError &&
                err.message.includes('Cannot create component new_comp without a type'));
            // Verify that 'root' was NOT mutated
            assert.strictEqual(surface.componentsModel.get('root')?.properties.text, 'Initial');
            assert.strictEqual(surface.componentsModel.has('new_comp'), false);
        });
        it('applies Surface allowedParents rule only to rootId and checks all parents of a component', () => {
            const compositionCatalog = Catalog.fromJson({
                catalogId: 'custom',
                protocolVersion: '1.0',
                components: {
                    Box: {
                        type: 'object',
                        properties: {
                            children: { $ref: '#/$defs/ChildList' },
                        },
                    },
                    Card: {
                        type: 'object',
                        allowedParents: ['Box'],
                        properties: {
                            children: { $ref: '#/$defs/ChildList' },
                        },
                    },
                    Header: {
                        type: 'object',
                        allowedParents: ['Box'],
                    },
                },
            });
            // 1. Rewriting a container to drop a child whose allowedParents does not
            // include 'Surface' succeeds when orphans are allowed (default), and
            // reports an orphan IntegrityError (not UNALLOWED_PARENT) in strict mode.
            const relaxedProc = new MessageProcessor([compositionCatalog]);
            relaxedProc.processMessages([
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 's1',
                        catalogId: 'custom',
                        components: [
                            { id: 'root', component: 'Box', children: ['h'] },
                            { id: 'h', component: 'Header' },
                        ],
                    },
                },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's1',
                        components: [{ id: 'root', component: 'Box', children: [] }],
                    },
                },
            ]);
            assert.deepStrictEqual(relaxedProc.getSurface('s1')?.componentsModel.get('root')?.properties.children, []);
            assert.strictEqual(relaxedProc.getSurface('s1')?.componentsModel.get('h')?.type, 'Header');
            const strictProc = new MessageProcessor([compositionCatalog], undefined, {
                validationConfig: STRICT_VALIDATION,
            });
            strictProc.processMessages({
                version: '1.0',
                createSurface: {
                    surfaceId: 's1',
                    catalogId: 'custom',
                    components: [
                        { id: 'root', component: 'Box', children: ['h'] },
                        { id: 'h', component: 'Header' },
                    ],
                },
            });
            assert.throws(() => strictProc.processMessages({
                version: '1.0',
                updateComponents: {
                    surfaceId: 's1',
                    components: [{ id: 'root', component: 'Box', children: [] }],
                },
            }), (err) => err instanceof A2uiIntegrityError &&
                err.message.includes("Component 'h' is not reachable from 'root'"));
            // 2. Root component referenced by another component is still checked
            // against 'Surface' (for both default 'root' and a custom rootId).
            const rootRefProc = new MessageProcessor([compositionCatalog]);
            assert.throws(() => rootRefProc.processMessages({
                version: '1.0',
                createSurface: {
                    surfaceId: 's1',
                    catalogId: 'custom',
                    components: [
                        { id: 'root', component: 'Card' },
                        { id: 'box', component: 'Box', children: ['root'] },
                    ],
                },
            }), (err) => err instanceof A2uiValidationError &&
                err.code === 'UNALLOWED_PARENT' &&
                err.message.includes("Component 'root' (Card) cannot be placed under parent 'Surface' (Surface)."));
            const customRootProc = new MessageProcessor([compositionCatalog], undefined, {
                validationConfig: { rootId: 'main_root', allowOrphanComponents: true },
            });
            assert.throws(() => customRootProc.processMessages({
                version: '1.0',
                createSurface: {
                    surfaceId: 's1',
                    catalogId: 'custom',
                    components: [
                        { id: 'main_root', component: 'Card' },
                        { id: 'box', component: 'Box', children: ['main_root'] },
                    ],
                },
            }), (err) => err instanceof A2uiValidationError &&
                err.code === 'UNALLOWED_PARENT' &&
                err.message.includes("Component 'main_root' (Card) cannot be placed under parent 'Surface' (Surface)."));
            // 3. Component with multiple parents checks every parent edge regardless
            // of component order.
            for (const components of [
                [
                    { id: 'root', component: 'Box', children: ['card', 'b'] },
                    { id: 'card', component: 'Card', children: ['h'] },
                    { id: 'b', component: 'Box', children: ['h'] },
                    { id: 'h', component: 'Header' },
                ],
                [
                    { id: 'root', component: 'Box', children: ['b', 'card'] },
                    { id: 'b', component: 'Box', children: ['h'] },
                    { id: 'card', component: 'Card', children: ['h'] },
                    { id: 'h', component: 'Header' },
                ],
            ]) {
                const multiParentProc = new MessageProcessor([compositionCatalog]);
                assert.throws(() => multiParentProc.processMessages({
                    version: '1.0',
                    createSurface: {
                        surfaceId: 's1',
                        catalogId: 'custom',
                        components,
                    },
                }), (err) => err instanceof A2uiValidationError &&
                    err.code === 'UNALLOWED_PARENT' &&
                    err.message.includes("Component 'h' (Header) cannot be placed under parent 'card' (Card)."));
            }
        });
        it("checks the surface's own root id against Surface, as a v0.8 beginRendering root sets it", () => {
            const catalog = Catalog.fromJson({
                catalogId: 'custom',
                protocolVersion: '1.0',
                components: {
                    Box: { type: 'object', properties: { children: { $ref: '#/$defs/ChildList' } } },
                    Card: { type: 'object', allowedParents: ['Box'] },
                },
            });
            const surfaceWithRoot = (rootId) => new SurfaceModel('s1', catalog, new Map([[catalog.id, catalog]]), {}, false, undefined, rootId);
            const resolveCatalog = () => catalog;
            // The surface's root, 'main', is a Card, which may only be under a Box.
            assert.throws(() => validateCompositionConstraints(surfaceWithRoot('main'), [
                { id: 'main', component: 'Card' },
                { id: 'box', component: 'Box', children: ['main'] },
            ], resolveCatalog, undefined), (err) => err instanceof A2uiValidationError &&
                err.message.includes("Component 'main' (Card) cannot be placed under parent 'Surface'"));
            // A component named 'root' is not the root of this surface, so it is not
            // checked against Surface.
            assert.doesNotThrow(() => validateCompositionConstraints(surfaceWithRoot('main'), [
                { id: 'main', component: 'Box', children: [] },
                { id: 'root', component: 'Card' },
            ], resolveCatalog, undefined));
        });
    });
    describe('MessageProcessor Bidirectional RPC & Asynchronous Pipeline', () => {
        const rpcApi = {
            name: 'echoFunction',
            returnType: 'string',
            schema: z.object({ text: z.string() }),
            allowedCallers: 'rendererOrAgent',
        };
        const rpcImpl = createFunctionImplementation(rpcApi, (args) => `Echo: ${args.text}`);
        const secureApi = {
            name: 'secureAction',
            returnType: 'boolean',
            schema: z.object({}),
            allowedCallers: 'rendererOrAgent',
            requiresUserActivation: true,
        };
        const secureImpl = createFunctionImplementation(secureApi, () => true);
        const rpcCatalog = new Catalog('rpc-cat', '1.0', [], [rpcImpl, secureImpl]);
        it('processes callRendererFunction via processMessagesAsync and returns response', async () => {
            const proc = new MessageProcessor([rpcCatalog]);
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'rpc-cat' },
            });
            const responses = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-call-1',
                    callFunction: {
                        call: 'echoFunction',
                        catalogId: 'rpc-cat',
                        args: { text: 'World' },
                    },
                },
            });
            assert.strictEqual(responses.length, 1);
            assert.strictEqual(responses[0].rendererFunctionResponse.functionCallId, 'rpc-call-1');
            assert.strictEqual(responses[0].rendererFunctionResponse.value, 'Echo: World');
            assert.strictEqual(responses[0].rendererFunctionResponse.error, undefined);
        });
        it('hands the RpcHandler a callRendererFunction message that names the function with @call', async () => {
            const proc = new MessageProcessor([rpcCatalog]);
            const received = [];
            const original = proc.rpc.handleCallRendererFunction.bind(proc.rpc);
            proc.rpc.handleCallRendererFunction = (msg, ...rest) => {
                received.push(msg);
                return original(msg, ...rest);
            };
            await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-call-at',
                    callFunction: { '@call': 'echoFunction', catalogId: 'rpc-cat', args: { text: 'A' } },
                },
            });
            assert.strictEqual(received.length, 1);
            assert.deepStrictEqual(received[0].callRendererFunction.callFunction, {
                '@call': 'echoFunction',
                catalogId: 'rpc-cat',
                args: { text: 'A' },
            });
        });
        it('targets the specified surfaceId data model when surfaceId is provided, uses an isolated empty model when omitted, and returns INVALID_FUNCTION_CALL when surfaceId does not exist', async () => {
            const readModelApi = {
                name: 'readUserName',
                returnType: 'string',
                schema: z.object({ text: z.string().optional() }),
                allowedCallers: 'rendererOrAgent',
            };
            const readModelImpl = createFunctionImplementation(readModelApi, (args, ctx) => args?.text ?? ctx?.surface?.dataModel?.get('/user/name') ?? 'empty');
            const cat = new Catalog('rpc-model-cat', '1.0', [], [readModelImpl]);
            const proc = new MessageProcessor([cat]);
            proc.processMessages([
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 's1',
                        catalogId: 'rpc-model-cat',
                        dataModel: { user: { name: 'Alice' } },
                    },
                },
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 's2',
                        catalogId: 'rpc-model-cat',
                        dataModel: { user: { name: 'Bob' } },
                    },
                },
            ]);
            // 1. With surfaceId: 's2' and @path arg -> resolves against s2's data model ('Bob')
            const resWithSurface = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    surfaceId: 's2',
                    functionCallId: 'rpc-surf-1',
                    callFunction: {
                        call: 'readUserName',
                        catalogId: 'rpc-model-cat',
                        args: { text: { '@path': '/user/name' } },
                    },
                },
            });
            assert.strictEqual(resWithSurface.length, 1);
            assert.strictEqual(resWithSurface[0].rendererFunctionResponse.value, 'Bob');
            // 2. Without surfaceId and @path arg -> resolves against isolated empty root model ('empty')
            const resIsolated = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-surf-2',
                    callFunction: {
                        call: 'readUserName',
                        catalogId: 'rpc-model-cat',
                        args: { text: { '@path': '/user/name' } },
                    },
                },
            });
            assert.strictEqual(resIsolated.length, 1);
            assert.strictEqual(resIsolated[0].rendererFunctionResponse.value, 'empty');
            // 3. With non-existent surfaceId -> returns INVALID_FUNCTION_CALL
            const resMissing = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    surfaceId: 'non_existent_surface',
                    functionCallId: 'rpc-surf-3',
                    callFunction: {
                        call: 'readUserName',
                        catalogId: 'rpc-model-cat',
                        args: {},
                    },
                },
            });
            assert.strictEqual(resMissing.length, 1);
            assert.strictEqual(resMissing[0].rendererFunctionResponse.error?.code, RpcErrorCode.INVALID_FUNCTION_CALL);
            assert.match(resMissing[0].rendererFunctionResponse.error?.message ?? '', /Surface not found: non_existent_surface/);
            // 4. With @call: '@index' in args -> returns EXECUTION_ERROR
            const resIndexErr = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-surf-4',
                    callFunction: {
                        call: 'readUserName',
                        catalogId: 'rpc-model-cat',
                        args: { text: { '@call': '@index' } },
                    },
                },
            });
            assert.strictEqual(resIndexErr.length, 1);
            assert.strictEqual(resIndexErr[0].rendererFunctionResponse.error?.code, RpcErrorCode.EXECUTION_ERROR);
            // 5. Wire message missing callFunction.catalogId -> throws A2uiValidationError
            await assert.rejects(proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-surf-5',
                    callFunction: {
                        call: 'readUserName',
                        args: {},
                    },
                },
            }), A2uiValidationError);
        });
        it('enforces requiresUserActivation in processMessagesAsync via context options', async () => {
            const proc = new MessageProcessor([rpcCatalog]);
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'rpc-cat' },
            });
            // Without user activation
            const unauthResponses = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-call-2',
                    callFunction: {
                        call: 'secureAction',
                        catalogId: 'rpc-cat',
                        args: {},
                    },
                },
            });
            assert.strictEqual(unauthResponses.length, 1);
            assert.strictEqual(unauthResponses[0].rendererFunctionResponse.error?.code, RpcErrorCode.INVALID_FUNCTION_CALL);
            // With user activation
            const authResponses = await proc.processMessagesAsync({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-call-3',
                    callFunction: {
                        call: 'secureAction',
                        catalogId: 'rpc-cat',
                        args: {},
                    },
                },
            }, { isUserActivated: true });
            assert.strictEqual(authResponses.length, 1);
            assert.strictEqual(authResponses[0].rendererFunctionResponse.value, true);
        });
        it('initiates callAgentFunction and resolves via inbound agentFunctionResponse in processMessages', async () => {
            let emittedMessage;
            const proc = new MessageProcessor([rpcCatalog], undefined, {
                outboundListener: msg => {
                    emittedMessage = msg;
                },
            });
            const callPromise = proc.callAgentFunction('s1', {
                call: 'fetchAgentData',
                catalogId: 'rpc-cat',
                args: { id: '42' },
            });
            assert.ok(emittedMessage);
            assert.strictEqual(emittedMessage.callAgentFunction.surfaceId, 's1');
            assert.strictEqual(emittedMessage.callAgentFunction.callFunction['@call'], 'fetchAgentData');
            assert.ok(!Object.hasOwn(emittedMessage.callAgentFunction.callFunction, 'call'));
            const callId = emittedMessage.callAgentFunction.functionCallId;
            // Inbound response processed through standard message processing pipeline
            proc.processMessages({
                version: '1.0',
                agentFunctionResponse: {
                    functionCallId: callId,
                    value: { data: 'Agent Result' },
                },
            });
            const result = await callPromise;
            assert.deepStrictEqual(result, { data: 'Agent Result' });
        });
        it('rejects pending callAgentFunction on processor disposal', async () => {
            const proc = new MessageProcessor([rpcCatalog], undefined, {
                outboundListener: () => { },
            });
            const callPromise = proc.callAgentFunction('s1', {
                call: 'fetchData',
            });
            proc.dispose();
            await assert.rejects(callPromise, (err) => {
                assert.strictEqual(err.code, RpcErrorCode.CANCELLED);
                return true;
            });
        });
        it('executes callRendererFunction in synchronous processMessages and emits to outboundListener', async () => {
            let emittedResponse;
            const proc = new MessageProcessor([rpcCatalog], undefined, {
                outboundListener: msg => {
                    emittedResponse = msg;
                },
            });
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'rpc-cat' },
            });
            // Fire-and-forget callRendererFunction in synchronous pipeline
            proc.processMessages({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'rpc-sync-1',
                    callFunction: {
                        call: 'echoFunction',
                        catalogId: 'rpc-cat',
                        args: { text: 'SyncTest' },
                    },
                },
            });
            // Give the asynchronous promise chain a tick to complete
            await new Promise(resolve => setTimeout(resolve, 10));
            assert.ok(emittedResponse);
            assert.strictEqual(emittedResponse.rendererFunctionResponse.functionCallId, 'rpc-sync-1');
            assert.strictEqual(emittedResponse.rendererFunctionResponse.value, 'Echo: SyncTest');
        });
        it('catches and logs unexpected promise rejections from callRendererFunction in processMessages', async () => {
            let loggedError = false;
            const originalConsoleError = console.error;
            console.error = () => {
                loggedError = true;
            };
            try {
                const proc = new MessageProcessor([rpcCatalog]);
                proc.rpc.handleCallRendererFunction = async () => {
                    throw new Error('RPC exploded');
                };
                proc.processMessages({
                    version: '1.0',
                    callRendererFunction: {
                        functionCallId: 'rpc-sync-2',
                        callFunction: {
                            call: 'echoFunction',
                            catalogId: 'rpc-cat',
                            args: {},
                        },
                    },
                });
                await new Promise(resolve => setTimeout(resolve, 10));
                assert.strictEqual(loggedError, true);
            }
            finally {
                console.error = originalConsoleError;
            }
        });
    });
    describe('Backwards Compatibility Shims', () => {
        it('provides getClientCapabilities alias', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            const caps = proc.getClientCapabilities({ versions: ['v0.9'] });
            assert.deepStrictEqual(caps, proc.getRendererCapabilities({ versions: ['v0.9'] }));
            assert.deepStrictEqual(caps['v0.9'].supportedCatalogIds, ['test-cat']);
        });
        it('defaults getClientCapabilities to v0.9 and accepts the legacy version option', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            const expected = proc.getRendererCapabilities({ versions: ['v0.9'] });
            assert.deepStrictEqual(proc.getClientCapabilities(), expected);
            assert.deepStrictEqual(proc.getClientCapabilities({}), expected);
            assert.deepStrictEqual(proc.getClientCapabilities({ version: 'v0.9' }), expected);
            assert.deepStrictEqual(proc.getRendererCapabilities({ version: 'v0.9' }), expected, 'getRendererCapabilities also accepts the legacy version option');
            assert.throws(() => proc.getRendererCapabilities({}), /At least one protocol version must be provided/);
        });
        it('treats an unversioned v0.9 envelope as v0.9 when every catalog is pre-1.0', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            proc.processMessages([
                { createSurface: { surfaceId: 's1', catalogId: 'test-cat' } },
                { updateDataModel: { surfaceId: 's1', path: '/user/name', value: 'Alice' } },
            ]);
            assert.strictEqual(proc.getSurface('s1')?.dataModel.get('/user/name'), 'Alice');
            proc.processMessages({ deleteSurface: { surfaceId: 's1' } });
            assert.strictEqual(proc.getSurface('s1'), undefined);
        });
        it('unwraps messages wrapper in unversioned payload', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            proc.processMessages({
                messages: [{ createSurface: { surfaceId: 's1', catalogId: 'test-cat' } }],
            });
            assert.ok(proc.getSurface('s1'));
        });
        it('treats an unversioned envelope as v0.9.1 when registered catalog is 0.9.1', () => {
            const cat = new Catalog('test-cat', '0.9.1', []);
            const proc = new MessageProcessor([cat]);
            proc.processMessages({ createSurface: { surfaceId: 's1', catalogId: 'test-cat' } });
            assert.ok(proc.getSurface('s1'));
        });
        it('keeps rejecting unversioned envelopes with a v1.0 catalog or a validationConfig', () => {
            const unversioned = { createSurface: { surfaceId: 's1', catalogId: 'test-cat' } };
            const withV10 = new MessageProcessor([
                new Catalog('test-cat', '0.9', []),
                new Catalog('v10-cat', '1.0', []),
            ]);
            assert.throws(() => withV10.processMessages(unversioned), /missing a valid 'version'/);
            const validating = new MessageProcessor([new Catalog('test-cat', '0.9', [])], undefined, {
                validationConfig: THEME_ONLY_VALIDATION,
            });
            assert.throws(() => validating.processMessages(unversioned), /missing a valid 'version'/);
        });
        it('leaves nested calls unchecked on a pre-1.0 surface without a validationConfig', () => {
            const textApi = { name: 'Text', schema: z.object({ text: z.any() }) };
            const v09 = new Catalog('v09', '0.9', [textApi]);
            const lenient = new MessageProcessor([v09]);
            lenient.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', text: { call: 'nope', args: {} } }],
                    },
                },
            ]);
            assert.ok(lenient.getSurface('s')?.componentsModel.get('root'));
            const strict = new MessageProcessor([new Catalog('v09', '0.9', [textApi])], undefined, {
                validationConfig: { ...THEME_ONLY_VALIDATION, allowUnknownElements: false },
            });
            assert.throws(() => strict.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', text: { call: 'nope', args: {} } }],
                    },
                },
            ]), /Unrecognized function 'nope'/);
        });
        it('provides getClientDataModel alias', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            proc.processMessages({
                version: 'v0.9',
                createSurface: {
                    surfaceId: 's1',
                    catalogId: 'test-cat',
                    sendDataModel: true,
                },
            });
            proc.processMessages({
                version: 'v0.9',
                updateDataModel: {
                    surfaceId: 's1',
                    path: '/user/name',
                    value: 'Alice',
                },
            });
            const dataModel = proc.getClientDataModel('v0.9');
            assert.deepStrictEqual(dataModel, proc.getRendererDataModel('v0.9'));
            assert.deepStrictEqual(dataModel?.surfaces?.s1, { user: { name: 'Alice' } });
        });
        it('records the createSurface message protocol version on the surface and falls back to catalog version', () => {
            const textApi = {
                name: 'Text',
                schema: z.object({ text: z.string() }).strict(),
            };
            const v09Cat = new Catalog('cat-09', '0.9', [textApi]);
            const handledErrors = [];
            const proc = new MessageProcessor([v09Cat], undefined, {
                errorHandler: err => handledErrors.push(err),
            });
            proc.processMessages([
                {
                    version: 'v0.9.1',
                    createSurface: {
                        surfaceId: 's-091',
                        catalogId: 'cat-09',
                        sendDataModel: true,
                    },
                },
                {
                    version: 'v0.9.1',
                    updateDataModel: {
                        surfaceId: 's-091',
                        path: '/greeting',
                        value: 'hi',
                    },
                },
            ]);
            assert.strictEqual(proc.getSurface('s-091')?.protocolVersion, 'v0.9.1');
            proc.processMessages({
                type: 'createSurface',
                surfaceId: 's-unversioned',
                catalogId: 'cat-09',
                sendDataModel: true,
                dataModel: { greeting: 'hello' },
            });
            assert.strictEqual(proc.getSurface('s-unversioned')?.protocolVersion, 'v0.9');
            // An unversioned operation failing on the v0.9.1 surface inherits the surface's v0.9.1 version.
            assert.throws(() => {
                proc.processMessages({
                    type: 'updateComponents',
                    surfaceId: 's-091',
                    components: [{ id: 'root', component: 'Text', text: 42 }],
                });
            }, A2uiValidationError);
            assert.strictEqual(handledErrors.length, 1);
            assert.strictEqual(handledErrors[0].version, 'v0.9.1');
            assert.strictEqual(handledErrors[0].error.surfaceId, 's-091');
            // Mixing v0.9 and v0.9.1 active surfaces with sendDataModel throws without an explicit version.
            assert.throws(() => proc.getRendererDataModel(), (err) => err instanceof A2uiValidationError &&
                err.message.includes('Multiple protocol versions detected among active surfaces: v0.9, v0.9.1'));
            assert.deepStrictEqual(proc.getRendererDataModel('v0.9.1'), {
                version: 'v0.9.1',
                surfaces: {
                    's-091': { greeting: 'hi' },
                    's-unversioned': { greeting: 'hello' },
                },
            });
            assert.deepStrictEqual(proc.getRendererDataModel('v0.9'), {
                version: 'v0.9',
                surfaces: {
                    's-091': { greeting: 'hi' },
                    's-unversioned': { greeting: 'hello' },
                },
            });
        });
        it('provides resolvePath method on MessageProcessor', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            assert.strictEqual(proc.resolvePath('/absolute/path'), '/absolute/path');
            assert.strictEqual(proc.resolvePath('relative', '/base'), '/base/relative');
            assert.strictEqual(proc.resolvePath('relative', '/base/'), '/base/relative');
            assert.strictEqual(proc.resolvePath('standalone'), '/standalone');
        });
        it('rejects component with non-string or empty id', () => {
            const cat = new Catalog('test-cat', '0.9', []);
            const proc = new MessageProcessor([cat]);
            proc.processMessages({
                version: 'v0.9',
                createSurface: { surfaceId: 's1', catalogId: 'test-cat' },
            });
            assert.throws(() => {
                proc.processMessages({
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's1',
                        components: [{ id: 123, component: 'Text' }],
                    },
                });
            }, (err) => {
                return err instanceof A2uiValidationError && err.message.includes("missing an 'id'");
            });
        });
    });
    describe('surface and component metadata and default catalog resolution', () => {
        it('propagates surface metadata from createSurface op to surface.metadata', () => {
            const proc = new MessageProcessor([new Catalog('default', '1.0', [])]);
            proc.processMessages([
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 'meta_surface',
                        metadata: { extensions: { vendor_app: { author: 'test_agent', priority: 'high' } } },
                    },
                },
            ]);
            const surface = proc.getSurface('meta_surface');
            assert.ok(surface);
            assert.deepStrictEqual(surface.metadata, {
                extensions: { vendor_app: { author: 'test_agent', priority: 'high' } },
            });
        });
        it('extracts and propagates component metadata on component creation and update', () => {
            const proc = new MessageProcessor([new Catalog('default', '1.0', [])]);
            proc.processMessages([
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 'comp_meta_surface',
                        catalogId: 'default',
                    },
                },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 'comp_meta_surface',
                        components: [
                            {
                                id: 'btn1',
                                component: 'Button',
                                metadata: {
                                    extensions: { vendor_app: { analyticsId: 'track_btn_1', role: 'primary' } },
                                },
                            },
                        ],
                    },
                },
            ]);
            const surface = proc.getSurface('comp_meta_surface');
            assert.ok(surface);
            const btn1 = surface.componentsModel.get('btn1');
            assert.ok(btn1);
            assert.deepStrictEqual(btn1.metadata, {
                extensions: { vendor_app: { analyticsId: 'track_btn_1', role: 'primary' } },
            });
            // Update component metadata
            proc.processMessages([
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 'comp_meta_surface',
                        components: [
                            {
                                id: 'btn1',
                                component: 'Button',
                                metadata: {
                                    extensions: {
                                        vendor_app: { analyticsId: 'track_btn_1_updated', role: 'secondary' },
                                    },
                                },
                            },
                        ],
                    },
                },
            ]);
            assert.deepStrictEqual(btn1.metadata, {
                extensions: {
                    vendor_app: { analyticsId: 'track_btn_1_updated', role: 'secondary' },
                },
            });
        });
        it('keeps metadata as an ordinary property below v1.0', () => {
            const cardApi = {
                name: 'Card',
                schema: z.object({ metadata: z.record(z.string(), z.unknown()) }).strict(),
            };
            const proc = new MessageProcessor([new Catalog('v09', '0.9', [cardApi])]);
            proc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Card', metadata: { source: 'crm' } }],
                    },
                },
            ]);
            const card = proc.getSurface('s')?.componentsModel.get('root');
            assert.ok(card);
            assert.deepStrictEqual(card.properties, { metadata: { source: 'crm' } });
            assert.strictEqual(card.metadata, undefined);
            proc.processMessages([
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            { id: 'root', component: 'Card', metadata: { extensions: { vendor_app: 'v' } } },
                        ],
                    },
                },
            ]);
            assert.deepStrictEqual(card.properties, { metadata: { extensions: { vendor_app: 'v' } } });
            assert.strictEqual(card.metadata, undefined);
        });
    });
    // The conformance suite (conformance/core/message_processor_v1_0.yaml) covers
    // catalog resolution through messages. These tests keep what it cannot
    // observe: which catalog object a component is bound to, behaviour that is
    // specific to web_core, and evaluation of a stored call.
    describe('v1.0 catalog resolution', () => {
        const textApi = {
            name: 'Text',
            schema: z.object({ text: z.any() }).strict(),
        };
        const upperFn = createFunctionImplementation({
            name: 'upper',
            returnType: 'string',
            schema: z.object({ value: z.string() }).strict(),
        }, args => args.value.toUpperCase());
        /** Rejects unknown functions while relaxing every topology rule. */
        const STRICT_FUNCTIONS_ONLY = { ...THEME_ONLY_VALIDATION, allowUnknownElements: false };
        it('rebinds a v1.0 component to the surface default when an update names no catalogId', () => {
            const textInCustom = new Catalog('custom', '1.0', [textApi]);
            const base = new Catalog('base', '1.0', [textApi]);
            const proc = new MessageProcessor([base, textInCustom], undefined, {
                validationConfig: { ...STRICT_VALIDATION, allowOrphanComponents: true },
            });
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'base' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', catalogId: 'custom', text: 'Hi' }],
                    },
                },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', text: 'Bye' }],
                    },
                },
            ]);
            assert.strictEqual(proc.getSurface('s')?.componentsModel.get('root')?.catalog, base);
        });
        it('treats catalogId as an ordinary component property below v1.0 (#4012)', () => {
            const textWithCatalogId = {
                name: 'Text',
                schema: z.object({ text: z.any(), catalogId: z.string().optional() }).strict(),
            };
            const v09Base = new Catalog('v09-base', '0.9', [textWithCatalogId]);
            const v09Custom = new Catalog('v09-custom', '0.9', [textWithCatalogId]);
            const proc = new MessageProcessor([v09Base, v09Custom]);
            proc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09-base' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', catalogId: 'v09-custom', text: 'Hi' }],
                    },
                },
            ]);
            const root = proc.getSurface('s')?.componentsModel.get('root');
            assert.strictEqual(root?.catalog, v09Base);
            assert.deepStrictEqual(root?.properties, { catalogId: 'v09-custom', text: 'Hi' });
            // A component that doesn't declare it rejects the property.
            const strictProc = new MessageProcessor([
                new Catalog('v09-strict', '0.9', [textApi]),
            ]);
            assert.throws(() => strictProc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09-strict' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', catalogId: 'v09-strict', text: 'Hi' }],
                    },
                },
            ]), A2uiValidationError);
        });
        it('still falls back to a registered catalog for version-less and v0.8 surfaces', () => {
            const v08 = new Catalog('v08-cat', '0.8', []);
            const proc = new MessageProcessor([v08]);
            proc.processMessages({ type: 'createSurface', surfaceId: 'unversioned' });
            proc.processMessages({ version: 'v0.8', beginRendering: { surfaceId: 'v08', root: 'root' } });
            for (const surfaceId of ['unversioned', 'v08']) {
                assert.strictEqual(proc.getSurface(surfaceId)?.defaultCatalog, v08, surfaceId);
            }
        });
        it('evaluates @index on a surface without a default catalog', () => {
            const base = new Catalog('base', '1.0', [textApi]);
            const proc = new MessageProcessor([base]);
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            {
                                id: 'root',
                                component: 'Text',
                                catalogId: 'base',
                                text: { '@call': '@index', args: { offset: 1 } },
                            },
                        ],
                    },
                },
            ]);
            const surface = proc.getSurface('s');
            const errors = [];
            surface.onError.subscribe(err => {
                errors.push(err);
            });
            const text = surface.componentsModel.get('root')?.properties['text'];
            const context = new DataContext(surface, '/items/2');
            assert.strictEqual(context.resolveDynamicValue(text), 3);
            assert.strictEqual(peekValue(context.resolveSignal(text)), 3);
            assert.deepStrictEqual(errors, []);
        });
        it('tolerates an unknown function in the surface default without a validationConfig', () => {
            const base = new Catalog('base', '1.0', [textApi]);
            const proc = new MessageProcessor([base]);
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'base' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', text: { '@call': 'anything', args: {} } }],
                    },
                },
            ]);
            assert.ok(proc.getSurface('s')?.componentsModel.get('root'));
        });
        /** Processes a v1.0 surface on `base` whose root Text has the given `text`. */
        function processV10Text(proc, text) {
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'base' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', text }],
                    },
                },
            ]);
        }
        it('rejects a catalogId on an @index call even without a validationConfig', () => {
            const base = new Catalog('base', '1.0', [textApi]);
            const proc = new MessageProcessor([base]);
            assert.throws(() => processV10Text(proc, { '@call': '@index', catalogId: 'base' }), (err) => err instanceof A2uiValidationError &&
                /System function '@index' belongs to no catalog and must not name a catalogId/.test(err.message));
            assert.strictEqual(proc.getSurface('s')?.componentsModel.get('root'), undefined);
        });
        it('treats an empty catalogId on a call as a catalog name, not the surface default', () => {
            const base = new Catalog('base', '1.0', [textApi], [upperFn]);
            const proc = new MessageProcessor([base]);
            assert.throws(() => processV10Text(proc, { '@call': 'upper', catalogId: '', args: { value: 'x' } }), (err) => err instanceof A2uiCatalogError && err.message === 'Catalog not found: ');
        });
        it('treats an empty catalogId on a v1.0 component as a catalog name', () => {
            const base = new Catalog('base', '1.0', [textApi]);
            const proc = new MessageProcessor([base]);
            assert.throws(() => proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'base' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', component: 'Text', catalogId: '', text: 'x' }],
                    },
                },
            ]), (err) => err instanceof A2uiCatalogError && err.message === 'Catalog not found: ');
        });
        it('validates calls inside nested objects with keys named id or component', () => {
            const base = new Catalog('base', '1.0', [textApi], [upperFn]);
            for (const key of ['id', 'component']) {
                const proc = new MessageProcessor([base], undefined, {
                    validationConfig: STRICT_FUNCTIONS_ONLY,
                });
                assert.throws(() => processV10Text(proc, { [key]: { '@call': 'nope', args: {} } }), /Unrecognized function 'nope'/, key);
            }
        });
        it('validates a v0.9 call naming another catalogId against the surface catalog', () => {
            const v09Base = new Catalog('v09-base', '0.9', [textApi], [upperFn]);
            const v09Other = new Catalog('v09-other', '0.9', [textApi], [upperFn]);
            const proc = new MessageProcessor([v09Base, v09Other], undefined, {
                validationConfig: STRICT_FUNCTIONS_ONLY,
            });
            assert.throws(() => proc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'v09-base' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            {
                                id: 'root',
                                component: 'Text',
                                text: { call: 'nope', catalogId: 'v09-other', args: {} },
                            },
                        ],
                    },
                },
            ]), /Unrecognized function 'nope'/);
        });
        describe('nested calls in a component naming a catalog other than the surface default', () => {
            const lowerFn = createFunctionImplementation({
                name: 'lower',
                returnType: 'string',
                schema: z.object({ value: z.string() }).strict(),
            }, args => args.value.toLowerCase());
            /** Processes a v1.0 surface on `base` whose root component is `root`. */
            function processRoot(proc, root) {
                proc.processMessages([
                    { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'base' } },
                    { version: '1.0', updateComponents: { surfaceId: 's', components: [root] } },
                ]);
            }
            function newProcessor() {
                const base = new Catalog('base', '1.0', [textApi], [upperFn]);
                const custom = new Catalog('custom', '1.0', [textApi], [lowerFn]);
                return new MessageProcessor([base, custom], undefined, {
                    validationConfig: STRICT_FUNCTIONS_ONLY,
                });
            }
            it('accepts a catalogless call to a function only in the surface default', () => {
                const proc = newProcessor();
                processRoot(proc, {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'upper', args: { value: 'x' } },
                });
                assert.ok(proc.getSurface('s')?.componentsModel.get('root'));
            });
            it('rejects an unknown catalogless call in a component naming the surface default', () => {
                // A component naming the surface default is in the catalog its
                // catalogless calls run in, so component validation checks them.
                assert.throws(() => processRoot(newProcessor(), {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'base',
                    text: { '@call': 'noSuchFn' },
                }), (err) => err instanceof A2uiValidationError &&
                    (err.message.match(/Unrecognized function 'noSuchFn'/g) ?? []).length === 1);
            });
            it('checks a catalogless call in a component naming the surface default once', () => {
                let checks = 0;
                const countedFn = createFunctionImplementation({
                    name: 'counted',
                    returnType: 'string',
                    schema: z
                        .object({
                        value: z.string().refine(() => {
                            checks++;
                            return true;
                        }),
                    })
                        .strict(),
                }, args => args.value);
                const base = new Catalog('base', '1.0', [textApi], [countedFn]);
                const custom = new Catalog('custom', '1.0', [textApi], [lowerFn]);
                const proc = new MessageProcessor([base, custom], undefined, {
                    validationConfig: STRICT_FUNCTIONS_ONLY,
                });
                processRoot(proc, {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'base',
                    text: { '@call': 'counted', args: { value: 'x' } },
                });
                assert.ok(proc.getSurface('s')?.componentsModel.get('root'));
                assert.strictEqual(checks, 1);
            });
            it('checks a catalogless call against the surface default', () => {
                assert.throws(() => processRoot(newProcessor(), {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'upper', args: { value: 3 } },
                }), /Validation failed for function 'upper'/);
                assert.throws(() => processRoot(newProcessor(), {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'lower', args: { value: 'x' } },
                }), /Unrecognized function 'lower'/);
            });
            it("checks a call naming the component's catalog against that catalog", () => {
                const proc = newProcessor();
                processRoot(proc, {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'lower', catalogId: 'custom', args: { value: 'X' } },
                });
                assert.ok(proc.getSurface('s')?.componentsModel.get('root'));
                assert.throws(() => processRoot(newProcessor(), {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'lower', catalogId: 'custom', args: { value: 3 } },
                }), /Validation failed for function 'lower'/);
                assert.throws(() => processRoot(newProcessor(), {
                    id: 'root',
                    component: 'Text',
                    catalogId: 'custom',
                    text: { '@call': 'upper', catalogId: 'custom', args: { value: 'x' } },
                }), /Unrecognized function 'upper'/);
            });
            it('checks the calls of a component type its catalog does not define', () => {
                const newProc = () => {
                    const base = new Catalog('base', '1.0', [textApi], [upperFn]);
                    const custom = new Catalog('custom', '1.0', [], [lowerFn]);
                    return new MessageProcessor([base, custom], undefined, {
                        validationConfig: { ...THEME_ONLY_VALIDATION, allowUnknownElements: true },
                    });
                };
                const widget = (catalogId, text) => ({
                    id: 'root',
                    component: 'Widget',
                    catalogId,
                    text,
                });
                // Component validation can't check the properties of an unknown type,
                // but it still checks the calls in them.
                assert.throws(() => processRoot(newProc(), widget('custom', { '@call': 'lower', catalogId: 'custom', args: { value: 3 } })), /Validation failed for function 'lower'/);
                assert.throws(() => processRoot(newProc(), widget('base', { '@call': 'upper', args: { value: 3 } })), /Validation failed for function 'upper'/);
                // Reserved system functions too.
                assert.throws(() => processRoot(newProc(), widget('base', { '@call': '@index', catalogId: 'base' })), /System function '@index' belongs to no catalog and must not name a catalogId/);
                assert.throws(() => processRoot(newProc(), widget('base', { '@call': '@index', args: { offset: 'one' } })), /Validation failed for function '@index'/);
                processRoot(newProc(), widget('base', { '@call': '@index', args: { offset: 1 } }));
            });
            it('rejects a non-string catalogId on a call', () => {
                const base = new Catalog('base', '1.0', [textApi], [upperFn]);
                for (const component of ['Text', 'Widget']) {
                    const proc = new MessageProcessor([base]);
                    assert.throws(() => processRoot(proc, {
                        id: 'root',
                        component,
                        text: { '@call': 'upper', catalogId: 7, args: { value: 'x' } },
                    }), (err) => err instanceof A2uiValidationError &&
                        err.message === "Function call 'upper' has a non-string 'catalogId'.", component);
                }
            });
            it('rejects a call with an empty name', () => {
                const base = new Catalog('base', '1.0', [textApi], [upperFn]);
                // `Widget` is unknown to the catalog; its call is checked all the same.
                for (const component of ['Text', 'Widget']) {
                    const proc = new MessageProcessor([base]);
                    assert.throws(() => processRoot(proc, { id: 'root', component, text: { '@call': '' } }), (err) => err instanceof A2uiValidationError &&
                        /Function name '' must be a valid UAX #31 identifier/.test(err.message), component);
                }
            });
            it('accepts a closed component schema in a named catalog', () => {
                const tagApi = { name: 'Tag', schema: z.object({ label: z.string() }).strict() };
                const closed = new Catalog('closed', '1.0', [tagApi]);
                const proc = new MessageProcessor([closed], undefined, {
                    validationConfig: STRICT_VALIDATION,
                });
                proc.processMessages([
                    { version: '1.0', createSurface: { surfaceId: 's' } },
                    {
                        version: '1.0',
                        updateComponents: {
                            surfaceId: 's',
                            components: [
                                { id: 'root', component: 'Tag', catalogId: 'closed', label: 'Hello' },
                            ],
                        },
                    },
                ]);
                assert.strictEqual(proc.model.getSurface('s')?.componentsModel.get('root')?.type, 'Tag');
            });
            it('rejects a non-string catalogId on a component', () => {
                const base = new Catalog('base', '1.0', [textApi], [upperFn]);
                for (const catalogId of [7, null, {}]) {
                    const proc = new MessageProcessor([base]);
                    assert.throws(() => processRoot(proc, { id: 'root', component: 'Text', catalogId, text: 'x' }), A2uiValidationError, String(catalogId));
                }
            });
            it('reports a bad argument name in a call to another catalog once', () => {
                const proc = newProcessor();
                assert.throws(() => processRoot(proc, {
                    id: 'root',
                    component: 'Text',
                    text: { '@call': 'lower', catalogId: 'custom', args: { '1bad': 'v' } },
                }), (err) => err instanceof A2uiValidationError &&
                    err.message.split("Function argument '1bad'").length === 2);
            });
        });
        it('reports component and function catalog faults with the same messages', () => {
            const base = new Catalog('base', '1.0', [textApi], [upperFn]);
            const v09 = new Catalog('v09', '0.9', [textApi], [upperFn]);
            const cases = [
                [
                    { id: 'root', component: 'Text', catalogId: 'missing', text: 'x' },
                    'Catalog not found: missing',
                ],
                [
                    {
                        id: 'root',
                        component: 'Text',
                        catalogId: 'base',
                        text: { '@call': 'upper', catalogId: 'missing' },
                    },
                    'Catalog not found: missing',
                ],
                [
                    { id: 'root', component: 'Text', catalogId: 'v09', text: 'x' },
                    "Component 'root' names catalog 'v09', whose specification version (0.9) does not match surface 's' version (1.0).",
                ],
                [
                    {
                        id: 'root',
                        component: 'Text',
                        catalogId: 'base',
                        text: { '@call': 'upper', catalogId: 'v09' },
                    },
                    "Function call 'upper' names catalog 'v09', whose specification version (0.9) does not match surface 's' version (1.0).",
                ],
                [
                    { id: 'root', component: 'Text', text: 'x' },
                    "Component 'root' names no catalogId and surface 's' has no default catalogId.",
                ],
                [
                    { id: 'root', component: 'Text', catalogId: 'base', text: { '@call': 'upper' } },
                    "Function call 'upper' names no catalogId and surface 's' has no default catalogId.",
                ],
            ];
            for (const [component, message] of cases) {
                const proc = new MessageProcessor([base, v09]);
                assert.throws(() => proc.processMessages([
                    { version: '1.0', createSurface: { surfaceId: 's' } },
                    { version: '1.0', updateComponents: { surfaceId: 's', components: [component] } },
                ]), (err) => err instanceof A2uiCatalogError && err.message === message, message);
            }
        });
        it('maps errors to ErrorMessage and emits via errorHandler, onError, and processMessagesWithErrors', () => {
            const strictTextApi = {
                name: 'Text',
                schema: z.object({ text: z.string() }).strict(),
            };
            const base = new Catalog('base', '1.0', [strictTextApi]);
            const handledErrors = [];
            const groupErrors = [];
            const proc = new MessageProcessor([base], undefined, {
                version: '1.0',
                errorHandler: msg => handledErrors.push(msg),
            });
            proc.model.onError.subscribe(err => {
                groupErrors.push(err);
            });
            proc.processMessages([{ version: '1.0', createSurface: { surfaceId: 's1', catalogId: 'base' } }]);
            const surfaceErrors = [];
            proc.getSurface('s1').onError.subscribe(err => {
                surfaceErrors.push(err);
            });
            const errors = proc.processMessagesWithErrors([
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's1',
                        components: [{ id: 'root', component: 'Text', text: 123 }],
                    },
                },
            ]);
            assert.strictEqual(errors.length, 1);
            assert.strictEqual(errors[0].version, '1.0');
            assert.strictEqual(errors[0].error.code, 'VALIDATION_FAILED');
            assert.strictEqual(errors[0].error.surfaceId, 's1');
            assert.strictEqual(errors[0].error.path, '/components/0/text');
            assert.strictEqual(handledErrors.length, 1);
            assert.strictEqual(surfaceErrors.length, 1);
            assert.strictEqual(groupErrors.length, 1);
        });
        it('maps callRendererFunction envelope faults to INVALID_FUNCTION_CALL with functionCallId', () => {
            const ctx = extractEnvelopeErrorContext({
                version: '1.0',
                callRendererFunction: {
                    functionCallId: 'fn-99',
                    callFunction: { call: 'foo', catalogId: 'cat', args: 'bad' },
                },
            });
            assert.strictEqual(ctx.functionCallId, 'fn-99');
            const err = new A2uiValidationError('Bad args', undefined, 'VALIDATION_FAILED', {
                functionCallId: 'fn-99',
            });
            const mapped = mapErrorToRendererMessage(err, ctx);
            assert.strictEqual(mapped.error.code, 'INVALID_FUNCTION_CALL');
            assert.strictEqual(mapped.error.functionCallId, 'fn-99');
            assert.strictEqual(mapped.error.surfaceId, undefined);
            assert.strictEqual(mapped.error.path, undefined);
        });
        it('attributes prepareOperations parse errors to the failing item in multi-message arrays', async () => {
            const textApi = { name: 'Text', schema: z.object({ text: z.string() }) };
            const v09Cat = new Catalog('cat-v09', '0.9', [textApi]);
            const v10Cat = new Catalog('cat-v10', '1.0', [textApi]);
            const handledErrors = [];
            const proc = new MessageProcessor([v09Cat, v10Cat], undefined, {
                errorHandler: msg => handledErrors.push(msg),
            });
            assert.throws(() => {
                proc.processMessages([
                    { version: 'v0.9', createSurface: { surfaceId: 's1', catalogId: 'cat-v09' } },
                    { version: '1.0', updateComponents: { surfaceId: 's2', components: 'not-an-array' } },
                ]);
            });
            assert.strictEqual(proc.getSurface('s1'), undefined);
            assert.strictEqual(handledErrors.length, 1);
            assert.strictEqual(handledErrors[0].version, '1.0');
            assert.strictEqual(handledErrors[0].error.surfaceId, 's2');
            handledErrors.length = 0;
            await assert.rejects(async () => {
                await proc.processMessagesAsync([
                    { version: 'v0.9', createSurface: { surfaceId: 's1', catalogId: 'cat-v09' } },
                    {
                        version: '1.0',
                        callRendererFunction: {
                            functionCallId: 'fn-item-2',
                            callFunction: { call: 'missingFn', catalogId: 'cat-v10', args: 'invalid' },
                        },
                    },
                ]);
            });
            assert.strictEqual(proc.getSurface('s1'), undefined);
            assert.strictEqual(handledErrors.length, 1);
            assert.strictEqual(handledErrors[0].version, '1.0');
            assert.strictEqual(handledErrors[0].error.code, 'INVALID_FUNCTION_CALL');
            assert.strictEqual(handledErrors[0].error.functionCallId, 'fn-item-2');
            assert.strictEqual(handledErrors[0].error.surfaceId, undefined);
        });
        it('rejects callRendererFunction without catalogId with scoped validation error and INVALID_FUNCTION_CALL error report (#3529)', async () => {
            const v10Cat = new Catalog('https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json', '1.0', [], BASIC_FUNCTIONS);
            const handledErrors = [];
            const outboundMessages = [];
            const proc = new MessageProcessor([v10Cat], undefined, {
                errorHandler: msg => handledErrors.push(msg),
                outboundListener: msg => {
                    outboundMessages.push(msg);
                },
            });
            const missingCatalogPayload = [
                {
                    version: '1.0',
                    callRendererFunction: {
                        functionCallId: 'f1',
                        callFunction: { '@call': 'formatString', args: { value: 'x' } },
                    },
                },
            ];
            const expectedMessage = 'Invalid 1.0 message: callRendererFunction.callFunction.catalogId: Expected string, received undefined';
            assert.throws(() => proc.processMessages(missingCatalogPayload), (err) => {
                assert.ok(err instanceof A2uiValidationError);
                assert.strictEqual(err.message, expectedMessage);
                assert.strictEqual(err.functionCallId, 'f1');
                return true;
            });
            assert.strictEqual(outboundMessages.length, 0);
            assert.deepStrictEqual(handledErrors, [
                {
                    version: '1.0',
                    error: {
                        code: 'INVALID_FUNCTION_CALL',
                        functionCallId: 'f1',
                        message: expectedMessage,
                    },
                },
            ]);
            handledErrors.length = 0;
            await assert.rejects(() => proc.processMessagesAsync(missingCatalogPayload), (err) => {
                assert.ok(err instanceof A2uiValidationError);
                assert.strictEqual(err.message, expectedMessage);
                assert.strictEqual(err.functionCallId, 'f1');
                return true;
            });
            assert.strictEqual(outboundMessages.length, 0);
            assert.deepStrictEqual(handledErrors, [
                {
                    version: '1.0',
                    error: {
                        code: 'INVALID_FUNCTION_CALL',
                        functionCallId: 'f1',
                        message: expectedMessage,
                    },
                },
            ]);
            const reportOnlyErrors = [];
            const reportOnlyOutbound = [];
            const reportOnlyProc = new MessageProcessor([v10Cat], undefined, {
                reportErrorsOnly: true,
                errorHandler: msg => reportOnlyErrors.push(msg),
                outboundListener: msg => {
                    reportOnlyOutbound.push(msg);
                },
            });
            reportOnlyProc.processMessages(missingCatalogPayload);
            const asyncResponses = await reportOnlyProc.processMessagesAsync(missingCatalogPayload);
            assert.deepStrictEqual(asyncResponses, []);
            assert.strictEqual(reportOnlyOutbound.length, 0);
            assert.strictEqual(reportOnlyErrors.length, 2);
            assert.strictEqual(reportOnlyErrors[0].error.code, 'INVALID_FUNCTION_CALL');
            assert.strictEqual(reportOnlyErrors[0].error.functionCallId, 'f1');
            assert.strictEqual(reportOnlyErrors[0].error.message, expectedMessage);
        });
        it('writes createSurface dataModel per top-level key with RFC 6901 escaping before resolving components', () => {
            const counterApi = {
                name: 'Counter',
                schema: z.object({
                    count: z.union([z.number(), z.object({ '@path': z.string() })]),
                }),
            };
            const cat = new Catalog('cat-v10', '1.0', [counterApi]);
            const proc = new MessageProcessor([cat]);
            let rootNotifications = 0;
            const surfaceErrors = [];
            let resolver;
            proc.model.onSurfaceCreated.subscribe(surface => {
                surface.dataModel.subscribe('/', () => {
                    rootNotifications++;
                });
                surface.onError.subscribe(err => {
                    surfaceErrors.push(err);
                });
                resolver = new NodeResolver(surface, cat);
            });
            proc.processMessages([
                {
                    version: '1.0',
                    createSurface: {
                        surfaceId: 's1',
                        catalogId: 'cat-v10',
                        dataModel: { a: 1, 'x/y~z': { c: 2 } },
                        components: [
                            {
                                id: 'root',
                                component: 'Counter',
                                count: { '@path': '/x~1y~0z/c' },
                            },
                        ],
                    },
                },
            ]);
            const surface = proc.getSurface('s1');
            assert.strictEqual(rootNotifications, 2);
            assert.strictEqual(surface.dataModel.get('/x~1y~0z/c'), 2);
            assert.deepStrictEqual(surfaceErrors, []);
            const rootNode = peekValue(resolver.rootNode);
            assert.ok(rootNode);
            const rootProps = peekValue(rootNode.props);
            assert.ok(rootProps['count'] instanceof ResolvedBinding);
            assert.strictEqual(rootProps['count'].value, 2);
            resolver?.dispose();
            proc.dispose();
        });
    });
    describe('unifiedOutbound', () => {
        const v10Catalog = new Catalog('cat-v10', '1.0', BASIC_COMPONENTS);
        const v09Catalog = new Catalog('cat-v09', '0.9', [CardApi, RowApi]);
        it('throws A2uiValidationError when unifiedOutbound is true without outboundListener', () => {
            assert.throws(() => new MessageProcessor([v10Catalog], undefined, { unifiedOutbound: true }), (err) => {
                assert.ok(err instanceof A2uiValidationError);
                assert.match(err.message, /unifiedOutbound requires an outboundListener/);
                return true;
            });
        });
        it('defaults to off so actions and errors do not reach outboundListener', async () => {
            const actionLog = [];
            const errorLog = [];
            const outboundLog = [];
            const proc = new MessageProcessor([v10Catalog], a => {
                actionLog.push(a);
            }, {
                errorHandler: err => {
                    errorLog.push(err);
                },
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                reportErrorsOnly: true,
            });
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'cat-v10' },
            });
            await proc
                .getSurface('s1')
                .dispatchAction({ event: { name: 'click', context: { ok: true } } }, 'btn-1');
            proc.processMessages({
                version: '1.0',
                updateComponents: { surfaceId: 'missing-surface', components: [] },
            });
            assert.strictEqual(actionLog.length, 1);
            assert.strictEqual(errorLog.length, 1);
            assert.deepStrictEqual(outboundLog, []);
        });
        it('forwards actions from 1.0, v0.9, and v0.9.1 surfaces to outboundListener and still fires actionHandler', async () => {
            const actionLog = [];
            const outboundLog = [];
            const proc = new MessageProcessor([v10Catalog, v09Catalog], a => {
                actionLog.push(a);
            }, {
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                unifiedOutbound: true,
            });
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's-10', catalogId: 'cat-v10' } },
                { version: 'v0.9', createSurface: { surfaceId: 's-09', catalogId: 'cat-v09' } },
                { version: 'v0.9.1', createSurface: { surfaceId: 's-091', catalogId: 'cat-v09' } },
            ]);
            await proc.getSurface('s-10').dispatchAction({
                event: {
                    name: 'submit',
                    context: { item: 1 },
                    catalogId: 'cat-v10',
                    userMessage: 'Submitted 1.0',
                },
            }, 'btn-10', { extensions: { vendor_tag: 'v1' } });
            await proc.getSurface('s-09').dispatchAction({
                event: {
                    name: 'select',
                    context: { item: 2 },
                },
            }, 'btn-09');
            await proc.getSurface('s-091').dispatchAction({
                event: {
                    name: 'confirm',
                    context: { item: 3 },
                    catalogId: 'cat-v09',
                },
            }, 'btn-091');
            assert.strictEqual(actionLog.length, 3);
            assert.strictEqual(outboundLog.length, 3);
            assert.strictEqual(outboundLog[0].version, '1.0');
            assert.strictEqual(outboundLog[0].action.name, 'submit');
            assert.strictEqual(outboundLog[0].action.surfaceId, 's-10');
            assert.strictEqual(outboundLog[0].action.sourceComponentId, 'btn-10');
            assert.strictEqual(typeof outboundLog[0].action.timestamp, 'string');
            assert.deepStrictEqual(outboundLog[0].action.context, { item: 1 });
            assert.strictEqual(outboundLog[0].action.catalogId, 'cat-v10');
            assert.strictEqual(outboundLog[0].action.userMessage, 'Submitted 1.0');
            assert.deepStrictEqual(outboundLog[0].action.metadata, { extensions: { vendor_tag: 'v1' } });
            assert.strictEqual(outboundLog[1].version, 'v0.9');
            assert.strictEqual(outboundLog[1].action.name, 'select');
            assert.strictEqual(outboundLog[1].action.surfaceId, 's-09');
            assert.strictEqual(outboundLog[1].action.sourceComponentId, 'btn-09');
            assert.deepStrictEqual(outboundLog[1].action.context, { item: 2 });
            assert.strictEqual('catalogId' in outboundLog[1].action, false);
            assert.strictEqual(outboundLog[2].version, 'v0.9.1');
            assert.strictEqual(outboundLog[2].action.name, 'confirm');
            assert.strictEqual(outboundLog[2].action.surfaceId, 's-091');
            assert.strictEqual(outboundLog[2].action.sourceComponentId, 'btn-091');
            assert.deepStrictEqual(outboundLog[2].action.context, { item: 3 });
            assert.strictEqual(outboundLog[2].action.catalogId, 'cat-v09');
        });
        it('uses the fallback wire version when a surface has no protocolVersion', async () => {
            const v10Out = [];
            const v10Proc = new MessageProcessor([v10Catalog], undefined, {
                outboundListener: msg => {
                    v10Out.push(msg);
                },
                unifiedOutbound: true,
            });
            const unversionedV10Surface = new SurfaceModel('s-unver-10', undefined, new Map());
            assert.strictEqual(unversionedV10Surface.protocolVersion, undefined);
            v10Proc.model.addSurface(unversionedV10Surface);
            await unversionedV10Surface.dispatchAction({ event: { name: 'act1', context: {} } }, 'c1');
            assert.strictEqual(v10Out.length, 1);
            assert.strictEqual(v10Out[0].version, '1.0');
            const mixedOut = [];
            const mixedProc = new MessageProcessor([v10Catalog, v09Catalog], undefined, {
                outboundListener: msg => {
                    mixedOut.push(msg);
                },
                unifiedOutbound: true,
            });
            const unversionedMixedSurface = new SurfaceModel('s-unver-mixed', undefined, new Map());
            assert.strictEqual(unversionedMixedSurface.protocolVersion, undefined);
            mixedProc.model.addSurface(unversionedMixedSurface);
            await unversionedMixedSurface.dispatchAction({ event: { name: 'act2', context: {} } }, 'c2');
            assert.strictEqual(mixedOut.length, 1);
            assert.strictEqual(mixedOut[0].version, 'v0.9');
            const explicitDefaultOut = [];
            const explicitDefaultProc = new MessageProcessor([v10Catalog, v09Catalog], undefined, {
                version: 'v0.9.1',
                outboundListener: msg => {
                    explicitDefaultOut.push(msg);
                },
                unifiedOutbound: true,
            });
            const unversionedExplicitSurface = new SurfaceModel('s-unver-exp', undefined, new Map());
            assert.strictEqual(unversionedExplicitSurface.protocolVersion, undefined);
            explicitDefaultProc.model.addSurface(unversionedExplicitSurface);
            await unversionedExplicitSurface.dispatchAction({ event: { name: 'act3', context: {} } }, 'c3');
            assert.strictEqual(explicitDefaultOut.length, 1);
            assert.strictEqual(explicitDefaultOut[0].version, 'v0.9.1');
            const unparseableSurface = new SurfaceModel('s-unparseable', undefined, new Map(), undefined, false, undefined, 'root', undefined, 'not-a-semver');
            assert.strictEqual(unparseableSurface.protocolVersion, 'not-a-semver');
            v10Proc.model.addSurface(unparseableSurface);
            await unparseableSurface.dispatchAction({ event: { name: 'act4', context: {} } }, 'c4');
            assert.strictEqual(v10Out.length, 1);
        });
        it('forwards processing errors to outboundListener and still fires errorHandler', () => {
            const errorLog = [];
            const outboundLog = [];
            const proc = new MessageProcessor([v10Catalog], undefined, {
                errorHandler: err => {
                    errorLog.push(err);
                },
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            proc.processMessages({
                version: '1.0',
                updateComponents: {
                    surfaceId: 'nonexistent',
                    components: [{ id: 'root', component: 'Text', text: 'hi' }],
                },
            });
            assert.strictEqual(errorLog.length, 1);
            assert.strictEqual(outboundLog.length, 1);
            assert.deepStrictEqual(outboundLog[0], errorLog[0]);
            assert.strictEqual(outboundLog[0].version, '1.0');
            assert.strictEqual(outboundLog[0].error.code, 'INTEGRITY_ERROR');
        });
        it('does not forward v0.8 actions or v0.8 errors to outboundListener', async () => {
            const v08Cat = new Catalog('cat-v08', '0.8', []);
            const actionLog = [];
            const errorLog = [];
            const outboundLog = [];
            const proc = new MessageProcessor([v08Cat], a => {
                actionLog.push(a);
            }, {
                version: 'v0.8',
                errorHandler: err => {
                    errorLog.push(err);
                },
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            proc.processMessages({
                beginRendering: { surfaceId: 's-08', root: 'root', catalogId: 'cat-v08' },
            });
            await proc
                .getSurface('s-08')
                .dispatchAction({ event: { name: 'legacyClick', context: {} } }, 'btn-08');
            proc.processMessages({
                surfaceUpdate: { surfaceId: 'missing-08', components: [] },
            });
            assert.strictEqual(actionLog.length, 1);
            assert.strictEqual(errorLog.length, 1);
            assert.strictEqual(errorLog[0].version, 'v0.8');
            assert.deepStrictEqual(outboundLog, []);
            // Also verify v0.8 errors are suppressed when options.version is omitted,
            // and unversioned errors on a 1.0-only processor use fallbackWireVersion().
            const unversionedV08Outbound = [];
            const unversionedV08Proc = new MessageProcessor([v08Cat, v10Catalog], undefined, {
                outboundListener: msg => {
                    unversionedV08Outbound.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            unversionedV08Proc.processMessages({
                surfaceUpdate: { surfaceId: 'missing-08-unver', components: [] },
            });
            assert.deepStrictEqual(unversionedV08Outbound, []);
            const v08OnlyOutbound = [];
            const v08OnlyProc = new MessageProcessor([v08Cat], undefined, {
                outboundListener: msg => {
                    v08OnlyOutbound.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            v08OnlyProc.processMessages('not-an-object');
            assert.deepStrictEqual(v08OnlyOutbound, []);
            const v10OnlyOutbound = [];
            const v10OnlyProc = new MessageProcessor([v10Catalog], undefined, {
                outboundListener: msg => {
                    v10OnlyOutbound.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            v10OnlyProc.processMessages('not-an-object');
            assert.strictEqual(v10OnlyOutbound.length, 1);
            assert.strictEqual(v10OnlyOutbound[0].version, '1.0');
        });
        it('resolves surface protocolVersion before actionHandler deletes the surface', async () => {
            const outboundLog = [];
            const proc = new MessageProcessor([v10Catalog, v09Catalog], action => {
                proc.model.deleteSurface(action.surfaceId);
            }, {
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                unifiedOutbound: true,
            });
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's-dismiss', catalogId: 'cat-v10' },
            });
            const surface = proc.getSurface('s-dismiss');
            await surface.dispatchAction({ event: { name: 'dismiss', context: {} } }, 'btn-dismiss');
            assert.strictEqual(proc.getSurface('s-dismiss'), undefined);
            assert.strictEqual(outboundLog.length, 1);
            assert.strictEqual(outboundLog[0].version, '1.0');
            assert.strictEqual(outboundLog[0].action.name, 'dismiss');
        });
        it('stops forwarding actions and errors after dispose()', async () => {
            const outboundLog = [];
            const proc = new MessageProcessor([v10Catalog], undefined, {
                outboundListener: msg => {
                    outboundLog.push(msg);
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'cat-v10' },
            });
            const surface = proc.getSurface('s1');
            proc.dispose();
            await surface.dispatchAction({ event: { name: 'afterDispose', context: {} } }, 'btn');
            proc.processMessages({
                version: '1.0',
                updateComponents: { surfaceId: 'missing', components: [] },
            });
            assert.deepStrictEqual(outboundLog, []);
        });
        it('catches synchronous throws and async rejections from outboundListener without breaking dispatch', async () => {
            const actionLog = [];
            const errorLog = [];
            let callCount = 0;
            const proc = new MessageProcessor([v10Catalog], a => {
                actionLog.push(a);
            }, {
                errorHandler: err => {
                    errorLog.push(err);
                },
                outboundListener: () => {
                    callCount++;
                    if (callCount % 2 === 1) {
                        throw new Error('sync transport failure');
                    }
                    return Promise.reject(new Error('async transport failure'));
                },
                unifiedOutbound: true,
                reportErrorsOnly: true,
            });
            proc.processMessages({
                version: '1.0',
                createSurface: { surfaceId: 's1', catalogId: 'cat-v10' },
            });
            await proc.getSurface('s1').dispatchAction({ event: { name: 'a1', context: {} } }, 'btn');
            await proc.getSurface('s1').dispatchAction({ event: { name: 'a2', context: {} } }, 'btn');
            proc.processMessages({
                version: '1.0',
                updateComponents: { surfaceId: 'missing-1', components: [] },
            });
            proc.processMessages({
                version: '1.0',
                updateComponents: { surfaceId: 'missing-2', components: [] },
            });
            assert.strictEqual(callCount, 4);
            assert.strictEqual(actionLog.length, 2);
            assert.strictEqual(errorLog.length, 2);
        });
    });
});
describe('MessageProcessor component envelope mixins', () => {
    /** A catalog whose `GcbpTable` declares its own `metadata` and `catalogId`. */
    function gcbpCatalog(catalogId, protocolVersion) {
        return Catalog.fromJson({
            catalogId,
            protocolVersion,
            components: {
                GcbpTable: {
                    type: 'object',
                    properties: {
                        metadata: {
                            type: 'object',
                            properties: { pageNumber: { type: 'number' }, pageSize: { type: 'number' } },
                            additionalProperties: false,
                        },
                        catalogId: { type: 'string' },
                        accessibility: { type: 'string' },
                    },
                    additionalProperties: false,
                },
                Field: {
                    type: 'object',
                    allOf: [
                        { $ref: 'common_types.json#/$defs/Checkable' },
                        { type: 'object', properties: { label: { type: 'string' } } },
                    ],
                    unevaluatedProperties: false,
                },
            },
        });
    }
    describe('below v1.0', () => {
        it('keeps metadata and catalogId as properties across full and partial updates (#4012)', () => {
            const proc = new MessageProcessor([gcbpCatalog('gcbp', '0.9')], undefined, {
                validationConfig: STRICT_VALIDATION,
            });
            proc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'gcbp' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            {
                                id: 'root',
                                component: 'GcbpTable',
                                metadata: { pageNumber: 0, pageSize: 10 },
                                catalogId: 'source-a',
                            },
                        ],
                    },
                },
            ]);
            const root = () => proc.getSurface('s').componentsModel.get('root');
            assert.deepStrictEqual(root().properties, {
                metadata: { pageNumber: 0, pageSize: 10 },
                catalogId: 'source-a',
            });
            assert.strictEqual(root().metadata, undefined);
            assert.strictEqual(root().catalog.id, 'gcbp');
            proc.processMessages([
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [{ id: 'root', metadata: { pageNumber: 1, pageSize: 10 }, catalogId: 'b' }],
                    },
                },
            ]);
            assert.deepStrictEqual(root().properties, {
                metadata: { pageNumber: 1, pageSize: 10 },
                catalogId: 'b',
            });
            assert.strictEqual(root().metadata, undefined);
            proc.dispose();
        });
        it('rejects @-prefixed envelope keys', () => {
            const proc = new MessageProcessor([gcbpCatalog('gcbp', '0.9')]);
            assert.throws(() => proc.processMessages([
                { version: 'v0.9', createSurface: { surfaceId: 's', catalogId: 'gcbp' } },
                {
                    version: 'v0.9',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            { id: 'root', component: 'GcbpTable', '@metadata': { extensions: { com_a: 1 } } },
                        ],
                    },
                },
            ]), A2uiValidationError);
            proc.dispose();
        });
    });
    describe('from v1.0', () => {
        function process(proc, components) {
            proc.processMessages([
                { version: '1.0', updateComponents: { surfaceId: 's', components } },
            ]);
        }
        function v10Processor(...catalogs) {
            const proc = new MessageProcessor(catalogs, undefined, {
                validationConfig: STRICT_VALIDATION,
            });
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: catalogs[0].id } },
            ]);
            return proc;
        }
        it('stores @-prefixed mixins in the component model', () => {
            const proc = v10Processor(gcbpCatalog('main', '1.0'), gcbpCatalog('other', '1.0'));
            process(proc, [
                {
                    'id': 'root',
                    'component': 'Field',
                    'label': 'Email',
                    '@catalogId': 'other',
                    '@metadata': { extensions: { com_example_trace: 't1' } },
                    '@accessibility': { label: 'Email address' },
                    '@checks': [{ condition: true, message: 'Required' }],
                },
            ]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.strictEqual(root.catalog.id, 'other');
            assert.deepStrictEqual(root.metadata, { extensions: { com_example_trace: 't1' } });
            assert.deepStrictEqual(root.properties, {
                'label': 'Email',
                '@accessibility': { label: 'Email address' },
                '@checks': [{ condition: true, message: 'Required' }],
            });
            proc.dispose();
        });
        it('reads legacy bare mixins the component schema does not declare', () => {
            const proc = v10Processor(gcbpCatalog('main', '1.0'), gcbpCatalog('other', '1.0'));
            process(proc, [
                {
                    id: 'root',
                    component: 'Field',
                    label: 'Email',
                    catalogId: 'other',
                    metadata: { extensions: { com_example_trace: 't1' } },
                    accessibility: { label: 'Email address' },
                    checks: [{ condition: true, message: 'Required' }],
                },
            ]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.strictEqual(root.catalog.id, 'other');
            assert.deepStrictEqual(root.metadata, { extensions: { com_example_trace: 't1' } });
            assert.deepStrictEqual(root.properties, {
                'label': 'Email',
                '@accessibility': { label: 'Email address' },
                '@checks': [{ condition: true, message: 'Required' }],
            });
            proc.dispose();
        });
        it('keeps custom properties beside the @-prefixed mixins (#1376)', () => {
            const proc = v10Processor(gcbpCatalog('main', '1.0'));
            process(proc, [
                {
                    'id': 'root',
                    'component': 'GcbpTable',
                    'metadata': { pageNumber: 0 },
                    'catalogId': 'not-a-catalog',
                    'accessibility': 'compact',
                    '@metadata': { extensions: { com_example_vendor: 'acme' } },
                    '@accessibility': { label: 'Table' },
                },
            ]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.strictEqual(root.catalog.id, 'main');
            assert.deepStrictEqual(root.metadata, { extensions: { com_example_vendor: 'acme' } });
            assert.deepStrictEqual(root.properties, {
                'metadata': { pageNumber: 0 },
                'catalogId': 'not-a-catalog',
                'accessibility': 'compact',
                '@accessibility': { label: 'Table' },
            });
            proc.dispose();
        });
        it('reads a legacy bare catalogId by the default catalog for routing and storage', () => {
            // `Text` declares no `catalogId` in the surface default, so a bare
            // `catalogId` routes the component, even though the target catalog's
            // `Text` declares a `catalogId` property of its own.
            const plainText = { name: 'Text', schema: z.object({ text: z.any() }).strict() };
            const textWithCatalogId = {
                name: 'Text',
                schema: z.object({ text: z.any(), catalogId: z.string().optional() }).strict(),
            };
            const proc = v10Processor(new Catalog('main', '1.0', [plainText]), new Catalog('other', '1.0', [textWithCatalogId]));
            process(proc, [{ id: 'root', component: 'Text', text: 'Hi', catalogId: 'other' }]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.strictEqual(root.catalog.id, 'other');
            assert.deepStrictEqual(root.properties, { text: 'Hi' });
            proc.dispose();
        });
        it('serializes @metadata when an optional custom metadata is omitted', () => {
            const chart = {
                name: 'Chart',
                schema: z.object({ title: z.string(), metadata: z.string().optional() }).strict(),
            };
            const proc = v10Processor(new Catalog('main', '1.0', [chart]));
            process(proc, [
                {
                    'id': 'root',
                    'component': 'Chart',
                    'title': 'Sales',
                    '@metadata': { extensions: { com_example_trace: 't1' } },
                },
            ]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.deepStrictEqual(root.properties, { title: 'Sales' });
            assert.deepStrictEqual(root.componentTree, {
                'id': 'root',
                'component': 'Chart',
                'title': 'Sales',
                '@metadata': { extensions: { com_example_trace: 't1' } },
            });
            proc.dispose();
        });
        it('keeps a bare metadata declared in a union option as a property', () => {
            const widget = {
                name: 'Widget',
                schema: z.union([
                    z.object({ kind: z.literal('a'), metadata: z.string().optional() }).strict(),
                    z.object({ kind: z.literal('b'), label: z.string().optional() }).strict(),
                ]),
            };
            const proc = v10Processor(new Catalog('main', '1.0', [widget]));
            process(proc, [
                {
                    'id': 'root',
                    'component': 'Widget',
                    'kind': 'a',
                    'metadata': 'x',
                    '@metadata': { extensions: { com_example_trace: 't1' } },
                },
            ]);
            const root = proc.getSurface('s').componentsModel.get('root');
            assert.deepStrictEqual(root.properties, { kind: 'a', metadata: 'x' });
            assert.deepStrictEqual(root.metadata, { extensions: { com_example_trace: 't1' } });
            proc.dispose();
        });
        it('rejects @metadata with invalid extension keys and conflicting mixins', () => {
            const proc = v10Processor(gcbpCatalog('main', '1.0'));
            assert.throws(() => process(proc, [
                { 'id': 'root', 'component': 'Field', '@metadata': { extensions: { 'a.b': 1 } } },
            ]), A2uiValidationError);
            assert.throws(() => process(proc, [
                {
                    'id': 'root',
                    'component': 'Field',
                    '@accessibility': { label: 'New' },
                    'accessibility': { label: 'Old' },
                },
            ]), (err) => {
                assert.ok(err instanceof A2uiValidationError);
                assert.match(err.message, /cannot specify both '@accessibility' and legacy 'accessibility'/);
                assert.match(err.details[0].path, /\/@accessibility$/);
                return true;
            });
            proc.dispose();
        });
        it('evaluates @checks into validation props without exposing the rules', () => {
            const cat = gcbpCatalog('main', '1.0');
            const proc = new MessageProcessor([cat]);
            let resolver;
            proc.model.onSurfaceCreated.subscribe(surface => {
                resolver = new NodeResolver(surface, cat);
            });
            proc.processMessages([
                { version: '1.0', createSurface: { surfaceId: 's', catalogId: 'main' } },
                {
                    version: '1.0',
                    updateComponents: {
                        surfaceId: 's',
                        components: [
                            {
                                'id': 'root',
                                'component': 'Field',
                                '@accessibility': { label: 'Email address' },
                                '@checks': [{ condition: false, message: 'Required' }],
                            },
                        ],
                    },
                },
            ]);
            const props = peekValue(peekValue(resolver.rootNode).props);
            assert.strictEqual(props['isValid'], false);
            assert.deepStrictEqual(props['validationErrors'], ['Required']);
            assert.ok(!('@checks' in props));
            const accessibility = props['@accessibility'];
            const label = accessibility['label'];
            assert.strictEqual(label instanceof ResolvedBinding ? label.value : label, 'Email address');
            resolver?.dispose();
            proc.dispose();
        });
    });
});
//# sourceMappingURL=message-processor.test.js.map