export {};
//# sourceMappingURL=message-error-mapper.test.d.ts.map