export { CreateSurfaceMessageSchema, type CreateSurfaceMessage, UpdateComponentsMessageSchema, type UpdateComponentsMessage, UpdateDataModelMessageSchema, type UpdateDataModelMessage, DeleteSurfaceMessageSchema, type DeleteSurfaceMessage, CallRendererFunctionMessageSchema, type CallRendererFunctionMessage, AgentFunctionResponseMessageSchema, type AgentFunctionResponseMessage, AgentToRendererMessageSchema, type AgentToRendererMessage, FunctionCallValidationSchemaSchema, type FunctionCallValidationSchema, type FunctionCallValidationSchemaInput, FunctionDefinitionSchema, type FunctionDefinition, type FunctionDefinitionInput, LeafDefinitionSchema, type LeafDefinition, type LeafDefinitionInput, ComponentDefinitionSchema, type ComponentDefinition, type ComponentDefinitionInput, ValidationResultSchema, type ValidationResult, type ValidationResultInput, ComponentIdSchema, type ComponentId, CallIdSchema, type CallId, DataBindingSchema, type DataBinding, FunctionCommonSchema, type FunctionCommon, FunctionCallSchema, type FunctionCall, DynamicStringSchema, type DynamicString, DynamicBooleanSchema, type DynamicBoolean, AccessibilityAttributesSchema, type AccessibilityAttributes, ExtensionsSchema, ComponentCommonSchema, type ComponentCommon, ChildSchema, type Child, ChildListSchema, type ChildList, DynamicValueSchema, type DynamicValue, DynamicNumberSchema, type DynamicNumber, DynamicStringListSchema, type DynamicStringList, IndexSystemFunctionSchema, type IndexSystemFunction, CheckRuleSchema, type CheckRule, CheckableSchema, type Checkable, ActionSchema, type Action, SurfaceSchema, type Surface, FunctionResponseSchema, type FunctionResponse, CommonSchemas, V10RendererCapabilitiesSchema, type V10RendererCapabilities, ActionMessageSchema, type ActionMessage, CallAgentFunctionMessageSchema, type CallAgentFunctionMessage, RendererFunctionResponseMessageSchema, type RendererFunctionResponseMessage, ErrorMessageSchema, type ErrorMessage, RendererToAgentMessageSchema, type RendererToAgentMessage, type ChildRefKind, type RefSchemaOptions, markChildRef, childRefKindOf, TemplateChildListSchema, type TemplateChildList, componentId, dynamicString, dynamicNumber, dynamicBoolean, dynamicValue, dynamicStringList, childList, AnyComponentSchema, type AnyComponent, ComponentsListSchema, type ComponentsList, RendererCapabilitiesSchema, type RendererCapabilities, } from './schema/index.js';
export { V10_CHILD_REF_OPTIONS, V10_STANDARD_DEFS } from './standard_defs.js';
export { IndexApi, IndexImplementation, SYSTEM_FUNCTIONS } from './functions/system_functions.js';
export { RequiredV1Point0Api, RegexV1Point0Api, LengthV1Point0Api, NumericV1Point0Api, EmailV1Point0Api, V10_VALIDATION_FUNCTION_APIS, } from './functions/validation_functions_api.js';
export { RequiredV1Point0Implementation, RegexV1Point0Implementation, LengthV1Point0Implementation, NumericV1Point0Implementation, EmailV1Point0Implementation, V10_VALIDATION_FUNCTION_IMPLEMENTATIONS, } from './functions/validation_functions.js';
export { JsonComponentApi, JsonFunctionApi, spec, specDef, type SpecAnnotation, type SpecMixin, createFunctionImplementation, type ComponentChildRefs, AgentFunction, isAgentFunction, type AgentFunctionContext, type AgentFunctionHandler, type AgentFunctionInit, type A2uiReturnTypeMap, type A2uiReturnType, type InferA2uiReturnType, type FunctionApi, type JsonSchemaObject, type FunctionImplementation, type ResolvedDynamic, type ResolvedFunctionArgs, type ComponentApi, type InferredComponentApiSchemaType, type CatalogUnions, type CatalogDocumentOptions, type CatalogOptions, type CopyWithCatalogOptions, type DeriveCatalogOptions, type CatalogInterface, Catalog, type CatalogApi, type FunctionInvoker, } from '../catalog/index.js';
export { type ActionPayload, type A2uiErrorPayload, type A2uiWarningPayload, type ActionListener, type AgentFunctionCall, type AgentFunctionCallOptions, type AgentFunctionCaller, SurfaceModel, SurfaceGroupModel, SurfaceComponentsModel, ComponentModel, type DataSubscription, MAX_ARRAY_INDEX, DataModel, } from '../state/index.js';
export { mapErrorToRendererMessage, extractEnvelopeErrorContext, normalizeJsonPointer, type RendererErrorMessage, type A2uiRendererError, type ValidationFailedErrorBody, type GenericErrorBody, type ErrorEnvelopeContext, type ProcessableMessage, type ProcessableMessagePayload, type ClientCapabilities, type ValidationConfig, type OutboundActionMessage, type OutboundMessageListener, type CallOptions, STRICT_VALIDATION, RELAXED_VALIDATION, A2uiRpcError, RpcErrorCode, type ExecutionContext, type CapabilitiesOptions, type MessageProcessorOptions, formatZodIssue, MessageProcessor, VersionAdapterFactory, defaultVersionAdapterFactory, isCatalogVersionCompatible, registerKnownActionsProvider, type ProtocolVersion, SUPPORTED_PROTOCOL_VERSIONS, DEFAULT_CATALOG_COMPATIBILITY, type VersionAdapterResolver, type VersionAdapter, type KnownActionsProvider, BaseVersionAdapter, type A2uiErrorDetail, type A2uiErrorContext, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiCatalogError, A2uiIntegrityError, A2uiRecursionError, } from '../processing/index.js';
export { PLACEHOLDER_TYPE, isComponentNode, type ComponentNode, type NodeAction, type NodeProps, type NodeState, type MarkdownRenderer, type MarkdownRendererOptions, type MarkdownRendererTagClassMap, ComponentContext, getKnownSchemaKeys, validateFunctionArgs, isSingleAtKey, unescapeObjectKey, validateReservedDirectives, resolveContextIndex, MAX_DYNAMIC_VALUE_DEPTH, DataContext, scrapeComponentBehavior, scrapeSchemaBehavior, getSafeChildList, type BehaviorNode, type ResolveA2uiProp, type GenerateSetters, type ResolveA2uiProps, MAX_DYNAMIC_CHILD_LIST_SIZE, GenericBinder, NodeResolver, extractRefFields, type RefKind, type RefFields, isWritable, sameBinding, ResolvedBinding, WritableBinding, } from '../resolution/index.js';
export type { ResolvedChildRef } from '../resolution/index.js';
export { setSignalImplementation, signal, computed, effect, batchWrite, isSignal, getValue, setValue, peekValue, type Signal, type SignalImplementations, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, } from '../reactivity/index.js';
export { MAX_EXPRESSION_TEMPLATE_LENGTH, MAX_EXPRESSION_PARTS, ExpressionParser, } from '../expressions/index.js';
export { type RpcHandlerOptions, RpcHandler } from '../rpc/index.js';
export { PayloadValidator, getComponentReferences, validateRecursionAndPaths, MAX_GLOBAL_DEPTH, MAX_FUNC_CALL_DEPTH, RELAXED_PATH_PATTERN, type ChildRefAnalysis, type ChildRefAnalysisOptions, type ComponentRefMap, analyzeChildRefSchema, assertUax31Identifier, buildComponentRefMap, isChildListSchema, isChildOrChildListSchema, isChildSchema, isValidUax31Identifier, V08_CHILD_REF_OPTIONS, V09_CHILD_REF_OPTIONS, type TopologyOptions, } from '../validation/index.js';
export { type Subscription, type EventListener, type EventSource, EventEmitter, } from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, type A2uiMetadata, type Extensions, type ActionDispatchOptions, } from '../common/metadata.js';
export { BASIC_FUNCTIONS, createBasicCatalogFunctions, AndImplementation, OrImplementation, NotImplementation, FormatStringImplementation, FormatNumberImplementation, createFormatNumberImplementation, FormatCurrencyImplementation, createFormatCurrencyImplementation, FormatDateImplementation, createFormatDateImplementation, PluralizeImplementation, createPluralizeImplementation, OpenUrlImplementation, RequiredApi, RegexApi, LengthApi, NumericApi, EmailApi, FormatStringApi, FormatNumberApi, FormatCurrencyApi, FormatDateApi, PluralizeApi, OpenUrlApi, AndApi, OrApi, NotApi, BASIC_FUNCTION_APIS, V10_SPEC_FUNCTION_APIS, basicCatalog, BasicCatalogThemeSchema, ThemeSchema, type BasicCatalogTheme, isValidCssColor, injectBasicCatalogStyles, computeColorVariant, type ColorVariantLightDarkOptions, type ColorVariantHoverOptions, Context, markdown, setMarkdownRenderer, getMarkdownRenderer, A2uiAudioPlayer, A2uiButton, A2uiCard, A2uiCheckBox, A2uiChoicePicker, A2uiColumn, A2uiDateTimeInput, A2uiDivider, A2uiIcon, A2uiImage, A2uiList, A2uiModal, A2uiRow, A2uiSlider, A2uiTabs, A2uiText, A2uiTextField, A2uiVideo, BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, WeightSchema, } from '../catalogs/basic/v1/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, type AnchorKind, type CodePointRange, type RegexAnalysisResult, type RegexNode, type RegexRejection, } from '../common/regex_subset.js';
export { type A2uiChildRef, A2uiLitElement, type CheckableResolvedProps, type ResolvedAccessibilityAttributes, type ResolvedChildList, A2uiController, type A2uiWebComponentElement, registerUniversalElement, isWebComponentImplementation, renderA2uiNode, sanitizeMediaUrl, bindHostAccessibility, createAccessibilityTargets, type AccessibilityTargets, type WebComponentImplementation, } from '../universal/index.js';
export { SpecVersion } from '../spec_versions.js';
export declare const Schemas: {
    A2uiMessageSchemaRaw: {
        $schema: string;
        $id: string;
        title: string;
        description: string;
        type: string;
        oneOf: {
            $ref: string;
        }[];
        $defs: {
            CreateSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    createSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            catalogId: {
                                type: string;
                                description: string;
                            };
                            sendDataModel: {
                                type: string;
                                description: string;
                            };
                            components: {
                                $ref: string;
                            };
                            dataModel: {
                                type: string;
                                description: string;
                                additionalProperties: boolean;
                            };
                            metadata: {
                                type: string;
                                description: string;
                                properties: {
                                    extensions: {
                                        $ref: string;
                                    };
                                };
                                additionalProperties: boolean;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            Component: {
                description: string;
                allOf: ({
                    $ref: string;
                    type?: undefined;
                    properties?: undefined;
                } | {
                    type: string;
                    properties: {
                        component: {
                            not: {
                                const: string;
                            };
                        };
                    };
                    $ref?: undefined;
                })[];
                unevaluatedProperties: boolean;
            };
            ComponentsList: {
                type: string;
                description: string;
                minItems: number;
                items: {
                    $ref: string;
                };
            };
            UpdateComponentsMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateComponents: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            components: {
                                $ref: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateDataModelMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateDataModel: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            path: {
                                type: string;
                                description: string;
                            };
                            value: {
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            DeleteSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    deleteSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            CallRendererFunctionMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    callRendererFunction: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            functionCallId: {
                                $ref: string;
                                description: string;
                            };
                            callFunction: {
                                allOf: ({
                                    $ref: string;
                                    required?: undefined;
                                } | {
                                    required: string[];
                                    $ref?: undefined;
                                })[];
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            AgentFunctionResponseMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    agentFunctionResponse: {
                        $ref: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
};
//# sourceMappingURL=index.d.ts.map