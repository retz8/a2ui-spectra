export {};
//# sourceMappingURL=system_functions.test.d.ts.map