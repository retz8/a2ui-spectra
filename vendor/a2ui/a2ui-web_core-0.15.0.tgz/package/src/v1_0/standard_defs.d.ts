import type { ChildRefAnalysisOptions } from '../catalog/reference-map.js';
/**
 * Child reference analysis configuration for A2UI v1.0 schemas.
 */
export declare const V10_CHILD_REF_OPTIONS: ChildRefAnalysisOptions;
/**
 * Standard $defs dictionary for A2UI v1.0 catalog JSON schemas.
 */
export declare const V10_STANDARD_DEFS: Record<string, unknown>;
//# sourceMappingURL=standard_defs.d.ts.map