/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export { CreateSurfaceMessageSchema, UpdateComponentsMessageSchema, UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema, CallRendererFunctionMessageSchema, AgentFunctionResponseMessageSchema, AgentToRendererMessageSchema, FunctionCallValidationSchemaSchema, FunctionDefinitionSchema, LeafDefinitionSchema, ComponentDefinitionSchema, ValidationResultSchema, ComponentIdSchema, CallIdSchema, DataBindingSchema, FunctionCommonSchema, FunctionCallSchema, DynamicStringSchema, DynamicBooleanSchema, AccessibilityAttributesSchema, ExtensionsSchema, ComponentCommonSchema, ChildSchema, ChildListSchema, DynamicValueSchema, DynamicNumberSchema, DynamicStringListSchema, IndexSystemFunctionSchema, CheckRuleSchema, CheckableSchema, ActionSchema, SurfaceSchema, FunctionResponseSchema, CommonSchemas, V10RendererCapabilitiesSchema, ActionMessageSchema, CallAgentFunctionMessageSchema, RendererFunctionResponseMessageSchema, ErrorMessageSchema, RendererToAgentMessageSchema, markChildRef, childRefKindOf, TemplateChildListSchema, componentId, dynamicString, dynamicNumber, dynamicBoolean, dynamicValue, dynamicStringList, childList, AnyComponentSchema, ComponentsListSchema, RendererCapabilitiesSchema, } from './schema/index.js';
export { V10_CHILD_REF_OPTIONS, V10_STANDARD_DEFS } from './standard_defs.js';
export { IndexApi, IndexImplementation, SYSTEM_FUNCTIONS } from './functions/system_functions.js';
export { RequiredV1Point0Api, RegexV1Point0Api, LengthV1Point0Api, NumericV1Point0Api, EmailV1Point0Api, V10_VALIDATION_FUNCTION_APIS, } from './functions/validation_functions_api.js';
export { RequiredV1Point0Implementation, RegexV1Point0Implementation, LengthV1Point0Implementation, NumericV1Point0Implementation, EmailV1Point0Implementation, V10_VALIDATION_FUNCTION_IMPLEMENTATIONS, } from './functions/validation_functions.js';
export { JsonComponentApi, JsonFunctionApi, spec, specDef, createFunctionImplementation, AgentFunction, isAgentFunction, Catalog, } from '../catalog/index.js';
export { SurfaceModel, SurfaceGroupModel, SurfaceComponentsModel, ComponentModel, MAX_ARRAY_INDEX, DataModel, } from '../state/index.js';
export { mapErrorToRendererMessage, extractEnvelopeErrorContext, normalizeJsonPointer, STRICT_VALIDATION, RELAXED_VALIDATION, A2uiRpcError, RpcErrorCode, formatZodIssue, MessageProcessor, VersionAdapterFactory, defaultVersionAdapterFactory, isCatalogVersionCompatible, registerKnownActionsProvider, SUPPORTED_PROTOCOL_VERSIONS, DEFAULT_CATALOG_COMPATIBILITY, BaseVersionAdapter, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiCatalogError, A2uiIntegrityError, A2uiRecursionError, } from '../processing/index.js';
export { PLACEHOLDER_TYPE, isComponentNode, ComponentContext, getKnownSchemaKeys, validateFunctionArgs, isSingleAtKey, unescapeObjectKey, validateReservedDirectives, resolveContextIndex, MAX_DYNAMIC_VALUE_DEPTH, DataContext, scrapeComponentBehavior, scrapeSchemaBehavior, getSafeChildList, MAX_DYNAMIC_CHILD_LIST_SIZE, GenericBinder, NodeResolver, extractRefFields, isWritable, sameBinding, ResolvedBinding, WritableBinding, } from '../resolution/index.js';
export { setSignalImplementation, signal, computed, effect, batchWrite, isSignal, getValue, setValue, peekValue, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, } from '../reactivity/index.js';
export { MAX_EXPRESSION_TEMPLATE_LENGTH, MAX_EXPRESSION_PARTS, ExpressionParser, } from '../expressions/index.js';
export { RpcHandler } from '../rpc/index.js';
export { PayloadValidator, getComponentReferences, validateRecursionAndPaths, MAX_GLOBAL_DEPTH, MAX_FUNC_CALL_DEPTH, RELAXED_PATH_PATTERN, analyzeChildRefSchema, assertUax31Identifier, buildComponentRefMap, isChildListSchema, isChildOrChildListSchema, isChildSchema, isValidUax31Identifier, V08_CHILD_REF_OPTIONS, V09_CHILD_REF_OPTIONS, } from '../validation/index.js';
export { EventEmitter, } from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, } from '../common/metadata.js';
export { BASIC_FUNCTIONS, createBasicCatalogFunctions, AndImplementation, OrImplementation, NotImplementation, FormatStringImplementation, FormatNumberImplementation, createFormatNumberImplementation, FormatCurrencyImplementation, createFormatCurrencyImplementation, FormatDateImplementation, createFormatDateImplementation, PluralizeImplementation, createPluralizeImplementation, OpenUrlImplementation, RequiredApi, RegexApi, LengthApi, NumericApi, EmailApi, FormatStringApi, FormatNumberApi, FormatCurrencyApi, FormatDateApi, PluralizeApi, OpenUrlApi, AndApi, OrApi, NotApi, BASIC_FUNCTION_APIS, V10_SPEC_FUNCTION_APIS, basicCatalog, BasicCatalogThemeSchema, ThemeSchema, isValidCssColor, injectBasicCatalogStyles, computeColorVariant, Context, markdown, setMarkdownRenderer, getMarkdownRenderer, A2uiAudioPlayer, A2uiButton, A2uiCard, A2uiCheckBox, A2uiChoicePicker, A2uiColumn, A2uiDateTimeInput, A2uiDivider, A2uiIcon, A2uiImage, A2uiList, A2uiModal, A2uiRow, A2uiSlider, A2uiTabs, A2uiText, A2uiTextField, A2uiVideo, BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, WeightSchema, } from '../catalogs/basic/v1/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, } from '../common/regex_subset.js';
export { A2uiLitElement, A2uiController, registerUniversalElement, isWebComponentImplementation, renderA2uiNode, sanitizeMediaUrl, bindHostAccessibility, createAccessibilityTargets, } from '../universal/index.js';
export { SpecVersion } from '../spec_versions.js';
import A2uiMessageSchemaRaw from './schemas/agent_to_renderer.json' with { type: 'json' };
export const Schemas = {
    A2uiMessageSchemaRaw,
};
//# sourceMappingURL=index.js.map