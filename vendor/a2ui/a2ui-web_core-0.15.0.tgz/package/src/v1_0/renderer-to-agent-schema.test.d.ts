export {};
//# sourceMappingURL=renderer-to-agent-schema.test.d.ts.map