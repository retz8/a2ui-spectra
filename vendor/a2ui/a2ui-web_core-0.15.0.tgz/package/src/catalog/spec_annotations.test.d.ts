export {};
//# sourceMappingURL=spec_annotations.test.d.ts.map