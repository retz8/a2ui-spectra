/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, it } from 'node:test';
import { isDeepStrictEqual } from 'node:util';
import { z } from 'zod';
import { basicCatalog as v10BasicCatalog } from '../catalogs/basic/v1/catalog.js';
import { A2uiText as V10Text } from '../catalogs/basic/v1/components/index.js';
import { A2uiCatalogError, A2uiValidationError } from '../errors.js';
import { MessageProcessor, STRICT_VALIDATION } from '../processing/message-processor.js';
import { basicCatalog as v08BasicCatalog } from '../v0_8/basic_catalog/catalog.js';
import { basicCatalog as v09BasicCatalog } from '../v0_9/basic_catalog/catalog.js';
import { A2uiText as V09Text } from '../v0_9/basic_catalog/components/index.js';
import { exclusiveUnion } from './exclusive_union.js';
import { JsonComponentApi, JsonFunctionApi } from './json_entries.js';
import { generateValidationSchema } from './schema_generator.js';
import { DEFAULT_PROTOCOL_VERSION } from './schema_loader.js';
import { spec, specDef } from './spec_annotations.js';
import { Catalog, createFunctionImplementation, } from './types.js';
function readRepoJson(relativePath) {
    return JSON.parse(readFileSync(resolve(process.cwd(), '../../..', relativePath), 'utf-8'));
}
/**
 * Returns a copy of an entry whose schema carries no specification
 * annotation, so that the catalog generates its definition from Zod.
 */
function plain(entry) {
    return { ...entry, schema: entry.schema.describe(entry.schema.description) };
}
function isPlainRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function resolvePointer(root, pointer) {
    if (!pointer || pointer === '/')
        return root;
    return pointer
        .replace(/^\//, '')
        .split('/')
        .map(part => part.replace(/~1/g, '/').replace(/~0/g, '~'))
        .reduce((cur, seg) => (isPlainRecord(cur) ? cur[seg] : undefined), root);
}
/**
 * Evaluates a JSON value against a JSON Schema 2020-12 subset, tracking
 * evaluated object properties across `$ref`, `allOf`, `oneOf`, `anyOf`, and
 * `unevaluatedProperties`.
 */
function evaluateJsonSchema(value, schema, docName, docs) {
    const fail = { valid: false, evaluatedProps: new Set() };
    if (typeof schema === 'boolean') {
        if (!schema)
            return fail;
        return {
            valid: true,
            evaluatedProps: isPlainRecord(value) ? new Set(Object.keys(value)) : new Set(),
        };
    }
    if (!isPlainRecord(schema))
        return fail;
    if (typeof schema.type === 'string') {
        const ok = (schema.type === 'object' && isPlainRecord(value)) ||
            (schema.type === 'string' && typeof value === 'string') ||
            (schema.type === 'number' && typeof value === 'number') ||
            (schema.type === 'integer' && typeof value === 'number' && Number.isInteger(value)) ||
            (schema.type === 'boolean' && typeof value === 'boolean') ||
            (schema.type === 'array' && Array.isArray(value)) ||
            (schema.type === 'null' && value === null);
        if (!ok)
            return fail;
    }
    if (Object.hasOwn(schema, 'const') && !isDeepStrictEqual(value, schema.const))
        return fail;
    if (Array.isArray(schema.enum) && !schema.enum.some(entry => isDeepStrictEqual(value, entry))) {
        return fail;
    }
    const evaluatedProps = new Set();
    const localEvaluated = new Set();
    if (isPlainRecord(value)) {
        if (Array.isArray(schema.required)) {
            for (const reqKey of schema.required) {
                if (typeof reqKey === 'string' && !Object.hasOwn(value, reqKey))
                    return fail;
            }
        }
        if (isPlainRecord(schema.properties)) {
            for (const [propKey, propSchema] of Object.entries(schema.properties)) {
                if (Object.hasOwn(value, propKey)) {
                    if (!evaluateJsonSchema(value[propKey], propSchema, docName, docs).valid)
                        return fail;
                    localEvaluated.add(propKey);
                    evaluatedProps.add(propKey);
                }
            }
        }
        if (isPlainRecord(schema.patternProperties)) {
            for (const [pattern, patSchema] of Object.entries(schema.patternProperties)) {
                const regex = new RegExp(pattern, 'u');
                for (const propKey of Object.keys(value)) {
                    if (regex.test(propKey)) {
                        if (!evaluateJsonSchema(value[propKey], patSchema, docName, docs).valid)
                            return fail;
                        localEvaluated.add(propKey);
                        evaluatedProps.add(propKey);
                    }
                }
            }
        }
        if (Object.hasOwn(schema, 'additionalProperties') &&
            schema.additionalProperties !== undefined) {
            for (const propKey of Object.keys(value)) {
                if (!localEvaluated.has(propKey)) {
                    if (!evaluateJsonSchema(value[propKey], schema.additionalProperties, docName, docs).valid) {
                        return fail;
                    }
                    evaluatedProps.add(propKey);
                }
            }
        }
    }
    if (Array.isArray(value) && schema.items !== undefined) {
        for (const item of value) {
            if (!evaluateJsonSchema(item, schema.items, docName, docs).valid)
                return fail;
        }
    }
    if (typeof schema.$ref === 'string') {
        const hashIdx = schema.$ref.indexOf('#');
        const refDoc = hashIdx === -1 ? schema.$ref : schema.$ref.slice(0, hashIdx);
        const pointer = hashIdx === -1 ? '' : schema.$ref.slice(hashIdx + 1);
        const targetDocName = refDoc || docName;
        const targetRoot = docs[targetDocName];
        if (!targetRoot)
            throw new Error(`Unknown schema document: ${targetDocName}`);
        const targetSchema = resolvePointer(targetRoot, pointer);
        if (targetSchema === undefined) {
            throw new Error(`Unresolved $ref: ${schema.$ref} in ${targetDocName}`);
        }
        const refResult = evaluateJsonSchema(value, targetSchema, targetDocName, docs);
        if (!refResult.valid)
            return fail;
        for (const p of refResult.evaluatedProps)
            evaluatedProps.add(p);
    }
    if (Array.isArray(schema.allOf)) {
        for (const sub of schema.allOf) {
            const subResult = evaluateJsonSchema(value, sub, docName, docs);
            if (!subResult.valid)
                return fail;
            for (const p of subResult.evaluatedProps)
                evaluatedProps.add(p);
        }
    }
    if (Array.isArray(schema.oneOf)) {
        const matches = schema.oneOf
            .map(sub => evaluateJsonSchema(value, sub, docName, docs))
            .filter(r => r.valid);
        if (matches.length !== 1)
            return fail;
        for (const p of matches[0].evaluatedProps)
            evaluatedProps.add(p);
    }
    if (Array.isArray(schema.anyOf)) {
        const matches = schema.anyOf
            .map(sub => evaluateJsonSchema(value, sub, docName, docs))
            .filter(r => r.valid);
        if (matches.length === 0)
            return fail;
        for (const m of matches) {
            for (const p of m.evaluatedProps)
                evaluatedProps.add(p);
        }
    }
    if (Object.hasOwn(schema, 'not') && schema.not !== undefined) {
        if (evaluateJsonSchema(value, schema.not, docName, docs).valid)
            return fail;
    }
    if (isPlainRecord(value) &&
        Object.hasOwn(schema, 'unevaluatedProperties') &&
        schema.unevaluatedProperties !== undefined) {
        for (const propKey of Object.keys(value)) {
            if (!evaluatedProps.has(propKey)) {
                if (!evaluateJsonSchema(value[propKey], schema.unevaluatedProperties, docName, docs).valid) {
                    return fail;
                }
                evaluatedProps.add(propKey);
            }
        }
    }
    return { valid: true, evaluatedProps };
}
function collectRefs(node, refs = []) {
    if (Array.isArray(node)) {
        for (const item of node)
            collectRefs(item, refs);
    }
    else if (node && typeof node === 'object') {
        const ref = node.$ref;
        if (typeof ref === 'string')
            refs.push(ref);
        for (const value of Object.values(node))
            collectRefs(value, refs);
    }
    return refs;
}
const PUBLISHED_CATALOGS = [
    'catalogs/basic/v1/catalog.json',
    'catalogs/mcp/catalog.json',
    'catalogs/vegachart/v0_9/catalog.json',
    'catalogs/vegachart/v1/catalog.json',
    'specification/v0_9/catalogs/basic/catalog.json',
    'specification/v0_9/catalogs/minimal/catalog.json',
    'specification/v0_9_1/catalogs/basic/catalog.json',
];
describe('Catalog.toJson', () => {
    for (const catalogPath of PUBLISHED_CATALOGS) {
        it(`returns ${catalogPath} unchanged after fromJson`, () => {
            const document = readRepoJson(catalogPath);
            const out = Catalog.fromJson(document).toJson();
            assert.deepStrictEqual(out, document);
            assert.deepStrictEqual(Catalog.fromJson(out).toJson(), out);
        });
    }
    it('returns a fresh copy on every call', () => {
        const document = readRepoJson('catalogs/basic/v1/catalog.json');
        const catalog = Catalog.fromJson(document);
        const first = catalog.toJson();
        first.components.Text.type = 'mutated';
        delete first.$defs.anyComponent;
        assert.deepStrictEqual(catalog.toJson(), document);
    });
    it('assembles the document once per catalog', () => {
        let reads = 0;
        const labelSchema = z.object({});
        const counted = {
            name: 'Label',
            get schema() {
                reads++;
                return labelSchema;
            },
        };
        const catalog = new Catalog('https://example.com/cached', '1.0', [counted]);
        const first = catalog.toJson();
        const readsAfterFirst = reads;
        assert.ok(readsAfterFirst > 0);
        const second = catalog.toJson();
        assert.strictEqual(reads, readsAfterFirst, 'the second call does not read the model again');
        assert.notStrictEqual(first, second);
        assert.deepStrictEqual(first, second);
    });
    it('keeps the document-level fields in a catalog derived with withEntries', () => {
        const document = readRepoJson('specification/v0_9/catalogs/basic/catalog.json');
        const loaded = Catalog.fromJson(document);
        const derived = loaded.withEntries([...loaded.components.values()], []);
        const out = derived.toJson();
        const { functions: _functions, $defs: outDefs, ...outFields } = out;
        const { functions: _f, $defs: documentDefs, ...documentFields } = document;
        assert.deepStrictEqual(outFields, documentFields);
        assert.deepStrictEqual(out.functions, {});
        assert.deepStrictEqual(outDefs.anyFunction, { not: {} });
        assert.deepStrictEqual(outDefs.theme, documentDefs.theme);
        assert.strictEqual(derived.themeSchema, loaded.themeSchema);
    });
    it('returns a v1.0 document without components unchanged', () => {
        const document = {
            catalogId: 'https://example.com/functions-only',
            protocolVersion: '1.0',
            functions: { f: { returnType: 'string' } },
            $defs: { anyComponent: { not: {} }, anyFunction: { oneOf: [{ $ref: '#/functions/f' }] } },
        };
        const catalog = Catalog.fromJson(document);
        assert.strictEqual(catalog.declaresComponents, false);
        assert.deepStrictEqual(catalog.toJson(), document);
    });
    it('returns a v0.9 document without components unchanged', () => {
        const document = readRepoJson('specification/v0_9/catalogs/basic/catalog.json');
        delete document.components;
        delete document.$defs.anyComponent;
        delete document.$defs.CatalogComponentCommon;
        const catalog = Catalog.fromJson(document);
        assert.strictEqual(catalog.declaresComponents, false);
        assert.deepStrictEqual(catalog.toJson(), document);
    });
    it('writes components when the document declares none but the catalog has some', () => {
        const loaded = Catalog.fromJson({
            catalogId: 'https://example.com/functions-only',
            protocolVersion: '1.0',
            functions: { f: { returnType: 'string' } },
        });
        const label = { name: 'Label', schema: z.object({ text: z.string() }) };
        const derived = loaded.withEntries([label], [...loaded.functions.values()]);
        assert.strictEqual(derived.declaresComponents, false);
        assert.deepStrictEqual(Object.keys(derived.toJson().components), ['Label']);
        assert.ok(!('components' in loaded.withEntries([], []).toJson()));
    });
    it('writes an empty components map for a catalog defined in code', () => {
        const catalog = new Catalog('https://example.com/empty', '1.0');
        assert.strictEqual(catalog.declaresComponents, true);
        assert.deepStrictEqual(catalog.toJson().components, {});
    });
    it('does not add metadata, protocolVersion or $defs the document omits', () => {
        const document = {
            catalogId: 'https://example.com/plain',
            components: {
                Label: {
                    type: 'object',
                    properties: {
                        component: { const: 'Label' },
                        text: { $ref: 'common_types.json#/$defs/DynamicString' },
                    },
                    required: ['component', 'text'],
                },
            },
        };
        assert.deepStrictEqual(Catalog.fromJson(document, '1.0').toJson(), document);
    });
    it('keeps the list form of functions', () => {
        const document = {
            catalogId: 'https://example.com/list',
            components: {},
            functions: [
                {
                    name: 'shout',
                    returnType: 'string',
                    parameters: { type: 'object', properties: { value: { type: 'string' } } },
                },
            ],
        };
        assert.deepStrictEqual(Catalog.fromJson(document).toJson(), document);
    });
    for (const [label, builtin, catalogPath] of [
        ['v0.8', v08BasicCatalog, 'specification/v0_8/json/standard_catalog_definition.json'],
        ['v0.9', v09BasicCatalog, 'specification/v0_9/catalogs/basic/catalog.json'],
        ['1.0', v10BasicCatalog, 'catalogs/basic/v1/catalog.json'],
    ]) {
        it(`returns the published document for the built-in ${label} basic catalog`, () => {
            assert.deepStrictEqual(builtin.toJson(), readRepoJson(catalogPath));
        });
    }
    it('emits catalogId only when the source declared it', () => {
        const document = {
            components: { Label: { type: 'object', properties: { component: { const: 'Label' } } } },
        };
        const catalog = Catalog.fromJson(document, '1.0', 'https://example.com/injected');
        assert.strictEqual(catalog.id, 'https://example.com/injected');
        assert.deepStrictEqual(catalog.toJson(), document);
        const declared = { catalogId: 'https://example.com/declared', ...document };
        const overridden = Catalog.fromJson(declared, '1.0', 'https://example.com/other');
        assert.strictEqual(overridden.id, 'https://example.com/other');
        assert.strictEqual(overridden.toJson().catalogId, 'https://example.com/other');
    });
    it('computes the definitions of the basic models in another code-defined catalog', () => {
        const published = readRepoJson('catalogs/basic/v1/catalog.json');
        const out = new Catalog('https://example.com/reused', '1.0', [...v10BasicCatalog.components.values()], [...v10BasicCatalog.functions.values()]).toJson();
        assert.deepStrictEqual(out.components, published.components);
        assert.deepStrictEqual(out.functions, published.functions);
        assert.deepStrictEqual(out.$defs, published.$defs);
    });
    it('serializes a code-defined v1.0 catalog unbundled, with both unions', () => {
        const codeDefined = new Catalog(v10BasicCatalog.id, '1.0', [...v10BasicCatalog.components.values()].map(plain), [...v10BasicCatalog.functions.values()].map(plain));
        const out = codeDefined.toJson();
        assert.strictEqual(out.catalogId, v10BasicCatalog.id);
        assert.strictEqual(out.protocolVersion, '1.0');
        assert.strictEqual(out.theme, undefined);
        assert.deepStrictEqual(Object.keys(out.$defs).sort(), [
            'anyComponent',
            'anyFunction',
        ]);
        const functions = out.functions;
        assert.ok(!('@index' in functions), 'system functions are not part of the document');
        assert.deepStrictEqual(functions.formatNumber.properties['@call'], { const: 'formatNumber' });
        assert.strictEqual(functions.formatNumber.returnType, 'string');
        for (const ref of collectRefs(out)) {
            assert.ok(ref.startsWith('common_types.json#/$defs/') ||
                ref.startsWith('#/components/') ||
                ref.startsWith('#/functions/'), `unexpected reference '${ref}'`);
        }
        const text = out.components.Text;
        assert.deepStrictEqual(text.properties.component, { const: 'Text' });
        assert.ok(text.required.includes('component'));
        assert.ok(!('id' in text.properties));
        assert.strictEqual(Object.hasOwn(text, 'unevaluatedProperties'), false);
    });
    it('omits unevaluatedProperties: false and catchall subschemas on v1.0 code-defined components while keeping v0.9 closed and passthrough open', () => {
        const DefaultComp = {
            name: 'DefaultComp',
            schema: z.object({ label: z.string(), weight: z.number().optional() }),
        };
        const StrictComp = {
            name: 'StrictComp',
            schema: z.object({ label: z.string() }).strict(),
        };
        const OpenComp = {
            name: 'OpenComp',
            schema: z.object({ label: z.string() }).passthrough(),
        };
        const CatchallComp = {
            name: 'CatchallComp',
            schema: z.object({ label: z.string() }).catchall(z.number()),
        };
        const v10Doc = new Catalog('https://example.com/v10-closure', '1.0', [
            DefaultComp,
            StrictComp,
            OpenComp,
            CatchallComp,
        ]).toJson();
        const v10Comps = v10Doc.components;
        assert.strictEqual(Object.hasOwn(v10Comps.DefaultComp, 'unevaluatedProperties'), false);
        assert.strictEqual(Object.hasOwn(v10Comps.StrictComp, 'unevaluatedProperties'), false);
        assert.strictEqual(v10Comps.OpenComp.unevaluatedProperties, true);
        assert.strictEqual(Object.hasOwn(v10Comps.CatchallComp, 'unevaluatedProperties'), false);
        const v09Doc = new Catalog('https://example.com/v09-closure', '0.9', [
            DefaultComp,
            StrictComp,
            OpenComp,
            CatchallComp,
        ]).toJson();
        const v09Comps = v09Doc.components;
        assert.strictEqual(v09Comps.DefaultComp.unevaluatedProperties, false);
        assert.strictEqual(v09Comps.StrictComp.unevaluatedProperties, false);
        assert.strictEqual(v09Comps.OpenComp.unevaluatedProperties, true);
        assert.deepStrictEqual(v09Comps.CatchallComp.unevaluatedProperties, { type: 'number' });
    });
    it('serializes code-defined functions in the call shape of the protocol version', () => {
        const fn = createFunctionImplementation({
            name: 'launch',
            returnType: 'void',
            schema: z.object({ url: z.string() }),
            allowedCallers: 'rendererOnly',
            requiresUserActivation: true,
            description: 'Launches a URL.',
        }, () => undefined);
        const v10 = new Catalog('https://example.com/v10', '1.0', [], [fn]).toJson();
        assert.deepStrictEqual(v10.functions.launch, {
            type: 'object',
            description: 'Launches a URL.',
            returnType: 'void',
            allowedCallers: 'rendererOnly',
            requiresUserActivation: true,
            properties: {
                '@call': { const: 'launch' },
                args: {
                    type: 'object',
                    properties: { url: { type: 'string' } },
                    required: ['url'],
                    unevaluatedProperties: false,
                },
            },
            required: ['@call', 'args'],
        });
        assert.deepStrictEqual(v10.$defs, {
            anyComponent: { not: {} },
            anyFunction: { oneOf: [{ $ref: '#/functions/launch' }] },
        });
        const v09 = new Catalog('https://example.com/v09', '0.9', [], [fn]).toJson();
        const launch = v09.functions.launch;
        assert.deepStrictEqual(launch.properties.call, { const: 'launch' });
        assert.deepStrictEqual(launch.properties.returnType, { const: 'void' });
        assert.deepStrictEqual(launch.required, ['call', 'args']);
    });
    it('emits metadata given to a code-defined catalog', () => {
        const out = new Catalog('https://example.com/meta', '1.0', [], [], {
            schemaUri: 'https://json-schema.org/draft/2020-12/schema',
            schemaId: 'https://example.com/meta.json',
            title: 'Meta',
            description: 'A catalog.',
            instructions: 'Be brief.',
        }).toJson();
        assert.strictEqual(out.$schema, 'https://json-schema.org/draft/2020-12/schema');
        assert.strictEqual(out.$id, 'https://example.com/meta.json');
        assert.strictEqual(out.title, 'Meta');
        assert.strictEqual(out.description, 'A catalog.');
        assert.strictEqual(out.instructions, 'Be brief.');
        assert.strictEqual(out.protocolVersion, '1.0');
    });
    it('serializes an entry without a definition from its model in a loaded catalog', () => {
        const document = readRepoJson('catalogs/basic/v1/catalog.json');
        const loaded = Catalog.fromJson(document);
        const rewritten = {
            name: 'Text',
            schema: z.object({ text: z.string().describe('REF:common_types.json#/$defs/DynamicString') }),
        };
        const derived = loaded.withEntries([rewritten, loaded.components.get('Image')], []);
        const out = derived.toJson();
        assert.strictEqual(out.title, document.title);
        assert.strictEqual(out.instructions, document.instructions);
        const components = out.components;
        assert.deepStrictEqual(components.Image, document.components.Image);
        assert.deepStrictEqual(components.Text.properties.text, {
            $ref: 'common_types.json#/$defs/DynamicString',
        });
        assert.deepStrictEqual(out.$defs.anyComponent, {
            oneOf: [{ $ref: '#/components/Text' }, { $ref: '#/components/Image' }],
            discriminator: { propertyName: 'component' },
        });
        assert.deepStrictEqual(out.$defs.anyFunction, { not: {} });
        assert.deepStrictEqual(out.functions, {});
    });
    it('drops authored $defs that only removed entries referenced', () => {
        const document = readRepoJson('specification/v0_9/catalogs/basic/catalog.json');
        const loaded = Catalog.fromJson(document);
        const derived = loaded.withEntries([], []);
        const defs = derived.toJson().$defs;
        assert.ok(!('CatalogComponentCommon' in defs), 'orphaned mixin is dropped');
        assert.ok('theme' in defs, 'a definition the source never referenced is kept');
    });
});
describe('Catalog.validationSchema', () => {
    it('is the bundled schema that catalogSchema still returns', () => {
        const catalog = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
        const schema = catalog.validationSchema;
        assert.deepStrictEqual(catalog.catalogSchema, schema);
        const defs = schema.$defs;
        assert.ok('DynamicString' in defs, 'common types are bundled');
        for (const ref of collectRefs(schema.components)) {
            assert.ok(ref.startsWith('#'), `reference '${ref}' is localized`);
        }
    });
    it('is unaffected by toJson', () => {
        const catalog = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
        const before = JSON.stringify(catalog.validationSchema);
        catalog.toJson();
        assert.strictEqual(JSON.stringify(catalog.validationSchema), before);
    });
});
describe('union export', () => {
    const OVERLAPPING_BRANCHES = [{ type: 'string', enum: ['md', 'lg'] }, { type: 'string' }];
    /** Whether the catalog's `Box` component accepts `radius`. */
    function acceptsRadius(catalog, radius) {
        return catalog.components.get('Box').schema.safeParse({ radius }).success;
    }
    /** The `radius` property of the `Box` component in a catalog document. */
    function radiusSchema(document) {
        return document.components.Box.properties.radius;
    }
    /** A catalog document with a `Box` whose `radius` is the given union. */
    function boxDocument(version, radius) {
        return {
            catalogId: 'https://example.org/catalog.json',
            protocolVersion: version,
            components: {
                Box: {
                    type: 'object',
                    properties: { component: { const: 'Box' }, radius },
                    required: ['component', 'radius'],
                    unevaluatedProperties: false,
                },
            },
            $defs: {
                anyComponent: {
                    oneOf: [{ $ref: '#/components/Box' }],
                    discriminator: { propertyName: 'component' },
                },
                anyFunction: { not: {} },
            },
        };
    }
    for (const version of ['v0.9', '1.0']) {
        it(`exports z.union as anyOf and keeps its accepted values on reload in ${version}`, () => {
            const schema = z.object({ radius: z.union([z.enum(['md', 'lg']), z.string()]) });
            const original = new Catalog('https://example.org/catalog.json', version, [
                { name: 'Box', schema },
            ]);
            const document = original.toJson();
            assert.deepStrictEqual(radiusSchema(document), { anyOf: OVERLAPPING_BRANCHES });
            const reloaded = Catalog.fromJson(document);
            for (const catalog of [original, reloaded]) {
                assert.strictEqual(acceptsRadius(catalog, 'md'), true);
                assert.strictEqual(acceptsRadius(catalog, '12px'), true);
                assert.strictEqual(acceptsRadius(catalog, false), false);
            }
            const validation = original.validationSchema.components;
            assert.deepStrictEqual(validation.Box.properties.radius, { anyOf: OVERLAPPING_BRANCHES });
        });
        it(`keeps an authored oneOf exclusive and writes it back as oneOf in ${version}`, () => {
            const document = boxDocument(version, { oneOf: OVERLAPPING_BRANCHES });
            const loaded = Catalog.fromJson(document);
            assert.strictEqual(acceptsRadius(loaded, 'md'), false, 'md matches both branches');
            assert.strictEqual(acceptsRadius(loaded, '12px'), true);
            assert.strictEqual(acceptsRadius(loaded, false), false);
            assert.deepStrictEqual(radiusSchema(loaded.toJson()), { oneOf: OVERLAPPING_BRANCHES });
            assert.deepStrictEqual(Catalog.fromJson(loaded.toJson()).toJson(), loaded.toJson());
            // A catalog defined in code from the loaded schema keeps it exclusive.
            const reused = new Catalog('https://example.org/reused.json', version, [
                { name: 'Box', schema: loaded.components.get('Box').schema },
            ]);
            assert.deepStrictEqual(radiusSchema(reused.toJson()), { oneOf: OVERLAPPING_BRANCHES });
            const validation = reused.validationSchema.components;
            assert.deepStrictEqual(validation.Box.properties.radius, { oneOf: OVERLAPPING_BRANCHES });
            const reloaded = Catalog.fromJson(reused.toJson());
            assert.strictEqual(acceptsRadius(reloaded, 'md'), false);
            assert.strictEqual(acceptsRadius(reloaded, '12px'), true);
        });
        it(`keeps an authored anyOf inclusive in ${version}`, () => {
            const document = boxDocument(version, { anyOf: OVERLAPPING_BRANCHES });
            const loaded = Catalog.fromJson(document);
            assert.strictEqual(acceptsRadius(loaded, 'md'), true);
            assert.deepStrictEqual(radiusSchema(loaded.toJson()), { anyOf: OVERLAPPING_BRANCHES });
        });
        it(`writes a specification-shaped union as oneOf only when its branches are disjoint in ${version}`, () => {
            const boxSchema = spec(z
                .object({
                radius: z.union([z.enum(['md', 'lg']), z.string()]),
                size: z.union([z.number(), z.object({ token: z.string() }).strict()]),
            })
                .strict(), { mixins: [] });
            const catalog = new Catalog('https://example.org/shaped.json', version, [
                { name: 'Box', schema: boxSchema },
            ]);
            const document = catalog.toJson();
            const box = document.components.Box;
            // A v1.0 definition without mixins lists its properties itself; a v0.9
            // one lists them in its `allOf`.
            const properties = (box.properties ??
                box.allOf.find((m) => m.properties).properties);
            assert.deepStrictEqual(properties.radius, { anyOf: OVERLAPPING_BRANCHES });
            assert.deepStrictEqual(properties.size, {
                oneOf: [
                    { type: 'number' },
                    {
                        type: 'object',
                        properties: { token: { type: 'string' } },
                        required: ['token'],
                        additionalProperties: false,
                    },
                ],
            });
            const reloaded = Catalog.fromJson(document).components.get('Box').schema;
            assert.strictEqual(reloaded.safeParse({ radius: 'md', size: 1 }).success, true);
            assert.strictEqual(reloaded.safeParse({ radius: 'md', size: { token: 'x' } }).success, true);
            assert.strictEqual(reloaded.safeParse({ radius: 'md', size: 'x' }).success, false);
        });
        it(`keeps a loaded oneOf with a description and default exclusive when reused in ${version}`, () => {
            const radius = {
                oneOf: OVERLAPPING_BRANCHES,
                description: 'The corner radius.',
                default: '12px',
            };
            const loaded = Catalog.fromJson(boxDocument(version, radius));
            assert.strictEqual(acceptsRadius(loaded, 'md'), false);
            assert.strictEqual(acceptsRadius(loaded, '12px'), true);
            const reused = new Catalog('https://example.org/reused.json', version, [
                { name: 'Box', schema: loaded.components.get('Box').schema },
            ]);
            assert.deepStrictEqual(radiusSchema(reused.toJson()), radius);
            const validation = reused.validationSchema.components;
            assert.deepStrictEqual(validation.Box.properties.radius, radius);
        });
        it(`writes function arguments as anyOf, or as oneOf when exclusive, in ${version}`, () => {
            const branches = [z.enum(['md', 'lg']), z.string()];
            const fn = createFunctionImplementation({
                name: 'round',
                returnType: 'string',
                schema: z.object({
                    inclusive: z.union(branches),
                    exclusive: exclusiveUnion(branches),
                }),
            }, () => '');
            const catalog = new Catalog('https://example.org/functions.json', version, [], [fn]);
            const args = catalog.toJson().functions.round.properties.args;
            assert.deepStrictEqual(args.properties.inclusive, { anyOf: OVERLAPPING_BRANCHES });
            assert.deepStrictEqual(args.properties.exclusive, { oneOf: OVERLAPPING_BRANCHES });
            const reloaded = Catalog.fromJson(catalog.toJson()).functions.get('round').schema;
            assert.strictEqual(reloaded.safeParse({ inclusive: 'md', exclusive: '12px' }).success, true);
            assert.strictEqual(reloaded.safeParse({ inclusive: 'md', exclusive: 'md' }).success, false);
        });
        describe(`specification-shaped union keyword in ${version}`, () => {
            /** A branch whose definition is exactly `json`. */
            const raw = (json) => spec(z.any(), { keywords: json });
            /** A branch that references a definition of the common types. */
            const commonRef = (name) => z.any().describe(`REF:#/$defs/${name}`);
            /** The keyword the document writes for a shaped component's `value` union. */
            function unionKeyword(union) {
                const schema = spec(z.object({ value: union }).strict(), { mixins: [] });
                const catalog = new Catalog('https://example.org/shaped.json', version, [
                    { name: 'Box', schema },
                ]);
                const box = catalog.toJson().components.Box;
                const properties = box.properties ?? box.allOf.find((m) => m.properties).properties;
                const keywords = Object.keys(properties.value).filter(k => k === 'oneOf' || k === 'anyOf');
                assert.strictEqual(keywords.length, 1, JSON.stringify(properties.value));
                return keywords[0];
            }
            const overlapping = {
                'integer and number': z.union([z.number().int(), z.number()]),
                'open objects requiring different keys': z.union([
                    z.object({ a: z.string() }),
                    z.object({ b: z.string() }),
                ]),
                "a closed object that allows the other's required key": z.union([
                    z.object({ a: z.string(), b: z.string().optional() }).strict(),
                    z.object({ a: z.string() }),
                ]),
                'an enum and a const that share a value': z.union([z.enum(['a', 'b']), z.literal('b')]),
                'a reference to an unknown common type': z.union([commonRef('NoSuchDef'), z.number()]),
                "a catalog's own definition named like a common type": z.union([
                    raw({ $ref: '#/$defs/DataBinding' }),
                    z.number(),
                ]),
                'object values that differ only in key order': z.union([
                    raw({ enum: [{ a: 1, b: 2 }] }),
                    raw({ const: { b: 2, a: 1 } }),
                ]),
                'three branches of which two overlap': z.union([z.number(), z.string(), z.enum(['a'])]),
            };
            for (const [name, union] of Object.entries(overlapping)) {
                it(`writes anyOf for ${name}`, () => assert.strictEqual(unionKeyword(union), 'anyOf'));
            }
            const disjoint = {
                'consts with no shared value': z.union([z.literal('a'), z.literal('b')]),
                'enums with no shared value': z.union([z.enum(['a', 'b']), z.enum(['c'])]),
                'a closed object and a branch requiring a key it does not allow': z.union([
                    z.object({ a: z.string() }).strict(),
                    z.object({ b: z.string() }),
                ]),
                'open objects whose required discriminators differ': z.union([
                    z.object({ kind: z.literal('a'), x: z.string() }),
                    z.object({ kind: z.literal('b'), y: z.string() }),
                ]),
                'a discriminated union': z.discriminatedUnion('kind', [
                    z.object({ kind: z.literal('a') }),
                    z.object({ kind: z.literal('b') }),
                ]),
                'a common type reference and a number': z.union([commonRef('DataBinding'), z.number()]),
            };
            for (const [name, union] of Object.entries(disjoint)) {
                it(`writes oneOf for ${name}`, () => assert.strictEqual(unionKeyword(union), 'oneOf'));
            }
        });
    }
});
describe('Catalog.fromJson', () => {
    it('lets a protocolVersion argument take precedence over the declared one', () => {
        const document = {
            catalogId: 'https://example.com/versioned',
            protocolVersion: '1.0',
            components: {},
            $defs: { anyComponent: { not: {} }, anyFunction: { not: {} } },
        };
        const overridden = Catalog.fromJson(document, '0.9');
        assert.strictEqual(overridden.protocolVersion, '0.9');
        assert.strictEqual(overridden.declaredProtocolVersion, '1.0');
        assert.deepStrictEqual(overridden.toJson(), document);
        const declared = Catalog.fromJson(document);
        assert.strictEqual(declared.protocolVersion, '1.0');
        const { protocolVersion: _version, ...undeclared } = document;
        assert.strictEqual(Catalog.fromJson(undeclared, '0.9').protocolVersion, '0.9');
        assert.strictEqual(Catalog.fromJson(undeclared).protocolVersion, DEFAULT_PROTOCOL_VERSION);
    });
    it('captures document metadata and authored entries', () => {
        const document = readRepoJson('catalogs/basic/v1/catalog.json');
        const catalog = Catalog.fromJson(document);
        assert.strictEqual(catalog.schemaUri, document.$schema);
        assert.strictEqual(catalog.schemaId, document.$id);
        assert.strictEqual(catalog.title, document.title);
        assert.strictEqual(catalog.description, document.description);
        assert.strictEqual(catalog.declaredProtocolVersion, '1.0');
        assert.strictEqual(catalog.declaresCatalogId, true);
        assert.strictEqual(catalog.functionsLayout, 'map');
        // The unions list exactly the entries, so they are computed, not kept.
        assert.deepStrictEqual(catalog.unions, { anyComponent: true, anyFunction: true });
        assert.deepStrictEqual(catalog.defs, { Weight: document.$defs.Weight });
        assert.strictEqual(catalog.extensionFields, undefined);
        const checkBox = catalog.components.get('CheckBox');
        const openUrl = catalog.functions.get('openUrl');
        assert.ok(checkBox instanceof JsonComponentApi);
        assert.ok(openUrl instanceof JsonFunctionApi);
        assert.deepStrictEqual(checkBox.jsonSchema, document.components.CheckBox);
        assert.deepStrictEqual(openUrl.jsonSchema, document.functions.openUrl);
        assert.strictEqual(openUrl.returnType, 'void');
        assert.strictEqual(openUrl.requiresUserActivation, true);
        assert.strictEqual(openUrl.description, document.functions.openUrl.description);
    });
    it('derives the Zod schema of a loaded entry from its definition once, on first use', () => {
        const catalog = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
        const text = catalog.components.get('Text');
        const schema = text.schema;
        assert.strictEqual(text.schema, schema, 'the derived schema is cached');
        assert.ok(schema.safeParse({ text: 'hi' }).success);
        assert.ok(!schema.safeParse({ text: 'hi', unknown: 1 }).success);
        assert.ok(!Object.keys(text).includes('jsonSchema'), 'the definition is not an own property');
    });
    it('keeps the named $defs and other top-level keys as model fields', () => {
        const document = readRepoJson('specification/v0_9/catalogs/basic/catalog.json');
        const catalog = Catalog.fromJson(document);
        assert.deepStrictEqual(Object.keys(catalog.defs), ['CatalogComponentCommon', 'theme']);
        assert.strictEqual(catalog.declaredProtocolVersion, null);
        const v08 = Catalog.fromJson(readRepoJson('specification/v0_8/json/standard_catalog_definition.json'), '0.8', 'https://example.com/v08');
        assert.strictEqual(v08.declaresCatalogId, false);
        assert.deepStrictEqual(Object.keys(v08.extensionFields), ['styles']);
        assert.deepStrictEqual(v08.unions, { anyComponent: false, anyFunction: false });
    });
    it('keeps a union that is not the computed one as written', () => {
        const document = {
            catalogId: 'https://example.com/reordered',
            extensions: { vendor: { flag: true } },
            components: {
                A: { type: 'object', properties: { component: { const: 'A' } } },
                B: { type: 'object', properties: { component: { const: 'B' } } },
            },
            $defs: {
                anyComponent: {
                    oneOf: [{ $ref: '#/components/B' }, { $ref: '#/components/A' }],
                    discriminator: { propertyName: 'component' },
                },
            },
        };
        const catalog = Catalog.fromJson(document);
        assert.deepStrictEqual(catalog.unions, { anyComponent: false, anyFunction: false });
        assert.deepStrictEqual(catalog.defs, document.$defs);
        assert.deepStrictEqual(catalog.extensionFields, { extensions: document.extensions });
        assert.deepStrictEqual(catalog.toJson(), document);
    });
    it('sets declaredProtocolVersion to null when the document omits it', () => {
        const catalog = Catalog.fromJson(readRepoJson('specification/v0_9/catalogs/basic/catalog.json'));
        assert.strictEqual(catalog.declaredProtocolVersion, null);
        assert.strictEqual(catalog.protocolVersion, '0.9');
    });
    it('rejects a document without a catalog ID', () => {
        assert.throws(() => Catalog.fromJson({ components: {} }), /Catalog ID/);
    });
    it('does not share objects with its input', () => {
        const document = readRepoJson('catalogs/basic/v1/catalog.json');
        const catalog = Catalog.fromJson(document);
        const json = JSON.stringify(catalog.toJson());
        const text = catalog.components.get('Text');
        const textSchemaResult = text.schema.safeParse({ text: 'hi', variant: 'h1' }).success;
        document.components.Text.properties.variant.enum = ['mutated'];
        document.components.Text.description = 'mutated';
        document.functions.openUrl.description = 'mutated';
        document.$defs.anyComponent = { not: {} };
        document.catalogId = 'mutated';
        const fresh = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
        assert.strictEqual(JSON.stringify(catalog.toJson()), json);
        assert.deepStrictEqual(catalog.validationSchema, fresh.validationSchema);
        assert.strictEqual(text.schema.safeParse({ text: 'hi', variant: 'h1' }).success, textSchemaResult);
    });
    it('leaves the definitions unchanged when building validationSchema', () => {
        const catalog = Catalog.fromJson(readRepoJson('specification/v0_9/catalogs/basic/catalog.json'));
        const sources = () => JSON.stringify([
            [...catalog.components.values()].map(c => c.jsonSchema),
            [...catalog.functions.values()].map(f => f.jsonSchema),
            catalog.defs,
            catalog.extensionFields,
        ]);
        const before = sources();
        void catalog.validationSchema;
        catalog.toJson();
        assert.strictEqual(sources(), before);
    });
    it('round-trips a code-defined function without required args through toJson', () => {
        const fn = createFunctionImplementation({ name: 'now', returnType: 'string', schema: z.object({ format: z.string().optional() }) }, () => '');
        for (const version of ['0.9', '1.0']) {
            const codeCatalog = new Catalog(`https://example.com/now/${version}`, version, [], [fn]);
            const out = codeCatalog.toJson();
            const call = out.functions.now;
            assert.ok(!call.required.includes('args'), `args is optional in ${version}`);
            // The document declares the version the code-defined catalog only implies.
            const { protocolVersion, ...reloaded } = Catalog.fromJson(out, version).validationSchema;
            assert.strictEqual(protocolVersion, version);
            assert.deepStrictEqual(reloaded, codeCatalog.validationSchema);
        }
    });
    it('round-trips v1.0 code-defined components through toJson without rejecting ComponentCommon fields', () => {
        const Banner = {
            name: 'Banner',
            schema: z.object({
                text: z.string().describe('REF:common_types.json#/$defs/DynamicString'),
                weight: z.number().optional(),
            }),
        };
        const StrictBanner = {
            name: 'StrictBanner',
            schema: z
                .object({
                text: z.string().describe('REF:common_types.json#/$defs/DynamicString'),
                weight: z.number().optional(),
            })
                .strict(),
        };
        const OpenBanner = {
            name: 'OpenBanner',
            schema: z.object({ text: z.string() }).passthrough(),
        };
        const CatchallBanner = {
            name: 'CatchallBanner',
            schema: z
                .object({
                text: z.string().describe('REF:common_types.json#/$defs/DynamicString'),
                weight: z.number().optional(),
            })
                .catchall(z.number()),
        };
        const originalCatalog = new Catalog('https://example.com/v10-roundtrip.json', '1.0', [
            Banner,
            StrictBanner,
            OpenBanner,
            CatchallBanner,
        ]);
        const serializedDoc = originalCatalog.toJson();
        const roundTripped = Catalog.fromJson(serializedDoc);
        const { protocolVersion, ...reloadedValidation } = roundTripped.validationSchema;
        assert.strictEqual(protocolVersion, '1.0');
        assert.deepStrictEqual(reloadedValidation, originalCatalog.validationSchema);
        const basePayload = {
            'id': 'root',
            '@catalogId': roundTripped.id,
            '@accessibility': {
                label: 'Welcome banner',
                description: 'Primary surface greeting',
                live: 'polite',
            },
            '@metadata': { extensions: { vendor_ext: { featured: true } } },
            'text': 'Hello world',
            'weight': 2,
        };
        // 1. Validate against official v1.0 protocol schemas (agent_to_renderer.json#/$defs/Component).
        const agentToRenderer = readRepoJson('specification/v1_0/json/agent_to_renderer.json');
        const commonTypes = readRepoJson('specification/v1_0/json/common_types.json');
        for (const catalogDoc of [serializedDoc, roundTripped.toJson()]) {
            const protocolDocs = {
                'agent_to_renderer.json': agentToRenderer,
                'common_types.json': commonTypes,
                'catalog.json': catalogDoc,
            };
            const componentWireSchema = agentToRenderer.$defs.Component;
            for (const closedType of ['Banner', 'StrictBanner', 'CatchallBanner']) {
                assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: closedType }, componentWireSchema, 'agent_to_renderer.json', protocolDocs).valid, true);
                assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: closedType, undeclared: 'nope' }, componentWireSchema, 'agent_to_renderer.json', protocolDocs).valid, false);
            }
            assert.strictEqual(evaluateJsonSchema({
                'id': 'root',
                'component': 'OpenBanner',
                '@catalogId': roundTripped.id,
                '@accessibility': basePayload['@accessibility'],
                '@metadata': basePayload['@metadata'],
                'text': 'Hello world',
                'customExtra': 42,
            }, componentWireSchema, 'agent_to_renderer.json', protocolDocs).valid, true);
        }
        // 2. Validate against originalCatalog.validationSchema, roundTripped.validationSchema,
        //    and generateValidationSchema().
        const bundledEnvelopeSchema = {
            type: 'object',
            allOf: [{ $ref: 'common_types.json#/$defs/ComponentCommon' }, { $ref: '#/$defs/anyComponent' }],
            unevaluatedProperties: false,
        };
        for (const validationSchema of [
            originalCatalog.validationSchema,
            roundTripped.validationSchema,
        ]) {
            const validationDocs = {
                'validation.json': validationSchema,
                'common_types.json': commonTypes,
            };
            assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: 'Banner' }, { $ref: '#/$defs/anyComponent' }, 'validation.json', validationDocs).valid, true);
            for (const closedType of ['Banner', 'StrictBanner', 'CatchallBanner']) {
                assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: closedType }, bundledEnvelopeSchema, 'validation.json', validationDocs).valid, true);
                assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: closedType, undeclared: 'nope' }, bundledEnvelopeSchema, 'validation.json', validationDocs).valid, false);
            }
        }
        const envelopeWrapped = generateValidationSchema(roundTripped, {
            componentEnvelopeRef: 'common_types.json#/$defs/ComponentCommon',
        });
        const wrappedComponents = envelopeWrapped.components;
        assert.strictEqual(evaluateJsonSchema({ ...basePayload, component: 'Banner' }, wrappedComponents.Banner, 'wrapped.json', { 'wrapped.json': envelopeWrapped, 'common_types.json': commonTypes }).valid, true);
        // 3. Validate runtime processing via MessageProcessor with STRICT_VALIDATION.
        const processor = new MessageProcessor([roundTripped], undefined, {
            validationConfig: STRICT_VALIDATION,
        });
        processor.processMessages({
            version: '1.0',
            createSurface: { surfaceId: 's1', catalogId: roundTripped.id },
        });
        for (const closedType of ['Banner', 'StrictBanner', 'CatchallBanner']) {
            processor.processMessages({
                version: '1.0',
                updateComponents: {
                    surfaceId: 's1',
                    components: [{ ...basePayload, component: closedType }],
                },
            });
            assert.strictEqual(processor.model.getSurface('s1')?.componentsModel.get('root')?.type, closedType);
            assert.throws(() => processor.processMessages({
                version: '1.0',
                updateComponents: {
                    surfaceId: 's1',
                    components: [{ ...basePayload, component: closedType, undeclared: 'nope' }],
                },
            }), A2uiValidationError);
        }
        processor.processMessages({
            version: '1.0',
            updateComponents: {
                surfaceId: 's1',
                components: [
                    {
                        'id': 'root',
                        'component': 'OpenBanner',
                        '@catalogId': roundTripped.id,
                        '@accessibility': basePayload['@accessibility'],
                        '@metadata': basePayload['@metadata'],
                        'text': 'Hello world',
                        'customExtra': 42,
                    },
                ],
            },
        });
        assert.strictEqual(processor.model.getSurface('s1')?.componentsModel.get('root')?.type, 'OpenBanner');
    });
    it('is what the deprecated fromSchema returns', () => {
        const document = readRepoJson('catalogs/mcp/catalog.json');
        assert.deepStrictEqual(Catalog.fromSchema(document).toJson(), document);
    });
});
describe('composite catalogs', () => {
    const Custom = { name: 'Custom', schema: z.object({ label: z.string() }).strict() };
    for (const [version, basic] of [
        ['0.9', v09BasicCatalog],
        ['1.0', v10BasicCatalog],
    ]) {
        for (const withUri of [false, true]) {
            it(`resolves every reference of reused v${version} basic entries${withUri ? ' given their common types URI' : ''}`, () => {
                const composite = new Catalog('https://example.com/composite', version, [...basic.components.values(), Custom], [...basic.functions.values()], withUri ? { commonTypesUri: basic.commonTypesUri } : undefined);
                const doc = composite.toJson();
                for (const ref of collectRefs(doc)) {
                    if (!ref.startsWith('#/'))
                        continue;
                    const target = ref
                        .slice(2)
                        .split('/')
                        .reduce((node, key) => node?.[key], doc);
                    assert.ok(target !== undefined, `reference '${ref}' resolves in toJson`);
                }
                // The models compute their definitions, and the definitions of their
                // mixins, in any catalog of their version; common types references
                // are written against the catalog's common types URI.
                const published = basic.toJson();
                const text = doc.components.Text;
                const publishedText = published.components.Text;
                if (withUri || version === '1.0') {
                    assert.deepStrictEqual(text, publishedText);
                }
                else {
                    assert.strictEqual(text.allOf[0].$ref, 'common_types.json#/$defs/ComponentCommon');
                }
                if (version === '0.9') {
                    assert.deepStrictEqual(doc.$defs.CatalogComponentCommon, published.$defs.CatalogComponentCommon);
                }
                const validationText = composite.validationSchema.components.Text;
                assert.ok('weight' in validationText.properties, 'validationSchema keeps weight');
                assert.deepStrictEqual(validationText, basic.validationSchema.components.Text);
                const reloaded = Catalog.fromJson(doc, version);
                const shape = reloaded.components.get('Text').schema.shape;
                assert.ok('weight' in shape, 'fromJson(toJson()) keeps weight');
                assert.ok(reloaded.components.get('Text').schema.safeParse({ text: 'hi', weight: 1 }).success);
            });
        }
    }
    it('drops a mixin definition when no remaining component composes it', () => {
        const derived = v09BasicCatalog.withEntries([Custom], []);
        const defs = derived.toJson().$defs;
        assert.ok(!('CatalogComponentCommon' in defs));
        assert.ok('theme' in defs, 'the theme model is kept');
        assert.deepStrictEqual(defs.anyComponent, {
            oneOf: [{ $ref: '#/components/Custom' }],
            discriminator: { propertyName: 'component' },
        });
    });
});
describe('entry definitions', () => {
    it('keeps no JSON definition on the built-in entries, which are generated models', () => {
        for (const [builtin, text] of [
            [v09BasicCatalog, V09Text],
            [v10BasicCatalog, V10Text],
        ]) {
            const entry = builtin.components.get('Text');
            assert.ok(!(entry instanceof JsonComponentApi));
            assert.ok(!('definition' in entry) && !('jsonSchema' in entry));
            assert.strictEqual(entry.schema, text.schema);
            assert.strictEqual(entry.tagName, text.tagName);
        }
    });
    it('serializes an entry copied with a new schema from that schema', () => {
        const changed = {
            ...v10BasicCatalog.components.get('Text'),
            schema: z.object({ text: z.string(), extra: z.number() }),
        };
        const loadedText = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json')).components.get('Text');
        const changedLoaded = {
            ...loadedText,
            schema: z.object({ text: z.string(), extra: z.number() }),
        };
        for (const entry of [changed, changedLoaded]) {
            const catalog = new Catalog('https://example.com/changed', '1.0', [entry]);
            const text = catalog.toJson().components.Text;
            assert.deepStrictEqual(Object.keys(text.properties), ['component', 'text', 'extra']);
            const validation = catalog.validationSchema.components.Text;
            assert.deepStrictEqual(Object.keys(validation.properties), [
                'id',
                'text',
                'extra',
                'component',
            ]);
        }
    });
    it('writes a loaded entry as its definition, and a spread copy from its schema', () => {
        const document = readRepoJson('catalogs/basic/v1/catalog.json');
        const loaded = Catalog.fromJson(document);
        const loadedText = loaded.components.get('Text');
        const reused = new Catalog('https://example.com/reused', '1.0', [loadedText], [], {
            defs: loaded.defs,
        });
        assert.deepStrictEqual(reused.toJson().components.Text, document.components.Text);
        // A spread copy keeps the derived schema but not the definition, so it
        // cannot write a definition that a changed field no longer matches.
        const copy = { ...loadedText };
        assert.ok(!(copy instanceof JsonComponentApi));
        assert.strictEqual(copy.schema, loadedText.schema);
        const copied = new Catalog('https://example.com/copied', '1.0', [copy]);
        const text = copied.toJson().components.Text;
        assert.deepStrictEqual(Object.keys(text.properties).sort(), [
            'component',
            'text',
            'variant',
            'weight',
        ]);
    });
    it('cannot be changed through the catalog', () => {
        const catalog = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
        const before = catalog.toJson();
        const text = catalog.components.get('Text');
        const openUrl = catalog.functions.get('openUrl');
        assert.throws(() => {
            text.jsonSchema.description = 'changed';
        }, TypeError);
        assert.throws(() => {
            openUrl.jsonSchema.description = 'changed';
        }, TypeError);
        assert.throws(() => {
            text.schema = z.object({});
        }, TypeError);
        assert.throws(() => {
            catalog.defs.extra = {};
        }, TypeError);
        assert.deepStrictEqual(catalog.toJson(), before);
    });
    it('copies the defs and extension fields a caller passes to the constructor', () => {
        const defs = { Shared: { type: 'string' } };
        const extensionFields = { extensions: { flag: true } };
        const catalog = new Catalog('https://example.com/own', '0.9', [], [], {
            defs,
            extensionFields,
        });
        defs.Shared.type = 'number';
        extensionFields.extensions.flag = false;
        assert.deepStrictEqual(catalog.toJson().extensions, { flag: true });
        assert.deepStrictEqual(catalog.defs, { Shared: { type: 'string' } });
        assert.deepStrictEqual(catalog.toJson().$defs, { Shared: { type: 'string' } });
    });
});
describe('specification annotations', () => {
    const Common = specDef('Common', z.object({ weight: z.number().describe('The weight.').optional() }));
    const Badge = {
        name: 'Badge',
        schema: spec(z
            .object({
            ...Common.shape,
            label: z.string().describe('REF:#/$defs/DynamicString|The label.'),
            tone: spec(z.enum(['info', 'warn']).describe('The tone.'), {
                keywords: { deprecated: true },
            }),
            size: z.number().int().optional(),
        })
            .describe('A badge.')
            .strict(), { mixins: ['ComponentCommon', Common], required: ['tone', 'label'] }),
    };
    it('computes a v0.9 definition with allOf mixins and the catalog definitions they name', () => {
        const out = new Catalog('https://example.com/badges', '0.9', [Badge], [], {
            commonTypesUri: 'https://example.com/common_types.json',
        }).toJson();
        assert.deepStrictEqual(out.components.Badge, {
            type: 'object',
            allOf: [
                { $ref: 'https://example.com/common_types.json#/$defs/ComponentCommon' },
                { $ref: '#/$defs/Common' },
                {
                    type: 'object',
                    description: 'A badge.',
                    properties: {
                        component: { const: 'Badge' },
                        label: {
                            $ref: 'https://example.com/common_types.json#/$defs/DynamicString',
                            description: 'The label.',
                        },
                        tone: {
                            type: 'string',
                            enum: ['info', 'warn'],
                            description: 'The tone.',
                            deprecated: true,
                        },
                        size: { type: 'integer' },
                    },
                    required: ['component', 'tone', 'label'],
                },
            ],
            unevaluatedProperties: false,
        });
        assert.deepStrictEqual(out.$defs.Common, {
            type: 'object',
            properties: { weight: { type: 'number', description: 'The weight.' } },
        });
    });
    it('computes a v1.0 definition without mixins as a flat object', () => {
        const out = new Catalog('https://example.com/badges', '1.0', [
            { ...Badge, schema: spec(Badge.schema, { mixins: [] }) },
        ]).toJson();
        const badge = out.components.Badge;
        assert.strictEqual(badge.description, 'A badge.');
        assert.strictEqual(badge.allOf, undefined);
        assert.deepStrictEqual(Object.keys(badge.properties), [
            'component',
            'weight',
            'label',
            'tone',
            'size',
        ]);
        assert.ok(!('Common' in out.$defs), 'no mixin, no definition');
    });
    it('does not change validation', () => {
        const annotated = spec(z.string(), { keywords: { format: 'uri' } });
        assert.ok(annotated.safeParse('not a uri').success);
        assert.ok(Badge.schema.safeParse({ label: 'x', tone: 'info' }).success);
        assert.ok(!Badge.schema.safeParse({ label: 'x', tone: 'other' }).success);
    });
    it('recomputes an out-of-order authored union when withEntries changes entries', () => {
        const reordered = Catalog.fromJson({
            catalogId: 'https://example.com/reordered',
            components: {
                Card: { type: 'object', properties: { component: { const: 'Card' } } },
                Label: { type: 'object', properties: { component: { const: 'Label' } } },
            },
            $defs: {
                anyComponent: {
                    oneOf: [{ $ref: '#/components/Label' }, { $ref: '#/components/Card' }],
                    discriminator: { propertyName: 'component' },
                },
            },
        });
        const prunedReordered = reordered
            .withEntries([reordered.components.get('Label')], [])
            .toJson();
        assert.deepStrictEqual(prunedReordered.$defs.anyComponent, {
            oneOf: [{ $ref: '#/components/Label' }],
            discriminator: { propertyName: 'component' },
        });
    });
    it('uses commonTypesUri when serializing unannotated Zod REF markers', () => {
        const uri = 'https://a2ui.org/specification/v0_9/common_types.json';
        const comp = {
            name: 'Label',
            schema: z.object({ text: z.string().describe('REF:#/$defs/DynamicString') }),
        };
        const out = new Catalog('https://example.com/custom-uri', '0.9', [comp], [], {
            commonTypesUri: uri,
        }).toJson();
        assert.strictEqual(out.components.Label.properties.text
            .$ref, `${uri}#/$defs/DynamicString`);
    });
    it('preserves required keys omitted from a spec() required ordering hint', () => {
        const comp = {
            name: 'Form',
            schema: spec(z.object({ a: z.string(), b: z.string(), c: z.string() }).strict(), {
                mixins: [],
                required: ['b', 'a'],
            }),
        };
        const out = new Catalog('https://example.com/form', '1.0', [comp]).toJson();
        assert.deepStrictEqual(out.components.Form.required, [
            'component',
            'b',
            'a',
            'c',
        ]);
    });
    it('omits args from required on a spec()-annotated function without required arguments', () => {
        const fn = createFunctionImplementation({
            name: 'now',
            returnType: 'string',
            schema: spec(z.object({ format: z.string().optional() }).strict(), {
                closure: 'unevaluatedProperties',
            }),
        }, () => '');
        for (const version of ['0.9', '1.0']) {
            const cat = new Catalog(`https://example.com/spec-now/${version}`, version, [], [fn]);
            const docFn = cat.toJson().functions.now;
            const valFn = cat.validationSchema.functions.now;
            assert.ok(!docFn.required.includes('args'), `toJson omits args in ${version}`);
            assert.deepStrictEqual(docFn.required, valFn.required);
        }
    });
    it('requires args when every branch of a union function argument schema requires arguments', () => {
        const unionSchema = z.union([
            z.object({ kind: z.literal('a'), value: z.string() }),
            z.object({ kind: z.literal('b'), count: z.number() }),
        ]);
        const choose = createFunctionImplementation({
            name: 'choose',
            returnType: 'string',
            schema: unionSchema,
        }, () => 'result');
        const chooseSpec = createFunctionImplementation({
            name: 'chooseSpec',
            returnType: 'string',
            schema: spec(unionSchema, {}),
        }, () => 'result');
        for (const [version, callKey] of [
            ['0.9', 'call'],
            ['1.0', '@call'],
        ]) {
            const cat = new Catalog(`https://example.com/union-required/${version}`, version, [], [choose, chooseSpec]);
            const docFns = cat.toJson().functions;
            const valFns = cat.validationSchema.functions;
            assert.deepStrictEqual(docFns.choose.required, [callKey, 'args']);
            assert.deepStrictEqual(valFns.choose.required, [callKey, 'args']);
            assert.deepStrictEqual(docFns.chooseSpec.required, [callKey, 'args']);
            assert.deepStrictEqual(valFns.chooseSpec.required, [callKey, 'args']);
        }
    });
    it('omits args from required when at least one branch of a union function schema has no required arguments', () => {
        const optionalBranchUnion = z.union([
            z.object({ kind: z.literal('a'), value: z.string() }),
            z.object({ format: z.string().optional() }),
        ]);
        const chooseOptional = createFunctionImplementation({
            name: 'chooseOptional',
            returnType: 'string',
            schema: optionalBranchUnion,
        }, () => 'result');
        const chooseOptionalSpec = createFunctionImplementation({
            name: 'chooseOptionalSpec',
            returnType: 'string',
            schema: spec(optionalBranchUnion, {}),
        }, () => 'result');
        for (const [version, callKey] of [
            ['0.9', 'call'],
            ['1.0', '@call'],
        ]) {
            const cat = new Catalog(`https://example.com/union-optional/${version}`, version, [], [chooseOptional, chooseOptionalSpec]);
            const docFns = cat.toJson().functions;
            const valFns = cat.validationSchema.functions;
            assert.deepStrictEqual(docFns.chooseOptional.required, [callKey]);
            assert.deepStrictEqual(valFns.chooseOptional.required, [callKey]);
            assert.deepStrictEqual(docFns.chooseOptionalSpec.required, [callKey]);
            assert.deepStrictEqual(valFns.chooseOptionalSpec.required, [callKey]);
        }
    });
});
describe('built-in basic catalogs', () => {
    /**
     * Differences between a built-in catalog's Zod schemas and its
     * published document that are known and accepted, as `<label>:<entry>`.
     */
    const KNOWN_DIFFERENCES = new Set([]);
    /** The names, properties, required lists and function metadata of a validation schema. */
    function summarize(schema) {
        const components = {};
        for (const [name, comp] of Object.entries((schema.components ?? {}))) {
            components[name] = {
                properties: Object.keys(comp.properties ?? {}).sort(),
                required: [...(comp.required ?? [])].sort(),
            };
        }
        const functions = {};
        for (const [name, fn] of Object.entries((schema.functions ?? {}))) {
            const args = fn.properties?.args ?? {};
            functions[name] = {
                returnType: fn.returnType ?? fn.properties?.returnType?.const,
                allowedCallers: fn.allowedCallers,
                requiresUserActivation: fn.requiresUserActivation,
                args: Object.keys(args.properties ?? {}).sort(),
                argsRequired: [...(args.required ?? [])].sort(),
            };
        }
        return { components, functions };
    }
    for (const [label, builtin] of [
        ['v0.8', v08BasicCatalog],
        ['v0.9', v09BasicCatalog],
        ['1.0', v10BasicCatalog],
    ]) {
        it(`keeps the ${label} Zod schemas in line with the published document`, () => {
            // Copies of the entries without their annotations are generated from Zod.
            const fromZod = new Catalog(builtin.id, builtin.protocolVersion, [...builtin.components.values()].map(plain), [...builtin.functions.values()].map(plain), { themeSchema: builtin.themeSchema });
            const published = summarize(builtin.validationSchema);
            const zod = summarize(fromZod.validationSchema);
            assert.deepStrictEqual(Object.keys(zod.components).sort(), Object.keys(published.components).sort());
            assert.deepStrictEqual(Object.keys(zod.functions).sort(), Object.keys(published.functions).sort());
            for (const section of ['components', 'functions']) {
                for (const [name, expected] of Object.entries(published[section])) {
                    if (KNOWN_DIFFERENCES.has(`${label}:${name}`))
                        continue;
                    assert.deepStrictEqual(zod[section][name], expected, `${label} ${section} ${name}`);
                }
            }
        });
    }
    it('preserves specDef references across .describe(), avoids leaking def metadata, and resolves union disjointness', () => {
        const ColorToken = specDef('ColorToken', z.enum(['primary', 'secondary']).default('primary'), {
            keywords: { title: 'ColorToken' },
        });
        const ColorValue = specDef('ColorValue', z.union([ColorToken, z.number()]));
        const BoxComponent = {
            name: 'Box',
            schema: spec(z
                .object({
                id: z.string(),
                component: z.literal('Box'),
                color: ColorValue.describe('Override color description').optional(),
                token: ColorToken.optional(),
            })
                .strict(), { mixins: [] }),
        };
        const cat = new Catalog('https://example.com/cat', '1.0', [BoxComponent], []);
        const doc = cat.toJson();
        const defs = doc.$defs;
        assert.deepStrictEqual(defs.ColorToken, {
            type: 'string',
            enum: ['primary', 'secondary'],
            title: 'ColorToken',
            default: 'primary',
        });
        assert.deepStrictEqual(defs.ColorValue, {
            oneOf: [{ $ref: '#/$defs/ColorToken' }, { type: 'number' }],
        });
        const boxProps = doc.components.Box.properties;
        assert.deepStrictEqual(boxProps.color, {
            $ref: '#/$defs/ColorValue',
            description: 'Override color description',
        });
        assert.deepStrictEqual(boxProps.token, {
            $ref: '#/$defs/ColorToken',
        });
    });
    it('validates LeafDefinitionSchema and ComponentDefinitionSchema against catalog_schema_relaxation.json', async () => {
        const { LeafDefinitionSchema, ComponentDefinitionSchema } = await import('../v1_0/schema/catalog-definition.js');
        const suite = readRepoJson('specification/v1_0/test/cases/catalog_schema_relaxation.json');
        const validCatalog = suite.tests[0].data;
        for (const [defName, defSchema] of Object.entries(validCatalog.$defs)) {
            if (defName === 'anyComponent' || defName === 'anyFunction')
                continue;
            assert.strictEqual(LeafDefinitionSchema.safeParse(defSchema).success, true, `Expected valid leaf def ${defName} to pass LeafDefinitionSchema`);
        }
        for (const [compName, compSchema] of Object.entries(validCatalog.components)) {
            assert.strictEqual(ComponentDefinitionSchema.safeParse(compSchema).success, true, `Expected valid component ${compName} to pass ComponentDefinitionSchema`);
        }
        assert.strictEqual(LeafDefinitionSchema.safeParse(suite.tests[1].data.$defs.BadComponentDef).success, false);
        assert.strictEqual(LeafDefinitionSchema.safeParse(suite.tests[2].data.$defs.BadWrappedComponentDef).success, false);
        assert.strictEqual(ComponentDefinitionSchema.safeParse(suite.tests[3].data.components.Card).success, false);
        assert.strictEqual(ComponentDefinitionSchema.safeParse(suite.tests[4].data.components.Card).success, false);
    });
});
describe('Catalog.derive', () => {
    const basic = Catalog.fromJson(readRepoJson('catalogs/basic/v1/catalog.json'));
    const label = { name: 'Label', schema: z.object({ text: z.string() }) };
    it('keeps the named entries and adds new ones under the new ID', () => {
        const derived = basic.derive({
            catalogId: 'https://example.com/chat',
            components: ['Text', 'Button', label],
            functions: ['openUrl'],
        });
        assert.strictEqual(derived.id, 'https://example.com/chat');
        assert.strictEqual(derived.protocolVersion, basic.protocolVersion);
        assert.deepStrictEqual([...derived.components.keys()], ['Text', 'Button', 'Label']);
        assert.strictEqual(derived.components.get('Text'), basic.components.get('Text'));
        assert.strictEqual(derived.components.get('Label'), label);
        assert.deepStrictEqual([...derived.functions.keys()], ['openUrl']);
        assert.strictEqual(derived.themeSchema, basic.themeSchema);
        const out = derived.toJson();
        assert.strictEqual(out.catalogId, 'https://example.com/chat');
        assert.deepStrictEqual(Object.keys(out.components), ['Text', 'Button', 'Label']);
    });
    it("drops the source's $id, title, description and instructions", () => {
        const out = basic.derive({ catalogId: 'https://example.com/chat' }).toJson();
        assert.strictEqual(out.$schema, basic.schemaUri);
        assert.ok(!('$id' in out));
        assert.ok(!('title' in out));
        assert.ok(!('description' in out));
        assert.ok(!('instructions' in out));
    });
    it('takes the instructions it is given', () => {
        const derived = basic.derive({
            catalogId: 'https://example.com/chat',
            instructions: 'Be brief.',
        });
        assert.strictEqual(derived.instructions, 'Be brief.');
        assert.strictEqual(derived.toJson().instructions, 'Be brief.');
    });
    it('keeps every entry of a kind it is given no list for', () => {
        const derived = basic.derive({ catalogId: 'https://example.com/chat' });
        assert.deepStrictEqual([...derived.components.keys()], [...basic.components.keys()]);
        assert.deepStrictEqual([...derived.functions.keys()], [...basic.functions.keys()]);
    });
    it("replaces the source's entry with a new entry of the same name", () => {
        const text = { name: 'Text', schema: z.object({ text: z.string() }) };
        const derived = basic.derive({
            catalogId: 'https://example.com/chat',
            components: [text],
        });
        assert.strictEqual(derived.components.get('Text'), text);
    });
    it('throws for a name the source has no entry of', () => {
        assert.throws(() => basic.derive({ catalogId: 'https://example.com/chat', components: ['Nope'] }), (e) => e instanceof A2uiCatalogError &&
            e.message.includes("has no component 'Nope'") &&
            e.message.includes('https://example.com/chat'));
        assert.throws(() => basic.derive({ catalogId: 'https://example.com/chat', functions: ['nope'] }), (e) => e instanceof A2uiCatalogError && e.message.includes("has no function 'nope'"));
    });
    it('drops authored $defs that only left-out entries referenced', () => {
        const loaded = Catalog.fromJson(readRepoJson('specification/v0_9/catalogs/basic/catalog.json'));
        const derived = loaded.derive({ catalogId: 'https://example.com/chat', components: [] });
        const defs = derived.toJson().$defs;
        assert.ok(!('CatalogComponentCommon' in defs));
        assert.ok('theme' in defs);
    });
});
//# sourceMappingURL=schema_serializer.test.js.map