export {};
//# sourceMappingURL=component_envelope.test.d.ts.map