export {};
//# sourceMappingURL=reference-map.test.d.ts.map