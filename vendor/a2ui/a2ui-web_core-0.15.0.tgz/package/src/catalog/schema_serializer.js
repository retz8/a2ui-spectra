/*
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { zodToJsonSchema } from 'zod-to-json-schema';
import { isAtLeastVersion, toCanonicalVersion } from '../common/semver.js';
import { isAgentFunction } from './agent_function_brand.js';
import { exclusiveUnionOverride } from './exclusive_union.js';
import { loadedDefinition } from './json_entries.js';
import { getSpecAnnotation } from './spec_annotations.js';
import { DEFAULT_COMMON_TYPES_URI, isSpecComponentSchema, isSpecFunctionSchema, schemaRequiresArgs, SpecShaper, } from './spec_shape.js';
/** Names of the union definitions a catalog computes from its entries. */
export const UNION_DEF_NAMES = new Set(['anyComponent', 'anyFunction']);
/** Top-level keys under which a catalog document may declare its theme. */
export const THEME_DOCUMENT_KEYS = ['theme', 'themeSchema', 'styles'];
/**
 * Returns a deep copy of a JSON value.
 *
 * @param value JSON-compatible value to copy.
 * @returns A structurally equal copy that shares no objects with `value`.
 */
export function deepCopyJson(value) {
    if (value === undefined)
        return value;
    return JSON.parse(JSON.stringify(value));
}
/**
 * Freezes a JSON value and everything it contains, in place.
 *
 * @param value JSON-compatible value.
 * @returns `value`.
 */
export function deepFreeze(value) {
    if (typeof value === 'object' && value !== null && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const child of Object.values(value))
            deepFreeze(child);
    }
    return value;
}
/**
 * Returns a deeply frozen copy of a JSON value, or the value itself when it is
 * already frozen.
 *
 * @param value JSON-compatible value.
 */
export function frozenJson(value) {
    if (typeof value !== 'object' || value === null || Object.isFrozen(value))
        return value;
    return deepFreeze(deepCopyJson(value));
}
function isObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/**
 * Adds to `found` the name of every definition a local `#/$defs/<name>`
 * reference in `node` reaches: the first segment of its pointer.
 */
function collectLocalDefNames(node, found) {
    if (Array.isArray(node)) {
        for (const item of node)
            collectLocalDefNames(item, found);
        return;
    }
    if (!isObject(node))
        return;
    const ref = node.$ref;
    if (typeof ref === 'string' && ref.startsWith('#/$defs/')) {
        found.add(ref.slice('#/$defs/'.length).split('/')[0].replace(/~1/g, '/').replace(/~0/g, '~'));
    }
    for (const value of Object.values(node))
        collectLocalDefNames(value, found);
}
/**
 * Returns the names of the definitions `roots` reach through local
 * references, directly or through other definitions of `defs`. Names `defs`
 * does not define are included.
 */
function reachableDefs(roots, defs) {
    const reached = new Set();
    const pending = new Set();
    for (const root of roots)
        collectLocalDefNames(root, pending);
    while (pending.size > 0) {
        const [name] = pending;
        pending.delete(name);
        if (reached.has(name))
            continue;
        reached.add(name);
        if (name in defs)
            collectLocalDefNames(defs[name], pending);
    }
    return reached;
}
/**
 * Returns the definition of an entry `Catalog.fromJson` loaded, if
 * `toJson` and `validationSchema` can use it in a catalog with `defs`, or
 * `undefined` when they should build the entry from its model instead.
 *
 * A definition is used when every local `#/$defs/<name>` reference it reaches
 * resolves against `defs` (or names a union the catalog computes). A loaded
 * entry reused in a catalog without the definitions it references falls back
 * to its Zod schema.
 *
 * @param entry A component or function.
 * @param defs The definitions of the catalog that holds the entry.
 */
export function entryDefinition(entry, defs) {
    const definition = loadedDefinition(entry);
    if (!isObject(definition))
        return undefined;
    const available = defs ?? {};
    for (const name of reachableDefs([definition], available)) {
        if (!(name in available) && !UNION_DEF_NAMES.has(name))
            return undefined;
    }
    return definition;
}
/**
 * Whether a function definition is an item of a `functions` list (with its
 * `name` and `parameters`) rather than an entry of a `functions` map.
 */
export function isFunctionListItem(definition) {
    return typeof definition['name'] === 'string' && !('properties' in definition);
}
/**
 * Returns the definitions of `defs` that a catalog with the entries `after`
 * keeps, given that it is derived from a catalog with the entries `before`.
 *
 * A definition that only entries of `before` missing from `after` reached is
 * dropped. One that no entry of `before` reached, such as a theme, is kept,
 * and so is everything it reaches.
 *
 * @param defs The `defs` of the catalog derived from.
 * @param before The entries of the catalog derived from.
 * @param after The entries of the derived catalog.
 * @param extensionFields The document's other top-level fields, whose
 *     references keep definitions too.
 * @returns `defs` itself when nothing is dropped.
 */
export function retainedDefs(defs, before, after, extensionFields) {
    if (!defs)
        return defs;
    const definitions = (entries) => entries
        .map(entry => entryDefinition(entry, defs) ?? (isAgentFunction(entry) ? entry.jsonSchema : undefined))
        .filter(d => d !== undefined);
    const reachedBefore = reachableDefs(definitions(before), defs);
    const unconditional = Object.keys(defs).filter(name => !reachedBefore.has(name));
    const reachedAfter = reachableDefs([...definitions(after), extensionFields, ...unconditional.map(name => defs[name])], defs);
    const kept = {};
    let dropped = false;
    for (const [name, def] of Object.entries(defs)) {
        if (!reachedBefore.has(name) || reachedAfter.has(name)) {
            kept[name] = def;
        }
        else {
            dropped = true;
        }
    }
    return dropped ? kept : defs;
}
/**
 * Rewrites `REF:<ref>|<description>` markers left by the loader and by
 * code-defined schemas into `$ref` nodes, keeping common types references
 * external (`<commonTypesUri>#/$defs/<name>`).
 *
 * @param node Schema node to rewrite in place.
 * @param localDefs Names of authored definitions that stay local references.
 * @param commonTypesUri The URI of the common types document.
 */
function rewriteRefMarkers(node, localDefs, commonTypesUri = DEFAULT_COMMON_TYPES_URI) {
    if (Array.isArray(node)) {
        for (const item of node)
            rewriteRefMarkers(item, localDefs, commonTypesUri);
        return;
    }
    if (!isObject(node))
        return;
    if (typeof node.description === 'string' && node.description.startsWith('REF:')) {
        const content = node.description.substring(4);
        const pipeIndex = content.indexOf('|');
        const ref = pipeIndex === -1 ? content : content.substring(0, pipeIndex);
        const desc = pipeIndex === -1 ? '' : content.substring(pipeIndex + 1);
        const savedDefault = node.default;
        for (const key of Object.keys(node))
            delete node[key];
        // The first segment names the definition; a deeper pointer into it, such as
        // `/oneOf/0`, is kept whole.
        const pointer = ref.split(/#\/(?:\$defs|definitions)\//)[1];
        const defName = pointer?.split('/')[0];
        node.$ref =
            defName === undefined
                ? ref
                : ref.startsWith('#') && localDefs.has(defName)
                    ? ref
                    : `${commonTypesUri}#/$defs/${pointer}`;
        if (savedDefault !== undefined)
            node.default = savedDefault;
        if (desc)
            node.description = desc;
        return;
    }
    for (const key of ['additionalProperties', 'unevaluatedProperties']) {
        const value = node[key];
        if (isObject(value) && Object.keys(value).length === 0)
            node[key] = true;
    }
    delete node.$schema;
    for (const value of Object.values(node))
        rewriteRefMarkers(value, localDefs, commonTypesUri);
}
/**
 * Converts a Zod schema into an unbundled JSON Schema object.
 */
function zodToUnbundledJson(schema, localDefs, commonTypesUri = DEFAULT_COMMON_TYPES_URI) {
    if (!schema || typeof schema !== 'object' || !('safeParse' in schema)) {
        return { type: 'object', properties: {} };
    }
    const json = zodToJsonSchema(schema, {
        target: 'jsonSchema2019-09',
        $refStrategy: 'none',
        override: exclusiveUnionOverride,
    });
    delete json.definitions;
    delete json.$defs;
    rewriteRefMarkers(json, localDefs, commonTypesUri);
    return json;
}
/**
 * Moves an object schema's `additionalProperties` to `unevaluatedProperties`,
 * defaulting to `false`.
 */
function closeObjectSchema(json) {
    if (json.type !== 'object')
        return;
    const extra = json.unevaluatedProperties ?? json.additionalProperties;
    delete json.additionalProperties;
    json.unevaluatedProperties =
        typeof extra === 'boolean' || isObject(extra) ? extra : false;
}
/**
 * Serializes a component from its model, as an authored catalog entry.
 */
function serializeComponentModel(name, comp, localDefs, isAtLeastV10, commonTypesUri = DEFAULT_COMMON_TYPES_URI) {
    const json = zodToUnbundledJson(comp.schema, localDefs, commonTypesUri);
    const { component: _component, id: _id, ...props } = (isObject(json.properties) ? json.properties : {});
    const required = Array.isArray(json.required)
        ? json.required.filter(r => r !== 'component' && r !== 'id')
        : [];
    const extra = json.unevaluatedProperties ?? json.additionalProperties;
    // From v1.0 the protocol's Component envelope combines the entry with
    // ComponentCommon in a sibling `allOf` branch under an outer
    // `unevaluatedProperties: false` (and forbids wrapping ComponentCommon
    // inside individual component entries), so emitting `false` or a catchall
    // subschema on the entry itself would apply to ComponentCommon fields.
    const closure = isAtLeastV10
        ? extra === true
            ? true
            : undefined
        : typeof extra === 'boolean' || isObject(extra)
            ? extra
            : false;
    const result = {
        type: 'object',
        properties: { component: { const: name }, ...props },
        required: ['component', ...required],
        ...(closure !== undefined ? { unevaluatedProperties: closure } : {}),
    };
    if (comp.allowedParents && comp.allowedParents.length > 0) {
        result.allowedParents = [...comp.allowedParents];
    }
    if (comp.allowedChildren && comp.allowedChildren.length > 0) {
        result.allowedChildren = [...comp.allowedChildren];
    }
    if (comp.metadata !== undefined) {
        result.metadata = deepCopyJson(comp.metadata);
    }
    return result;
}
/**
 * Serializes a function from its model, in the call shape of the catalog's
 * protocol version (`@call` from v1.0, `call` before), or as a list item.
 */
function serializeFunctionModel(name, fn, localDefs, isAtLeastV10, asListItem, commonTypesUri = DEFAULT_COMMON_TYPES_URI, defs) {
    const args = zodToUnbundledJson(fn.schema, localDefs, commonTypesUri);
    // An agent function writes only what its declaration or constructor set,
    // not its defaults.
    const allowedCallers = isAgentFunction(fn) ? fn.explicitAllowedCallers : fn.allowedCallers;
    const requiresUserActivation = isAgentFunction(fn)
        ? fn.explicitRequiresUserActivation
        : fn.requiresUserActivation;
    if (asListItem) {
        return {
            name,
            ...(fn.description ? { description: fn.description } : {}),
            returnType: fn.returnType,
            parameters: args,
            ...(allowedCallers ? { allowedCallers } : {}),
            ...(requiresUserActivation !== undefined ? { requiresUserActivation } : {}),
        };
    }
    closeObjectSchema(args);
    // A call to a function without required parameters may omit `args`, as in
    // the validation schema.
    const argsRequired = schemaRequiresArgs(args, defs);
    const result = { type: 'object' };
    if (fn.description)
        result.description = fn.description;
    if (isAtLeastV10) {
        result.returnType = fn.returnType;
        if (allowedCallers)
            result.allowedCallers = allowedCallers;
        if (requiresUserActivation !== undefined) {
            result.requiresUserActivation = requiresUserActivation;
        }
        result.properties = { '@call': { const: name }, args };
        result.required = argsRequired ? ['@call', 'args'] : ['@call'];
        return result;
    }
    if (allowedCallers)
        result.allowedCallers = allowedCallers;
    if (requiresUserActivation !== undefined) {
        result.requiresUserActivation = requiresUserActivation;
    }
    result.properties = { call: { const: name }, args, returnType: { const: fn.returnType } };
    result.required = argsRequired ? ['call', 'args'] : ['call'];
    result.unevaluatedProperties = false;
    return result;
}
/**
 * Serializes a theme Zod schema into a `$defs.theme` object schema.
 */
function serializeThemeModel(theme, localDefs, commonTypesUri = DEFAULT_COMMON_TYPES_URI) {
    const json = zodToUnbundledJson(theme, localDefs, commonTypesUri);
    return {
        type: 'object',
        properties: isObject(json.properties) ? json.properties : {},
        ...(Array.isArray(json.required) && json.required.length > 0 ? { required: json.required } : {}),
        additionalProperties: json.additionalProperties !== undefined ? json.additionalProperties : true,
    };
}
/**
 * A union that no value matches. JSON Schema requires `oneOf` to list at least
 * one schema, so an empty union cannot be written as `{oneOf: []}`.
 */
const EMPTY_UNION = { not: {} };
export function buildComponentUnion(names) {
    const oneOf = [...names].map(name => ({ $ref: `#/components/${escapePointer(name)}` }));
    if (oneOf.length === 0)
        return { ...EMPTY_UNION };
    return { oneOf, discriminator: { propertyName: 'component' } };
}
export function buildFunctionUnion(names) {
    const oneOf = [...names].map(name => ({ $ref: `#/functions/${escapePointer(name)}` }));
    return oneOf.length === 0 ? { ...EMPTY_UNION } : { oneOf };
}
function escapePointer(token) {
    return token.replace(/~/g, '~0').replace(/\//g, '~1');
}
const documentModels = new WeakMap();
/**
 * Returns the document model of a catalog, computed from the catalog's
 * entries, fields and models, and memoized per catalog. It is deeply frozen.
 *
 * @param catalog The catalog.
 */
export function catalogDocumentModel(catalog) {
    let model = documentModels.get(catalog);
    if (!model) {
        model = buildDocumentModel(catalog);
        documentModels.set(catalog, model);
    }
    return model;
}
function buildDocumentModel(catalog) {
    const shaper = new SpecShaper(catalog.protocolVersion, catalog.commonTypesUri);
    const computedDefs = new Map();
    const shapedComponents = new Map();
    for (const [name, comp] of catalog.components) {
        if (loadedDefinition(comp) || !isSpecComponentSchema(comp.schema))
            continue;
        const { schema, catalogDefs } = shaper.componentSchema(name, comp.schema, comp.allowedParents, comp.allowedChildren);
        if (comp.metadata !== undefined) {
            schema['metadata'] = deepCopyJson(comp.metadata);
        }
        shapedComponents.set(name, deepFreeze(schema));
        for (const [defName, defModel] of catalogDefs)
            computedDefs.set(defName, defModel);
    }
    for (const defModel of catalog.defModels ?? []) {
        const defName = getSpecAnnotation(defModel)?.defName;
        if (defName === undefined) {
            throw new Error('A catalog definition model must be named with specDef().');
        }
        computedDefs.set(defName, defModel);
    }
    const functions = new Map();
    const rawFunctions = new Map();
    for (const [name, fn] of catalog.functions) {
        if (!loadedDefinition(fn) && isSpecFunctionSchema(fn.schema)) {
            rawFunctions.set(name, fn);
            // Pre-scan function schema for any referenced catalog $defs models.
            shaper.toJson(fn.schema, computedDefs);
        }
    }
    const defs = { ...catalog.defs };
    const serializedDefs = new Set();
    while ([...computedDefs.keys()].some(defName => !serializedDefs.has(defName) && !(defName in defs))) {
        for (const [defName, defModel] of [...computedDefs]) {
            if (serializedDefs.has(defName) || defName in defs)
                continue;
            serializedDefs.add(defName);
            defs[defName] = shaper.defSchema(defModel, computedDefs);
        }
    }
    const extensionFields = { ...catalog.extensionFields };
    if (catalog.themeLocation === 'styles' && catalog.themeSchema && !hasAuthoredTheme(catalog)) {
        const theme = shaper.defSchema(catalog.themeSchema);
        extensionFields['styles'] = isObject(theme['properties']) ? theme['properties'] : {};
    }
    const components = new Map();
    for (const [name, comp] of catalog.components) {
        components.set(name, shapedComponents.get(name) ?? entryDefinition(comp, defs));
    }
    for (const [name, fn] of catalog.functions) {
        const loaded = entryDefinition(fn, defs);
        functions.set(name, loaded ??
            (rawFunctions.has(name)
                ? deepFreeze(shaper.functionSchema(name, fn, defs, computedDefs))
                : undefined));
    }
    return {
        components,
        functions,
        defs: deepFreeze(defs),
        extensionFields: deepFreeze(extensionFields),
    };
}
/** Whether the catalog's `defs` or top-level fields declare a theme. */
function hasAuthoredTheme(catalog) {
    return (isObject(catalog.defs?.['theme']) ||
        THEME_DOCUMENT_KEYS.some(key => catalog.extensionFields?.[key] !== undefined));
}
/**
 * Serializes a catalog into an unbundled catalog document, assembled from the
 * catalog's model. See `Catalog.toJson` for the full contract.
 *
 * @param catalog The catalog to serialize.
 * @returns A fresh catalog document that shares no objects with the catalog.
 */
export function serializeCatalogDocument(catalog) {
    const isAtLeastV10 = isAtLeastVersion(catalog.protocolVersion, '1.0');
    const model = catalogDocumentModel(catalog);
    const localDefs = new Set(Object.keys(model.defs));
    const doc = {};
    if (catalog.schemaUri !== undefined)
        doc.$schema = catalog.schemaUri;
    if (catalog.schemaId !== undefined)
        doc.$id = catalog.schemaId;
    if (typeof catalog.declaredProtocolVersion === 'string') {
        doc.protocolVersion = catalog.declaredProtocolVersion;
    }
    else if (catalog.declaredProtocolVersion === undefined) {
        doc.protocolVersion = toCanonicalVersion(catalog.protocolVersion) ?? catalog.protocolVersion;
    }
    if (catalog.title !== undefined)
        doc.title = catalog.title;
    if (catalog.description !== undefined)
        doc.description = catalog.description;
    if (catalog.declaresCatalogId !== false)
        doc.catalogId = catalog.id;
    if (catalog.instructions !== undefined)
        doc.instructions = catalog.instructions;
    // Components, unless the document has no `components` key and the catalog
    // has none.
    const commonTypesUri = catalog.commonTypesUri ?? DEFAULT_COMMON_TYPES_URI;
    if (catalog.declaresComponents !== false || catalog.components.size > 0) {
        const components = {};
        for (const [name, comp] of catalog.components) {
            const definition = model.components.get(name);
            components[name] = definition
                ? deepCopyJson(definition)
                : serializeComponentModel(name, comp, localDefs, isAtLeastV10, commonTypesUri);
        }
        doc.components = components;
    }
    // Functions, in the document's layout. System functions such as `@index`
    // belong to the protocol rather than the catalog, so a code-defined one that
    // a catalog registers for evaluation is not part of the document.
    const functionEntries = [...catalog.functions].filter(([name, fn]) => loadedDefinition(fn) !== undefined || !name.startsWith('@'));
    const functionNames = functionEntries.map(([name]) => name);
    if (catalog.functionsLayout === 'list') {
        doc.functions = functionEntries.map(([name, fn]) => {
            const definition = model.functions.get(name);
            return definition && isFunctionListItem(definition)
                ? deepCopyJson(definition)
                : serializeFunctionModel(name, fn, localDefs, isAtLeastV10, true, commonTypesUri, model.defs);
        });
    }
    else if (catalog.functionsLayout === 'map' || functionEntries.length > 0) {
        const functions = {};
        for (const [name, fn] of functionEntries) {
            const definition = model.functions.get(name);
            functions[name] =
                definition && !isFunctionListItem(definition)
                    ? deepCopyJson(definition)
                    : serializeFunctionModel(name, fn, localDefs, isAtLeastV10, false, commonTypesUri, model.defs);
        }
        doc.functions = functions;
    }
    // Any other top-level keys of the document, such as a v0.8 `styles` theme.
    for (const [key, value] of Object.entries(model.extensionFields)) {
        if (!(key in doc))
            doc[key] = deepCopyJson(value);
    }
    // Definitions: the catalog's own and those computed from its models, a
    // theme generated from Zod for a catalog defined in code, and the computed
    // unions.
    const defs = deepCopyJson({ ...model.defs });
    const themeLocation = catalog.themeLocation ?? (isAtLeastV10 ? undefined : 'defs');
    if (themeLocation === 'defs' && catalog.themeSchema && !hasAuthoredTheme(model)) {
        defs.theme = getSpecAnnotation(catalog.themeSchema)
            ? new SpecShaper(catalog.protocolVersion, catalog.commonTypesUri).defSchema(catalog.themeSchema)
            : serializeThemeModel(catalog.themeSchema, localDefs, commonTypesUri);
    }
    const unions = catalog.unions ?? {
        anyComponent: isAtLeastV10 || catalog.components.size > 0,
        anyFunction: isAtLeastV10 || functionNames.length > 0,
    };
    if (unions.anyComponent && !('anyComponent' in defs)) {
        const savedAnyFunction = defs.anyFunction;
        if (savedAnyFunction !== undefined)
            delete defs.anyFunction;
        defs.anyComponent = buildComponentUnion(catalog.components.keys());
        if (savedAnyFunction !== undefined)
            defs.anyFunction = savedAnyFunction;
    }
    if (unions.anyFunction && !('anyFunction' in defs)) {
        defs.anyFunction = buildFunctionUnion(functionNames);
    }
    if (catalog.defs !== undefined || Object.keys(defs).length > 0) {
        doc.$defs = defs;
    }
    return doc;
}
//# sourceMappingURL=schema_serializer.js.map