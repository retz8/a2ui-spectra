export {};
//# sourceMappingURL=schema_serializer.test.d.ts.map