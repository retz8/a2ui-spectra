/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert';
import { describe, it } from 'node:test';
import { promises as fsPromises, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { z } from 'zod';
import { A2uiCatalogError, A2uiValidationError } from '../errors.js';
import { Catalog } from './types.js';
import { analyzeChildRefSchema } from './reference-map.js';
import { V10_CHILD_REF_OPTIONS } from '../v1_0/standard_defs.js';
import { STRICT_VALIDATION } from '../validation/integrity-checker.js';
import { PayloadValidator } from '../validation/payload-validator.js';
describe('Catalog.fromJson & schema_loader', () => {
    const basicCatalogPath = resolve(process.cwd(), '../../../specification/v0_9_1/catalogs/basic/catalog.json');
    const basicCatalogJson = JSON.parse(readFileSync(basicCatalogPath, 'utf-8'));
    it('loads basic catalog successfully and dynamically resolves weight and accessibility', () => {
        const catalog = Catalog.fromJson(basicCatalogJson, '0.9');
        assert.strictEqual(catalog.id, 'https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json');
        assert.ok(catalog.components.size > 0);
        // Text component
        const textComp = catalog.components.get('Text');
        assert.ok(textComp);
        assert.strictEqual(textComp.name, 'Text');
        assert.ok(textComp.schema instanceof z.ZodObject);
        // Verify envelope fields ('component', 'id') are omitted
        const textShape = textComp.schema.shape;
        assert.strictEqual(textShape.id, undefined);
        assert.strictEqual(textShape.component, undefined);
        // Verify text property exists and validates strings & data bindings
        assert.ok(textShape.text);
        const validText = textComp.schema.safeParse({ text: 'Hello World' });
        assert.strictEqual(validText.success, true);
        const validBinding = textComp.schema.safeParse({
            text: { path: '/user/name' },
        });
        assert.strictEqual(validBinding.success, true);
        // Verify weight is dynamically resolved from #/$defs/CatalogComponentCommon
        assert.ok(textShape.weight);
        const validWeight = textComp.schema.safeParse({ text: 'Hello', weight: 2 });
        assert.strictEqual(validWeight.success, true);
        // Verify accessibility is dynamically resolved from common_types.json#/$defs/ComponentCommon
        assert.ok(textShape.accessibility);
        const validAccessibility = textComp.schema.safeParse({
            text: 'Hello',
            accessibility: { label: 'Heading text' },
        });
        assert.strictEqual(validAccessibility.success, true);
        // Row component with ChildList
        const rowComp = catalog.components.get('Row');
        assert.ok(rowComp);
        const rowShape = rowComp.schema.shape;
        assert.ok(rowShape.children);
        const validChildren = rowComp.schema.safeParse({
            children: ['c1', 'c2'],
        });
        assert.strictEqual(validChildren.success, true);
        // Button component with Action
        const btnComp = catalog.components.get('Button');
        assert.ok(btnComp);
        const btnShape = btnComp.schema.shape;
        assert.ok(btnShape.action);
        const validAction = btnComp.schema.safeParse({
            child: 'txt1',
            action: { event: { name: 'click_me' } },
        });
        assert.strictEqual(validAction.success, true);
    });
    it('resolves the Checkable mixin referenced from an external document', () => {
        // Checkable arrives as an allOf $ref into common_types.json, a document the loader never
        // reads. It used to fall through every branch and be discarded without an error, taking
        // `checks` off every input component with it.
        const catalog = Catalog.fromJson(basicCatalogJson);
        for (const name of [
            'Button',
            'TextField',
            'CheckBox',
            'ChoicePicker',
            'Slider',
            'DateTimeInput',
        ]) {
            const comp = catalog.components.get(name);
            assert.ok(comp, `${name} is missing from the basic catalog`);
            const shape = comp.schema.shape;
            assert.ok(shape.checks, `${name} lost its checks property`);
        }
        const button = catalog.components.get('Button');
        assert.ok(button);
        const withChecks = button.schema.safeParse({
            child: 'txt1',
            action: { event: { name: 'submit' } },
            checks: [{ condition: { path: '/form/valid' }, message: 'This field is required' }],
        });
        assert.strictEqual(withChecks.success, true);
        // The property is typed, not a free-form escape hatch.
        const badChecks = button.schema.safeParse({
            child: 'txt1',
            action: { event: { name: 'submit' } },
            checks: 'always',
        });
        assert.strictEqual(badChecks.success, false);
    });
    it('resolves an external mixin written as a relative reference', () => {
        // v1.0 catalogs spell the same reference without the absolute URL prefix.
        const catalog = Catalog.fromJson({
            catalogId: 'test_relative_checkable',
            protocolVersion: '1.0',
            components: {
                Input: {
                    type: 'object',
                    allOf: [
                        { $ref: 'common_types.json#/$defs/Checkable' },
                        { type: 'object', properties: { label: { type: 'string' } } },
                    ],
                },
            },
        });
        const input = catalog.components.get('Input');
        assert.ok(input);
        const shape = input.schema.shape;
        assert.ok(shape.checks);
        assert.ok(shape.label);
    });
    it('resolves the Child reference from common_types.json', () => {
        const v10BasicCatalogPath = resolve(process.cwd(), '../../../catalogs/basic/v1/catalog.json');
        const v10BasicCatalogJson = JSON.parse(readFileSync(v10BasicCatalogPath, 'utf-8'));
        const catalog = Catalog.fromJson(v10BasicCatalogJson);
        // The regression was not that the description stamp went missing, but that
        // `analyzeChildRefSchema` stopped reporting these properties as child references at
        // all, which silently emptied the reference map for v1.0. Assert the outcome, and the
        // stamp only as a secondary detail.
        const expectedChildProps = [
            ['Card', 'child'],
            ['Button', 'child'],
            ['Modal', 'trigger'],
            ['Modal', 'content'],
        ];
        for (const [componentName, propName] of expectedChildProps) {
            const component = catalog.components.get(componentName);
            assert.ok(component, `${componentName} is missing from the v1.0 basic catalog`);
            const shape = component.schema.shape;
            const prop = shape[propName];
            assert.ok(prop, `${componentName}.${propName} is missing`);
            const analysis = analyzeChildRefSchema(prop, V10_CHILD_REF_OPTIONS);
            assert.equal(analysis.isChild, true, `${componentName}.${propName} is not recognised as a child reference`);
            assert.ok(prop.description?.includes('REF:common_types.json#/$defs/Child'), `${componentName}.${propName} lost its REF description stamp`);
        }
    });
    it('ignores an external reference that names no canonical protocol type in a v0.9 catalog', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'test_unknown_external_ref',
            components: {
                Widget: {
                    type: 'object',
                    allOf: [
                        { $ref: 'other_document.json#/$defs/NotAProtocolType' },
                        { type: 'object', properties: { label: { type: 'string' } } },
                    ],
                },
            },
        });
        assert.strictEqual(catalog.protocolVersion, '0.9');
        const widget = catalog.components.get('Widget');
        assert.ok(widget);
        const shape = widget.schema.shape;
        assert.deepStrictEqual(Object.keys(shape), ['label']);
    });
    describe('v1.0 external $ref targets', () => {
        const rejects = (catalog, ref, pointer) => assert.throws(() => Catalog.fromJson({ catalogId: 'test_external_ref', protocolVersion: '1.0', ...catalog }), (err) => err instanceof A2uiCatalogError &&
            err.message ===
                `Unsupported external $ref '${ref}' at ${pointer}: a v1.0 catalog may only ` +
                    'reference its own components and functions (#/...) or common_types.json.');
        it('rejects a relative reference to a component of another catalog', () => {
            rejects({
                components: {
                    FancyText: {
                        type: 'object',
                        allOf: [{ $ref: 'basic_catalog.json#/components/Text' }],
                        properties: { component: { const: 'FancyText' } },
                        required: ['component'],
                    },
                },
            }, 'basic_catalog.json#/components/Text', '/components/FancyText/allOf/0/$ref');
        });
        it('rejects an absolute URI reference to another catalog', () => {
            const ref = 'https://a2ui.org/specification/v1_0/catalogs/basic/catalog.json#/components/Button';
            rejects({
                components: {
                    FancyButton: {
                        type: 'object',
                        properties: { component: { const: 'FancyButton' }, action: { $ref: ref } },
                    },
                },
            }, ref, '/components/FancyButton/properties/action/$ref');
        });
        it('rejects a catalog.json reference that is not the bare envelope placeholder', () => {
            rejects({
                components: {
                    Widget: {
                        type: 'object',
                        properties: { component: { const: 'Widget' }, child: { $ref: 'foo/catalog.json#/x' } },
                    },
                },
            }, 'foo/catalog.json#/x', '/components/Widget/properties/child/$ref');
        });
        it('rejects an external reference nested in function arguments', () => {
            rejects({
                functions: {
                    formatBadge: {
                        type: 'object',
                        returnType: 'string',
                        properties: {
                            '@call': { const: 'formatBadge' },
                            args: {
                                type: 'object',
                                properties: { value: { $ref: 'other_catalog.json#/functions/formatString' } },
                            },
                        },
                    },
                },
            }, 'other_catalog.json#/functions/formatString', '/functions/formatBadge/properties/args/properties/value/$ref');
        });
        it('rejects an external reference in $defs and escapes the pointer', () => {
            rejects({
                $defs: { 'a/b~c': { anyOf: [{ $ref: 'other_catalog.json#/$defs/Thing' }] } },
            }, 'other_catalog.json#/$defs/Thing', '/$defs/a~1b~0c/anyOf/0/$ref');
        });
        it('accepts local, catalog.json and common_types.json references', () => {
            const catalog = Catalog.fromJson({
                catalogId: 'test_allowed_refs',
                protocolVersion: '1.0',
                components: {
                    Label: {
                        type: 'object',
                        allOf: [{ $ref: 'common_types.json#/$defs/Checkable' }],
                        properties: {
                            component: { const: 'Label' },
                            text: { $ref: 'common_types.json#/$defs/DynamicString' },
                            caption: {
                                $ref: 'https://a2ui.org/specification/v1_0/common_types.json#/$defs/DynamicString',
                            },
                            child: { $ref: 'catalog.json#/$defs/anyComponent' },
                        },
                    },
                    Wrapper: {
                        type: 'object',
                        allOf: [{ $ref: '#/components/Label' }],
                        properties: { component: { const: 'Wrapper' } },
                    },
                },
            });
            assert.deepStrictEqual([...catalog.components.keys()], ['Label', 'Wrapper']);
        });
        it('does not apply to a v0.9 catalog', () => {
            const catalog = Catalog.fromJson({
                catalogId: 'test_v09_external_ref',
                components: {
                    FancyText: {
                        type: 'object',
                        allOf: [
                            { $ref: 'basic_catalog.json#/components/Text' },
                            { type: 'object', properties: { badge: { type: 'string' } } },
                        ],
                    },
                },
            }, '0.9');
            assert.ok(catalog.components.get('FancyText'));
        });
    });
    it('is catalog-agnostic and does not inject weight into custom catalogs lacking weight in $defs', () => {
        const customCatalog = {
            catalogId: 'https://example.com/custom_catalog.json',
            components: {
                CustomButton: {
                    type: 'object',
                    allOf: [
                        {
                            $ref: 'https://a2ui.org/specification/v0_9/common_types.json#/$defs/ComponentCommon',
                        },
                        {
                            properties: {
                                label: { type: 'string' },
                            },
                            required: ['label'],
                        },
                    ],
                },
            },
        };
        const catalog = Catalog.fromJson(customCatalog, '0.9');
        const btn = catalog.components.get('CustomButton');
        assert.ok(btn);
        const shape = btn.schema.shape;
        // Protocol accessibility is present
        assert.ok(shape.accessibility);
        assert.ok(shape.label);
        // weight is NOT present in custom catalog without CatalogComponentCommon
        assert.strictEqual(shape.weight, undefined);
    });
    it('safely converts non-string enums and handles defensive prop schemas', () => {
        const catalogWithEnums = {
            catalogId: 'https://example.com/enum_catalog.json',
            components: {
                EnumWidget: {
                    properties: {
                        numEnum: { enum: [1, 2, 3] },
                        singleEnum: { enum: ['only_one'] },
                        invalidProp: null,
                    },
                },
            },
        };
        const catalog = Catalog.fromJson(catalogWithEnums, '0.9');
        const widget = catalog.components.get('EnumWidget');
        assert.ok(widget);
        const valid = widget.schema.safeParse({ numEnum: 2, singleEnum: 'only_one' });
        assert.strictEqual(valid.success, true);
        const invalid = widget.schema.safeParse({ numEnum: 99 });
        assert.strictEqual(invalid.success, false);
    });
    it('filters non-string elements from allowedParents and allowedChildren', () => {
        const catalogJson = {
            catalogId: 'https://example.com/sanitized_hierarchy_catalog.json',
            components: {
                StrictNode: {
                    properties: { id: { type: 'string' } },
                    allowedParents: ['ParentValid', 123, null],
                    allowedChildren: ['ChildValid', false, {}],
                },
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        const comp = catalog.components.get('StrictNode');
        assert.ok(comp);
        assert.deepStrictEqual(comp.allowedParents, ['ParentValid']);
        assert.deepStrictEqual(comp.allowedChildren, ['ChildValid']);
    });
    it('applies passthrough when additionalProperties is a schema object', () => {
        const catalogJson = {
            catalogId: 'https://example.com/add_props_catalog.json',
            components: {
                FlexibleCard: {
                    type: 'object',
                    properties: {
                        title: { type: 'string' },
                    },
                    required: ['title'],
                    additionalProperties: { type: 'string' },
                },
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        const card = catalog.components.get('FlexibleCard');
        assert.ok(card);
        const result = card.schema.safeParse({
            title: 'Valid title',
            extraField: 'any string value',
        });
        assert.strictEqual(result.success, true);
    });
    it('preserves component and id properties in theme schemas', () => {
        const catalogJson = {
            catalogId: 'https://example.com/theme_props_catalog.json',
            components: {},
            theme: {
                type: 'object',
                properties: {
                    id: { type: 'string' },
                    component: { type: 'string' },
                    primaryColor: { type: 'string' },
                },
                required: ['id', 'component', 'primaryColor'],
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        assert.ok(catalog.themeSchema);
        const result = catalog.themeSchema.safeParse({
            id: 'theme-1',
            component: 'DarkTheme',
            primaryColor: '#000',
        });
        assert.strictEqual(result.success, true);
    });
    it('applies passthrough when unevaluatedProperties is true or a schema object', () => {
        const catalogJson = {
            catalogId: 'https://example.com/uneval_props_catalog.json',
            components: {
                OpenCard: {
                    type: 'object',
                    properties: {
                        title: { type: 'string' },
                    },
                    unevaluatedProperties: true,
                },
                SchemaCard: {
                    type: 'object',
                    properties: {
                        title: { type: 'string' },
                    },
                    unevaluatedProperties: { type: 'number' },
                },
                StrictCard: {
                    type: 'object',
                    properties: {
                        title: { type: 'string' },
                    },
                    unevaluatedProperties: false,
                },
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        const openCard = catalog.components.get('OpenCard');
        const schemaCard = catalog.components.get('SchemaCard');
        const strictCard = catalog.components.get('StrictCard');
        assert.ok(openCard);
        assert.ok(schemaCard);
        assert.ok(strictCard);
        assert.strictEqual(openCard.schema.safeParse({ title: 'A', extra: 'allowed' }).success, true);
        assert.strictEqual(schemaCard.schema.safeParse({ title: 'B', extra: 123 }).success, true);
        assert.strictEqual(strictCard.schema.safeParse({ title: 'C', extra: 'rejected' }).success, false);
    });
    it('converts multi-branch oneOf unions to z.union', () => {
        const catalogJson = {
            $id: 'https://example.com/union-cat',
            title: 'Union Catalog',
            components: {
                FlexibleInput: {
                    type: 'object',
                    properties: {
                        value: {
                            oneOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }],
                        },
                    },
                    required: ['value'],
                },
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        const inputComp = catalog.components.get('FlexibleInput');
        assert.ok(inputComp);
        assert.strictEqual(inputComp.schema.safeParse({ value: 'hello' }).success, true);
        assert.strictEqual(inputComp.schema.safeParse({ value: 42 }).success, true);
        assert.strictEqual(inputComp.schema.safeParse({ value: true }).success, true);
        assert.strictEqual(inputComp.schema.safeParse({ value: { invalid: 'obj' } }).success, false);
    });
    it('rejects a missing required property whose schema accepts any value', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'https://example.com/any_required.json',
            components: {
                Holder: {
                    type: 'object',
                    properties: { component: { const: 'Holder' }, payload: { description: 'Anything.' } },
                    required: ['payload'],
                },
            },
            functions: {
                required: {
                    properties: {
                        call: { const: 'required' },
                        args: {
                            type: 'object',
                            properties: { value: { description: 'The value to check.' } },
                            required: ['value'],
                        },
                    },
                },
            },
        }, '0.9');
        const args = catalog.functions.get('required').schema;
        assert.strictEqual(args.safeParse({ value: null }).success, true);
        assert.strictEqual(args.safeParse({ value: { nested: 1 } }).success, true);
        assert.strictEqual(args.safeParse({}).success, false);
        const holder = catalog.components.get('Holder').schema;
        assert.strictEqual(holder.safeParse({ payload: 0 }).success, true);
        assert.strictEqual(holder.safeParse({}).success, false);
    });
    it('applies the default of an optional function argument that is missing', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'https://example.com/fn_defaults_catalog.json',
            protocolVersion: '1.0',
            components: {},
            functions: {
                quote: {
                    type: 'object',
                    properties: {
                        '@call': { const: 'quote' },
                        args: {
                            type: 'object',
                            properties: {
                                symbol: { type: 'string' },
                                currency: { type: 'string', default: 'USD' },
                                options: {
                                    type: 'object',
                                    properties: {
                                        extendedHours: { type: 'boolean', default: false },
                                    },
                                    additionalProperties: false,
                                },
                                legs: {
                                    type: 'array',
                                    items: {
                                        type: 'object',
                                        properties: {
                                            side: { type: 'string', default: 'buy' },
                                        },
                                        additionalProperties: false,
                                    },
                                },
                            },
                            required: ['symbol'],
                            additionalProperties: false,
                        },
                    },
                    required: ['@call', 'args'],
                },
            },
        });
        const schema = catalog.functions.get('quote').schema;
        assert.deepStrictEqual(schema.parse({ symbol: 'GOOG' }), { symbol: 'GOOG', currency: 'USD' });
        assert.deepStrictEqual(schema.parse({ symbol: 'GOOG', currency: 'EUR', options: {}, legs: [{}] }), {
            symbol: 'GOOG',
            currency: 'EUR',
            options: { extendedHours: false },
            legs: [{ side: 'buy' }],
        });
        assert.strictEqual(schema.safeParse({ currency: 'EUR' }).success, false);
    });
    it('applies passthrough on function argument schemas when unevaluatedProperties is true or a schema object', () => {
        const catalogJson = {
            catalogId: 'https://example.com/fn_uneval_props_catalog.json',
            functions: {
                openFn: {
                    properties: {
                        args: {
                            type: 'object',
                            properties: {
                                target: { type: 'string' },
                            },
                            unevaluatedProperties: true,
                        },
                    },
                },
                schemaFn: {
                    properties: {
                        args: {
                            type: 'object',
                            properties: {
                                target: { type: 'string' },
                            },
                            unevaluatedProperties: { type: 'number' },
                        },
                    },
                },
                strictFn: {
                    properties: {
                        args: {
                            type: 'object',
                            properties: {
                                target: { type: 'string' },
                            },
                            unevaluatedProperties: false,
                        },
                    },
                },
            },
        };
        const catalog = Catalog.fromJson(catalogJson, '0.9');
        const openFn = catalog.functions.get('openFn');
        const schemaFn = catalog.functions.get('schemaFn');
        const strictFn = catalog.functions.get('strictFn');
        assert.ok(openFn);
        assert.ok(schemaFn);
        assert.ok(strictFn);
        assert.strictEqual(openFn.schema.safeParse({ target: 'A', extra: 'allowed' }).success, true);
        assert.strictEqual(schemaFn.schema.safeParse({ target: 'B', extra: 123 }).success, true);
        assert.strictEqual(strictFn.schema.safeParse({ target: 'C', extra: 'rejected' }).success, false);
    });
    it('keeps nested child references from inline object array items', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'tabs-cat',
            protocolVersion: '0.9',
            components: {
                Tabs: {
                    type: 'object',
                    properties: {
                        tabs: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    title: { type: 'string' },
                                    child: { $ref: '#/$defs/ComponentId' },
                                },
                            },
                        },
                    },
                },
            },
        });
        const refs = catalog.componentRefMap['Tabs'];
        assert.deepStrictEqual([...refs.listRefs], ['tabs']);
        assert.deepStrictEqual([...(refs.nestedRefs?.['tabs'] ?? [])], ['child']);
        // The item schema is structural rather than an opaque record, but still
        // tolerates keys the catalog did not declare.
        const schema = catalog.components.get('Tabs').schema;
        assert.ok(schema.safeParse({ tabs: [{ title: 'Overview', child: 'c1', extra: 1 }] }).success);
        assert.ok(!schema.safeParse({ tabs: [{ title: 42 }] }).success);
    });
    /**
     * A v1.0 catalog whose Toggle narrows properties that a standard mixin
     * (`checks` from Checkable), a local definition (`label`, `size` from Base)
     * and an inline branch (`size`) also declare, with the mixins listed last.
     */
    const precedenceCatalog = {
        catalogId: 'https://example.com/precedence.json',
        protocolVersion: '1.0',
        components: {
            Toggle: {
                allOf: [
                    {
                        properties: {
                            component: { const: 'Toggle' },
                            checks: { type: 'string', enum: ['strict'] },
                            label: { type: 'number' },
                            size: { type: 'string' },
                        },
                    },
                    { $ref: '#/$defs/Base' },
                    { $ref: 'common_types.json#/$defs/Checkable' },
                    { $ref: 'common_types.json#/$defs/ComponentCommon' },
                ],
                properties: { size: { type: 'integer' } },
            },
        },
        $defs: {
            Base: { properties: { label: { type: 'string' }, size: { type: 'boolean' } } },
        },
    };
    it('lets a component override a property its mixins and local definitions declare', () => {
        const schema = Catalog.fromJson(precedenceCatalog).components.get('Toggle')
            .schema;
        assert.ok(schema.safeParse({ checks: 'strict', label: 3, size: 2 }).success);
        assert.ok(!schema.safeParse({ checks: [{ condition: true, message: 'x' }] }).success);
        assert.ok(!schema.safeParse({ label: 'text' }).success, 'inline beats the local definition');
        assert.ok(!schema.safeParse({ size: 'large' }).success, 'top level beats the inline branch');
        assert.ok(!schema.safeParse({ size: true }).success, 'top level beats the local definition');
        assert.deepStrictEqual(Object.keys(schema.shape), [
            'checks',
            '@checks',
            'accessibility',
            '@accessibility',
            '@metadata',
            'label',
            'size',
        ]);
    });
    it('lets a component override a property its mixins declare in validationSchema', () => {
        const schema = Catalog.fromJson(precedenceCatalog).validationSchema;
        const toggle = schema.components.Toggle;
        assert.deepStrictEqual(toggle.properties.checks, { type: 'string', enum: ['strict'] });
        assert.deepStrictEqual(toggle.properties.label, { type: 'number' });
        assert.deepStrictEqual(toggle.properties.size, { type: 'integer' });
        assert.ok(!('catalogId' in toggle.properties));
    });
    it('treats catalogId as a component envelope field', () => {
        const catalog = Catalog.fromJson(precedenceCatalog);
        const schema = catalog.components.get('Toggle').schema;
        assert.ok(!('catalogId' in schema.shape));
        assert.ok(!('@catalogId' in schema.shape));
        assert.ok('@metadata' in schema.shape);
        new PayloadValidator(catalog, STRICT_VALIDATION).validateComponent({
            id: 'toggle1',
            component: 'Toggle',
            catalogId: 'https://example.com/precedence.json',
            metadata: { extensions: { source: 'test' } },
            size: 2,
        });
    });
    it('validates parameter names in object-based functions with shorthand parameter maps', () => {
        assert.throws(() => Catalog.fromJson({
            catalogId: 'https://example.com/test.json',
            protocolVersion: '1.0',
            functions: {
                customFunc: {
                    parameters: {
                        'invalid-param': { type: 'string' },
                    },
                },
            },
        }), /UAX #?31/);
        const catalog = Catalog.fromJson({
            catalogId: 'https://example.com/test.json',
            protocolVersion: '1.0',
            functions: {
                customFunc: {
                    parameters: {
                        valid_param: { type: 'string' },
                    },
                },
            },
        });
        assert.ok(catalog.functions.has('customFunc'));
    });
    it('accepts parameters defined with $ref or combiners without treating them as shorthand maps', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'https://example.com/test-ref.json',
            protocolVersion: '1.0',
            $defs: {
                MyArgs: {
                    type: 'object',
                    properties: {
                        valid_param: { type: 'string' },
                    },
                    required: ['valid_param'],
                },
                OpenArgs: {
                    type: 'object',
                    properties: {
                        opt: { type: 'number' },
                    },
                    additionalProperties: true,
                },
            },
            functions: {
                refFunc: {
                    parameters: { $ref: '#/$defs/MyArgs' },
                    returnType: 'string',
                },
                openFunc: {
                    parameters: { $ref: '#/$defs/OpenArgs' },
                    returnType: 'string',
                },
                unresolvableFunc: {
                    parameters: { $ref: '#/$defs/MissingArgs' },
                    returnType: 'string',
                },
                oneOfFunc: {
                    parameters: { oneOf: [{ type: 'string' }, { type: 'number' }] },
                    returnType: 'string',
                },
                allOfFunc: {
                    parameters: {
                        allOf: [
                            { $ref: '#/$defs/MyArgs' },
                            {
                                type: 'object',
                                properties: { extra_arg: { type: 'number' } },
                                required: ['extra_arg'],
                            },
                        ],
                    },
                    returnType: 'string',
                },
            },
        });
        // 1. refFunc validates arguments against #/$defs/MyArgs
        const refFunc = catalog.functions.get('refFunc');
        assert.ok(refFunc);
        assert.strictEqual(refFunc.schema.safeParse({ valid_param: 'hello' }).success, true);
        assert.strictEqual(refFunc.schema.safeParse({}).success, false);
        assert.strictEqual(refFunc.schema.safeParse({ valid_param: 'hello', unexpected: 123 }).success, false);
        // 2. allOfFunc merges properties and required fields
        const allOfFunc = catalog.functions.get('allOfFunc');
        assert.ok(allOfFunc);
        assert.strictEqual(allOfFunc.schema.safeParse({ valid_param: 'hello', extra_arg: 42 }).success, true);
        assert.strictEqual(allOfFunc.schema.safeParse({ valid_param: 'hello' }).success, false);
        assert.strictEqual(allOfFunc.schema.safeParse({ extra_arg: 42 }).success, false);
        assert.strictEqual(allOfFunc.schema.safeParse({ valid_param: 'hello', extra_arg: 42, extra: true }).success, false);
        // 3. openFunc allows extra properties
        const openFunc = catalog.functions.get('openFunc');
        assert.ok(openFunc);
        assert.strictEqual(openFunc.schema.safeParse({ opt: 10, other: 'allowed' }).success, true);
        // 4. unresolvableFunc falls back to passthrough
        const unresolvableFunc = catalog.functions.get('unresolvableFunc');
        assert.ok(unresolvableFunc);
        assert.strictEqual(unresolvableFunc.schema.safeParse({ anything: 123 }).success, true);
        // 5. oneOfFunc falls back to passthrough
        const oneOfFunc = catalog.functions.get('oneOfFunc');
        assert.ok(oneOfFunc);
        assert.strictEqual(oneOfFunc.schema.safeParse({ anything: 'ok' }).success, true);
        assert.throws(() => Catalog.fromJson({
            catalogId: 'https://example.com/test-bad-allof.json',
            protocolVersion: '1.0',
            functions: {
                badFunc: {
                    parameters: {
                        allOf: [{ properties: { '123bad': { type: 'string' } } }],
                    },
                },
            },
        }), /UAX #?31/);
        assert.throws(() => Catalog.fromJson({
            catalogId: 'https://example.com/test-bad-ref.json',
            protocolVersion: '1.0',
            $defs: {
                BadDefs: {
                    type: 'object',
                    properties: { '123bad': { type: 'string' } },
                },
            },
            functions: {
                badFunc: {
                    parameters: { $ref: '#/$defs/BadDefs' },
                },
            },
        }), /UAX #?31/);
    });
    it('resolves common_types.json $refs and validates components without network or disk I/O', t => {
        const originalFetch = globalThis.fetch;
        t.mock.method(fsPromises, 'readFile', () => {
            throw new Error('Unexpected fs.promises.readFile during schema resolution');
        });
        globalThis.fetch = (() => {
            throw new Error('Unexpected globalThis.fetch during schema resolution');
        });
        try {
            const v1Catalog = Catalog.fromJson({
                catalogId: 'https://example.com/network_free_v1_0.json',
                protocolVersion: '1.0',
                $defs: {
                    Tone: { type: 'string', enum: ['info', 'warning'] },
                },
                components: {
                    FormField: {
                        type: 'object',
                        allOf: [{ $ref: 'common_types.json#/$defs/Checkable' }],
                        properties: {
                            component: { const: 'FormField' },
                            label: { $ref: 'common_types.json#/$defs/DynamicString' },
                            count: {
                                $ref: 'https://a2ui.org/specification/v1_0/common_types.json#/$defs/DynamicNumber',
                            },
                            child: { $ref: 'common_types.json#/$defs/Child' },
                            tone: { $ref: '#/$defs/Tone' },
                        },
                        required: ['component', 'label'],
                    },
                },
            });
            const v1Validator = new PayloadValidator(v1Catalog, STRICT_VALIDATION);
            v1Validator.validateComponent({
                id: 'field_1',
                component: 'FormField',
                label: { '@path': '/form/label' },
                count: 5,
                child: 'child_1',
                tone: 'info',
                checks: [{ condition: true, message: 'Valid' }],
                accessibility: { label: 'Field label' },
            });
            assert.throws(() => v1Validator.validateComponent({
                id: 'field_bad',
                component: 'FormField',
                label: 12345,
            }), A2uiValidationError);
            const v09Catalog = Catalog.fromJson({
                catalogId: 'https://example.com/network_free_v0_9.json',
                components: {
                    CustomCard: {
                        type: 'object',
                        allOf: [
                            {
                                $ref: 'https://a2ui.org/specification/v0_9/common_types.json#/$defs/ComponentCommon',
                            },
                        ],
                        properties: {
                            component: { const: 'CustomCard' },
                            title: {
                                $ref: 'https://a2ui.org/specification/v0_9/common_types.json#/$defs/DynamicString',
                            },
                        },
                        required: ['component', 'title'],
                    },
                },
            }, '0.9');
            const v09Validator = new PayloadValidator(v09Catalog, STRICT_VALIDATION);
            v09Validator.validateComponent({
                id: 'card_1',
                component: 'CustomCard',
                title: { path: '/card/title' },
                accessibility: { label: 'Card' },
            });
            assert.throws(() => v09Validator.validateComponent({
                id: 'card_bad',
                component: 'CustomCard',
                title: 42,
            }), A2uiValidationError);
        }
        finally {
            globalThis.fetch = originalFetch;
        }
    });
    it('preserves custom checks property on a v1.0 Checkable component that also accepts @checks', () => {
        const catalog = Catalog.fromJson({
            catalogId: 'https://example.com/checkable_custom_checks_v1_0.json',
            protocolVersion: '1.0',
            components: {
                ScoreInput: {
                    type: 'object',
                    allOf: [
                        { $ref: 'common_types.json#/$defs/Checkable' },
                        {
                            type: 'object',
                            properties: {
                                component: { const: 'ScoreInput' },
                                checks: { type: 'integer' },
                            },
                            required: ['component', 'checks'],
                        },
                    ],
                },
            },
        }, '1.0');
        const validator = new PayloadValidator(catalog, STRICT_VALIDATION);
        validator.validateComponent({
            id: 'score_1',
            component: 'ScoreInput',
            checks: 3,
            '@checks': [{ condition: true, message: 'Must pass' }],
        });
    });
    it('omits @-prefixed envelope mixins from pre-1.0 JSON catalog component schemas', () => {
        const v09Catalog = Catalog.fromJson({
            catalogId: 'https://example.com/v09_checkable.json',
            protocolVersion: '0.9',
            components: {
                Field: {
                    type: 'object',
                    allOf: [
                        { $ref: 'common_types.json#/$defs/ComponentCommon' },
                        { $ref: 'common_types.json#/$defs/Checkable' },
                        {
                            type: 'object',
                            properties: {
                                component: { const: 'Field' },
                                label: { type: 'string' },
                            },
                            required: ['component', 'label'],
                        },
                    ],
                    unevaluatedProperties: false,
                },
            },
        }, '0.9');
        const shape = v09Catalog.components.get('Field').schema.shape;
        assert.ok('accessibility' in shape);
        assert.ok('checks' in shape);
        assert.ok(!('@accessibility' in shape));
        assert.ok(!('@metadata' in shape));
        assert.ok(!('@checks' in shape));
        const v09Validator = new PayloadValidator(v09Catalog, STRICT_VALIDATION);
        assert.throws(() => v09Validator.validateComponent({
            id: 'f1',
            component: 'Field',
            label: 'Name',
            '@checks': [{ condition: true, message: 'No v1.0 @checks on v0.9' }],
        }), A2uiValidationError);
    });
});
//# sourceMappingURL=schema_loader.test.js.map