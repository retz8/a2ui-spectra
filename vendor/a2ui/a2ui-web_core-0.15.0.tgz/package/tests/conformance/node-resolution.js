/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import yaml from 'js-yaml';
import { Catalog, createFunctionImplementation } from '../../src/catalog/types.js';
import { jsonValueEquals } from '../../src/common/metadata.js';
import { MessageProcessor } from '../../src/processing/message-processor.js';
import { batchWrite, effect, getValue, peekValue } from '../../src/reactivity/signals.js';
import { isComponentNode, PLACEHOLDER_TYPE, } from '../../src/resolution/component-node.js';
import { NodeResolver } from '../../src/resolution/node-resolver.js';
import { isWritable, ResolvedBinding } from '../../src/resolution/resolved-binding.js';
import { ComponentModel } from '../../src/state/component-model.js';
import { SurfaceModel } from '../../src/state/surface-model.js';
const flush = () => new Promise(resolve => setTimeout(resolve, 0));
const KNOWN_KEYS = {
    case: new Set(['action', 'description', 'expect', 'features', 'fixture', 'name', 'steps']),
    fixture: new Set(['catalog', 'components', 'data', 'surface']),
    expect: new Set([
        'created_emissions',
        'data',
        'destroyed',
        'emissions',
        'errors',
        'events',
        'functions',
        'metadata_emissions',
        'nodes',
        'replaced_nodes',
        'same_nodes',
    ]),
    node: new Set([
        'component_id',
        'data_path',
        'isValid',
        'metadata',
        'props',
        'state',
        'type',
        'validationErrors',
        'validationResults',
    ]),
    event: new Set(['context', 'metadata', 'name', 'source_component_id']),
    function: new Set(['args', 'name']),
    error: new Set(['code', 'message', 'surfaceId']),
    step: {
        set_data: new Set(['expect', 'op', 'path', 'value']),
        update_components: new Set(['components', 'expect', 'op']),
        remove_component: new Set(['component_id', 'expect', 'op']),
        write: new Set(['expect', 'node', 'op', 'property', 'value']),
        invoke: new Set(['expect', 'metadata', 'node', 'op', 'property']),
        process_messages: new Set(['expect', 'messages', 'op']),
        dispose: new Set(['expect', 'op']),
    },
};
function assertKnownKeys(obj, allowed, where) {
    if (obj === undefined || obj === null)
        return;
    assert.ok(typeof obj === 'object' && !Array.isArray(obj), `${where}: expected object`);
    const unknown = Object.keys(obj).filter(key => !allowed.has(key));
    assert.deepEqual(unknown, [], `${where}: unknown keys: ${unknown.map(k => `${where}.${k}`).join(', ')}`);
}
function assertKnownKeysList(items, allowed, where) {
    if (!Array.isArray(items))
        return;
    for (let i = 0; i < items.length; i++) {
        assertKnownKeys(items[i], allowed, `${where}[${i}]`);
    }
}
/** Detached values preserve binding snapshots and name child references by tree position. */
function normalize(value, path) {
    if (isComponentNode(value))
        return { node: path };
    if (value instanceof ResolvedBinding) {
        return { value: normalize(value.value, path), writable: isWritable(value) };
    }
    if (typeof value === 'function')
        return { action: true };
    if (Array.isArray(value))
        return value.map((item, i) => normalize(item, `${path}/${i}`));
    if (value !== null && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, normalize(item, `${path}/${key}`)]));
    }
    return value ?? null;
}
/** Enumerates mounted nodes, including references nested inside ordinary property containers. */
function mountedNodes(resolver) {
    const nodes = new Map();
    const seen = new Set();
    function visit(node, path) {
        assert.ok(!seen.has(node), `${path}: each mounted position must have a distinct node`);
        assert.equal(node.disposed, false, `${path}: mounted node is disposed`);
        seen.add(node);
        nodes.set(path, node);
        const siblingIds = new Set();
        function children(value, childPath) {
            if (isComponentNode(value)) {
                assert.ok(!siblingIds.has(value.instanceId), `${childPath}: duplicate sibling instanceId`);
                siblingIds.add(value.instanceId);
                visit(value, childPath);
            }
            else if (Array.isArray(value)) {
                value.forEach((item, i) => children(item, `${childPath}/${i}`));
            }
            else if (value !== null &&
                typeof value === 'object' &&
                !(value instanceof ResolvedBinding)) {
                for (const [key, item] of Object.entries(value))
                    children(item, `${childPath}/${key}`);
            }
        }
        children(peekValue(node.props), path);
    }
    const root = peekValue(resolver.rootNode);
    if (root)
        visit(root, 'root');
    return nodes;
}
function requiredNode(nodes, path) {
    const node = nodes.get(path);
    assert.ok(node, `No node at ${path}`);
    return node;
}
function checkNodeValidationProps(props, fields, path, reason) {
    for (const key of ['isValid', 'validationErrors', 'validationResults']) {
        if (key in fields) {
            assert.deepEqual(normalize(props[key], `${path}/${key}`), fields[key], `${reason}: ${path}.${key}`);
        }
    }
}
function checkNodes(nodes, expected, reason, surface) {
    assert.deepEqual([...nodes.keys()].sort(), Object.keys(expected.nodes).sort(), `${reason}: node paths`);
    for (const [path, fields] of Object.entries(expected.nodes)) {
        assertKnownKeys(fields, KNOWN_KEYS.node, `${reason}.expect.nodes.${path}`);
        const node = requiredNode(nodes, path);
        const nodeType = node.state === 'cyclic' && node.type === PLACEHOLDER_TYPE && surface
            ? (surface.componentsModel.get(node.componentId)?.type ?? node.type)
            : node.type;
        const actual = {
            component_id: node.componentId,
            type: nodeType,
            state: node.state,
            data_path: node.dataPath,
        };
        for (const key of ['component_id', 'type', 'state', 'data_path']) {
            if (key in fields)
                assert.equal(actual[key], fields[key], `${reason}: ${path}.${key}`);
        }
        const props = peekValue(node.props);
        checkNodeValidationProps(props, fields, path, reason);
        for (const [key, value] of Object.entries(fields.props ?? {})) {
            assert.ok(key in props, `${reason}: ${path}.${key} is absent`);
            assert.deepEqual(normalize(props[key], `${path}/${key}`), value, `${reason}: ${path}.${key}`);
        }
        if ('metadata' in fields) {
            assert.deepEqual(peekValue(node.metadata) ?? null, fields.metadata, `${reason}: ${path}.metadata`);
        }
    }
}
function updateComponents(surface, catalog, components) {
    for (const { id, component, metadata, ...properties } of components) {
        const existing = surface.componentsModel.get(id);
        if (existing) {
            assert.equal(existing.type, component, `update_components cannot change ${id}'s type`);
            batchWrite(() => {
                existing.metadata = metadata;
                if (!jsonValueEquals(existing.properties, properties)) {
                    existing.properties = properties;
                }
            });
        }
        else {
            surface.componentsModel.addComponent(new ComponentModel(id, component, properties, catalog, metadata));
        }
    }
}
function saveBindings(nodes) {
    const saved = [];
    function visit(value) {
        if (value instanceof ResolvedBinding) {
            saved.push([value, normalize(value.value, '')]);
        }
        else if (!isComponentNode(value) && value !== null && typeof value === 'object') {
            for (const item of Object.values(value))
                visit(item);
        }
    }
    for (const node of nodes.values())
        visit(peekValue(node.props));
    return saved;
}
function checkExpectedErrors(actualErrors, expectedErrors, reason) {
    if (expectedErrors === undefined)
        return;
    assert.equal(actualErrors.length, expectedErrors.length, `${reason}: errors count`);
    for (let i = 0; i < expectedErrors.length; i++) {
        const expErr = expectedErrors[i];
        assertKnownKeys(expErr, KNOWN_KEYS.error, `${reason}.expect.errors[${i}]`);
        const actErr = actualErrors[i];
        if (expErr.code !== undefined) {
            assert.equal(actErr.code, expErr.code, `${reason}: errors[${i}].code`);
        }
        if (expErr.surfaceId !== undefined) {
            assert.equal(actErr.surfaceId, expErr.surfaceId, `${reason}: errors[${i}].surfaceId`);
        }
        if (expErr.message !== undefined) {
            assert.ok(actErr.message.includes(expErr.message), `${reason}: errors[${i}].message (${actErr.message})`);
        }
    }
}
async function executeNodeResolutionStep(step, before, ctx, catalog, processor, reason) {
    switch (step.op) {
        case 'set_data':
            assertKnownKeys(step, KNOWN_KEYS.step.set_data, reason);
            assert.ok(ctx.surface, `${reason}: no surface`);
            ctx.surface.dataModel.set(step.path, step.value);
            break;
        case 'update_components':
            assertKnownKeys(step, KNOWN_KEYS.step.update_components, reason);
            assert.ok(ctx.surface, `${reason}: no surface`);
            updateComponents(ctx.surface, catalog, step.components);
            break;
        case 'remove_component':
            assertKnownKeys(step, KNOWN_KEYS.step.remove_component, reason);
            assert.ok(ctx.surface, `${reason}: no surface`);
            ctx.surface.componentsModel.removeComponent(step.component_id);
            break;
        case 'write': {
            assertKnownKeys(step, KNOWN_KEYS.step.write, reason);
            const binding = peekValue(requiredNode(before, step.node).props)[step.property];
            assert.ok(binding instanceof ResolvedBinding && isWritable(binding), `${reason}: not a writable binding`);
            binding.set(step.value);
            break;
        }
        case 'invoke': {
            assertKnownKeys(step, KNOWN_KEYS.step.invoke, reason);
            const action = peekValue(requiredNode(before, step.node).props)[step.property];
            assert.equal(typeof action, 'function', `${reason}: not an action`);
            await action(step.metadata ? { metadata: step.metadata } : undefined);
            break;
        }
        case 'process_messages':
            assertKnownKeys(step, KNOWN_KEYS.step.process_messages, reason);
            processor.processMessages(step.messages);
            break;
        case 'dispose':
            assertKnownKeys(step, KNOWN_KEYS.step.dispose, reason);
            assert.ok(ctx.resolver, `${reason}: no resolver`);
            ctx.resolver.dispose();
            break;
        default:
            assert.fail(`Unknown node operation: ${step.op}`);
    }
}
function watchNodes(nodes, watches, onPropsUpdated) {
    for (const [path, node] of nodes) {
        const existing = watches.get(node);
        if (existing) {
            existing.path = path;
            continue;
        }
        const watch = {
            path,
            emissions: 0,
            metadataEmissions: 0,
            destroyed: 0,
            stop: () => { },
        };
        const stopProps = effect(() => {
            const props = getValue(node.props);
            watch.emissions++;
            watch.lastProps = normalize(props, watch.path);
            onPropsUpdated?.();
        });
        const stopMetadata = effect(() => {
            getValue(node.metadata);
            watch.metadataEmissions++;
        });
        const stopDestroyed = node.onDestroyed.subscribe(() => {
            watch.destroyed++;
        });
        watch.stop = () => {
            stopProps();
            stopMetadata();
            stopDestroyed.unsubscribe();
        };
        watches.set(node, watch);
    }
}
function watchCreatedNodes(resolver, createdEmissions, createdStops) {
    for (const node of mountedNodes(resolver).values()) {
        if (createdEmissions.has(node))
            continue;
        createdEmissions.set(node, 0);
        let initial = true;
        const stop = effect(() => {
            getValue(node.props);
            if (initial) {
                initial = false;
            }
            else {
                createdEmissions.set(node, (createdEmissions.get(node) ?? 0) + 1);
            }
            watchCreatedNodes(resolver, createdEmissions, createdStops);
        });
        createdStops.push(stop);
    }
}
function checkExpectation(expected, before, ctx, reason) {
    assertKnownKeys(expected, KNOWN_KEYS.expect, `${reason}.expect`);
    assertKnownKeysList(expected.events, KNOWN_KEYS.event, `${reason}.expect.events`);
    assertKnownKeysList(expected.functions, KNOWN_KEYS.function, `${reason}.expect.functions`);
    const after = ctx.resolver ? mountedNodes(ctx.resolver) : new Map();
    checkNodes(after, expected, reason, ctx.surface);
    const beforeNodes = new Set(before.values());
    const surviving = new Set(after.values());
    const emissions = {};
    const metadataEmissions = {};
    const destroyed = {};
    for (const [node, watch] of ctx.watches) {
        // Removal may update a binding before teardown; only surviving nodes have
        // exact emission counts. Retired nodes remain watched for destruction.
        if (watch.emissions && surviving.has(node)) {
            emissions[watch.path] = (emissions[watch.path] ?? 0) + watch.emissions;
            assert.deepEqual(watch.lastProps, normalize(peekValue(node.props), watch.path), `${reason}: ${watch.path} last emission`);
        }
        if (watch.metadataEmissions && surviving.has(node)) {
            metadataEmissions[watch.path] =
                (metadataEmissions[watch.path] ?? 0) + watch.metadataEmissions;
        }
        if (watch.destroyed) {
            destroyed[watch.path] = (destroyed[watch.path] ?? 0) + watch.destroyed;
            assert.equal(node.disposed, true, `${reason}: ${watch.path} destruction without disposal`);
        }
    }
    assert.deepEqual(emissions, expected.emissions ?? {}, `${reason}: emissions`);
    if (expected.created_emissions !== undefined) {
        const createdEmissions = {};
        for (const [path, node] of after) {
            if (!beforeNodes.has(node)) {
                createdEmissions[path] = ctx.createdEmissions.get(node) ?? 0;
            }
        }
        assert.deepEqual(createdEmissions, expected.created_emissions, `${reason}: created_emissions`);
    }
    if (expected.metadata_emissions !== undefined) {
        assert.deepEqual(metadataEmissions, expected.metadata_emissions, `${reason}: metadata_emissions`);
    }
    assert.deepEqual(destroyed, expected.destroyed ?? {}, `${reason}: destroyed`);
    for (const path of expected.same_nodes ?? []) {
        assert.equal(requiredNode(after, path), requiredNode(before, path), `${reason}: ${path} identity`);
    }
    for (const path of expected.replaced_nodes ?? []) {
        assert.notEqual(requiredNode(after, path), requiredNode(before, path), `${reason}: ${path} replacement`);
    }
    for (const [path, value] of Object.entries(expected.data ?? {})) {
        assert.ok(ctx.surface, `${reason}: no surface for data ${path}`);
        assert.deepEqual(normalize(ctx.surface.dataModel.get(path), path), value, `${reason}: data ${path}`);
    }
    assert.deepEqual(ctx.events, expected.events ?? [], `${reason}: events`);
    assert.deepEqual(ctx.functions, expected.functions ?? [], `${reason}: functions`);
    checkExpectedErrors(ctx.errors, expected.errors, reason);
}
/**
 * Runs one `resolve_nodes` case; fixture and catalog paths resolve against
 * `conformanceRoot`.
 */
export async function runNodeResolutionCase(testCase, conformanceRoot) {
    assertKnownKeys(testCase, KNOWN_KEYS.case, testCase.name || 'resolve_nodes');
    assert.equal(testCase.action, 'resolve_nodes');
    const fixture = yaml.load(readFileSync(join(conformanceRoot, testCase.fixture), 'utf8'));
    assertKnownKeys(fixture, KNOWN_KEYS.fixture, `${testCase.name}.fixture`);
    const parsed = Catalog.fromJson(JSON.parse(readFileSync(join(conformanceRoot, fixture.catalog), 'utf8')));
    const functions = [];
    const events = [];
    const errors = [];
    const catalog = new Catalog(parsed.id, parsed.protocolVersion, [...parsed.components.values()], [...parsed.functions.values()].map(api => createFunctionImplementation(api, args => {
        functions.push({ name: api.name, args: normalize(args, '') });
        return null;
    })));
    const processor = new MessageProcessor([catalog]);
    const watches = new Map();
    const createdEmissions = new Map();
    const createdStops = [];
    const ctx = { watches, createdEmissions, events, functions, errors };
    const cleanups = [];
    const attachSurface = (s) => {
        if (s.id !== 's' || ctx.resolver)
            return;
        ctx.surface = s;
        const r = new NodeResolver(s, catalog);
        ctx.resolver = r;
        const stopRoot = effect(() => {
            getValue(r.rootNode);
            watchCreatedNodes(r, createdEmissions, createdStops);
        });
        const stopActions = s.onAction.subscribe(action => {
            events.push({
                name: action.name,
                source_component_id: action.sourceComponentId,
                context: normalize(action.context, ''),
                ...(action.metadata !== undefined ? { metadata: action.metadata } : {}),
            });
        });
        const stopErrors = s.onError.subscribe(err => {
            errors.push(err);
        });
        cleanups.push(stopRoot, () => stopActions.unsubscribe(), () => stopErrors.unsubscribe());
    };
    const stopSurfaceCreated = processor.model.onSurfaceCreated.subscribe(attachSurface);
    cleanups.push(() => stopSurfaceCreated.unsubscribe());
    if (fixture.surface !== false) {
        const surface = new SurfaceModel('s', catalog);
        processor.model.addSurface(surface);
        surface.dataModel.set('/', fixture.data);
        updateComponents(surface, catalog, fixture.components);
    }
    try {
        await flush();
        checkExpectation(testCase.expect, new Map(), ctx, `${testCase.name} initial`);
        for (const [index, step] of testCase.steps.entries()) {
            const reason = `${testCase.name} step ${index} (${step.op})`;
            const before = ctx.resolver ? mountedNodes(ctx.resolver) : new Map();
            watchNodes(before, watches, () => {
                if (ctx.resolver) {
                    watchCreatedNodes(ctx.resolver, createdEmissions, createdStops);
                }
            });
            for (const watch of watches.values()) {
                watch.emissions = 0;
                watch.metadataEmissions = 0;
                watch.destroyed = 0;
                watch.lastProps = undefined;
            }
            for (const stop of createdStops)
                stop();
            createdStops.length = 0;
            createdEmissions.clear();
            events.length = 0;
            functions.length = 0;
            errors.length = 0;
            const bindings = saveBindings(before);
            await executeNodeResolutionStep(step, before, ctx, catalog, processor, reason);
            await flush();
            checkExpectation(step.expect, before, ctx, reason);
            for (const [binding, value] of bindings) {
                assert.deepEqual(normalize(binding.value, ''), value, `${reason}: prior binding snapshot changed`);
            }
        }
    }
    finally {
        for (const stop of createdStops)
            stop();
        ctx.resolver?.dispose();
        ctx.surface?.dispose();
        await flush();
        for (const watch of watches.values())
            watch.stop();
        for (const cleanup of cleanups)
            cleanup();
    }
}
//# sourceMappingURL=node-resolution.js.map