type Component = Record<string, unknown> & {
    id: string;
    component: string;
};
interface NodeExpectation {
    component_id?: string;
    type?: string;
    state?: string;
    data_path?: string;
    isValid?: boolean;
    validationErrors?: string[];
    validationResults?: Array<Record<string, unknown>>;
    props?: Record<string, unknown>;
    metadata?: Record<string, unknown> | null;
}
interface Expectation {
    nodes: Record<string, NodeExpectation>;
    emissions?: Record<string, number>;
    created_emissions?: Record<string, number>;
    metadata_emissions?: Record<string, number>;
    same_nodes?: string[];
    replaced_nodes?: string[];
    destroyed?: Record<string, number>;
    data?: Record<string, unknown>;
    events?: unknown[];
    functions?: unknown[];
    errors?: Array<{
        code?: string;
        surfaceId?: string;
        message?: string;
    }>;
}
type Operation = {
    op: 'set_data';
    path: string;
    value: unknown;
} | {
    op: 'update_components';
    components: Component[];
} | {
    op: 'remove_component';
    component_id: string;
} | {
    op: 'write';
    node: string;
    property: string;
    value: unknown;
} | {
    op: 'invoke';
    node: string;
    property: string;
    metadata?: Record<string, unknown>;
} | {
    op: 'process_messages';
    messages: unknown[];
} | {
    op: 'dispose';
};
export interface ConformanceCase {
    name: string;
    action: 'resolve_nodes';
    fixture: string;
    expect: Expectation;
    steps: Array<Operation & {
        expect: Expectation;
    }>;
}
/**
 * Runs one `resolve_nodes` case; fixture and catalog paths resolve against
 * `conformanceRoot`.
 */
export declare function runNodeResolutionCase(testCase: ConformanceCase, conformanceRoot: string): Promise<void>;
export {};
//# sourceMappingURL=node-resolution.d.ts.map