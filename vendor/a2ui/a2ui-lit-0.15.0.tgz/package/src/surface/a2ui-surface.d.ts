import { LitElement, PropertyValues } from 'lit';
import { type ComponentNode, type SurfaceModel } from '@a2ui/web_core';
import type { LitComponentApi } from '../types.js';
/**
 * A Lit component that renders an A2UI Surface.
 *
 * This component takes a `SurfaceModel` and dynamically renders the root component
 * and its children using the provided catalog. It handles loading states if the
 * root component is not yet available.
 *
 * @element a2ui-surface
 */
export declare class A2uiSurface extends LitElement {
    /**
     * The surface model containing the component tree and catalog.
     */
    accessor surface: SurfaceModel<LitComponentApi> | undefined;
    /**
     * Resolved root component node from `NodeResolver`.
     * @internal
     */
    private accessor _rootNode;
    /**
     * Subscription cleanup function.
     * @internal
     */
    private unsubscribe?;
    /**
     * Returns the currently resolved root component node for this surface, if any.
     */
    get rootNode(): ComponentNode<LitComponentApi> | undefined;
    /**
     * Renders into the element's direct children (Light DOM) instead of a ShadowRoot
     * so host stylesheets can target components inside the surface.
     */
    createRenderRoot(): this;
    /**
     * Handles lifecycle updates, specifically when the `surface` property changes.
     *
     * It subscribes to the components model so the surface re-renders whenever
     * the 'root' component is created or deleted.
     *
     * @param changedProperties Map of changed properties.
     */
    protected willUpdate(changedProperties: PropertyValues): void;
    /**
     * Restores the root subscriptions when the element is reattached.
     */
    connectedCallback(): void;
    /**
     * Cleans up subscriptions.
     */
    disconnectedCallback(): void;
    /**
     * Tracks the 'root' component of the current surface via `NodeResolver` for
     * as long as the surface is shown.
     *
     * The processor replaces a component's model when an update changes its
     * type or catalog, deleting the old model and creating a new one, so the
     * subscription outlives the first creation of the root: the surface then
     * renders the new model.
     */
    private subscribeToRoot;
    /**
     * Renders the surface.
     *
     * If `surface` is not set, or the root has not resolved (it has not arrived,
     * has an unknown type, or is part of a cycle), returns `nothing`.
     * Otherwise, renders the root component using `renderA2uiNode`.
     */
    render(): import("lit-html/directive.js").DirectiveResult<import("lit-html/directive.js").DirectiveClass>;
}
//# sourceMappingURL=a2ui-surface.d.ts.map