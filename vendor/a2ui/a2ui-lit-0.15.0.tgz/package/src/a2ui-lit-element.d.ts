export { A2uiLitElement } from '@a2ui/web_core/universal';
//# sourceMappingURL=a2ui-lit-element.d.ts.map