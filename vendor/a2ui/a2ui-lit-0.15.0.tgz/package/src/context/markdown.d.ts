import type { MarkdownRenderer } from '@a2ui/web_core';
export type { MarkdownRenderer };
/**
 * The markdown renderer context.
 *
 * This is used by the Text widget to render markdown content.
 */
export declare const markdown: {
    __context__: MarkdownRenderer | undefined;
};
//# sourceMappingURL=markdown.d.ts.map