/**
 * Contexts used to inject dependencies into the Lit renderer.
 */
export declare const Context: {
    markdown: {
        __context__: import("@a2ui/web_core").MarkdownRenderer | undefined;
    };
};
//# sourceMappingURL=context.d.ts.map