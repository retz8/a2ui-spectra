export {};
//# sourceMappingURL=adapter_conformance.test.d.ts.map