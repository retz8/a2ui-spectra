import { type AdapterSession, type AdapterStep, type ExpectedError, type ExpectedViewNode } from './adapter_harness.js';
export interface E2eUiOp {
    op: AdapterStep['op'];
    surfaceId: string;
    targetNode?: string;
    inputValue?: unknown;
    userActivation?: boolean;
}
export interface E2eWirePart {
    text?: string;
    a2ui?: Array<Record<string, unknown>>;
}
export interface E2eTurn {
    userText: string;
    modelChunks?: Record<string, string[]>;
    expectWire: E2eWirePart[];
    expectViewTree?: Record<string, ExpectedViewNode | null>;
    expectErrors?: ExpectedError[];
    uiOps?: E2eUiOp[];
    expectDataModel?: Record<string, Record<string, unknown>>;
    expectOutbound?: Array<Record<string, unknown>>;
}
export interface E2eScenario {
    name: string;
    description?: string;
    action: string;
    protocolVersion: string;
    catalogPaths: string[];
    formats?: string[];
    source?: Record<string, unknown>;
    turns: E2eTurn[];
}
export declare function captureOutbound(session: AdapterSession): Array<Record<string, unknown>>;
export declare function assertOutbound(actual: Array<Record<string, unknown>>, expected: Array<Record<string, unknown>>, protocolVersion: string): void;
export declare function runScenario(scenario: E2eScenario, mountedElements: HTMLElement[]): Promise<void>;
//# sourceMappingURL=e2e_scenarios.test.d.ts.map