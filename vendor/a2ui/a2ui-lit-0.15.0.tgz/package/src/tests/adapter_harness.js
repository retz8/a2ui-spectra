/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { asyncUpdate } from './dom-setup.js';
import { html } from 'lit';
import { z } from 'zod';
import { Catalog, MessageProcessor, ResolvedBinding, getValue, isComponentNode, } from '@a2ui/web_core';
import { basicCatalog as v1BasicCatalog } from '@a2ui/web_core/catalogs/basic/v1';
import { basicCatalog as v09BasicCatalog } from '@a2ui/web_core/v0_9/basic_catalog';
import { A2uiLitElement } from '@a2ui/web_core/universal';
import { A2uiClientMessageSchema } from '@a2ui/web_core/v0_9';
import { RendererToAgentMessageSchema } from '@a2ui/web_core/v1_0';
/**
 * Reasoned skip entries keyed by `"<case>"` or `"<case>/<op|expectKey>"`.
 * Every entry in this map must match at least one case during the run.
 */
export const UNSUPPORTED = {
    'validation_results_error_disables_warning_allows/hints': 'SHOULD in framework adapter specification, not implemented in Web Basic Catalog TextField',
};
const matchedUnsupportedKeys = new Set();
export const KNOWN_KEYS = {
    adapterCase: new Set([
        'name',
        'description',
        'features',
        'action',
        'protocolVersion',
        'strictMode',
        'catalogPaths',
        'catalogs',
        'steps',
    ]),
    adapterCatalog: new Set(['catalogId', 'protocolVersion', 'components', 'functions']),
    adapterStep: new Set([
        'description',
        'op',
        'messages',
        'targetNode',
        'inputValue',
        'userActivation',
        'expectViewTree',
        'expectAccessibilityTree',
        'expectDataModel',
        'expectActions',
        'expectErrors',
        'expectOutbound',
        'expectSameViewIdentity',
        'expectNewViewIdentity',
        'expectDisposedNodes',
        'expectSurfaceRemoved',
        'expectThemeAbsent',
        'expectActiveSubscriptions',
    ]),
    adapterOps: new Set([
        'process_messages',
        'user_input',
        'user_gesture',
        'programmatic_invoke',
        'unmount_surface',
    ]),
    viewNode: new Set([
        'id',
        'type',
        'state',
        'occupiesLayout',
        'text',
        'value',
        'url',
        'name',
        'axis',
        'badgeText',
        'isValid',
        'validationErrors',
        'validationResults',
        'hints',
        'children',
    ]),
    validationResult: new Set(['valid', 'code', 'message', 'severity']),
    expectedAction: new Set(['name', 'surfaceId', 'sourceComponentId', 'context']),
    expectedError: new Set(['code', 'surfaceId', 'message']),
    accessibilityCase: new Set([
        'name',
        'description',
        'features',
        'action',
        'protocolVersion',
        'catalogPath',
        'surface',
        'messages',
        'assertions',
        'steps',
    ]),
    accessibilityStep: new Set(['description', 'messages', 'assertions']),
    accessibilityAssertions: new Set(['accessibilityTree', 'axeCore']),
    accessibilityNode: new Set(['label', 'description', 'live', 'hidden', 'role', 'checked']),
};
function assertObjectKeys(obj, allowed, where) {
    if (obj === undefined || obj === null) {
        return;
    }
    assert.ok(typeof obj === 'object' && !Array.isArray(obj), `${where}: expected object`);
    const unknown = Object.keys(obj).filter(key => !allowed.has(key));
    assert.deepEqual(unknown, [], `${where}: unknown keys: ${unknown.map(k => `${where}.${k}`).join(', ')}`);
}
function assertKnownViewNodeKeys(node, where) {
    if (node === undefined || node === null) {
        return;
    }
    assertObjectKeys(node, KNOWN_KEYS.viewNode, where);
    const record = node;
    if (Array.isArray(record.validationResults)) {
        record.validationResults.forEach((item, idx) => {
            assertObjectKeys(item, KNOWN_KEYS.validationResult, `${where}.validationResults[${idx}]`);
        });
    }
    if (Array.isArray(record.children)) {
        record.children.forEach((child, idx) => {
            assertKnownViewNodeKeys(child, `${where}.children[${idx}]`);
        });
    }
}
export function assertKnownKeys(obj, allowed = KNOWN_KEYS.adapterStep, where = 'step') {
    assertObjectKeys(obj, allowed, where);
    if (allowed !== KNOWN_KEYS.adapterStep || !obj || typeof obj !== 'object') {
        return;
    }
    const step = obj;
    if (step.op !== undefined) {
        assert.ok(typeof step.op === 'string' && KNOWN_KEYS.adapterOps.has(step.op), `${where}.op: unsupported op "${String(step.op)}"`);
    }
    if (step.expectViewTree !== undefined) {
        assertKnownViewNodeKeys(step.expectViewTree, `${where}.expectViewTree`);
    }
    if (step.expectAccessibilityTree !== undefined) {
        assert.ok(typeof step.expectAccessibilityTree === 'object' &&
            step.expectAccessibilityTree !== null &&
            !Array.isArray(step.expectAccessibilityTree), `${where}.expectAccessibilityTree: expected object`);
        for (const [compId, node] of Object.entries(step.expectAccessibilityTree)) {
            assertObjectKeys(node, KNOWN_KEYS.accessibilityNode, `${where}.expectAccessibilityTree.${compId}`);
        }
    }
    if (step.expectActions !== undefined) {
        assert.ok(Array.isArray(step.expectActions), `${where}.expectActions: expected array`);
        step.expectActions.forEach((item, idx) => {
            assertObjectKeys(item, KNOWN_KEYS.expectedAction, `${where}.expectActions[${idx}]`);
        });
    }
    if (step.expectErrors !== undefined) {
        assert.ok(Array.isArray(step.expectErrors), `${where}.expectErrors: expected array`);
        step.expectErrors.forEach((item, idx) => {
            assertObjectKeys(item, KNOWN_KEYS.expectedError, `${where}.expectErrors[${idx}]`);
        });
    }
    if (step.expectOutbound !== undefined) {
        assert.ok(Array.isArray(step.expectOutbound), `${where}.expectOutbound: expected array`);
        step.expectOutbound.forEach((item, idx) => {
            assert.ok(typeof item === 'object' && item !== null && !Array.isArray(item), `${where}.expectOutbound[${idx}]: expected object`);
            assert.equal(typeof item.version, 'string', `${where}.expectOutbound[${idx}].version: expected string`);
        });
    }
}
export function assertKnownAdapterCase(testCase) {
    assertObjectKeys(testCase, KNOWN_KEYS.adapterCase, `case(${testCase.name})`);
    if (testCase.action !== undefined) {
        assert.equal(testCase.action, 'render_surface', `case(${testCase.name}): unsupported action "${testCase.action}"`);
    }
    for (const [idx, cat] of (testCase.catalogs ?? []).entries()) {
        assertObjectKeys(cat, KNOWN_KEYS.adapterCatalog, `case(${testCase.name}).catalogs[${idx}]`);
    }
    for (const [idx, step] of testCase.steps.entries()) {
        assertKnownKeys(step, KNOWN_KEYS.adapterStep, `case(${testCase.name}).steps[${idx}]`);
    }
}
export function assertKnownAccessibilityAssertions(assertions, where) {
    if (!assertions) {
        return;
    }
    assertObjectKeys(assertions, KNOWN_KEYS.accessibilityAssertions, where);
    for (const [compId, node] of Object.entries(assertions.accessibilityTree ?? {})) {
        assertObjectKeys(node, KNOWN_KEYS.accessibilityNode, `${where}.accessibilityTree.${compId}`);
    }
}
export function assertKnownAccessibilityCase(testCase) {
    assertObjectKeys(testCase, KNOWN_KEYS.accessibilityCase, `case(${testCase.name})`);
    if (testCase.action !== undefined) {
        assert.equal(testCase.action, 'accessibility_check', `case(${testCase.name}): unsupported action "${testCase.action}"`);
    }
    assertKnownAccessibilityAssertions(testCase.assertions, `case(${testCase.name}).assertions`);
    for (const [idx, step] of (testCase.steps ?? []).entries()) {
        assertObjectKeys(step, KNOWN_KEYS.accessibilityStep, `case(${testCase.name}).steps[${idx}]`);
        assertKnownAccessibilityAssertions(step.assertions, `case(${testCase.name}).steps[${idx}].assertions`);
    }
}
function collectViewTreeKeys(node, out) {
    if (!node || typeof node !== 'object' || Array.isArray(node)) {
        return;
    }
    const rec = node;
    for (const key of Object.keys(rec)) {
        out.add(key);
    }
    if (Array.isArray(rec.children)) {
        for (const child of rec.children) {
            collectViewTreeKeys(child, out);
        }
    }
}
export function findUnsupportedReason(caseName, steps = []) {
    if (Object.hasOwn(UNSUPPORTED, caseName)) {
        matchedUnsupportedKeys.add(caseName);
        return UNSUPPORTED[caseName];
    }
    for (const step of steps) {
        const op = typeof step.op === 'string' ? step.op : undefined;
        if (op) {
            const opKey = `${caseName}/${op}`;
            if (Object.hasOwn(UNSUPPORTED, opKey)) {
                matchedUnsupportedKeys.add(opKey);
                return UNSUPPORTED[opKey];
            }
        }
        for (const key of Object.keys(step)) {
            const stepKey = `${caseName}/${key}`;
            if (Object.hasOwn(UNSUPPORTED, stepKey)) {
                matchedUnsupportedKeys.add(stepKey);
                return UNSUPPORTED[stepKey];
            }
        }
        const viewKeys = new Set();
        collectViewTreeKeys(step.expectViewTree, viewKeys);
        for (const key of viewKeys) {
            const viewKey = `${caseName}/${key}`;
            if (Object.hasOwn(UNSUPPORTED, viewKey)) {
                matchedUnsupportedKeys.add(viewKey);
                return UNSUPPORTED[viewKey];
            }
        }
        const assertions = step.assertions;
        if (assertions && typeof assertions === 'object' && !Array.isArray(assertions)) {
            for (const key of Object.keys(assertions)) {
                const assertionKey = `${caseName}/${key}`;
                if (Object.hasOwn(UNSUPPORTED, assertionKey)) {
                    matchedUnsupportedKeys.add(assertionKey);
                    return UNSUPPORTED[assertionKey];
                }
            }
        }
    }
    return undefined;
}
export function assertAllUnsupportedMatched(accessibilityCases = [], adapterCases = [], adapterV09Cases = []) {
    for (const testCase of accessibilityCases) {
        const steps = testCase.steps ?? [
            {
                messages: testCase.messages ?? [],
                assertions: testCase.assertions ?? {},
            },
        ];
        findUnsupportedReason(testCase.name, steps);
    }
    for (const testCase of [...adapterCases, ...adapterV09Cases]) {
        findUnsupportedReason(testCase.name, testCase.steps);
    }
    const unused = Object.keys(UNSUPPORTED).filter(key => !matchedUnsupportedKeys.has(key));
    assert.deepEqual(unused, [], `Unused UNSUPPORTED entries did not match any executed case: ${unused.join(', ')}`);
}
export function writeManifestRecord(rec) {
    const manifestDir = process.env.A2UI_CONFORMANCE_MANIFEST_DIR;
    if (!manifestDir) {
        return;
    }
    fs.mkdirSync(manifestDir, { recursive: true });
    const filePath = path.join(manifestDir, `${rec.harness}-${process.pid}.jsonl`);
    const payload = {
        harness: rec.harness,
        suite: rec.suite.replaceAll('\\', '/'),
        case: rec.case,
        status: rec.status,
    };
    if (rec.reason) {
        payload.reason = rec.reason;
    }
    fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
}
export async function settleSurface(root) {
    for (let pass = 0; pass < 3; pass++) {
        await asyncUpdate(root, () => { });
        const elements = [root, ...Array.from(root.querySelectorAll('*'))];
        for (const el of elements) {
            const litEl = el;
            if (litEl.updateComplete) {
                await litEl.updateComplete;
            }
        }
    }
}
function createIncrementCounterFn() {
    return {
        name: 'incrementCounter',
        returnType: 'void',
        schema: z.object({
            path: z.string().optional(),
            targetPath: z.string().optional(),
            step: z.any().optional(),
            amount: z.any().optional(),
        }),
        execute: (args, context) => {
            const targetPath = args.path ?? args.targetPath ?? '/counter';
            const delta = args.step ?? args.amount ?? 1;
            const current = Number(context.dataModel.get(targetPath) ?? 0);
            context.dataModel.set(targetPath, current + delta);
        },
    };
}
export function createAugmentedBasicCatalog(version = '1.0') {
    const base = (version === 'v0.9'
        ? v09BasicCatalog
        : v1BasicCatalog);
    const components = Array.from(base.components.values());
    const functions = [...Array.from(base.functions?.values() ?? []), createIncrementCounterFn()];
    return new Catalog(base.id, base.protocolVersion ?? version, components, functions, base.themeSchema, base.instructions);
}
export function buildSecondaryCatalog(spec) {
    const components = [];
    const badgeSchema = z.object({
        badgeText: z.string().optional(),
    });
    for (const compName of Object.keys(spec.components ?? {})) {
        const tagName = `a2ui-conformance-${compName.toLowerCase()}`;
        let element = customElements.get(tagName);
        if (!element) {
            class CustomBadgeElement extends A2uiLitElement {
                createRenderRoot() {
                    return this;
                }
                render() {
                    const props = this.controller?.props;
                    return html `<span class="a2ui-custom-badge">${String(props?.badgeText ?? '')}</span>`;
                }
            }
            element = CustomBadgeElement;
        }
        components.push({
            name: compName,
            tagName,
            element,
            schema: badgeSchema,
        });
    }
    const functions = spec.functions
        ? Object.entries(spec.functions).map(([name, fnDef]) => {
            const record = fnDef;
            return {
                name,
                returnType: record['returnType'] ?? 'any',
                schema: z.object({}).passthrough(),
                allowedCallers: record['allowedCallers'],
                requiresUserActivation: record['requiresUserActivation'],
            };
        })
        : [];
    return new Catalog(spec.catalogId, (spec.protocolVersion ?? 'v1.0'), components, functions);
}
function findDomElementByComponentId(container, componentId) {
    const elements = Array.from(container.querySelectorAll('*'));
    for (const el of elements) {
        const a2uiEl = el;
        if (a2uiEl.context?.componentModel.id === componentId) {
            return el;
        }
    }
    return undefined;
}
function getDirectChildNodes(node, surfaceEl) {
    const props = getValue(node.props);
    const childrenProp = props.children;
    if (Array.isArray(childrenProp)) {
        return childrenProp.filter(isComponentNode);
    }
    const childProp = props.child;
    if (isComponentNode(childProp)) {
        return [childProp];
    }
    const tabsProp = props.tabs;
    if (Array.isArray(tabsProp)) {
        const domEl = surfaceEl ? findDomElementForNode(surfaceEl, node) : undefined;
        const activeIndex = domEl?.activeIndex ?? 0;
        const activeTab = tabsProp[activeIndex];
        if (activeTab && isComponentNode(activeTab.child)) {
            return [activeTab.child];
        }
        return [];
    }
    const triggerProp = props.trigger;
    if (isComponentNode(triggerProp)) {
        const modalChildren = [triggerProp];
        const domEl = surfaceEl ? findDomElementForNode(surfaceEl, node) : undefined;
        const isOpen = domEl?.isOpen === true ||
            Boolean(domEl?.querySelector('.a2ui-modal-content'));
        if (isOpen && isComponentNode(props.content)) {
            modalChildren.push(props.content);
        }
        return modalChildren;
    }
    return [];
}
function findDomElementForNode(container, target) {
    const elements = Array.from(container.querySelectorAll('*'));
    for (const el of elements) {
        const a2uiEl = el;
        if (a2uiEl.node === target) {
            return el;
        }
        if (a2uiEl.node === undefined &&
            a2uiEl.context?.componentModel.id === target.componentId &&
            a2uiEl.context?.dataContext.path === target.dataPath) {
            return el;
        }
    }
    return undefined;
}
function resolveIdentityElement(surfaceEl, identityPath) {
    if (identityPath === 'root') {
        return findDomElementByComponentId(surfaceEl, 'root');
    }
    const match = /^root\/children\/(\d+)$/.exec(identityPath);
    if (match && surfaceEl.rootNode) {
        const idx = Number(match[1]);
        const children = getDirectChildNodes(surfaceEl.rootNode);
        const targetNode = children[idx];
        return targetNode ? findDomElementForNode(surfaceEl, targetNode) : undefined;
    }
    return findDomElementByComponentId(surfaceEl, identityPath);
}
function snapshotViewIdentities(surfaceEl) {
    const map = new Map();
    if (!surfaceEl?.rootNode) {
        return map;
    }
    const rootEl = resolveIdentityElement(surfaceEl, 'root');
    if (rootEl) {
        map.set('root', rootEl);
    }
    const children = getDirectChildNodes(surfaceEl.rootNode);
    children.forEach((child, index) => {
        const childEl = findDomElementForNode(surfaceEl, child);
        if (childEl) {
            map.set(`root/children/${index}`, childEl);
        }
    });
    return map;
}
function snapshotNodes(surfaceEl) {
    const map = new Map();
    if (!surfaceEl?.rootNode) {
        return map;
    }
    const visit = (node, path) => {
        map.set(path, node);
        map.set(node.componentId, node);
        const children = getDirectChildNodes(node);
        children.forEach((child, idx) => {
            visit(child, `${path}/children/${idx}`);
        });
    };
    visit(surfaceEl.rootNode, 'root');
    return map;
}
function unwrapProp(val) {
    return val instanceof ResolvedBinding ? val.value : val;
}
function assertNodeScalarProps(surfaceEl, actual, expected) {
    const props = getValue(actual.props);
    if (expected.text !== undefined) {
        assert.equal(unwrapProp(props.text), expected.text);
        if (surfaceEl) {
            const domEl = findDomElementForNode(surfaceEl, actual);
            assert.ok(domEl?.textContent?.includes(expected.text));
        }
    }
    if (expected.value !== undefined) {
        assert.deepEqual(unwrapProp(props.value), expected.value);
    }
    if (expected.url !== undefined) {
        assert.equal(unwrapProp(props.url), expected.url);
        if (surfaceEl) {
            const domEl = findDomElementForNode(surfaceEl, actual);
            const mediaEl = domEl?.querySelector('img, video, audio');
            if (mediaEl) {
                assert.equal(mediaEl.getAttribute('src'), expected.url);
            }
        }
    }
    if (expected.name !== undefined) {
        assert.equal(unwrapProp(props.name), expected.name);
    }
    if (expected.axis !== undefined) {
        assert.equal(unwrapProp(props.axis), expected.axis);
    }
    if (expected.badgeText !== undefined) {
        assert.equal(unwrapProp(props.badgeText), expected.badgeText);
        if (surfaceEl) {
            const domEl = findDomElementForNode(surfaceEl, actual);
            assert.ok(domEl?.textContent?.includes(expected.badgeText));
        }
    }
    if (expected.isValid !== undefined) {
        assert.equal(props.isValid, expected.isValid);
        if (surfaceEl) {
            const domEl = findDomElementForNode(surfaceEl, actual);
            const inputContainer = domEl?.querySelector('.a2ui-textfield');
            if (inputContainer) {
                assert.equal(inputContainer.classList.contains('a2ui-invalid'), !expected.isValid);
            }
        }
    }
    if (expected.validationErrors !== undefined) {
        const actualErrors = props.validationErrors;
        assert.deepEqual(actualErrors, expected.validationErrors);
    }
    if (expected.validationResults !== undefined) {
        assert.deepEqual(props.validationResults, expected.validationResults);
    }
    if (expected.hints !== undefined && surfaceEl) {
        const domEl = findDomElementForNode(surfaceEl, actual);
        for (const hint of expected.hints) {
            assert.ok(domEl?.textContent?.includes(hint));
        }
    }
}
export function extractViewTree(session) {
    return session.surfaceEl?.rootNode;
}
export function assertViewTree(actual, expected, surfaceEl) {
    assert.ok(actual, `Expected view node for "${expected.id}"`);
    const resolvedSurfaceEl = surfaceEl ??
        document.body.querySelector('a2ui-surface');
    assert.equal(actual.componentId, expected.id);
    if (expected.type !== undefined) {
        assert.equal(actual.type, expected.type);
    }
    if (expected.state !== undefined) {
        assert.equal(actual.state, expected.state);
    }
    if (expected.occupiesLayout !== undefined && resolvedSurfaceEl) {
        const domEl = findDomElementForNode(resolvedSurfaceEl, actual);
        const occupies = domEl !== undefined && !domEl.hidden && window.getComputedStyle(domEl).display !== 'none';
        assert.equal(occupies, expected.occupiesLayout);
    }
    if (actual.state === 'resolved' && resolvedSurfaceEl) {
        const domEl = findDomElementForNode(resolvedSurfaceEl, actual);
        assert.ok(domEl, `Expected mounted DOM element for "${actual.componentId}"`);
    }
    assertNodeScalarProps(resolvedSurfaceEl, actual, expected);
    if (expected.children !== undefined) {
        const actualChildren = getDirectChildNodes(actual, resolvedSurfaceEl);
        assert.equal(actualChildren.length, expected.children.length, `Child count mismatch on "${actual.componentId}"`);
        for (let i = 0; i < expected.children.length; i++) {
            assertViewTree(actualChildren[i], expected.children[i], resolvedSurfaceEl);
        }
    }
}
function isNestedComponentElement(host, candidate) {
    let current = candidate;
    while (current && current !== host) {
        const a2uiEl = current;
        if (a2uiEl.context || a2uiEl.node) {
            return true;
        }
        current = current.parentElement;
    }
    return false;
}
function resolveOwnAttribute(el, attr) {
    const hostValue = el.getAttribute(attr);
    if (hostValue) {
        return hostValue;
    }
    for (const descendant of Array.from(el.querySelectorAll(`[${attr}]`))) {
        if (!isNestedComponentElement(el, descendant) &&
            !descendant.matches('.a2ui-filter-input, .a2ui-modal-close')) {
            const value = descendant.getAttribute(attr);
            if (value) {
                return value;
            }
        }
    }
    return undefined;
}
function resolveAccessibleLabel(el) {
    const explicit = resolveOwnAttribute(el, 'aria-label');
    if (explicit) {
        return explicit;
    }
    const innerButton = el.querySelector('button');
    if (innerButton?.textContent) {
        return innerButton.textContent.trim();
    }
    const innerLabel = el.querySelector('label');
    if (innerLabel?.textContent) {
        return innerLabel.textContent.trim();
    }
    return el.textContent?.trim() || undefined;
}
function resolveSemanticRole(el) {
    const explicitRole = el.getAttribute('role');
    if (explicitRole) {
        return explicitRole;
    }
    if (el.querySelector('button')) {
        return 'button';
    }
    if (el.querySelector('input[type="checkbox"]')) {
        return 'checkbox';
    }
    if (el.querySelector('input[type="radio"]')) {
        return 'radiogroup';
    }
    if (el.querySelector('input:not([type="checkbox"]):not([type="radio"]):not([type="range"]), textarea')) {
        return 'textbox';
    }
    return undefined;
}
export function assertAccessibilityNode(container, componentId, expected) {
    const el = findDomElementByComponentId(container, componentId);
    assert.ok(el, `Expected DOM element for component "${componentId}"`);
    if (expected.label !== undefined) {
        assert.equal(resolveAccessibleLabel(el), expected.label);
    }
    if (expected.description !== undefined) {
        assert.equal(resolveOwnAttribute(el, 'aria-description'), expected.description);
    }
    if (expected.live !== undefined) {
        assert.equal(el.getAttribute('aria-live'), expected.live);
    }
    if (expected.hidden !== undefined) {
        assert.equal(el.getAttribute('aria-hidden'), String(expected.hidden));
    }
    if (expected.role !== undefined) {
        assert.equal(resolveSemanticRole(el), expected.role);
    }
    if (expected.checked !== undefined) {
        const checkbox = el.querySelector('input[type="checkbox"]');
        assert.equal(checkbox?.checked, expected.checked);
    }
}
export function assertAxeRules(container, rules) {
    if (rules.includes('button-name')) {
        const buttons = Array.from(container.querySelectorAll('button'));
        for (const btn of buttons) {
            const host = btn.closest('a2ui-basic-button');
            const name = btn.getAttribute('aria-label') ||
                host?.getAttribute('aria-label') ||
                btn.textContent?.trim();
            assert.ok(name, 'Expected accessible name on rendered button');
        }
    }
    if (rules.includes('aria-valid-attr-value')) {
        const liveNodes = Array.from(container.querySelectorAll('[aria-live]'));
        for (const node of liveNodes) {
            const val = node.getAttribute('aria-live');
            assert.ok(val !== null && ['off', 'polite', 'assertive'].includes(val), `Invalid aria-live attribute value: ${String(val)}`);
        }
    }
}
function countActiveSurfaceSubscriptions(surface) {
    const onCreatedSize = surface.componentsModel.onCreated
        .listeners.size;
    const onDeletedSize = surface.componentsModel.onDeleted
        .listeners.size;
    const dataSubsSize = surface.dataModel
        .subscriptions.size;
    return onCreatedSize + onDeletedSize + dataSubsSize;
}
export function frameActionEnvelope(action, protocolVersion) {
    const payload = {
        name: action.name,
        surfaceId: action.surfaceId,
        sourceComponentId: action.sourceComponentId,
        timestamp: action.timestamp,
        context: action.context ?? {},
    };
    if (action.userMessage !== undefined) {
        payload.userMessage = action.userMessage;
    }
    if (action.metadata !== undefined) {
        payload.metadata = action.metadata;
    }
    return {
        version: protocolVersion,
        action: payload,
    };
}
export function frameErrorEnvelope(err, surfaceId, protocolVersion) {
    const payload = {
        code: err.code,
        message: err.message,
    };
    if (typeof err.functionCallId === 'string') {
        payload.functionCallId = err.functionCallId;
    }
    else {
        payload.surfaceId = typeof err.surfaceId === 'string' ? err.surfaceId : surfaceId;
    }
    if (typeof err.path === 'string') {
        payload.path = err.path;
    }
    return {
        version: protocolVersion,
        error: payload,
    };
}
function isMatchAny(value) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        return false;
    }
    const keys = Object.keys(value);
    return keys.length === 1 && value['$match'] === 'any';
}
function assertMatchesExpectedOutbound(actual, expected, where) {
    if (isMatchAny(expected)) {
        assert.ok(actual !== undefined && actual !== null, `${where}: expected defined non-null value for {$match: "any"}`);
        return;
    }
    if (Array.isArray(expected)) {
        assert.ok(Array.isArray(actual), `${where}: expected array`);
        assert.equal(actual.length, expected.length, `${where}: array length mismatch`);
        for (let i = 0; i < expected.length; i++) {
            assertMatchesExpectedOutbound(actual[i], expected[i], `${where}[${i}]`);
        }
        return;
    }
    if (typeof expected === 'object' && expected !== null) {
        assert.ok(typeof actual === 'object' && actual !== null && !Array.isArray(actual), `${where}: expected object`);
        const actualRecord = actual;
        const expectedRecord = expected;
        const actualKeys = Object.keys(actualRecord).sort();
        const expectedKeys = Object.keys(expectedRecord).sort();
        assert.deepEqual(actualKeys, expectedKeys, `${where}: object keys mismatch`);
        for (const key of expectedKeys) {
            assertMatchesExpectedOutbound(actualRecord[key], expectedRecord[key], `${where}.${key}`);
        }
        return;
    }
    assert.equal(actual, expected, `${where}: value mismatch`);
}
function validateOutboundEnvelopes(envelopes, protocolVersion) {
    const isV09 = protocolVersion.startsWith('v0.9') || protocolVersion.startsWith('0.9');
    for (let i = 0; i < envelopes.length; i++) {
        const env = envelopes[i];
        const parsed = isV09
            ? A2uiClientMessageSchema.safeParse(env)
            : RendererToAgentMessageSchema.safeParse(env);
        assert.ok(parsed.success, `recordedOutbound[${i}] failed protocol schema validation: ${parsed.success ? '' : JSON.stringify(parsed.error.issues)}`);
    }
}
function assertExpectedOutbound(actual, expected) {
    assert.equal(actual.length, expected.length, `expectOutbound length mismatch: actual=${actual.length}, expected=${expected.length}`);
    for (let i = 0; i < expected.length; i++) {
        assertMatchesExpectedOutbound(actual[i], expected[i], `expectOutbound[${i}]`);
    }
}
export async function ensureSurfaceMounted(session, mountedElements = session.mountedElements) {
    if (session.surfaceEl) {
        return;
    }
    const surface = session.processor.model.getSurface('adapter_surface') ??
        session.processor.model.getSurface('a11y_surface') ??
        session.processor.model.surfacesMap.values().next().value;
    assert.ok(surface, 'Expected surface to exist in MessageProcessor');
    session.surface = surface;
    surface.onAction.subscribe(action => {
        session.recordedActions.push({
            name: action.name,
            surfaceId: action.surfaceId,
            sourceComponentId: action.sourceComponentId,
            context: action.context,
        });
        session.recordedOutbound.push(frameActionEnvelope(action, session.protocolVersion));
    });
    surface.onError.subscribe(err => {
        session.recordedErrors.push({
            code: err.code,
            message: err.message,
            surfaceId: surface.id,
        });
        session.recordedOutbound.push(frameErrorEnvelope(err, surface.id, session.protocolVersion));
    });
    const el = document.createElement('a2ui-surface');
    mountedElements.push(el);
    if (mountedElements !== session.mountedElements) {
        session.mountedElements.push(el);
    }
    document.body.appendChild(el);
    el.surface = surface;
    session.surfaceEl = el;
}
async function performStepOperation(session, step) {
    switch (step.op) {
        case 'process_messages':
            session.processor.processMessages(step.messages ?? []);
            return;
        case 'user_input': {
            assert.ok(session.surfaceEl && step.targetNode, 'Expected surfaceEl and targetNode');
            const hostEl = findDomElementByComponentId(session.surfaceEl, step.targetNode);
            assert.ok(hostEl, `Expected host element for "${step.targetNode}"`);
            const tag = hostEl.tagName.toLowerCase();
            if (tag === 'a2ui-checkbox' || typeof step.inputValue === 'boolean') {
                const checkbox = hostEl.querySelector('input[type="checkbox"]');
                assert.ok(checkbox, `Expected checkbox input inside "${step.targetNode}"`);
                checkbox.checked = Boolean(step.inputValue);
                checkbox.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                return;
            }
            if (tag === 'a2ui-choicepicker' || Array.isArray(step.inputValue)) {
                const values = (Array.isArray(step.inputValue) ? step.inputValue : [step.inputValue]).map(String);
                const options = Array.from(hostEl.querySelectorAll('input.a2ui-option-input'));
                assert.ok(options.length > 0, `Expected option inputs inside "${step.targetNode}"`);
                for (const opt of options) {
                    const shouldCheck = values.includes(opt.value);
                    if (opt.type === 'radio' ? shouldCheck : opt.checked !== shouldCheck) {
                        opt.checked = shouldCheck;
                        opt.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                    }
                }
                return;
            }
            if (tag === 'a2ui-tabs') {
                const tabButtons = Array.from(hostEl.querySelectorAll('button.a2ui-tab-button'));
                const tabIdx = Number(step.inputValue ?? 0);
                assert.ok(tabButtons[tabIdx], `Expected tab button at index ${tabIdx} inside "${step.targetNode}"`);
                tabButtons[tabIdx].click();
                return;
            }
            if (tag === 'a2ui-slider') {
                const slider = hostEl.querySelector('input[type="range"]');
                assert.ok(slider, `Expected range input inside "${step.targetNode}"`);
                slider.value = String(step.inputValue ?? 0);
                slider.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
                return;
            }
            if (tag === 'a2ui-datetimeinput') {
                const raw = String(step.inputValue ?? '');
                const [datePart, timePart] = raw.includes('T') ? raw.split('T') : [raw, ''];
                const dateInput = hostEl.querySelector('input[type="date"]');
                if (dateInput && datePart) {
                    dateInput.value = datePart.slice(0, 10);
                    dateInput.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                    await settleSurface(session.surfaceEl);
                }
                const timeInput = hostEl.querySelector('input[type="time"]');
                if (timeInput && timePart) {
                    timeInput.value = timePart.slice(0, 5);
                    timeInput.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                }
                return;
            }
            const input = hostEl.querySelector('input, textarea');
            assert.ok(input, `Expected input element inside "${step.targetNode}"`);
            input.value = String(step.inputValue ?? '');
            input.dispatchEvent(new Event('input', { bubbles: true }));
            return;
        }
        case 'user_gesture': {
            assert.ok(session.surfaceEl && step.targetNode, 'Expected surfaceEl and targetNode');
            const hostEl = findDomElementByComponentId(session.surfaceEl, step.targetNode);
            const btn = (hostEl?.querySelector('button') ?? hostEl);
            assert.ok(btn, `Expected clickable element for "${step.targetNode}"`);
            const origOpen = window.open;
            window.open = () => null;
            try {
                btn.click();
            }
            finally {
                window.open = origOpen;
            }
            return;
        }
        case 'programmatic_invoke': {
            assert.ok(session.surfaceEl && step.targetNode, 'Expected surfaceEl and targetNode');
            const hostEl = findDomElementByComponentId(session.surfaceEl, step.targetNode);
            const rawAction = hostEl?.context?.componentModel.properties.action;
            assert.ok(rawAction && hostEl?.context, `Expected action on "${step.targetNode}"`);
            hostEl.context.dataContext.resolveAction(rawAction, {
                userActivation: Boolean(step.userActivation),
            });
            return;
        }
        case 'unmount_surface':
            session.surfaceEl?.remove();
            return;
        default:
            assert.fail(`Unsupported adapter step op: ${String(step.op)}`);
    }
}
function assertSameViewIdentities(session, identityPaths) {
    assert.ok(session.surfaceEl, 'Expected mounted surfaceEl for view identity check');
    for (const idPath of identityPaths) {
        const beforeEl = session.priorIdentities.get(idPath);
        const afterEl = resolveIdentityElement(session.surfaceEl, idPath);
        assert.ok(beforeEl && afterEl, `Missing view identity for "${idPath}"`);
        assert.equal(afterEl, beforeEl, `Expected view identity to be preserved for "${idPath}"`);
    }
}
function assertNewViewIdentities(session, identityPaths) {
    assert.ok(session.surfaceEl, 'Expected mounted surfaceEl for new view identity check');
    for (const idPath of identityPaths) {
        const beforeEl = session.priorIdentities.get(idPath);
        const afterEl = resolveIdentityElement(session.surfaceEl, idPath);
        assert.ok(beforeEl && afterEl, `Missing view identity for "${idPath}"`);
        assert.notEqual(afterEl, beforeEl, `Expected new view identity for "${idPath}"`);
    }
}
function assertDisposedNodes(session, nodeIds) {
    for (const nodeId of nodeIds) {
        const prevNode = session.priorNodes.get(nodeId);
        assert.ok(prevNode, `Expected prior node "${nodeId}"`);
        assert.equal(prevNode.disposed, true, `Expected node "${nodeId}" to be disposed`);
        if (session.surfaceEl) {
            assert.equal(findDomElementByComponentId(session.surfaceEl, nodeId), undefined, `Expected node "${nodeId}" DOM element to be unmounted`);
        }
    }
}
function assertRecordedErrors(actualErrors, expectedErrors) {
    assert.equal(actualErrors.length, expectedErrors.length);
    for (let i = 0; i < expectedErrors.length; i++) {
        const exp = expectedErrors[i];
        const act = actualErrors[i];
        if (exp.code !== undefined) {
            assert.equal(act.code, exp.code);
        }
        if (exp.surfaceId !== undefined) {
            assert.equal(act.surfaceId, exp.surfaceId);
        }
        if (exp.message !== undefined) {
            assert.ok(act.message.includes(exp.message));
        }
    }
}
function verifyStepExpectations(session, step) {
    if (step.expectViewTree) {
        const actualRoot = extractViewTree(session);
        assertViewTree(actualRoot, step.expectViewTree, session.surfaceEl);
    }
    if (step.expectDataModel && session.surface) {
        assert.deepEqual(session.surface.dataModel.get('/'), step.expectDataModel);
    }
    if (step.expectSameViewIdentity) {
        assertSameViewIdentities(session, step.expectSameViewIdentity);
    }
    if (step.expectNewViewIdentity) {
        assertNewViewIdentities(session, step.expectNewViewIdentity);
    }
    if (step.expectDisposedNodes) {
        assertDisposedNodes(session, step.expectDisposedNodes);
    }
    if (step.expectSurfaceRemoved) {
        assert.ok(session.surface, 'Expected prior surface for expectSurfaceRemoved');
        assert.equal(session.processor.model.getSurface(session.surface.id), undefined);
        assert.equal(Boolean(session.surface?.isDisposed ?? session.surface?.disposed), true);
        assert.ok(!session.surfaceEl?.isConnected || session.surfaceEl.children.length === 0);
    }
    if (step.expectActions !== undefined) {
        assert.deepEqual(session.recordedActions, step.expectActions);
    }
    if (step.expectErrors !== undefined) {
        assertRecordedErrors(session.recordedErrors, step.expectErrors);
    }
    validateOutboundEnvelopes(session.recordedOutbound, session.protocolVersion);
    if (step.expectOutbound !== undefined) {
        assertExpectedOutbound(session.recordedOutbound, step.expectOutbound);
    }
    if (step.expectAccessibilityTree && session.surfaceEl) {
        for (const [compId, expected] of Object.entries(step.expectAccessibilityTree)) {
            assertAccessibilityNode(session.surfaceEl, compId, expected);
        }
    }
    if (step.expectThemeAbsent && session.surface && session.surfaceEl) {
        assert.deepEqual(session.surface.theme ?? {}, {});
        for (const el of Array.from(session.surfaceEl.querySelectorAll('*'))) {
            const htmlEl = el;
            assert.equal(htmlEl.style.getPropertyValue('--a2ui-color-primary'), '');
            const inlineStyle = (htmlEl.getAttribute('style') ?? '').toLowerCase();
            assert.ok(!inlineStyle.includes('#ff00aa') && !inlineStyle.includes('255, 0, 170'));
        }
    }
    if (step.expectActiveSubscriptions !== undefined && session.surface) {
        assert.equal(countActiveSurfaceSubscriptions(session.surface), step.expectActiveSubscriptions);
    }
}
export function mountSurface(caseSpec, mountedElements = []) {
    const protocolVersion = caseSpec?.protocolVersion ?? '1.0';
    const catalogs = [
        createAugmentedBasicCatalog(protocolVersion),
        ...(caseSpec?.catalogs ?? []).map(buildSecondaryCatalog),
    ];
    const recordedOutbound = [];
    const validationConfig = caseSpec?.strictMode === true
        ? {
            allowOrphanComponents: false,
            allowDanglingReferences: false,
            allowMissingRoot: false,
            allowUnknownElements: false,
        }
        : caseSpec?.strictMode === false
            ? {
                allowOrphanComponents: true,
                allowDanglingReferences: true,
                allowMissingRoot: true,
                allowUnknownElements: true,
            }
            : undefined;
    let lastCapturedCallId = '';
    const processor = new MessageProcessor(catalogs, undefined, {
        validationConfig,
        outboundListener: msg => {
            recordedOutbound.push(structuredClone(msg));
            const call = msg?.['callAgentFunction'];
            if (call && typeof call['functionCallId'] === 'string') {
                lastCapturedCallId = call['functionCallId'];
                if (session) {
                    session.lastCallId = lastCapturedCallId;
                }
            }
        },
    });
    const session = {
        processor,
        mountedElements,
        recordedActions: [],
        recordedErrors: [],
        recordedOutbound,
        protocolVersion,
        priorIdentities: new Map(),
        priorNodes: new Map(),
        lastCallId: lastCapturedCallId,
    };
    processor.model.onSurfaceDeleted.subscribe(deletedId => {
        if (session.surface?.id === deletedId) {
            session.surfaceEl?.remove();
        }
    });
    return session;
}
export function substituteLastCallId(value, lastCallId) {
    if (Array.isArray(value)) {
        return value.map(item => substituteLastCallId(item, lastCallId));
    }
    if (value && typeof value === 'object') {
        const rec = value;
        if (rec['$ref'] === 'lastCallId' && Object.keys(rec).length === 1) {
            return lastCallId;
        }
        const result = {};
        for (const [k, v] of Object.entries(rec)) {
            result[k] = substituteLastCallId(v, lastCallId);
        }
        return result;
    }
    return value;
}
export async function runStep(session, step) {
    assertKnownKeys(step);
    if (step.messages) {
        step = {
            ...step,
            messages: substituteLastCallId(step.messages, session.lastCallId ?? ''),
        };
    }
    session.recordedActions = [];
    session.recordedErrors = [];
    session.recordedOutbound.length = 0;
    session.priorIdentities = snapshotViewIdentities(session.surfaceEl);
    session.priorNodes = snapshotNodes(session.surfaceEl);
    if (step.op === 'process_messages' && !session.surfaceEl) {
        for (const msg of step.messages ?? []) {
            const record = msg;
            if ('createSurface' in record) {
                session.processor.processMessages([msg]);
                await ensureSurfaceMounted(session, session.mountedElements);
            }
            else {
                session.processor.processMessages([msg]);
            }
        }
    }
    else {
        await performStepOperation(session, step);
    }
    if (session.surfaceEl && step.op !== 'unmount_surface') {
        await settleSurface(session.surfaceEl);
    }
    verifyStepExpectations(session, step);
}
//# sourceMappingURL=adapter_harness.js.map