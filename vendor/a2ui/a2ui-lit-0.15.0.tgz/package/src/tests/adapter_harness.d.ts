import { Catalog, MessageProcessor, type ComponentNode, type ProcessableMessage, type SurfaceModel } from '@a2ui/web_core';
import type { A2uiSurface } from '../index.js';
import type { LitComponentApi } from '../types.js';
export interface ExpectedAccessibilityNode {
    label?: string;
    description?: string;
    live?: string;
    hidden?: boolean;
    role?: string;
    checked?: boolean;
}
export interface AccessibilityAssertions {
    accessibilityTree?: Record<string, ExpectedAccessibilityNode>;
    axeCore?: string[];
}
export interface AccessibilityStep {
    description?: string;
    messages: ProcessableMessage[];
    assertions: AccessibilityAssertions;
}
export interface AccessibilityTestCase {
    name: string;
    description?: string;
    features?: string[];
    protocolVersion?: string;
    action?: string;
    catalogPath?: string;
    surface?: Record<string, unknown>;
    messages?: ProcessableMessage[];
    assertions?: AccessibilityAssertions;
    steps?: AccessibilityStep[];
}
export interface ExpectedViewNode {
    id: string;
    type?: string;
    state?: string;
    occupiesLayout?: boolean;
    text?: string;
    value?: unknown;
    url?: string;
    name?: string;
    axis?: string;
    badgeText?: string;
    isValid?: boolean;
    validationErrors?: string[];
    validationResults?: unknown[];
    hints?: string[];
    children?: ExpectedViewNode[];
}
export interface ExpectedAction {
    name: string;
    surfaceId: string;
    sourceComponentId: string;
    context?: Record<string, unknown>;
}
export interface ExpectedError {
    code?: string;
    surfaceId?: string;
    message?: string;
}
export interface AdapterStep {
    description?: string;
    op: 'process_messages' | 'user_input' | 'user_gesture' | 'programmatic_invoke' | 'unmount_surface';
    messages?: ProcessableMessage[];
    targetNode?: string;
    inputValue?: unknown;
    userActivation?: boolean;
    expectViewTree?: ExpectedViewNode;
    expectDataModel?: Record<string, unknown>;
    expectSameViewIdentity?: string[];
    expectNewViewIdentity?: string[];
    expectDisposedNodes?: string[];
    expectSurfaceRemoved?: boolean;
    expectActions?: ExpectedAction[];
    expectErrors?: ExpectedError[];
    expectOutbound?: Array<Record<string, unknown>>;
    expectAccessibilityTree?: Record<string, ExpectedAccessibilityNode>;
    expectThemeAbsent?: boolean;
    expectActiveSubscriptions?: number;
}
export interface SecondaryCatalogSpec {
    catalogId: string;
    protocolVersion?: string;
    components?: Record<string, unknown>;
    functions?: Record<string, unknown>;
}
export interface AdapterTestCase {
    name: string;
    description?: string;
    features?: string[];
    protocolVersion?: string;
    strictMode?: boolean;
    action?: string;
    catalogPaths?: string[];
    catalogs?: SecondaryCatalogSpec[];
    steps: AdapterStep[];
}
export interface AdapterSession {
    processor: MessageProcessor<LitComponentApi>;
    surface?: SurfaceModel<LitComponentApi>;
    surfaceEl?: A2uiSurface;
    mountedElements: HTMLElement[];
    recordedActions: ExpectedAction[];
    recordedErrors: Array<{
        code: string;
        message: string;
        surfaceId: string;
    }>;
    recordedOutbound: Array<Record<string, unknown>>;
    protocolVersion: string;
    priorIdentities: Map<string, HTMLElement>;
    priorNodes: Map<string, ComponentNode<LitComponentApi>>;
    lastCallId?: string;
}
export interface ManifestRecord {
    harness: string;
    suite: string;
    case: string;
    status: 'passed' | 'failed' | 'skipped' | 'xfailed';
    reason?: string;
}
/**
 * Reasoned skip entries keyed by `"<case>"` or `"<case>/<op|expectKey>"`.
 * Every entry in this map must match at least one case during the run.
 */
export declare const UNSUPPORTED: Record<string, string>;
export declare const KNOWN_KEYS: {
    readonly adapterCase: Set<string>;
    readonly adapterCatalog: Set<string>;
    readonly adapterStep: Set<string>;
    readonly adapterOps: Set<string>;
    readonly viewNode: Set<string>;
    readonly validationResult: Set<string>;
    readonly expectedAction: Set<string>;
    readonly expectedError: Set<string>;
    readonly accessibilityCase: Set<string>;
    readonly accessibilityStep: Set<string>;
    readonly accessibilityAssertions: Set<string>;
    readonly accessibilityNode: Set<string>;
};
export declare function assertKnownKeys(obj: unknown, allowed?: ReadonlySet<string>, where?: string): void;
export declare function assertKnownAdapterCase(testCase: AdapterTestCase): void;
export declare function assertKnownAccessibilityAssertions(assertions: AccessibilityAssertions | undefined, where: string): void;
export declare function assertKnownAccessibilityCase(testCase: AccessibilityTestCase): void;
export declare function findUnsupportedReason(caseName: string, steps?: Array<Record<string, unknown>>): string | undefined;
export declare function assertAllUnsupportedMatched(accessibilityCases?: AccessibilityTestCase[], adapterCases?: AdapterTestCase[], adapterV09Cases?: AdapterTestCase[]): void;
export declare function writeManifestRecord(rec: ManifestRecord): void;
export declare function settleSurface(root: HTMLElement): Promise<void>;
export declare function createAugmentedBasicCatalog(version?: string): Catalog<LitComponentApi>;
export declare function buildSecondaryCatalog(spec: SecondaryCatalogSpec): Catalog<LitComponentApi>;
export declare function extractViewTree(session: AdapterSession): ComponentNode<LitComponentApi> | undefined;
export declare function assertViewTree(actual: ComponentNode<LitComponentApi> | undefined, expected: ExpectedViewNode, surfaceEl?: A2uiSurface): void;
export declare function assertAccessibilityNode(container: HTMLElement, componentId: string, expected: ExpectedAccessibilityNode): void;
export declare function assertAxeRules(container: HTMLElement, rules: string[]): void;
export declare function frameActionEnvelope(action: Record<string, unknown>, protocolVersion: string): Record<string, unknown>;
export declare function frameErrorEnvelope(err: Record<string, unknown>, surfaceId: string, protocolVersion: string): Record<string, unknown>;
export declare function ensureSurfaceMounted(session: AdapterSession, mountedElements?: HTMLElement[]): Promise<void>;
export declare function mountSurface(caseSpec?: Partial<AdapterTestCase>, mountedElements?: HTMLElement[]): AdapterSession;
export declare function substituteLastCallId(value: unknown, lastCallId: string): unknown;
export declare function runStep(session: AdapterSession, step: AdapterStep): Promise<void>;
//# sourceMappingURL=adapter_harness.d.ts.map