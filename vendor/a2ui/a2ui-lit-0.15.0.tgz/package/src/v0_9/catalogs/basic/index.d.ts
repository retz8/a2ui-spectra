import { Catalog } from '@a2ui/web_core';
import type { LitComponentApi } from '../../../types.js';
/**
 * The basic catalog for A2UI components in Lit.
 *
 * This catalog includes a wide range of components such as text, button,
 * text field, row, column, list, image, icon, video, audio player, card,
 * divider, checkbox, slider, date-time input, choice picker, tabs, and modal.
 * It also includes the basic functions.
 */
export declare const basicCatalog: Catalog<LitComponentApi, import("@a2ui/web_core").FunctionImplementation>;
//# sourceMappingURL=index.d.ts.map