/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Catalog } from '@a2ui/web_core';
import { BASIC_FUNCTIONS, A2uiAudioPlayer, A2uiButton, A2uiCard, A2uiCheckBox, A2uiChoicePicker, A2uiColumn, A2uiDateTimeInput, A2uiDivider, A2uiIcon, A2uiImage, A2uiList, A2uiModal, A2uiRow, A2uiSlider, A2uiTabs, A2uiText, A2uiTextField, A2uiVideo, } from '@a2ui/web_core/v0_9/basic_catalog';
/**
 * The basic catalog for A2UI components in Lit.
 *
 * This catalog includes a wide range of components such as text, button,
 * text field, row, column, list, image, icon, video, audio player, card,
 * divider, checkbox, slider, date-time input, choice picker, tabs, and modal.
 * It also includes the basic functions.
 */
export const basicCatalog = new Catalog('https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json', '0.9', [
    A2uiAudioPlayer,
    A2uiButton,
    A2uiCard,
    A2uiCheckBox,
    A2uiChoicePicker,
    A2uiColumn,
    A2uiDateTimeInput,
    A2uiDivider,
    A2uiIcon,
    A2uiImage,
    A2uiList,
    A2uiModal,
    A2uiRow,
    A2uiSlider,
    A2uiTabs,
    A2uiText,
    A2uiTextField,
    A2uiVideo,
], BASIC_FUNCTIONS);
//# sourceMappingURL=index.js.map