import { type ActionMessage, type AgentToRendererMessage, type CatalogInterface, type ComponentApi, type ErrorMessage, type FunctionApi, type RendererFunctionResponseMessage } from '../internal/web-core.js';
/**
 * What {@link RendererToAgentMessageProcessor.processMessage} did with a
 * message.
 */
export interface ProcessResult {
    /**
     * Whether the processor handled the message: always for `callAgentFunction`,
     * and for `action`, `error` and `rendererFunctionResponse` when their
     * callback is set. An unhandled message is left for the caller, such as a
     * framework that passes it on to the model's turn.
     */
    readonly handled: boolean;
    /**
     * The messages to send back to the renderer: exactly one
     * `agentFunctionResponse` for a `callAgentFunction`, otherwise none.
     */
    readonly replies: AgentToRendererMessage[];
}
/**
 * Options for a {@link RendererToAgentMessageProcessor}.
 */
export interface RendererToAgentMessageProcessorOptions {
    /** The catalogs whose `agentFunctions` answer `callAgentFunction` messages. */
    readonly catalogs: Iterable<CatalogInterface<ComponentApi, FunctionApi>>;
    /**
     * How long an agent function may run, in milliseconds, before its call is
     * answered with an `EXECUTION_ERROR`. No timeout when omitted.
     */
    readonly agentFunctionTimeoutMs?: number;
    /**
     * Receives each `action` message, validated against the v1.0 schema.
     * See {@link RendererMessageCallback} for declining one.
     */
    readonly onAction?: RendererMessageCallback<ActionMessage>;
    /**
     * Receives each `error` message, validated against the v1.0 schema.
     * See {@link RendererMessageCallback} for declining one.
     */
    readonly onError?: RendererMessageCallback<ErrorMessage>;
    /**
     * Receives each `rendererFunctionResponse` message, validated against the
     * v1.0 schema. See {@link RendererMessageCallback} for declining one.
     */
    readonly onRendererFunctionResponse?: RendererMessageCallback<RendererFunctionResponseMessage>;
}
/**
 * A callback for one kind of renderer message. It handles the message by
 * returning nothing or `true`, or declines it by returning `false` (directly
 * or through a `Promise`), so the message comes back with `handled: false`,
 * as if the callback weren't set: for example, to let a conversational action
 * reach the model while handling the others locally.
 */
export type RendererMessageCallback<T> = (message: T) => boolean | void | Promise<boolean | void>;
/**
 * Processes the messages a renderer sends an agent (`RendererToAgentMessage`),
 * the agent-side counterpart of web_core's `MessageProcessor`.
 *
 * - `callAgentFunction` runs the agent function of the catalogs and replies
 *   with its `agentFunctionResponse`. A call that fails after its
 *   `functionCallId` is known (an empty `surfaceId`, an unknown function, bad
 *   arguments, a handler error, the timeout) is answered with an `error`
 *   rather than thrown, so the renderer's pending call settles.
 * - `action`, `error` and `rendererFunctionResponse` go to their callback,
 *   when it is set, which may decline the message. Without one the message is
 *   not handled, and nothing is validated beyond its `version`.
 *
 * The processor keeps no state across messages, so build one per agent, or
 * per request from the active catalogs. It processes one message at a time:
 * the caller decides whether to process several concurrently, and how to
 * handle one that fails.
 */
export declare class RendererToAgentMessageProcessor {
    private readonly _registry;
    private readonly _onAction?;
    private readonly _onError?;
    private readonly _onRendererFunctionResponse?;
    /**
     * Initializes a new `RendererToAgentMessageProcessor`.
     *
     * @param options The catalogs, the agent function timeout and the callbacks.
     * @throws {RangeError} If `agentFunctionTimeoutMs` is not a finite number
     *   greater than 0.
     * @throws {A2uiCatalogError} If two catalogs have the same id.
     */
    constructor(options: RendererToAgentMessageProcessorOptions);
    /**
     * Processes one message from the renderer.
     *
     * @param message The parsed JSON message.
     * @returns Whether the message was handled, and the replies to send.
     * @throws {A2uiValidationError} If `message` is not an object, its
     *   `version` isn't `'1.0'`, it has no known message key or more than one,
     *   it is a `callAgentFunction` without a `functionCallId`, or it is a
     *   malformed message whose callback is set. An error a callback throws
     *   propagates.
     */
    processMessage(message: unknown): Promise<ProcessResult>;
}
//# sourceMappingURL=renderer-to-agent-message-processor.d.ts.map