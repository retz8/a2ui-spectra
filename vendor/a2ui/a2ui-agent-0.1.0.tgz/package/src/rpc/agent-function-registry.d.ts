import { type AgentFunctionResponseMessage, type CatalogInterface, type ComponentApi, type FunctionApi } from '../internal/web-core.js';
/**
 * Options for an {@link AgentFunctionRegistry}.
 */
export interface AgentFunctionRegistryOptions {
    /**
     * How long a handler may run, in milliseconds, before the call is answered
     * with an `EXECUTION_ERROR`. Must be greater than 0. No timeout when
     * omitted.
     */
    readonly timeoutMs?: number;
}
/**
 * Indexes the agent functions of catalogs and answers `callAgentFunction`
 * messages with them. Internal to `RendererToAgentMessageProcessor`.
 *
 * A call that fails after its `functionCallId` is known produces an
 * `agentFunctionResponse` with `error` rather than throwing, so the renderer's
 * pending `callAgentFunction` promise settles cleanly instead of hanging until
 * its timeout. A message without a usable `functionCallId` cannot be answered
 * and throws {@link A2uiValidationError}.
 */
export declare class AgentFunctionRegistry {
    private readonly _catalogs;
    private readonly _functions;
    private readonly _timeoutMs?;
    /**
     * Indexes the `agentFunctions` of each catalog by `(catalog.id, name)`.
     *
     * @param catalogs Catalogs whose `agentFunctions` should be registered.
     * @param options Optional handler timeout.
     * @throws {RangeError} If `timeoutMs <= 0`.
     * @throws {A2uiCatalogError} If two catalogs have the same id.
     */
    constructor(catalogs: Iterable<CatalogInterface<ComponentApi, FunctionApi>>, options?: AgentFunctionRegistryOptions);
    /**
     * Validates, routes, and executes a `callAgentFunction` message, returning
     * its `agentFunctionResponse` envelope.
     *
     * @param message Inbound `callAgentFunction` message.
     * @returns The outbound `agentFunctionResponse` message.
     * @throws {A2uiValidationError} If the message lacks a usable `functionCallId`.
     */
    handle(message: unknown): Promise<AgentFunctionResponseMessage>;
    private _execute;
}
//# sourceMappingURL=agent-function-registry.d.ts.map