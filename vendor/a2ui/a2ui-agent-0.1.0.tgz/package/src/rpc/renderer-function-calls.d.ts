import { type CatalogInterface, type ComponentApi, type FunctionApi, type CallRendererFunctionMessage, type RendererFunctionResponseMessage } from '../internal/web-core.js';
/**
 * Default timeout in milliseconds (`30_000` ms = 30 seconds) that a `callRendererFunction`
 * waits for its `rendererFunctionResponse`, matching the renderer's default `callAgentFunction`
 * timeout.
 */
export declare const DEFAULT_RENDERER_CALL_TIMEOUT_MS = 30000;
/**
 * A `Promise` representing a pending renderer function call that can also be
 * cancelled via {@link CancellablePromise.cancel}.
 */
export interface CancellablePromise<T> extends Promise<T> {
    /**
     * Cancels the pending call, rejecting this promise with {@link A2uiRpcError}
     * (`code: RpcErrorCode.CANCELLED`) and removing its `functionCallId` from
     * the pending calls map.
     */
    cancel(reason?: string): void;
}
/**
 * Return value of {@link RendererFunctionCalls.call}, supporting both tuple
 * destructuring (`const [message, result] = calls.call(...)`) and named
 * property destructuring (`const {message, result, functionCallId, cancel} = calls.call(...)`).
 */
export type PendingRendererCall<T = unknown> = readonly [
    CallRendererFunctionMessage,
    CancellablePromise<T>
] & {
    readonly message: CallRendererFunctionMessage;
    readonly result: CancellablePromise<T>;
    readonly functionCallId: string;
    readonly cancel: (reason?: string) => void;
};
/**
 * Options for configuring {@link RendererFunctionCalls}.
 */
export interface RendererFunctionCallsOptions {
    /**
     * Default timeout in milliseconds for each call. Defaults to `30_000` (30s).
     * Pass `null` to disable the default timeout.
     */
    readonly defaultTimeoutMs?: number | null;
    /**
     * Maximum number of concurrent pending calls allowed.
     * Pass `null` or omit for no limit.
     */
    readonly maxPending?: number | null;
    /**
     * The catalogs the renderer was sent. When given, `call` checks that the
     * target catalog declares the function as a renderer function (not an
     * agent function) and lets the agent call it
     * (`allowedCallers` is `rendererOrAgent` or `agentOnly`, and it doesn't
     * require user activation) before anything is sent. Without them, calls
     * aren't checked against a catalog.
     */
    readonly catalogs?: Iterable<CatalogInterface<ComponentApi, FunctionApi>>;
}
/**
 * Parameters for {@link RendererFunctionCalls.call}.
 */
export interface CallRendererFunctionOptions {
    /** Required catalog identifier declaring the renderer function. */
    readonly catalogId: string;
    /** Name of the renderer function to invoke (must be a valid UAX #31 identifier). */
    readonly name: string;
    /**
     * Optional arguments: a JSON object whose keys are valid UAX #31
     * identifiers and whose values are JSON values (no NaN or infinity).
     */
    readonly args?: Record<string, unknown>;
    /**
     * Optional target surface ID whose data model provides evaluation context.
     * An empty string counts as omitted.
     */
    readonly surfaceId?: string;
    /**
     * Optional per-call timeout in milliseconds, a finite number greater than
     * 0, overriding `defaultTimeoutMs`. When omitted, `defaultTimeoutMs`
     * applies; only `defaultTimeoutMs: null` disables timeouts.
     */
    readonly timeoutMs?: number;
    /** Optional custom `functionCallId`. When omitted, a UUID is generated. */
    readonly functionCallId?: string;
}
/**
 * Builds outbound `callRendererFunction` messages and correlates inbound
 * `rendererFunctionResponse` messages with their pending result promises.
 *
 * `resolve` is bound to the instance, so it can be passed straight to
 * `RendererToAgentMessageProcessor` as `onRendererFunctionResponse`:
 *
 * ```ts
 * const calls = new RendererFunctionCalls();
 * const processor = new RendererToAgentMessageProcessor({
 *   catalogs,
 *   onRendererFunctionResponse: calls.resolve,
 * });
 * ```
 */
export declare class RendererFunctionCalls {
    private readonly _defaultTimeoutMs;
    private readonly _maxPending;
    private readonly _pending;
    private readonly _catalogs?;
    private _disposed;
    /**
     * Creates a new `RendererFunctionCalls` correlation tracker.
     *
     * @param options Optional default timeout and maximum pending calls limit.
     * @throws {RangeError} If `defaultTimeoutMs <= 0` or `maxPending < 1`.
     * @throws {A2uiCatalogError} If two of `catalogs` have the same id.
     */
    constructor(options?: RendererFunctionCallsOptions);
    /**
     * Number of calls currently awaiting a `rendererFunctionResponse`.
     */
    get pendingCount(): number;
    /**
     * Whether a call with `functionCallId` is currently awaiting a renderer
     * response.
     *
     * @param functionCallId The call's id.
     * @returns `true` from `call` until the call is resolved, fails, times
     *   out, is cancelled or the tracker is disposed.
     */
    isPending(functionCallId: string): boolean;
    /**
     * Whether `dispose()` has been called on this tracker.
     */
    get disposed(): boolean;
    /**
     * Builds a `callRendererFunction` message and registers a pending result promise.
     *
     * @template T Expected return value type from the renderer function.
     * @param options Call parameters (`catalogId`, `name`, `args`, `surfaceId`, `timeoutMs`, `functionCallId`).
     * @returns A {@link PendingRendererCall} containing `[message, result]`.
     * The checks run in this order, each before anything is built, registered
     * or timed: the timeout; disposal (`DISPOSED`); an empty given
     * `functionCallId`; a pending id (`DUPLICATE`); `maxPending`
     * (`TOO_MANY_PENDING`); an empty `name`, then an empty `catalogId`; a `name`
     * that isn't a UAX #31 identifier or starts with `@`; the `args`; and, with
     * `catalogs`, the target (`UNKNOWN_FUNCTION` or `INVALID_FUNCTION_CALL`). An
     * empty `surfaceId` counts as omitted.
     *
     * @throws {RangeError} If `options.timeoutMs` isn't a finite number greater than 0.
     * @throws {A2uiRpcError} With `DISPOSED`, `DUPLICATE`, `TOO_MANY_PENDING`,
     *   `UNKNOWN_FUNCTION` or `INVALID_FUNCTION_CALL`.
     */
    call<T = unknown>(options: CallRendererFunctionOptions): PendingRendererCall<T>;
    /**
     * Settles the pending call matching `message.rendererFunctionResponse.functionCallId`.
     *
     * Responses with an unknown `functionCallId`, duplicate responses, and late
     * responses arriving after a timeout or cancellation are ignored without
     * throwing. A malformed response that carries the `functionCallId` of a
     * pending call fails that call right away with `UNKNOWN_ERROR`, rather than
     * leaving it to time out; any other malformed response is ignored.
     *
     * Used as `onRendererFunctionResponse`, it therefore declines the responses
     * it doesn't own, such as those to calls the model wrote, so they reach the
     * model.
     *
     * @param message Inbound `rendererFunctionResponse` message.
     * @returns `true` if the response settled or failed a pending call, `false`
     *   if its `functionCallId` isn't pending (unknown, late or a duplicate).
     */
    resolve(message: RendererFunctionResponseMessage | Record<string, unknown>): boolean;
    /**
     * Throws if the catalogs don't let the agent call `name` in `catalogId`.
     */
    private _checkTarget;
    /** Removes a pending call and clears its timer. */
    private _settle;
    /**
     * Fails all currently pending calls with {@link A2uiRpcError}
     * (`code: RpcErrorCode.CANCELLED`) and rejects future calls with
     * `code: RpcErrorCode.DISPOSED`.
     *
     * Idempotent: calling `dispose()` on an already-disposed tracker is a no-op.
     *
     * @param reason Human-readable disposal reason included in the `CANCELLED` error message.
     */
    dispose(reason?: string): void;
}
//# sourceMappingURL=renderer-function-calls.d.ts.map