import { CatalogApi } from '../internal/web-core.js';
/**
 * Checks that catalogs target the same release line and returns it.
 *
 * @throws {A2uiCatalogError} If no catalogs are provided or they target different protocol versions.
 */
export declare function checkParserCatalogs(catalogs: CatalogApi[]): string;
//# sourceMappingURL=catalog-checks.d.ts.map