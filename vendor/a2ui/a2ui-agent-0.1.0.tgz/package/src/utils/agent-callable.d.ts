import { CatalogApi } from '../internal/web-core.js';
/**
 * Returns the names of functions the agent may call directly via `callRendererFunction`.
 *
 * Iterates catalogs in order and their functions in declaration order,
 * returning each unique function name on v1.0+ catalogs whose
 * `requiresUserActivation` is falsy and whose `allowedCallers` is
 * `'agentOnly'` or `'rendererOrAgent'`.
 *
 * @param catalogs Active catalogs in priority order.
 * @returns Function names eligible for standalone agent calls.
 */
export declare function agentCallableFunctions(catalogs: readonly CatalogApi[]): string[];
//# sourceMappingURL=agent-callable.d.ts.map