/**
 * Returns the agent-to-renderer (server-to-client) JSON schema for a protocol version.
 */
export declare function loadAgentToRendererSchema(protocolVersion: string): Record<string, unknown>;
/**
 * Returns the common types JSON schema for a protocol version, or an empty object for v0.8.
 */
export declare function loadCommonTypesSchema(protocolVersion: string): Record<string, unknown>;
/**
 * Returns a copy of an agent-to-renderer schema that admits only the allowed messages.
 */
export declare function pruneMessagesSchema(a2rSchema: Record<string, unknown>, protocolVersion: string, allowedMessages: readonly string[]): Record<string, unknown>;
/**
 * Returns a copy of the common types schema with only the definitions referenced by
 * `referencingSchemas` (directly or transitively).
 */
export declare function pruneCommonTypesSchema(commonTypesSchema: Record<string, unknown>, ...referencingSchemas: Record<string, unknown>[]): Record<string, unknown>;
//# sourceMappingURL=message-schemas.d.ts.map