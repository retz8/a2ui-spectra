/**
 * The agent's mirror of the surfaces that a renderer holds.
 */
import { CatalogApi, ComponentApi, MessageProcessor, SurfaceModel } from '../internal/web-core.js';
/**
 * The agent's mirror of the surfaces a renderer holds.
 *
 * The state wraps one web_core `MessageProcessor` and runs the agent's outbound messages
 * through it, so a message is checked against everything the renderer has already
 * received: a reference resolves against the components earlier messages added, and a
 * cycle is found across the whole surface.
 *
 * How long a state lives is the one difference between the two ways an agent shows UI:
 *
 * - In a chat, each turn shows new UI, so each turn uses a new state. A parser makes one
 *   when it is given none.
 * - In a canvas, turns update the same surfaces, so one state lives for the whole
 *   conversation and every turn is parsed against it.
 *
 * A message is applied when it is sent. `apply` is atomic: if a message is rejected, the
 * state is left as it was before the call. `transaction` extends that to several calls,
 * which is how a response parsed whole is applied all or nothing. A streamed response
 * cannot be rolled back, since the renderer has already received what was emitted.
 *
 * Being atomic costs what the messages change, not the size of the surfaces they touch.
 * While an `apply` or a transaction is open, the state keeps an undo log: each message
 * records what it replaced, and a failure reverts those records, latest first. A deleted
 * surface is the one change recorded whole, and it is restored straight into the model. No
 * surface is copied when a message is applied or a transaction opens. A rollback leaves the
 * state as it was, down to the order of each surface's components and of each data model
 * object's keys.
 *
 * The state holds the surfaces as they now stand, not the messages that built them.
 *
 * An update to a surface the state never saw created is rejected, as the renderer would
 * reject it.
 *
 * The state is authoritative for surfaces and their components. The data model values it
 * holds can drift from the renderer's, since the user edits bound inputs there, but no
 * check depends on them.
 *
 * An app that is both the agent and the renderer makes the state with `RendererState.of`,
 * on the processor it renders from, so each message is checked and applied once.
 *
 * A v1.0 `callRendererFunction` is checked against the catalogs, the way the renderer would
 * check it, and never run by a state of its own: running it would run the renderer's
 * function on the agent. A state made by `RendererState.of` hands the call to the
 * renderer's processor once it is accepted.
 */
export declare class RendererState {
    private readonly _catalogs;
    private readonly releaseLine;
    private readonly processor;
    private readonly assumed;
    /** The components each surface added or replaced since its tree was last checked. */
    private readonly changed;
    /**
     * The pre-turn state of each component touched since its surface's tree was last checked
     * (`null` when the component did not exist before the turn).
     */
    private readonly baseline;
    /** How to undo each change made since the outermost open `apply` or transaction began. */
    private readonly log;
    /** How many `apply` calls and transactions are open. */
    private open;
    /** How many promises that transaction functions returned are still running. */
    private runaway;
    /** The function calls applied since the outermost open `apply` or transaction began. */
    private readonly calls;
    /**
     * Whether the state hands the function calls it accepts to its processor. Only a state
     * made by `RendererState.of` does, since its processor is the renderer's own.
     */
    private readonly runsCalls;
    /**
     * Creates the empty state of a renderer that holds the catalogs.
     *
     * @param catalogs The active catalogs, which must target compatible protocol versions.
     *     Each surface is checked against the catalog its `catalogId` names.
     * @throws {A2uiCatalogError} If no catalogs are given, if two share an id, if their
     *     messages state different versions, for example v0.9 and v1.0 catalogs, or if they
     *     target a protocol version the state does not support, such as v0.8.
     */
    constructor(catalogs: CatalogApi[]);
    /**
     * Creates the state of a renderer that renders from `processor`.
     *
     * The state applies each message it accepts to `processor` itself, so the renderer shows a
     * message as soon as the state applies it, and a rollback takes the message back out of the
     * renderer's model. A function call reaches the processor only once it passes the checks
     * `apply` makes and the outermost `apply` or transaction it was applied in succeeds, since
     * a function that ran cannot be rolled back.
     *
     * The state checks messages against the surfaces the processor holds, including those it
     * held before, under its own rules whatever rules the processor was created with. The
     * processor must take its messages from the state only: one applied around the state is
     * checked by nothing, and a transaction that fails after it cannot undo it.
     *
     * @param processor The renderer's processor. Its catalogs are the state's catalogs.
     * @throws {A2uiCatalogError} If the processor's catalogs could not make a state, as for the
     *     constructor.
     */
    static of<T extends ComponentApi>(processor: MessageProcessor<T>): RendererState;
    /** The active catalogs in priority order. */
    get catalogs(): CatalogApi[];
    /** The ids of the surfaces the renderer holds, in no particular order. */
    get surfaceIds(): string[];
    /** Returns the surface with the id, if the renderer holds it. Callers must not modify it. */
    getSurface(surfaceId: string): SurfaceModel | undefined;
    /**
     * Removes or restores a provisional component on `surfaceId` when a later statement in the
     * same scope supersedes its wire ID.
     */
    dropProvisionalComponent(surfaceId: string, componentId: string): void;
    /**
     * Whether an update to a surface the state never saw created makes an empty placeholder
     * for it instead of being rejected. Only a state that checks one payload on its own, with
     * no record of earlier ones, says yes.
     */
    protected get assumesUnknownSurfaces(): boolean;
    /**
     * Checks the messages against the state and applies them.
     *
     * Each message must match the protocol's message schema and state a `version` that the
     * catalogs' protocol version accepts: `v0.9` or `v0.9.1` for v0.9 and v0.9.1, and `v1.0`
     * for v1.0. Each component and function call is checked against the catalog it resolves
     * to, and component ids and cycles against the surface's components. References, the root
     * and reachability are left to `checkTopology`, since a component may name a child that a
     * later message adds.
     *
     * A v1.0 `callRendererFunction` is checked, never run: the surface it names must exist,
     * its catalog must be active and declare the function, the agent must be allowed to call
     * the function, which must not require a user activation, its arguments must match the
     * function's schema as written, and the calls nested in them must be calls the renderer
     * can make. The arguments are resolved outside any list template, so they may not call
     * `@index`, and each data binding in them must hold a string `@path` and nothing else.
     *
     * The call is atomic: if a message is rejected, none of them is applied. Being atomic
     * costs what the messages change, not the size of the surfaces they touch.
     *
     * @param payload One message or an iterable of messages, as parsed JSON objects.
     * @returns The ids of the surfaces the messages create, update or delete, in the order the
     *     messages first name them.
     * @throws {A2uiValidationError} If a renderer in this state would reject a message. The
     *     error, or a subclass such as `A2uiIntegrityError`, describes the first problem found.
     */
    apply(payload: unknown): string[];
    /**
     * Checks the whole tree of each surface.
     *
     * The surface must have its root, and every reference must resolve. Every component added
     * or replaced since the surface's tree was last checked must be reachable from the root,
     * within the depth limit. A component that an update left unreachable, by rewriting its
     * parent's children, is accepted: the protocol has no message that removes one component,
     * so replacing part of a canvas always leaves such components behind. A surface with no
     * components yet passes, since its components may arrive later. Surfaces that are deleted
     * or assumed are skipped.
     *
     * @throws {A2uiValidationError} If a surface's tree is incomplete or invalid.
     */
    checkTopology(surfaceIds: Iterable<string>): void;
    /**
     * Stops holding the components each surface changed against later checks.
     *
     * `checkTopology` calls this for the surfaces it checks. A caller calls it for the surfaces
     * of messages the renderer received that failed a check, such as a stream that failed after
     * it emitted them: no message removes a component, so a component the renderer already
     * holds can't be made reachable later, and the later turns are not held to it. Dangling
     * references and a missing root are still reported, since `checkTopology` checks those on
     * the whole surface. Like any other change, it is undone when the transaction it was made
     * in fails.
     */
    markChecked(surfaceIds: Iterable<string>): void;
    /**
     * Runs `fn` and applies everything it applies atomically.
     *
     * If `fn` throws, the state is restored to what it was when the call started, and the
     * error propagates. Opening a transaction copies nothing, and undoing one costs what was
     * applied inside it. Transactions nest: an inner transaction that fails restores the state
     * to where the inner one started, and the outer one goes on. `fn` must be synchronous: a
     * transaction cannot span an `await`.
     *
     * A JavaScript caller can still pass a function that returns a promise. The transaction
     * then restores the state and throws, but the promise keeps running, and nothing it does
     * after its first `await` could be rolled back. So until it settles, `apply`,
     * `transaction`, `checkTopology` and `markChecked` throw `TypeError`, whoever calls them, and a rejection
     * of the promise is handled, since the caller never got the promise to handle it.
     *
     * @returns What `fn` returns.
     * @throws {TypeError} If `fn` returns a promise, which the type of `fn` rejects at compile
     *   time. The state is restored first. Also thrown while such a promise is running.
     */
    transaction<T>(fn: (state: this) => T extends PromiseLike<unknown> ? never : T): T;
    /** Throws while a promise that a transaction function returned is still running. */
    private checkNoRunaway;
    /**
     * Runs `fn` and undoes what it changed if it throws.
     *
     * The frame is a position in the undo log. A failure reverts the log to it, so a failed
     * inner frame undoes only what was changed inside it. Once the outermost frame ends,
     * nothing can be undone any more, and the log is cleared. The error `fn` threw propagates,
     * even if an undo fails too.
     */
    private frame;
    /** Hands the function calls held back to the processor, in the order they were applied. */
    private runCalls;
    /**
     * Undoes the changes logged after a position, latest first.
     *
     * Every record is undone even if one throws, so that one failure doesn't leave the
     * changes logged before it in place. A record that throws is dropped.
     */
    private revert;
    /** Logs how to undo a change, if an `apply` or transaction is open. */
    private record;
    private setAssumed;
    /** Snapshots components on `surfaceId` before their first change since last check. */
    private noteBaseline;
    /** Records components a surface added or replaced since its tree was last checked. */
    private noteChanged;
    /**
     * Holds a function call back until the outermost `apply` or transaction succeeds. The
     * processor reads nothing of it but its envelope, which `checkMessage` has checked.
     */
    private holdCall;
    /** Stops holding what a surface changed against its next tree check. */
    private forgetChanged;
    /**
     * Runs one message through the processor, logging what it replaces.
     *
     * The processor checks a message whole before it changes a surface, so a rejected message
     * changes nothing. Should one fail part way all the same, what it changed is undone
     * before the error propagates.
     */
    private process;
    /** Runs messages through the processor, logging nothing. */
    private processUnlogged;
    /** Returns how to undo a message, read before it is applied, or nothing to undo. */
    private undoFor;
    /**
     * Records the components an `updateComponents` adds or replaces.
     *
     * The core updates a component in place when the update keeps its type and catalog, so
     * the record holds a copy of the component's previous properties, not the object the
     * update replaces them with.
     *
     * When an update changes a component's type or catalog, the core replaces the component
     * with a new one, which goes last in the surface's order. The order is visible: the tree
     * check reports the first problem it meets in it. So for such a component the record also
     * holds its position, and the undo puts the old component back there. Finding a position
     * costs one pass over the surface's components, made only for a message that changes a
     * type or catalog.
     */
    private componentsRestorer;
    /**
     * Whether an update to a component makes the core replace it with a new one, as it does
     * when the update changes the component's type or catalog. Mirrors how the core resolves
     * the catalog of a component update.
     */
    private replaces;
    /**
     * Records the data model value an `updateDataModel` replaces.
     *
     * Setting a path creates the containers above it that are missing, and pads a list up to
     * the index it sets, so the record is taken at the first segment of the path that does not
     * hold a container yet. The value there is replaced, not changed in place, and every later
     * change to it has a record of its own, so the record holds the value itself.
     *
     * The undo leaves the data as it was, as `JSON.stringify` shows it: a hole in a list stays
     * a hole, and a key the message deleted goes back to its place among its object's keys.
     * Finding that place costs one pass over the object's keys, made only for a message that
     * deletes a key.
     */
    private dataModelRestorer;
    /**
     * Records a surface that a message deletes, whole.
     *
     * It is restored straight into the model, not replayed through the processor: the
     * processor accepted the surface one message at a time, and replayed as one message it
     * could reject what it accepted, such as a data model deeper than one message may be. Each
     * component keeps its catalog, its place in the surface's order, its properties and its
     * metadata, and the data model its root, whatever JSON value that is. The properties and
     * the data model are copied, since the surface is disposed of once deleted.
     */
    private surfaceRestorer;
    /** Applies the message at `index` and returns the surface it targets, if any. */
    private applyMessage;
    /**
     * Checks a `callRendererFunction` the way the renderer would.
     *
     * The call is checked, never run: running it would run the renderer's function on the
     * agent, and the state has no renderer to answer. A renderer refuses a call with
     * `INVALID_FUNCTION_CALL` when the surface it names doesn't exist, its catalog isn't
     * registered, the catalog doesn't declare the function, the agent may not call the
     * function, or its arguments don't match the function's schema, so each of these is
     * rejected; see `checkFunctionCall`.
     *
     * A payload state assumes a surface the payload never named before, as it does for an
     * update, since an earlier payload may have created it.
     *
     * A call nested in the arguments that names no catalog runs in the default catalog of the
     * surface the call names, or in the catalog of the call when it names no surface; see
     * `NestedHome`.
     *
     * Everything the processor would check is checked here, so that `RendererState.of` never
     * holds back a call that the processor then rejects after the state's changes are final.
     *
     * @throws {A2uiValidationError} If the renderer would refuse the call.
     */
    private checkRendererFunctionCall;
    /**
     * Whether an update to a surface the state lacks assumes the surface.
     *
     * A payload state assumes a surface the payload never named before, but not one that an
     * earlier message of the payload deleted, nor one that a later message creates before any
     * message deletes it: a renderer rejects updates to either, since the surface does not
     * exist yet when they arrive.
     */
    private assumes;
    /**
     * Creates a placeholder for an unknown surface and applies the update.
     *
     * The updates to the surface are the message at `index` and the messages after it that
     * update the surface, up to one that creates or deletes it. The surface is created on each
     * catalog that defines every component those updates add, until one accepts all of them,
     * so a later update can rule out a catalog that the first one fits. If none does, the error
     * from the first is thrown. Only the first update is applied here; the others are applied
     * in turn.
     */
    private assumeSurface;
    /**
     * Throws if a message states the wrong version or doesn't match its schema.
     *
     * The version is checked first, since the envelope schemas require their own version and
     * would report a wrong one less clearly.
     */
    private checkMessage;
}
//# sourceMappingURL=renderer-state.d.ts.map