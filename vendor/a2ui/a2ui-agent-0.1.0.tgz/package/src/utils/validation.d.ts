/**
 * Stateless validation of the payloads that an agent sends.
 */
import { CatalogApi } from '../internal/web-core.js';
/**
 * Checks a payload the way a renderer holding the catalogs would.
 *
 * The check is stateless: it sees one payload, with no record of what earlier payloads
 * sent. A surface that the payload creates with `createSurface` is checked in full, so its
 * components must be valid and reachable from the root, and their references must resolve
 * once every message in the payload is applied: a component may name a child that a later
 * message adds. A surface that the payload only updates may already hold components, so
 * references to components outside the payload and a missing root are accepted there. Each
 * of its components is still checked against a catalog that defines all of them, and the
 * surface passes if one such catalog accepts it.
 *
 * A v1.0 `callRendererFunction` is checked against the catalogs, never run: its catalog must
 * be active and declare the function, the agent must be allowed to call the function, which
 * must not require a user activation, its arguments must match the function's schema, and
 * the calls nested in them must be calls the renderer can make. The arguments are resolved
 * outside any list template, so they may not call `@index`, and each data binding in them
 * must hold a string `@path` and nothing else. A surface it names must exist when it
 * arrives, or be one the payload never named before, which an earlier payload may have
 * created.
 *
 * To check a payload against what earlier payloads sent, keep a `RendererState` and call
 * its `apply` and `checkTopology` inside `state.transaction(...)`, so that a rejected
 * response is rolled back whole.
 *
 * Each message must match the protocol's message schema and state a `version` that the
 * catalogs' protocol version accepts, spelled as the specification spells it: `v0.9` or
 * `v0.9.1` for v0.9 and v0.9.1, and `v1.0` for v1.0.
 *
 * @param catalogs The active catalogs, which must target compatible protocol versions. Each
 *     surface is checked against the catalog its `catalogId` names.
 * @param payload One message, or an iterable of messages, as parsed JSON objects.
 * @throws {A2uiValidationError} If a renderer holding the catalogs would reject the payload.
 *     The error, or a subclass such as `A2uiIntegrityError`, describes the first problem
 *     found.
 * @throws {A2uiCatalogError} If no catalogs are given, or if their messages state different
 *     versions, for example v0.9 and v1.0 catalogs.
 */
export declare function validatePayload(catalogs: CatalogApi[], payload: unknown): void;
//# sourceMappingURL=validation.d.ts.map