import { CatalogApi, RendererCapabilities } from '../internal/web-core.js';
import { CatalogConfig } from '../processor/catalog-config.js';
/**
 * Matches renderer capabilities against registered catalogs and returns the active,
 * transformed set for this session.
 *
 * Every registered catalog the renderer names becomes active, in the renderer's preference
 * order, so its first choice is the first catalog the model reads about. An id the agent
 * does not hold is ignored. Each inline catalog the renderer declares becomes an active
 * catalog of its own when the agent accepts inline catalogs, and is dropped otherwise.
 * Inline catalogs are not transformed, since transformers belong to a registration.
 * Every inline catalog is built, so a malformed one is an error even when the agent does
 * not accept inline catalogs.
 *
 * @param catalogs Registered catalog configurations supported by the agent.
 * @param rendererCapabilities Capabilities sent by the client renderer (either keyed by
 *     protocol version, such as `{"v1.0": {"supportedCatalogIds": [...]}}`, or a single
 *     capabilities entry), or `undefined` when the request carried none. With no
 *     capabilities the renderer stated no preference, so every registered catalog is
 *     active, which is none when nothing is registered.
 * @param acceptsInlineCatalogs Whether the agent accepts inline catalogs from the client.
 * @returns Array of active CatalogApi instances.
 * @throws {A2uiCatalogError} If capabilities are given and the agent has no catalogs, if
 *     registered catalogs read different capabilities keys, if `inlineCatalogs` is not an
 *     array of valid catalogs, or if negotiation leaves no active catalog.
 * @throws {A2uiValidationError} If the capabilities have no valid entry for the protocol
 *     version of the registered catalogs.
 */
export declare function resolveCatalogs(catalogs: CatalogConfig[], rendererCapabilities: Record<string, RendererCapabilities> | RendererCapabilities | undefined, acceptsInlineCatalogs?: boolean): CatalogApi[];
//# sourceMappingURL=catalog-resolver.d.ts.map