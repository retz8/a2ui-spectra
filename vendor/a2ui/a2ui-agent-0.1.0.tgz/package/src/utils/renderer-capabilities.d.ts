import { RendererCapabilities } from '../internal/web-core.js';
import { ProtocolVersion } from '../types.js';
/** Transport metadata key for v0.9 and v0.9.1 client capabilities. */
export declare const A2UI_CLIENT_CAPABILITIES_KEY = "a2uiClientCapabilities";
/** Transport metadata key for v1.0 and later renderer capabilities. */
export declare const A2UI_RENDERER_CAPABILITIES_KEY = "a2uiRendererCapabilities";
/**
 * Reads and validates renderer capabilities for `version` from transport `metadata`.
 *
 * Looks up `a2uiRendererCapabilities` for v1.0 and `a2uiClientCapabilities` for
 * v0.9 and v0.9.1. Returns `undefined` when `metadata` is `null`/`undefined` or
 * the version's capabilities entry is absent, and throws `A2uiCatalogError` when
 * `version` is unsupported or the metadata key or version entry is malformed.
 *
 * @param metadata The transport message metadata object, or `null`/`undefined`.
 * @param version The A2UI protocol version to read capabilities for.
 * @returns A version-keyed capabilities object accepted unchanged by `resolveCatalogs`,
 *     or `undefined` when absent.
 */
export declare function readRendererCapabilities(metadata: unknown, version?: ProtocolVersion | string): Record<string, RendererCapabilities> | undefined;
//# sourceMappingURL=renderer-capabilities.d.ts.map