import { ProtocolVersion } from '../internal/web-core.js';
/**
 * Converts a catalog's declared protocol version into the form that goes on the wire.
 *
 * Pre-1.0 protocol messages carry the `v`-prefixed dotted form (`v0.9`, `v0.9.1`), whereas
 * 1.0+ protocol messages, capability objects, and catalogs all use bare semantic version
 * strings (`1.0`).
 *
 * There is deliberately no default. A version has to be stated by whoever supplies the
 * catalog, so a new protocol release never needs a hardcoded default bumped.
 *
 * @throws {A2uiCatalogError} If `raw` is empty or missing.
 */
export declare function toWireProtocolVersion(raw: string | undefined | null): ProtocolVersion;
/**
 * Converts a catalog's declared protocol version into the release line it belongs to.
 *
 * v0.9 and v0.9.1 catalogs are interchangeable, as in the core's catalog compatibility, so
 * both belong to `v0.9`. Every other version is its own release line, in wire form.
 *
 * @throws {A2uiCatalogError} If `raw` is empty or missing.
 */
export declare function toReleaseLine(raw: string | undefined | null): ProtocolVersion;
//# sourceMappingURL=protocol-version.d.ts.map