import { z } from 'zod';
/**
 * Returns the agent-to-renderer message schemas of a protocol version, keyed by the
 * envelope name each message carries (`createSurface`, `updateComponents`, and so on).
 *
 * The schemas are web_core's generated Zod models, so they always match the protocol
 * the renderer validates against.
 *
 * @param protocolVersion Protocol version in any spelling a catalog uses.
 * @throws {A2uiCatalogError} If the SDK has no message schemas for the version.
 */
export declare function envelopeSchemasFor(protocolVersion: string): Record<string, z.ZodTypeAny>;
/**
 * Validates an inbound server-to-client message envelope against the protocol schema.
 *
 * @param obj The parsed JSON object representing the message.
 * @param protocolVersion Wire protocol version string (e.g. 'v0.9', 'v1.0').
 * @throws {A2uiValidationError} If validation fails or if the envelope key is unknown.
 */
export declare function validateEnvelope(obj: Record<string, unknown>, protocolVersion: string): void;
//# sourceMappingURL=envelope-validation.d.ts.map