import { A2uiError } from './internal/web-core.js';
import type { ResponsePart } from './parser/response-part.js';
export { A2uiCatalogError, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiIntegrityError, A2uiRecursionError, A2uiRpcError, RpcErrorCode, } from './internal/web-core.js';
/**
 * Error raised on malformed model output during parsing.
 */
export declare class ParseError extends A2uiError {
    /**
     * Initializes a new `ParseError` instance.
     *
     * @param message Human-readable error description.
     */
    constructor(message: string);
}
/**
 * Exception raised when compiling/parsing an A2UI format block fails.
 */
export declare class A2uiCompilationError extends A2uiError {
    readonly detail: string;
    readonly rawContent: string;
    readonly line?: number;
    readonly column?: number;
    readonly helpMessage?: string;
    partialResults: ResponsePart[];
    constructor(message: string, options: {
        rawContent: string;
        line?: number;
        column?: number;
        helpMessage?: string;
        partialResults?: ResponsePart[];
    });
}
/**
 * Raised when a format block cannot be read at all.
 *
 * The block is malformed on its own terms: the notation's grammar rejects it,
 * or it is missing a part the notation requires before it names anything for
 * the catalog to check.
 *
 * Note: TypeScript has single inheritance, so this class cannot also extend ParseError.
 */
export declare class A2uiCompilationParseError extends A2uiCompilationError {
    constructor(message: string, options: {
        rawContent: string;
        line?: number;
        column?: number;
        helpMessage?: string;
        partialResults?: ResponsePart[];
    });
}
/**
 * Raised when a readable format block says something the catalog refuses.
 *
 * The block parses, so the failure is about what it names rather than how it
 * is written: a property the component does not declare, a value outside a
 * property's enum, a binding on a property that takes only a literal.
 *
 * Note: TypeScript has single inheritance, so this class cannot also extend A2uiValidationError.
 */
export declare class A2uiCompilationValidationError extends A2uiCompilationError {
    constructor(message: string, options: {
        rawContent: string;
        line?: number;
        column?: number;
        helpMessage?: string;
        partialResults?: ResponsePart[];
    });
}
/** Attaches the parts read before an `A2uiError` to it, and returns the error. */
export declare function withPartialResults(e: unknown, parts: ResponsePart[]): unknown;
//# sourceMappingURL=errors.d.ts.map