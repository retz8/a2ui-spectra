/**
 * Single dependency seam for @a2ui/web_core.
 *
 * Every @a2ui/web_core import in the SDK must funnel through this module.
 * This ensures that when the framework-agnostic pieces of web_core are moved to a
 * separate package (e.g., @a2ui/a2ui_core), the migration requires touching only this file.
 */
export { AgentFunction, Catalog, isAgentFunction } from '@a2ui/web_core/catalog';
export type { AgentFunctionContext, AgentFunctionHandler, AgentFunctionInit, CatalogApi, CatalogInterface, ComponentApi, CopyWithCatalogOptions, FunctionApi, FunctionImplementation, } from '@a2ui/web_core/catalog';
export { Schemas as V08Schemas } from '@a2ui/web_core/v0_8';
export { CreateSurfaceMessageSchema as V09CreateSurfaceMessageSchema, UpdateComponentsMessageSchema as V09UpdateComponentsMessageSchema, UpdateDataModelMessageSchema as V09UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema as V09DeleteSurfaceMessageSchema, Schemas as V09Schemas, V09_STANDARD_DEFS, } from '@a2ui/web_core/v0_9';
export { CreateSurfaceMessageSchema as V10CreateSurfaceMessageSchema, UpdateComponentsMessageSchema as V10UpdateComponentsMessageSchema, UpdateDataModelMessageSchema as V10UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema as V10DeleteSurfaceMessageSchema, CallRendererFunctionMessageSchema as V10CallRendererFunctionMessageSchema, AgentFunctionResponseMessageSchema as V10AgentFunctionResponseMessageSchema, RendererFunctionResponseMessageSchema as V10RendererFunctionResponseMessageSchema, ActionMessageSchema as V10ActionMessageSchema, ErrorMessageSchema as V10ErrorMessageSchema, AgentToRendererMessageSchema, RendererToAgentMessageSchema, Schemas as V10Schemas, V10RendererCapabilitiesSchema, V10_STANDARD_DEFS, } from '@a2ui/web_core/v1_0';
import type { ActionMessage, AgentFunctionResponseMessage, AgentToRendererMessage, CallAgentFunctionMessage, CallRendererFunctionMessage, ErrorMessage, RendererFunctionResponseMessage, RendererToAgentMessage, V10RendererCapabilities } from '@a2ui/web_core/v1_0';
export type { ActionMessage, AgentFunctionResponseMessage, AgentToRendererMessage, CallAgentFunctionMessage, CallRendererFunctionMessage, ErrorMessage, RendererFunctionResponseMessage, RendererToAgentMessage, V10RendererCapabilities, };
/**
 * Version-neutral alias for renderer capabilities across protocol versions.
 */
export type RendererCapabilities = V10RendererCapabilities;
export { validateRecursionAndPaths, STRICT_VALIDATION, getComponentReferences, buildComponentRefMap, isValidUax31Identifier, V10_CHILD_REF_OPTIONS, } from '@a2ui/web_core/validating';
export type { ValidationConfig } from '@a2ui/web_core/validating';
export type { ComponentRefMap } from '@a2ui/web_core/validating';
export { validateReservedDirectives } from '@a2ui/web_core/resolution';
export { ComponentModel, DataModel, SurfaceModel } from '@a2ui/web_core/state';
export { MessageProcessor } from '@a2ui/web_core/processing';
export type { MessageProcessorOptions } from '@a2ui/web_core/processing';
export { PayloadValidator } from '@a2ui/web_core/validation';
export { A2uiCatalogError, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiIntegrityError, A2uiRecursionError, A2uiRpcError, RpcErrorCode, } from '@a2ui/web_core/errors';
export type { ProtocolVersion } from '@a2ui/web_core/adapters';
export { compareSemVer, isAtLeastVersion, normalizeVersionString, toCanonicalVersion, } from '@a2ui/web_core/semver';
//# sourceMappingURL=web-core.d.ts.map