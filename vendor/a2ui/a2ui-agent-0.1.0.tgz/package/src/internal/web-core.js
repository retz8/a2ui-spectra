/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Single dependency seam for @a2ui/web_core.
 *
 * Every @a2ui/web_core import in the SDK must funnel through this module.
 * This ensures that when the framework-agnostic pieces of web_core are moved to a
 * separate package (e.g., @a2ui/a2ui_core), the migration requires touching only this file.
 */
// ./catalog
export { AgentFunction, Catalog, isAgentFunction } from '@a2ui/web_core/catalog';
// ./v0_8
export { Schemas as V08Schemas } from '@a2ui/web_core/v0_8';
// ./v0_9
export { CreateSurfaceMessageSchema as V09CreateSurfaceMessageSchema, UpdateComponentsMessageSchema as V09UpdateComponentsMessageSchema, UpdateDataModelMessageSchema as V09UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema as V09DeleteSurfaceMessageSchema, Schemas as V09Schemas, V09_STANDARD_DEFS, } from '@a2ui/web_core/v0_9';
// ./v1_0
export { CreateSurfaceMessageSchema as V10CreateSurfaceMessageSchema, UpdateComponentsMessageSchema as V10UpdateComponentsMessageSchema, UpdateDataModelMessageSchema as V10UpdateDataModelMessageSchema, DeleteSurfaceMessageSchema as V10DeleteSurfaceMessageSchema, CallRendererFunctionMessageSchema as V10CallRendererFunctionMessageSchema, AgentFunctionResponseMessageSchema as V10AgentFunctionResponseMessageSchema, RendererFunctionResponseMessageSchema as V10RendererFunctionResponseMessageSchema, ActionMessageSchema as V10ActionMessageSchema, ErrorMessageSchema as V10ErrorMessageSchema, AgentToRendererMessageSchema, RendererToAgentMessageSchema, Schemas as V10Schemas, V10RendererCapabilitiesSchema, V10_STANDARD_DEFS, } from '@a2ui/web_core/v1_0';
// ./validating
export { validateRecursionAndPaths, STRICT_VALIDATION, getComponentReferences, buildComponentRefMap, isValidUax31Identifier, V10_CHILD_REF_OPTIONS, } from '@a2ui/web_core/validating';
// ./resolution
export { validateReservedDirectives } from '@a2ui/web_core/resolution';
// ./state
export { ComponentModel, DataModel, SurfaceModel } from '@a2ui/web_core/state';
// ./processing
export { MessageProcessor } from '@a2ui/web_core/processing';
// ./validation
export { PayloadValidator } from '@a2ui/web_core/validation';
// ./errors
export { A2uiCatalogError, A2uiError, A2uiValidationError, A2uiDataError, A2uiExpressionError, A2uiStateError, A2uiIntegrityError, A2uiRecursionError, A2uiRpcError, RpcErrorCode, } from '@a2ui/web_core/errors';
// ./semver
export { compareSemVer, isAtLeastVersion, normalizeVersionString, toCanonicalVersion, } from '@a2ui/web_core/semver';
//# sourceMappingURL=web-core.js.map