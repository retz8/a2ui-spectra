export type { ProtocolVersion } from './internal/web-core.js';
//# sourceMappingURL=types.d.ts.map