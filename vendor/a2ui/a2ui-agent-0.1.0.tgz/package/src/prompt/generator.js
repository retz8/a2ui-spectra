/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiCatalogError } from '../errors.js';
/** Heading that introduces the few-shot examples in a prompt snippet or skill. */
export const EXAMPLES_HEADING = '### Examples:\n\n';
/**
 * Abstract base class for format-specific prompt generation.
 *
 * A generator renders the snippet of system prompt that tells the model how to write A2UI
 * for the active catalogs: the format's rules, the catalog schemas, and any examples. The
 * rest of the system prompt, such as the agent's role and workflow, belongs to the agent
 * developer, who places the snippet wherever it fits.
 */
export class PromptGenerator {
    /**
     * Initializes a new PromptGenerator instance.
     *
     * @param catalogs Active catalogs to render instructions for.
     * @throws {A2uiCatalogError} If no catalog is given, since the model would then have
     *     nothing it could be told to write.
     */
    constructor(catalogs) {
        this.catalogs = catalogs;
        if (catalogs.length === 0) {
            throw new A2uiCatalogError('A prompt snippet needs at least one active catalog.');
        }
    }
    /**
     * Signatures for one catalog, or for all active catalogs.
     */
    generateCatalogInstructions(catalog) {
        const targets = catalog ? [catalog] : this.catalogs;
        return targets
            .map(c => this.renderCatalogInstructions(c))
            .filter(s => s.length > 0)
            .join('\n\n');
    }
    /**
     * Few-shot examples for one catalog, or for all active catalogs.
     */
    generateExamples(catalog) {
        const targets = catalog ? [catalog] : this.catalogs;
        return targets
            .map(c => this.renderExamples(c))
            .filter(s => s.length > 0)
            .join('\n\n');
    }
    /**
     * Renders the prompt snippet: base rules, catalog instructions, and examples.
     *
     * Formats override the pieces, never this method.
     */
    generate() {
        const examples = this.generateExamples();
        return [
            this.generateBaseRules(),
            this.generateCatalogInstructions(),
            examples.length > 0 ? `${EXAMPLES_HEADING}${examples}` : '',
        ]
            .filter(s => s.length > 0)
            .join('\n\n');
    }
}
//# sourceMappingURL=generator.js.map