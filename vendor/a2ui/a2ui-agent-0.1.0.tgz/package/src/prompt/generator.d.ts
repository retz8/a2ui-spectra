import { CatalogApi } from '../internal/web-core.js';
/** Heading that introduces the few-shot examples in a prompt snippet or skill. */
export declare const EXAMPLES_HEADING = "### Examples:\n\n";
/**
 * Abstract base class for format-specific prompt generation.
 *
 * A generator renders the snippet of system prompt that tells the model how to write A2UI
 * for the active catalogs: the format's rules, the catalog schemas, and any examples. The
 * rest of the system prompt, such as the agent's role and workflow, belongs to the agent
 * developer, who places the snippet wherever it fits.
 */
export declare abstract class PromptGenerator {
    readonly catalogs: CatalogApi[];
    /**
     * Initializes a new PromptGenerator instance.
     *
     * @param catalogs Active catalogs to render instructions for.
     * @throws {A2uiCatalogError} If no catalog is given, since the model would then have
     *     nothing it could be told to write.
     */
    constructor(catalogs: CatalogApi[]);
    /**
     * Catalog-agnostic syntax contracts, grammar, and sentinel tags.
     */
    abstract generateBaseRules(): string;
    /**
     * Signatures for one catalog, or for all active catalogs.
     */
    generateCatalogInstructions(catalog?: CatalogApi): string;
    /**
     * Few-shot examples for one catalog, or for all active catalogs.
     */
    generateExamples(catalog?: CatalogApi): string;
    /** Format-specific rendering for a single catalog's instructions. */
    protected abstract renderCatalogInstructions(catalog: CatalogApi): string;
    /** Format-specific rendering for a single catalog's examples. */
    protected abstract renderExamples(catalog: CatalogApi): string;
    /**
     * Renders the prompt snippet: base rules, catalog instructions, and examples.
     *
     * Formats override the pieces, never this method.
     */
    generate(): string;
}
//# sourceMappingURL=generator.d.ts.map