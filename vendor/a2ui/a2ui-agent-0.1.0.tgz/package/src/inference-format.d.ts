import { AgentToRendererMessage, CatalogApi } from './internal/web-core.js';
import { Parser } from './parser/parser.js';
import { PromptGenerator } from './prompt/generator.js';
/**
 * Encapsulates format-specific prompt generation and response parsing logic.
 */
export interface InferenceFormat {
    readonly promptGenerator: PromptGenerator;
    /**
     * Creates a parser tied to this inference format.
     */
    createParser(): Parser;
}
/**
 * Factory for creating InferenceFormat instances bound to the negotiated catalogs.
 */
export interface InferenceFormatFactory {
    /**
     * Creates a new inference format instance.
     *
     * @param catalogs The negotiated active catalogs for this session.
     * @param examples Optional few-shot examples for prompt generation.
     */
    createFormat(catalogs: CatalogApi[], examples?: Record<string, AgentToRendererMessage[] | string>): InferenceFormat;
}
//# sourceMappingURL=inference-format.d.ts.map