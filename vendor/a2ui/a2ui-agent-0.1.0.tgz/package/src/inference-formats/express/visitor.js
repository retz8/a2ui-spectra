/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Custom AST visitor and error listener for A2UI Express DSL.
 *
 * Ported from Python's visitor.py. Traverses the ANTLR parse tree to construct
 * AST nodes tagged by `kind` and collects syntax errors.
 */
import { BaseErrorListener, CharStream, CommonTokenStream, Lexer, } from 'antlr4ng';
import { ExpressParseError } from './errors.js';
import { ExpressLexer } from './generated/ExpressLexer.js';
import { ExpressParser, } from './generated/ExpressParser.js';
import { ExpressVisitor } from './generated/ExpressVisitor.js';
/**
 * Checks whether a value is an AST node of the given kind.
 */
export function isExpressNode(val, kind) {
    return (typeof val === 'object' &&
        val !== null &&
        !Array.isArray(val) &&
        val.kind === kind);
}
/**
 * Sets `key` on `target` as an own, enumerable property.
 *
 * Unlike `target[key] = value`, this stores a key such as `__proto__` as data
 * rather than changing the object's prototype, so a map literal keeps every
 * key it is written with.
 */
export function setOwnEntry(target, key, value) {
    Object.defineProperty(target, key, { value, enumerable: true, writable: true, configurable: true });
}
function isArgKeyword(val) {
    return (typeof val === 'object' &&
        val !== null &&
        val.type === 'kw' &&
        typeof val.key === 'string');
}
function isArgPositional(val) {
    return typeof val === 'object' && val !== null && val.type === 'pos';
}
/**
 * Reads the text of a `NUMBER` token as a number.
 *
 * The token grammar is a JSON number with an optional leading `+` (`42`, `-1`,
 * `.5`, `1.`, `2.5E+3`), which `Number()` reads as is. Integers beyond
 * ±(2^53 − 1) lose precision, as they do in JSON.
 *
 * @param text The matched token text.
 * @returns The value of the literal.
 * @throws {ExpressParseError} When the value is outside the double range (such
 *   as `1e999`), so that every SDK rejects the same literals.
 */
export function parseNumberLiteral(text) {
    const value = Number(text);
    if (!Number.isFinite(value)) {
        throw new ExpressParseError(`Number literal ${text} is out of range.`);
    }
    return value;
}
/**
 * Resolves only standard escape sequences: \n, \r, \t, \\, and \".
 * Any other escape sequences are treated as literal characters.
 * Uses unicode flag (/u) to ensure surrogate pairs are not split.
 */
export function unescapeString(val) {
    return val.replace(/\\([\s\S])/gu, (match, char) => {
        switch (char) {
            case 'n':
                return '\n';
            case 'r':
                return '\r';
            case 't':
                return '\t';
            case '\\':
                return '\\';
            case '"':
                return '"';
            default:
                return match;
        }
    });
}
/**
 * Custom ANTLR error listener that collects syntax errors as 4-tuples:
 * `[line, column, message, isLexer]`.
 */
export class ExpressErrorListener extends BaseErrorListener {
    constructor() {
        super(...arguments);
        this.errors = [];
    }
    syntaxError(recognizer, _offendingSymbol, line, column, msg, _e) {
        const isLexer = recognizer instanceof Lexer;
        this.errors.push([line, column, msg, isLexer]);
    }
}
/**
 * Traverses the ANTLR parse tree to construct the expected AST nodes.
 */
export class ExpressAstVisitor extends ExpressVisitor {
    constructor(firstErrorLine) {
        super();
        this.visitProgram = (ctx) => {
            // program : statement* EOF ;
            const statements = [];
            for (const stmtCtx of ctx.statement()) {
                if (this.firstErrorLine !== undefined &&
                    stmtCtx.start !== null &&
                    stmtCtx.start.line >= this.firstErrorLine) {
                    break;
                }
                try {
                    const stmt = this.visit(stmtCtx);
                    if (stmt !== null && stmt !== undefined) {
                        statements.push(stmt);
                    }
                }
                catch {
                    // Python visitor.py:69-70 silently drops individual statements that fail to compile.
                    // This is the error-isolation step of the error-recovery workflow.
                }
            }
            return statements;
        };
        this.visitStatement = (ctx) => {
            // statement : assignment | expression ;
            if (ctx.assignment()) {
                return this.visit(ctx.assignment());
            }
            if (ctx.expression()) {
                return ['EXPR', this.visit(ctx.expression())];
            }
            return null;
        };
        this.visitAssignment = (ctx) => {
            // assignment : (identifier | path) '=' expression ;
            let target;
            if (ctx.identifier()) {
                target = ctx.identifier().getText();
            }
            else {
                target = ctx.path().getText();
            }
            const value = this.visit(ctx.expression());
            return ['ASSIGN', target, value];
        };
        this.visitExpression = (ctx) => {
            // expression has exactly one child rule
            const child = ctx.getChild(0);
            return child ? this.visit(child) : null;
        };
        this.visitArray = (ctx) => {
            // array : '[' (expression (',' expression)*)? ','? ']' ;
            return ctx.expression().map(expr => this.visit(expr));
        };
        this.visitMap = (ctx) => {
            // map : '{' (map_entry (',' map_entry)*)? ','? '}' ;
            const entries = {};
            for (const entry of ctx.map_entry()) {
                const [k, v] = this.visit(entry);
                setOwnEntry(entries, k, v);
            }
            return { kind: 'map', entries };
        };
        this.visitMap_entry = (ctx) => {
            // map_entry : (identifier | string) ':' expression ;
            let k;
            if (ctx.identifier()) {
                k = ctx.identifier().getText();
            }
            else {
                k = this.visit(ctx.string());
            }
            const v = this.visit(ctx.expression());
            return [k, v];
        };
        this.visitPath = (ctx) => {
            // path : PATH ;
            const text = ctx.PATH().getText();
            return { kind: 'path', path: text.slice(1) };
        };
        this.visitCheck = (ctx) => {
            // check : CHECK ('(' (expression (',' expression)*)? ','? ')')? ;
            const name = ctx.CHECK().getText().slice(1);
            const args = [];
            for (const expr of ctx.expression()) {
                args.push(this.visit(expr));
            }
            return { kind: 'check', name, args };
        };
        this.visitArg = (ctx) => {
            // arg : named_arg | expression ;
            if (ctx.named_arg()) {
                const [k, v] = this.visit(ctx.named_arg());
                return { type: 'kw', key: k, value: v };
            }
            return {
                type: 'pos',
                value: this.visit(ctx.expression()),
            };
        };
        this.visitNamed_arg = (ctx) => {
            // named_arg : identifier '=' expression ;
            const k = ctx.identifier().getText();
            const v = this.visit(ctx.expression());
            return [k, v];
        };
        this.visitCall = (ctx) => {
            // call : function_name '(' (arg (',' arg)*)? ','? ')' ;
            // function_name : identifier | SYSTEM_IDENTIFIER ;
            const name = ctx.function_name().getText();
            const args = [];
            const kwargs = {};
            for (const argCtx of ctx.arg()) {
                const res = this.visit(argCtx);
                if (isArgKeyword(res)) {
                    setOwnEntry(kwargs, res.key, res.value);
                }
                else if (isArgPositional(res)) {
                    args.push(res.value);
                }
                else {
                    // Python visitor.py appends any other result unconditionally.
                    args.push((res ?? null));
                }
            }
            return { kind: 'call', name, args, kwargs };
        };
        this.visitVariable = (ctx) => {
            // variable : '_' | identifier ;
            if (ctx.identifier()) {
                const name = ctx.identifier().getText();
                return { kind: 'variable', name };
            }
            return { kind: 'skipped' };
        };
        this.visitLiteral = (ctx) => {
            // literal : string | NUMBER | BOOLEAN | 'null' ;
            if (ctx.string()) {
                return this.visit(ctx.string());
            }
            if (ctx.NUMBER()) {
                return parseNumberLiteral(ctx.NUMBER().getText());
            }
            if (ctx.BOOLEAN()) {
                return ctx.BOOLEAN().getText() === 'true';
            }
            return null;
        };
        this.visitIdentifier = (ctx) => {
            // identifier : IDENTIFIER ;
            return ctx.IDENTIFIER().getText();
        };
        this.visitString = (ctx) => {
            // string : RAW_TRIPLE_STRING | TRIPLE_STRING | RAW_STRING | STANDARD_STRING ;
            if (ctx.RAW_TRIPLE_STRING()) {
                const val = ctx.RAW_TRIPLE_STRING().getText();
                return val.slice(4, -3);
            }
            if (ctx.RAW_STRING()) {
                const val = ctx.RAW_STRING().getText();
                return val.slice(2, -1);
            }
            if (ctx.TRIPLE_STRING()) {
                const val = ctx.TRIPLE_STRING().getText();
                return unescapeString(val.slice(3, -3));
            }
            if (ctx.STANDARD_STRING()) {
                const val = ctx.STANDARD_STRING().getText();
                return unescapeString(val.slice(1, -1).replace(/^[\r\n]+|[\r\n]+$/g, ''));
            }
            return ctx.getText();
        };
        this.firstErrorLine = firstErrorLine;
    }
}
const IDENT_START = 'a-zA-Z_';
const IDENT_CHARS = 'a-zA-Z0-9_';
const IDENTIFIER = `[${IDENT_START}][${IDENT_CHARS}]*`;
const SQL_COMMENT_OR_TOKEN_REGEX = /([rR]"""[\s\S]*?"""|[rR]"[^\r\n"]*"|"""(?:\\[\s\S]|[^\\])*?"""|"(?:\\[\s\S]|[^\\])*?"|(?:#|\/\/)[^\r\n]*|\/\*[\s\S]*?\*\/)|--([^\r\n]*)/g;
const DECLARED_LHS_REGEX = new RegExp(`^[ \\t]*(${IDENTIFIER})[ \\t]*=(?!=)`, 'gm');
const SPLIT_LHS_REGEX = new RegExp(`^([ \\t]*${IDENTIFIER})[ \\t]*(\\r?\\n)[ \\t]*([${IDENT_CHARS}]+)(?=[ \\t]*=(?!=))`, 'gm');
const SPLIT_DATA_PATH_REGEX = new RegExp('(\\$[' + IDENT_CHARS + '/]*/)[ \\t]*(\\r?\\n)[ \\t]*([' + IDENT_CHARS + '/]+)', 'g');
const IDENT_ONLY_REGEX = new RegExp(`^${IDENTIFIER}$`);
const ASSIGN_EQUALS_REGEX = /^[ \t]*=(?!=)/;
const SPLIT_ARG_IDENT_REGEX = new RegExp(`([([,:=][ \\t]*\\r?\\n?[ \\t]*|[([,:=][ \\t]*)(${IDENTIFIER})[ \\t]*(\\r?\\n)[ \\t]*([${IDENT_CHARS}]+)(?=[ \\t]*[,)\\]}]|\\s*\\r?\\n)`, 'g');
/**
 * Normalizes `--` comments and line-broken tokens outside strings and comments,
 * keeping line counts intact so syntax error positions match the original source.
 */
export function normalizeExpressSource(source) {
    const segments = [];
    let pos = 0;
    for (const m of source.matchAll(SQL_COMMENT_OR_TOKEN_REGEX)) {
        const idx = m.index ?? 0;
        if (idx > pos) {
            segments.push({ isTok: false, text: source.slice(pos, idx) });
        }
        if (m[1] !== undefined) {
            segments.push({ isTok: true, text: m[1] });
        }
        else {
            segments.push({ isTok: true, text: `//${m[2] ?? ''}` });
        }
        pos = idx + m[0].length;
    }
    if (pos < source.length) {
        segments.push({ isTok: false, text: source.slice(pos) });
    }
    let depth = 0;
    const segDepths = [];
    for (const seg of segments) {
        if (seg.isTok) {
            segDepths.push([]);
            continue;
        }
        const depths = [];
        for (let i = 0; i < seg.text.length; i++) {
            const ch = seg.text[i];
            depths.push(depth);
            if (ch === '(' || ch === '[' || ch === '{') {
                depth++;
            }
            else if (ch === ')' || ch === ']' || ch === '}') {
                if (depth > 0)
                    depth--;
            }
        }
        segDepths.push(depths);
    }
    const splitP2Starts = new Set();
    for (let segIdx = 0; segIdx < segments.length; segIdx++) {
        const seg = segments[segIdx];
        if (!seg.isTok) {
            const depths = segDepths[segIdx];
            for (const m of seg.text.matchAll(SPLIT_LHS_REGEX)) {
                const fullIdx = m.index ?? 0;
                if (depths[fullIdx] === 0) {
                    const p2Offset = fullIdx + m[0].length - m[3].length;
                    splitP2Starts.add(`${segIdx}:${p2Offset}`);
                }
            }
        }
    }
    const directDeclared = new Set();
    for (let segIdx = 0; segIdx < segments.length; segIdx++) {
        const seg = segments[segIdx];
        if (!seg.isTok) {
            const depths = segDepths[segIdx];
            for (const m of seg.text.matchAll(DECLARED_LHS_REGEX)) {
                const fullIdx = m.index ?? 0;
                const identOffset = fullIdx + m[0].indexOf(m[1]);
                if (depths[identOffset] === 0 && !splitP2Starts.has(`${segIdx}:${identOffset}`)) {
                    directDeclared.add(m[1]);
                }
            }
        }
    }
    const declared = new Set(directDeclared);
    for (let segIdx = 0; segIdx < segments.length; segIdx++) {
        const seg = segments[segIdx];
        if (!seg.isTok) {
            const depths = segDepths[segIdx];
            for (const m of seg.text.matchAll(SPLIT_LHS_REGEX)) {
                const fullIdx = m.index ?? 0;
                if (depths[fullIdx] === 0) {
                    const p1 = m[1].trim();
                    const p2 = m[3];
                    if (!directDeclared.has(p1) && !directDeclared.has(p2)) {
                        declared.add(p1 + p2);
                    }
                }
            }
        }
    }
    const out = [];
    for (const seg of segments) {
        if (seg.isTok) {
            out.push(seg.text);
            continue;
        }
        let text = seg.text.replace(SPLIT_DATA_PATH_REGEX, (full, p1, nl, p2, offset, string) => {
            const rest = string.slice(offset + full.length);
            if (IDENT_ONLY_REGEX.test(p2) && ASSIGN_EQUALS_REGEX.test(rest)) {
                return full;
            }
            return `${p1}${p2}${nl}`;
        });
        text = text.replace(SPLIT_LHS_REGEX, (full, p1Raw, nl, p2) => {
            const p1 = p1Raw.trim();
            if (!directDeclared.has(p1) && !directDeclared.has(p2)) {
                return `${p1Raw}${p2}${nl}`;
            }
            return full;
        });
        text = text.replace(SPLIT_ARG_IDENT_REGEX, (full, prefix, p1, nl, p2) => {
            const joined = p1 + p2;
            if (declared.has(joined) && !declared.has(p1) && !declared.has(p2)) {
                return `${prefix}${joined}${nl}`;
            }
            return full;
        });
        out.push(text);
    }
    return out.join('');
}
/**
 * Parses Express DSL source into syntax errors and statements.
 *
 * Runs the parsing pipeline mirroring compiler.py:256-283.
 */
export function parseExpress(source) {
    const inputStream = CharStream.fromString(normalizeExpressSource(source));
    const lexer = new ExpressLexer(inputStream);
    const errorListener = new ExpressErrorListener();
    lexer.removeErrorListeners();
    lexer.addErrorListener(errorListener);
    const tokenStream = new CommonTokenStream(lexer);
    const parser = new ExpressParser(tokenStream);
    parser.removeErrorListeners();
    parser.addErrorListener(errorListener);
    const tree = parser.program();
    const firstErrorLine = errorListener.errors.length > 0 ? errorListener.errors[0][0] : undefined;
    const visitor = new ExpressAstVisitor(firstErrorLine);
    const statements = visitor.visit(tree) ?? [];
    return {
        errors: errorListener.errors,
        statements,
    };
}
//# sourceMappingURL=visitor.js.map