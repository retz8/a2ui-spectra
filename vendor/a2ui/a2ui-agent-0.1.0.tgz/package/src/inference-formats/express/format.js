/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { resolveExpressVersion, toCatalogList } from './catalogs.js';
import { ExpressParser } from './parser.js';
import { ExpressPromptGenerator } from './prompt-generator.js';
import { DEFAULT_EXPRESS_PROGRESSIVE_KEYS } from './response-stream.js';
/**
 * Express inference format implementation.
 */
export class ExpressFormat {
    constructor(catalogs, options = {}) {
        this.catalogs = toCatalogList(catalogs);
        this.surfaceId = options.surfaceId ?? 'main';
        this.version = resolveExpressVersion(this.catalogs, options.version);
        this.progressiveKeys =
            options.progressiveKeys !== undefined
                ? new Set(options.progressiveKeys)
                : DEFAULT_EXPRESS_PROGRESSIVE_KEYS;
        this.promptGenerator = new ExpressPromptGenerator(this.catalogs, options.examples, options.allowedMessages, this.version);
    }
    createParser() {
        return new ExpressParser(this.catalogs, this.surfaceId, this.version, {
            progressiveKeys: this.progressiveKeys,
        });
    }
}
/**
 * Factory for creating ExpressFormat instances.
 */
export class ExpressFormatFactory {
    constructor(options = {}) {
        this.options = options;
        this.progressiveKeys =
            options.progressiveKeys !== undefined
                ? new Set(options.progressiveKeys)
                : DEFAULT_EXPRESS_PROGRESSIVE_KEYS;
    }
    createFormat(catalogs, examples) {
        return new ExpressFormat(catalogs, {
            ...this.options,
            examples,
            progressiveKeys: this.progressiveKeys,
        });
    }
}
//# sourceMappingURL=format.js.map