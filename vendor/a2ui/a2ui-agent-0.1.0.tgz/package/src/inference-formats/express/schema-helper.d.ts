import { CatalogApi } from '../../internal/web-core.js';
/**
 * Recognizes protocol common types referenced via `$ref` into `common_types.json`.
 *
 * Matches both relative paths (`common_types.json#/$defs/<Name>`) and absolute URLs
 * (`https://a2ui.org/specification/.../common_types.json#/$defs/<Name>`), under either
 * `$defs` or the older `definitions`.
 *
 * @param ref The `$ref` string to inspect.
 * @returns The def name if pointing into `common_types.json`, or undefined.
 */
export declare function commonDefName(ref: unknown): string | undefined;
/**
 * The four envelope mixin names that `ComponentCommon` and `Checkable` add to
 * component objects (`id` and `component` stay bare in all protocol versions).
 */
export declare const ENVELOPE_MIXIN_NAMES: readonly ["catalogId", "metadata", "accessibility", "checks"];
/** The `@`-prefixed v1.0 wire keys for the component envelope mixins. */
export declare const AT_ENVELOPE_MIXIN_KEYS: ReadonlySet<string>;
/**
 * Returns the wire key to write for an envelope mixin on a component object.
 */
export declare function envelopeKey(name: string, atLeastV10: boolean): string;
/**
 * Returns the key under which `component` holds envelope mixin `name`, or undefined.
 *
 * On v1.0, prefers `@<name>`, falling back to legacy bare `<name>` only when `<name>`
 * is not declared as a custom property of the component.
 */
export declare function envelopeReadKey(component: Readonly<Record<string, unknown>>, name: string, atLeastV10: boolean, customProperties?: ReadonlySet<string>): string | undefined;
/**
 * Reads an envelope mixin value from a component object, or returns undefined.
 */
export declare function getEnvelopeValue(component: Readonly<Record<string, unknown>>, name: string, atLeastV10: boolean, customProperties?: ReadonlySet<string>): unknown;
/**
 * Checks whether a property schema is an Action slot.
 *
 * A property is an action slot when its schema references the common `Action` def,
 * directly or through `oneOf`/`anyOf`/`allOf`.
 *
 * @param schema The property JSON schema to inspect.
 * @returns True if the schema references the common `Action` type.
 */
export declare function isActionSlot(schema: unknown): boolean;
/**
 * Checks if a property's schema expects a list of objects with label/value properties.
 *
 * Ported verbatim from Python's `_schema_expects_option_objects` (compiler.py:124-152).
 * Sanctioned exception: plan §5.2 item 2.
 *
 * @param schema The property JSON schema to inspect.
 * @returns True if schema expects option objects.
 */
export declare function expectsOptionObjects(schema: unknown): boolean;
/**
 * Returns the system functions that a protocol version's common types define.
 *
 * A system function is defined by the protocol rather than by a catalog: it is
 * a common types `$defs` entry whose `@call` property is a constant name
 * starting with `@`, such as `@index` from v1.0. It has the same shape as a
 * catalog function, so the same code reads its arguments.
 *
 * @param defs The common types `$defs` of a protocol version.
 * @returns The system function schemas keyed by their `@` name, which is empty
 *   for a version that defines none.
 */
export declare function systemFunctionSchemas(defs: Record<string, unknown> | undefined): Map<string, Record<string, unknown>>;
/**
 * The keys that mark a data binding (`path`) and a function call (`call`) on the wire.
 * v1.0 prefixes both with `@`; v0.9 and v0.9.1 use the plain names.
 */
export interface ReservedKeys {
    readonly path: string;
    readonly call: string;
}
export declare class CatalogSchemaHelper {
    readonly catalog: Record<string, unknown>;
    readonly commonTypes: Record<string, unknown>;
    readonly commonTypesLoaded: boolean;
    /** The wire keys for data bindings and function calls in this catalog's version. */
    readonly keys: ReservedKeys;
    readonly components: ReadonlyMap<string, Record<string, unknown>>;
    readonly functions: ReadonlyMap<string, Record<string, unknown>>;
    /**
     * The system functions that the catalog's protocol version defines, such as
     * `@index`, keyed by name. The function getters read them as well as the
     * catalog's own functions.
     */
    readonly systemFunctions: ReadonlyMap<string, Record<string, unknown>>;
    private readonly componentProperties;
    private readonly componentRequired;
    private readonly checkRuleProperties;
    private readonly inheritedCheckRulePropertyNames;
    private readonly inheritedCheckRuleSchemas;
    private readonly customEnvelopeProperties;
    private readonly componentPropertyEnums;
    private readonly functionProperties;
    private readonly functionRequired;
    private readonly systemFunctionProperties;
    private readonly systemFunctionRequired;
    constructor(catalog: CatalogApi, protocolVersion: string);
    private lookupCommonDef;
    private resolveJsonPointer;
    /**
     * Resolves a schema that is a local `#/...` reference against the catalog.
     *
     * @param sub The schema that may be a reference.
     * @returns The referenced schema, or undefined if `sub` is not a local reference.
     */
    private resolveLocalRef;
    /**
     * Lists the sub-schemas of a component in the order its properties are read.
     *
     * The component's own schema comes first, so its own definition of a property
     * overrides an inherited one. Then come the allOf entries that declare
     * `component` (the specific schemas), then the other allOf entries (the
     * common mixins). Each allOf entry is expanded depth first: a local `#/...`
     * reference is resolved against the catalog, and the entries of its own
     * allOf follow it. References into `common_types.json` are kept as is.
     *
     * @param schema The component schema.
     * @returns The ordered sub-schemas.
     */
    private orderedComponentSubSchemas;
    private getCheckRuleDefName;
    private isCheckRuleArraySchema;
    private loadMappings;
    /**
     * Returns a function schema's argument names in order, and the required ones.
     */
    private functionSignature;
    /** Returns the schema of a catalog or system function, or undefined. */
    private functionSchema;
    /**
     * Returns the ordered properties of the specified component.
     */
    getComponentProperties(name: string): string[];
    /**
     * Returns the list of required properties for the specified component.
     */
    getComponentRequired(name: string): string[];
    /**
     * Returns whether the specified component supports client-side checks.
     */
    isCheckable(name: string): boolean;
    /**
     * Returns the check-rule property name for the specified component, or undefined.
     */
    getCheckRuleProperty(name: string): string | undefined;
    /**
     * Returns the bare envelope mixin names (`catalogId`, `metadata`,
     * `accessibility`, `checks`) that the component declares as custom
     * properties in its own schema rather than inheriting from `ComponentCommon`
     * or `Checkable`.
     */
    getCustomEnvelopeProperties(name: string): ReadonlySet<string>;
    /**
     * Returns the ordered properties of a catalog or system function's arguments.
     */
    getFunctionProperties(name: string): string[];
    /**
     * Returns the required argument properties of a catalog or system function.
     */
    getFunctionRequired(name: string): string[];
    /**
     * Retrieves the JSON schema for a specific function argument property.
     */
    getFunctionPropertySchema(fnName: string, propName: string): Record<string, unknown> | undefined;
    /**
     * Returns the list of allowed enum values for a component property, or undefined.
     */
    getPropertyEnum(componentName: string, propertyName: string): string[] | undefined;
    /**
     * Retrieves the description of the component from its catalog schema.
     */
    getComponentDescription(name: string): string | undefined;
    /**
     * Retrieves the description of a catalog or system function.
     */
    getFunctionDescription(name: string): string | undefined;
    /**
     * Crawls all sub-schemas of a component to retrieve a property's schema definition.
     *
     * The sub-schemas are searched in the order `orderedComponentSubSchemas`
     * lists them, the component's own schema first, and the first definition
     * found is returned, so the component's own definition of a property
     * overrides an inherited one, including one from a nested allOf.
     */
    getPropertySchema(componentName: string, propertyName: string): Record<string, unknown> | undefined;
    /**
     * Retrieves the check-rule property's schema for a component (own or inherited).
     */
    getCheckRulePropertySchema(componentName: string): Record<string, unknown> | undefined;
    /**
     * Checks whether a schema admits a data binding path.
     *
     * True when the schema is, or combines via `$ref`/oneOf/anyOf/allOf, an object schema
     * whose `properties` contains `path` (v0.9) or `@path` (v1.0).
     *
     * Follows `$ref`s in `commonTypes` or the catalog document.
     * Never descends into `items` or property values.
     */
    admitsPath(schema: unknown): boolean;
    /**
     * Checks whether a property schema accepts a numeric value by resolving `$ref`s
     * in `commonTypes` or the catalog document.
     */
    acceptsNumber(schema: unknown): boolean;
    /**
     * Resolves the schema of an array's items.
     *
     * Traverses $ref (both in common types and catalog document), allOf, oneOf, and anyOf
     * to find the declared schema at that position.
     *
     * @param schema The array's JSON schema.
     * @returns The resolved item schema, or undefined if not declared.
     */
    resolveItemSchema(schema: unknown): Record<string, unknown> | undefined;
    /**
     * Resolves the schema of an object's property, falling back to `additionalProperties`
     * when the property is not declared.
     *
     * Traverses $ref (both in common types and catalog document), allOf, oneOf, and anyOf
     * to find the declared schema at that position. A property named `items` is looked up
     * as a property, not as the array items.
     *
     * @param schema The object's JSON schema.
     * @param name The property name.
     * @returns The resolved property schema, or undefined if not declared.
     */
    resolvePropertySchema(schema: unknown, name: string): Record<string, unknown> | undefined;
    /**
     * @param property The property to resolve, or undefined for the array items.
     */
    private resolveAt;
}
//# sourceMappingURL=schema-helper.d.ts.map