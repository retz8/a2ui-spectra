/**
 * @fileoverview Custom AST visitor and error listener for A2UI Express DSL.
 *
 * Ported from Python's visitor.py. Traverses the ANTLR parse tree to construct
 * AST nodes tagged by `kind` and collects syntax errors.
 */
import { type ATNSimulator, BaseErrorListener, type RecognitionException, type Recognizer, type Token } from 'antlr4ng';
import { type ArgContext, type ArrayContext, type AssignmentContext, type CheckContext, type CallContext, type ExpressionContext, type IdentifierContext, type LiteralContext, type MapContext, type Map_entryContext, type Named_argContext, type PathContext, type ProgramContext, type StatementContext, type StringContext, type VariableContext } from './generated/ExpressParser.js';
import { ExpressVisitor } from './generated/ExpressVisitor.js';
/**
 * Primitive literal values produced by the Express AST visitor.
 */
export type ExpressPrimitiveValue = string | number | boolean | null;
/**
 * A dynamic data model path (e.g. `$/user/name` -> `{kind: 'path', path: '/user/name'}`).
 */
export interface ExpressPathNode {
    kind: 'path';
    path: string;
}
/**
 * A validation check rule expression (e.g. `?required` ->
 * `{kind: 'check', name: 'required', args: []}`).
 */
export interface ExpressCheckNode {
    kind: 'check';
    name: string;
    args: ExpressValue[];
}
/**
 * A variable reference (e.g. `title` -> `{kind: 'variable', name: 'title'}`).
 */
export interface ExpressVariableNode {
    kind: 'variable';
    name: string;
}
/**
 * The special skip placeholder `_` in argument positions.
 */
export interface ExpressSkippedNode {
    kind: 'skipped';
}
/**
 * A function or component invocation (e.g. `Text("hello", variant="bold")`).
 */
export interface ExpressCallNode {
    kind: 'call';
    name: string;
    args: ExpressValue[];
    kwargs: Record<string, ExpressValue>;
}
/**
 * A dictionary/map literal (e.g. `{a: 1, "b": 2}`).
 *
 * Map literals are wrapped rather than represented as plain objects so that
 * their keys, whatever they are, can never be mistaken for another node.
 */
export interface ExpressMapNode {
    kind: 'map';
    entries: Record<string, ExpressValue>;
}
/**
 * Discriminated union of every non-primitive, non-array AST node.
 */
export type ExpressNode = ExpressPathNode | ExpressCheckNode | ExpressVariableNode | ExpressSkippedNode | ExpressCallNode | ExpressMapNode;
/**
 * Recursive type representing any expression value produced by the Express visitor.
 */
export type ExpressValue = ExpressPrimitiveValue | ExpressValue[] | ExpressNode;
/**
 * Checks whether a value is an AST node of the given kind.
 */
export declare function isExpressNode<K extends ExpressNode['kind']>(val: unknown, kind: K): val is Extract<ExpressNode, {
    kind: K;
}>;
/**
 * Sets `key` on `target` as an own, enumerable property.
 *
 * Unlike `target[key] = value`, this stores a key such as `__proto__` as data
 * rather than changing the object's prototype, so a map literal keeps every
 * key it is written with.
 */
export declare function setOwnEntry<T>(target: Record<string, T>, key: string, value: T): void;
/**
 * Variable or data path assignment statement (e.g. `root = Column(...)` or `$/a/b = "c"`).
 */
export type ExpressAssignStatement = ['ASSIGN', string, ExpressValue];
/**
 * Standalone expression statement (e.g. `surface("main")`).
 */
export type ExpressExprStatement = ['EXPR', ExpressValue];
/**
 * Discriminated union of all statements produced by the Express visitor.
 */
export type ExpressStatement = ExpressAssignStatement | ExpressExprStatement;
/**
 * A syntax error tuple collected during lexing or parsing:
 * `[line, column, message, isLexer]`.
 */
export type ExpressErrorRecord = [line: number, column: number, message: string, isLexer: boolean];
interface ExpressArgKeyword {
    type: 'kw';
    key: string;
    value: ExpressValue;
}
interface ExpressArgPositional {
    type: 'pos';
    value: ExpressValue;
}
type ExpressArgIntermediate = ExpressArgKeyword | ExpressArgPositional;
/**
 * Reads the text of a `NUMBER` token as a number.
 *
 * The token grammar is a JSON number with an optional leading `+` (`42`, `-1`,
 * `.5`, `1.`, `2.5E+3`), which `Number()` reads as is. Integers beyond
 * ±(2^53 − 1) lose precision, as they do in JSON.
 *
 * @param text The matched token text.
 * @returns The value of the literal.
 * @throws {ExpressParseError} When the value is outside the double range (such
 *   as `1e999`), so that every SDK rejects the same literals.
 */
export declare function parseNumberLiteral(text: string): number;
/**
 * Resolves only standard escape sequences: \n, \r, \t, \\, and \".
 * Any other escape sequences are treated as literal characters.
 * Uses unicode flag (/u) to ensure surrogate pairs are not split.
 */
export declare function unescapeString(val: string): string;
/**
 * Custom ANTLR error listener that collects syntax errors as 4-tuples:
 * `[line, column, message, isLexer]`.
 */
export declare class ExpressErrorListener extends BaseErrorListener {
    readonly errors: ExpressErrorRecord[];
    syntaxError<S extends Token, T extends ATNSimulator>(recognizer: Recognizer<T>, _offendingSymbol: S | null, line: number, column: number, msg: string, _e: RecognitionException | null): void;
}
/**
 * Traverses the ANTLR parse tree to construct the expected AST nodes.
 */
export declare class ExpressAstVisitor extends ExpressVisitor<unknown> {
    readonly firstErrorLine?: number;
    constructor(firstErrorLine?: number);
    visitProgram: (ctx: ProgramContext) => ExpressStatement[];
    visitStatement: (ctx: StatementContext) => ExpressStatement | null;
    visitAssignment: (ctx: AssignmentContext) => ExpressAssignStatement;
    visitExpression: (ctx: ExpressionContext) => ExpressValue;
    visitArray: (ctx: ArrayContext) => ExpressValue[];
    visitMap: (ctx: MapContext) => ExpressMapNode;
    visitMap_entry: (ctx: Map_entryContext) => [string, ExpressValue];
    visitPath: (ctx: PathContext) => ExpressPathNode;
    visitCheck: (ctx: CheckContext) => ExpressCheckNode;
    visitArg: (ctx: ArgContext) => ExpressArgIntermediate;
    visitNamed_arg: (ctx: Named_argContext) => [string, ExpressValue];
    visitCall: (ctx: CallContext) => ExpressCallNode;
    visitVariable: (ctx: VariableContext) => ExpressVariableNode | ExpressSkippedNode;
    visitLiteral: (ctx: LiteralContext) => ExpressPrimitiveValue;
    visitIdentifier: (ctx: IdentifierContext) => string;
    visitString: (ctx: StringContext) => string;
}
/**
 * Normalizes `--` comments and line-broken tokens outside strings and comments,
 * keeping line counts intact so syntax error positions match the original source.
 */
export declare function normalizeExpressSource(source: string): string;
/**
 * Parses Express DSL source into syntax errors and statements.
 *
 * Runs the parsing pipeline mirroring compiler.py:256-283.
 */
export declare function parseExpress(source: string): {
    errors: ExpressErrorRecord[];
    statements: ExpressStatement[];
};
export {};
//# sourceMappingURL=visitor.d.ts.map