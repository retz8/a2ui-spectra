/**
 * Returns whether a string can be written as a bare Express identifier, following the
 * `IDENTIFIER` lexer rule in `Express.g4`.
 *
 * @param str The candidate identifier.
 * @returns True if the string lexes as an identifier.
 */
export declare function isExpressIdentifier(str: string): boolean;
/**
 * Derives a valid Express variable name from an arbitrary component ID.
 *
 * Replaces every code point outside `XID_Continue` with `_`, then prefixes `_`
 * until the result is a valid non-reserved Express identifier.
 *
 * @param componentId The component ID to derive a variable name from.
 * @returns A valid Express variable name.
 */
export declare function deriveVariableName(componentId: string): string;
/**
 * Maps each component ID in a block to the variable name it is written under.
 *
 * An ID that is a valid Express identifier is its own variable name. Any other ID,
 * such as a pre-v1.0 `content-grid` or a reserved word like `true`, gets a derived
 * name (`content_grid`, `_true`) that no other ID or variable of the block uses,
 * and the component is written with an `id="..."` argument so that it compiles back
 * to its ID.
 *
 * @param componentIds The component IDs in the block, in component order.
 * @returns Map from component ID to assigned variable name.
 */
export declare function assignVariableNames(componentIds: readonly string[]): Map<string, string>;
//# sourceMappingURL=identifier.d.ts.map