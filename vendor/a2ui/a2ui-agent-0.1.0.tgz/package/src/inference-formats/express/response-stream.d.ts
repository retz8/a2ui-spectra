import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { ResponsePart, StreamPart } from '../../parser/response-part.js';
import { ResponseStream } from '../../parser/response-stream.js';
import { RendererState } from '../../utils/renderer-state.js';
import { CatalogSchemaHelper } from './schema-helper.js';
/** Default property keys whose string literals stream progressively before the closing quote. */
export declare const DEFAULT_EXPRESS_PROGRESSIVE_KEYS: ReadonlySet<string>;
/** Parser interface required by `ExpressResponseStream`. */
export interface ExpressStreamSource {
    readonly catalogs: CatalogApi[];
    readonly surfaceId: string;
    readonly version: string;
    readonly progressiveKeys: ReadonlySet<string>;
    compile(formatContent: string, isFinal?: boolean): AgentToRendererMessage[];
}
/** Returns where a tail of `text` could start `<a2ui>`, else its length. */
export declare function possibleOpenTagStart(text: string): number;
/** Finds `</a2ui>` outside string literals, or holds a partial close-tag tail. */
export declare function scanExpressBlock(content: string): [number | undefined, number];
/** Strips leading/trailing markdown fences from `block.slice(0, end)`. */
export declare function cleanExpressPayload(block: string, end: number): string | undefined;
/** Splits `source` into `[completePrefix, trailingFragment]`. */
export declare function splitCompleteStatements(source: string, isFinal?: boolean): [string, string];
/** Heals an unclosed progressive string literal at the tail of `fragment`. */
export declare function healProgressiveFragment(fragment: string, helpers: ReadonlyMap<string, CatalogSchemaHelper>, progressiveKeys: ReadonlySet<string>): string | undefined;
/** Wraps an `ExpressCompilerError` into the matching `A2uiCompilationError` subclass. */
export declare function wrapExpressCompilationError(error: unknown, rawContent: string): unknown;
/** How an Express stream is opened. */
export interface ExpressStreamOptions {
    /** False if the whole response is one block, without tags. */
    wrapped?: boolean;
    /** The state the stream's messages are applied to. */
    state?: RendererState;
    /** Whether the stream ends at a rejected block or reads past it. */
    afterRejectedBlock?: 'end' | 'continue';
    /** Property keys whose unclosed string literals are healed progressively. */
    progressiveKeys?: Iterable<string>;
}
/**
 * Reads a streamed A2UI Express response chunk by chunk.
 *
 * By default the stream ends at the first rejected block: `feed` or `close` throws, and the
 * error's `partialResults` holds the parts the chunk made ready before the failure. Opened
 * with `afterRejectedBlock: 'continue'`, it returns an `ErrorPart` in the block's place,
 * skips the rest of the block, and reads on. Either way the messages the block emitted stay
 * in the state and the components they added are marked checked.
 *
 * @template Part The parts the stream returns. See `ResponseStream`.
 */
export declare class ExpressResponseStream<Part extends StreamPart = ResponsePart> implements ResponseStream<Part> {
    private readonly parser;
    readonly state: RendererState;
    private readonly wrapped;
    private readonly continues;
    private readonly compiler;
    private readonly progressiveKeys;
    private closed;
    private held;
    private readonly text;
    private afterBlock;
    private wrappedInInlineBackticks;
    private inBlock;
    /** Whether the open block was rejected, so the rest of it is skipped. */
    private rejected;
    private block;
    private scanPos;
    private lastCompiledPrefix;
    private touched;
    private initialSurfaces;
    private session;
    /**
     * @param parser The parser that opened the stream.
     * @param options Whether the response is wrapped in tags, the state the stream's messages
     *     are applied to, whether the stream reads past a rejected block, and the keys whose
     *     strings heal progressively.
     */
    constructor(parser: ExpressStreamSource, { wrapped, state, afterRejectedBlock, progressiveKeys }?: ExpressStreamOptions);
    get isInBlock(): boolean;
    private newSession;
    /** Forgets the block that closed, whether it was read or rejected. */
    private resetBlock;
    feed(chunk: string): Part[];
    close(): Part[];
    private end;
    /**
     * Ends the stream after a failure. The renderer holds the messages already emitted, and so
     * does the state, so the components they added are marked checked.
     */
    private fail;
    /**
     * Runs a step that reads the open block. If the block is rejected and the stream reads past
     * rejected blocks, returns an `ErrorPart` for it and skips the rest of it; otherwise the
     * error propagates.
     */
    private readBlock;
    private read;
    private consumeBlockText;
    private consumeOutsideText;
    private emitReady;
    private tryCompileAndApplyHealed;
    private finishBlock;
    private compileStep;
    private apply;
}
//# sourceMappingURL=response-stream.d.ts.map