/**
 * Prompt generator for A2UI Express inference format.
 *
 * Compiles component catalog structures and logic helper catalogs into compact plain-text
 * signatures and instruction blocks.
 */
import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { PromptGenerator } from '../../prompt/generator.js';
import { CatalogSchemaHelper } from './schema-helper.js';
export declare const EXPRESS_RULES = "# A2UI Express DSL Output Contract\n\nYou must output the user interface using A2UI Express.\n\nIMPORTANT: You MUST always surround the entire A2UI Express block with the literal sentinel tags `<a2ui>` and `</a2ui>` (always include both the opening and closing tags; do NOT wrap the tags in backticks or replace the opening tag with a markdown code fence such as ```a2ui).\n\nThe host compiler will compile your A2UI Express output into the correct JSON envelopes automatically.\n\n## Grammar Rules\n\n1. Component constructors can be assigned to variables or nested inline inside parent component arguments:\n   header = ComponentA(prop1=\"val1\")\n   root = ComponentB([header, ComponentC(\"Click\", action=Event(\"submit\"))])\n\n   Keyword arguments (`param=value`) and positional arguments with `_` placeholders are supported.\n\n   Variable names MUST start with a letter or underscore, and only contain letters, digits, and underscores.\n\n2. The interface tree must have a single entry point assigned to the reserved variable 'root'.\n\n3. Primitives:\n   - Strings: Quoted with `\"` or `\"\"\"`. Support for `\\n`, `\\t`, `\\\\`, and `\\\"` escapes.\n     Raw Strings: Prefaced by `r` (e.g., `r\"...\"` or `r\"\"\"...\"\"\"`), with no escape processing.\n   - Numbers: write as integers or decimals, e.g., 42\n   - Booleans: write true or false\n   - Null values: write null\n   - Dates & Times: Values for date-time inputs (e.g. in DateTimeInput) must strictly use RFC 3339 format with a timezone offset (e.g. \"2026-03-14T00:00:00Z\").\n\n4. Lists: represent as arrays, e.g., [child1, child2].\n\n5. Maps: represent as key-value blocks, e.g., {title: \"Overview\", child: contentCol}. Map keys are always literal strings (dynamic variable resolution is not supported for keys).\n\n6. Data bindings: prefix absolute paths in the data model with '$', e.g., $/user/firstName.\n   Prefix relative list scopes with '$', e.g., $firstName.\n   A lone '$' represents an empty relative path which resolves to the root of the current context (e.g. inside a template, representing the entire item itself).\n\n7. Logic and validation: prefix client check rules with '?', e.g., ?required or ?regex(\"^[0-9]{5}$\"). To specify a custom error message for validation failures, append it as an extra string argument, e.g. ?regex(\"^[0-9]{5}$\", \"Postal code must be 5 digits\").\n\n8. Action events: represent server-side actions using the Event helper, `Event(name, context?, userMessage=...)`:\n   Event(\"save_deal\", {rep: $/form/rep})\n   Event(\"reply\", userMessage=\"Replying now\")\n   Event(\"save_deal\", {rep: $/form/rep}, userMessage=$/form/summary)\n   The context map is optional. Pass `userMessage=` as a keyword argument (a string, `$path` binding, or function call) to set the message shown on the user's behalf when the event fires.\n\n9. Nested functions: call client functions directly using catalog signatures, for example myFunction(\"value\").\n\n10. Data model population: Assign a value directly to an absolute data path (e.g. $/path/to/key = \"value\") to populate or initialize values inside the shared dataModel. The value can be a primitive, array, or map.\n\n11. Dynamic list templates: If a component expects a template child list, represent it using the _template helper:\n    _template($/path/to/list, itemTemplate)\n    And define the template component variable on another line, utilizing relative path references prefixed with $:\n    itemTemplate = Image($url)\n\n12. To delete a user interface surface, output the standalone `deleteSurface(surfaceId)` command (no variable assignment):\n    deleteSurface(\"dashboard-surface-1\")\n\n13. Static properties: Arguments annotated with '(static)' in the signatures below MUST be defined as literal values or arrays inline. You CANNOT use a dynamic data binding path (prefixed by $) for these arguments.\n\n14. Required actions: Parameters named 'action' (or annotated in component signatures) are strictly required. You must pass a valid Event (e.g. Event(\"click\")) or function call. If no specific action is described in the user request, you must provide a dummy click event like Event(\"click\") instead of passing null or omitting the parameter.\n\n15. Surface targeting: Output `surface(surfaceId)` to specify or target a user interface surface:\n    surface(\"dashboard-surface-1\")\n    root = ComponentA(...)";
export declare class ExpressPromptGenerator extends PromptGenerator {
    private readonly allowedMessages?;
    private readonly examples?;
    private readonly version;
    private readonly helpers;
    /**
     * @param catalogs Active catalogs to render instructions for.
     * @param examples Few-shot examples keyed by catalog id.
     * @param allowedMessages Optional allowlist of message names (`createSurface`,
     *     `updateComponents`, `updateDataModel`, `deleteSurface`). The base rules drop the
     *     instructions for messages outside it.
     * @param version Optional wire protocol version override.
     */
    constructor(catalogs: CatalogApi[], examples?: Record<string, AgentToRendererMessage[] | AgentToRendererMessage[][] | string>, allowedMessages?: readonly string[] | undefined, version?: string);
    private getHelper;
    private multiCatalogRules;
    /**
     * Returns the core syntax contract and grammar rules for A2UI Express.
     *
     * Matches `EXPRESS_RULES` (and express_base_rules.txt) when no allowlist of message
     * types was given, except that rule 15's `root = ...(...)` example names a component of
     * the active catalogs. Otherwise, also filters out envelope-specific instructions.
     */
    generateBaseRules(): string;
    /**
     * Lists the system functions of the target version, such as `@index`.
     *
     * System functions are defined by the protocol rather than a catalog, so they are
     * listed once, in the same signature format as catalog functions, and only for a
     * version that defines them.
     *
     * @returns The section, or an empty string if the version defines none.
     */
    private generateSystemFunctionSignatures;
    protected renderCatalogInstructions(catalog: CatalogApi): string;
    private replaceJsonBlockInInstructions;
    private formatSignatureEntry;
    private formatComponentArgLabel;
    private formatSubKeyLines;
    private formatComponentPropertyDetail;
    generateComponentSignatures(helper: CatalogSchemaHelper): string;
    generateFunctionSignatures(helper: CatalogSchemaHelper): string;
    /** Writes one signature, with its descriptions, for each named function. */
    private formatFunctionSignatures;
    transformExamples(rawExamplesMarkdown: string, catalog?: CatalogApi): string;
    private replaceJsonBlock;
    /**
     * Decompiles a list of messages into one sentinel-wrapped Express block.
     *
     * The list goes to the decompiler as a whole so that messages for the same surface
     * (e.g. `createSurface` followed by `updateComponents`) merge under a single
     * `surface(...)` header. Decompiling them one at a time would emit an empty
     * `surface(...)` scope per message, which fails to compile.
     *
     * @param messages The messages of one example.
     * @param catalog Optional catalog the example belongs to, used as the default catalog.
     */
    private decompileMessages;
    protected renderExamples(catalog: CatalogApi): string;
}
//# sourceMappingURL=prompt-generator.d.ts.map