import * as antlr from "antlr4ng";
import { ExpressVisitor } from "./ExpressVisitor.js";
export declare class ExpressParser extends antlr.Parser {
    static readonly T__0 = 1;
    static readonly T__1 = 2;
    static readonly T__2 = 3;
    static readonly T__3 = 4;
    static readonly T__4 = 5;
    static readonly T__5 = 6;
    static readonly T__6 = 7;
    static readonly T__7 = 8;
    static readonly T__8 = 9;
    static readonly T__9 = 10;
    static readonly T__10 = 11;
    static readonly RAW_TRIPLE_STRING = 12;
    static readonly TRIPLE_STRING = 13;
    static readonly RAW_STRING = 14;
    static readonly STANDARD_STRING = 15;
    static readonly PATH = 16;
    static readonly CHECK = 17;
    static readonly NUMBER = 18;
    static readonly BOOLEAN = 19;
    static readonly IDENTIFIER = 20;
    static readonly SYSTEM_IDENTIFIER = 21;
    static readonly COMMENT = 22;
    static readonly BLOCK_COMMENT = 23;
    static readonly SEMICOLON = 24;
    static readonly WS = 25;
    static readonly RULE_program = 0;
    static readonly RULE_statement = 1;
    static readonly RULE_assignment = 2;
    static readonly RULE_expression = 3;
    static readonly RULE_array = 4;
    static readonly RULE_map = 5;
    static readonly RULE_map_entry = 6;
    static readonly RULE_path = 7;
    static readonly RULE_check = 8;
    static readonly RULE_call = 9;
    static readonly RULE_function_name = 10;
    static readonly RULE_arg = 11;
    static readonly RULE_named_arg = 12;
    static readonly RULE_variable = 13;
    static readonly RULE_literal = 14;
    static readonly RULE_identifier = 15;
    static readonly RULE_string = 16;
    static readonly literalNames: (string | null)[];
    static readonly symbolicNames: (string | null)[];
    static readonly ruleNames: string[];
    get grammarFileName(): string;
    get literalNames(): (string | null)[];
    get symbolicNames(): (string | null)[];
    get ruleNames(): string[];
    get serializedATN(): number[];
    protected createFailedPredicateException(predicate?: string, message?: string): antlr.FailedPredicateException;
    constructor(input: antlr.TokenStream);
    program(): ProgramContext;
    statement(): StatementContext;
    assignment(): AssignmentContext;
    expression(): ExpressionContext;
    array(): ArrayContext;
    map(): MapContext;
    map_entry(): Map_entryContext;
    path(): PathContext;
    check(): CheckContext;
    call(): CallContext;
    function_name(): Function_nameContext;
    arg(): ArgContext;
    named_arg(): Named_argContext;
    variable(): VariableContext;
    literal(): LiteralContext;
    identifier(): IdentifierContext;
    string_(): StringContext;
    static readonly _serializedATN: number[];
    private static __ATN;
    static get _ATN(): antlr.ATN;
    private static readonly vocabulary;
    get vocabulary(): antlr.Vocabulary;
    private static readonly decisionsToDFA;
}
export declare class ProgramContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    EOF(): antlr.TerminalNode;
    statement(): StatementContext[];
    statement(i: number): StatementContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class StatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    assignment(): AssignmentContext | null;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class AssignmentContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext;
    identifier(): IdentifierContext | null;
    path(): PathContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class ExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    array(): ArrayContext | null;
    map(): MapContext | null;
    path(): PathContext | null;
    check(): CheckContext | null;
    call(): CallContext | null;
    variable(): VariableContext | null;
    literal(): LiteralContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class ArrayContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class MapContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    map_entry(): Map_entryContext[];
    map_entry(i: number): Map_entryContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class Map_entryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext;
    identifier(): IdentifierContext | null;
    string(): StringContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class PathContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    PATH(): antlr.TerminalNode;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class CheckContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CHECK(): antlr.TerminalNode;
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class CallContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    function_name(): Function_nameContext;
    arg(): ArgContext[];
    arg(i: number): ArgContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class Function_nameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifier(): IdentifierContext | null;
    SYSTEM_IDENTIFIER(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class ArgContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    named_arg(): Named_argContext | null;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class Named_argContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifier(): IdentifierContext;
    expression(): ExpressionContext;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class VariableContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifier(): IdentifierContext | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class LiteralContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    string(): StringContext | null;
    NUMBER(): antlr.TerminalNode | null;
    BOOLEAN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class IdentifierContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
export declare class StringContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    RAW_TRIPLE_STRING(): antlr.TerminalNode | null;
    TRIPLE_STRING(): antlr.TerminalNode | null;
    RAW_STRING(): antlr.TerminalNode | null;
    STANDARD_STRING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    accept<Result>(visitor: ExpressVisitor<Result>): Result | null;
}
//# sourceMappingURL=ExpressParser.d.ts.map