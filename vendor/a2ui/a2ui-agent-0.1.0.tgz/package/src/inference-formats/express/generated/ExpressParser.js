import * as antlr from "antlr4ng";
export class ExpressParser extends antlr.Parser {
    get grammarFileName() { return "Express.g4"; }
    get literalNames() { return ExpressParser.literalNames; }
    get symbolicNames() { return ExpressParser.symbolicNames; }
    get ruleNames() { return ExpressParser.ruleNames; }
    get serializedATN() { return ExpressParser._serializedATN; }
    createFailedPredicateException(predicate, message) {
        return new antlr.FailedPredicateException(this, predicate, message);
    }
    constructor(input) {
        super(input);
        this.interpreter = new antlr.ParserATNSimulator(this, ExpressParser._ATN, ExpressParser.decisionsToDFA, new antlr.PredictionContextCache());
    }
    program() {
        let localContext = new ProgramContext(this.context, this.state);
        this.enterRule(localContext, 0, ExpressParser.RULE_program);
        let _la;
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 37;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                while ((((_la) & ~0x1F) === 0 && ((1 << _la) & 4193316) !== 0)) {
                    {
                        {
                            this.state = 34;
                            this.statement();
                        }
                    }
                    this.state = 39;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                }
                this.state = 40;
                this.match(ExpressParser.EOF);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    statement() {
        let localContext = new StatementContext(this.context, this.state);
        this.enterRule(localContext, 2, ExpressParser.RULE_statement);
        try {
            this.state = 44;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 1, this.context)) {
                case 1:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 42;
                        this.assignment();
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 43;
                        this.expression();
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    assignment() {
        let localContext = new AssignmentContext(this.context, this.state);
        this.enterRule(localContext, 4, ExpressParser.RULE_assignment);
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 48;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                    case ExpressParser.IDENTIFIER:
                        {
                            this.state = 46;
                            this.identifier();
                        }
                        break;
                    case ExpressParser.PATH:
                        {
                            this.state = 47;
                            this.path();
                        }
                        break;
                    default:
                        throw new antlr.NoViableAltException(this);
                }
                this.state = 50;
                this.match(ExpressParser.T__0);
                this.state = 51;
                this.expression();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    expression() {
        let localContext = new ExpressionContext(this.context, this.state);
        this.enterRule(localContext, 6, ExpressParser.RULE_expression);
        try {
            this.state = 60;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 3, this.context)) {
                case 1:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 53;
                        this.array();
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 54;
                        this.map();
                    }
                    break;
                case 3:
                    this.enterOuterAlt(localContext, 3);
                    {
                        this.state = 55;
                        this.path();
                    }
                    break;
                case 4:
                    this.enterOuterAlt(localContext, 4);
                    {
                        this.state = 56;
                        this.check();
                    }
                    break;
                case 5:
                    this.enterOuterAlt(localContext, 5);
                    {
                        this.state = 57;
                        this.call();
                    }
                    break;
                case 6:
                    this.enterOuterAlt(localContext, 6);
                    {
                        this.state = 58;
                        this.variable();
                    }
                    break;
                case 7:
                    this.enterOuterAlt(localContext, 7);
                    {
                        this.state = 59;
                        this.literal();
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    array() {
        let localContext = new ArrayContext(this.context, this.state);
        this.enterRule(localContext, 8, ExpressParser.RULE_array);
        let _la;
        try {
            let alternative;
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 62;
                this.match(ExpressParser.T__1);
                this.state = 74;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 4193316) !== 0)) {
                    {
                        this.state = 63;
                        this.expression();
                        this.state = 68;
                        this.errorHandler.sync(this);
                        alternative = this.interpreter.adaptivePredict(this.tokenStream, 4, this.context);
                        while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                            if (alternative === 1) {
                                {
                                    {
                                        this.state = 64;
                                        this.match(ExpressParser.T__2);
                                        this.state = 65;
                                        this.expression();
                                    }
                                }
                            }
                            this.state = 70;
                            this.errorHandler.sync(this);
                            alternative = this.interpreter.adaptivePredict(this.tokenStream, 4, this.context);
                        }
                        this.state = 72;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                        if (_la === 3) {
                            {
                                this.state = 71;
                                this.match(ExpressParser.T__2);
                            }
                        }
                    }
                }
                this.state = 76;
                this.match(ExpressParser.T__3);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    map() {
        let localContext = new MapContext(this.context, this.state);
        this.enterRule(localContext, 10, ExpressParser.RULE_map);
        let _la;
        try {
            let alternative;
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 78;
                this.match(ExpressParser.T__4);
                this.state = 90;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1110016) !== 0)) {
                    {
                        this.state = 79;
                        this.map_entry();
                        this.state = 84;
                        this.errorHandler.sync(this);
                        alternative = this.interpreter.adaptivePredict(this.tokenStream, 7, this.context);
                        while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                            if (alternative === 1) {
                                {
                                    {
                                        this.state = 80;
                                        this.match(ExpressParser.T__2);
                                        this.state = 81;
                                        this.map_entry();
                                    }
                                }
                            }
                            this.state = 86;
                            this.errorHandler.sync(this);
                            alternative = this.interpreter.adaptivePredict(this.tokenStream, 7, this.context);
                        }
                        this.state = 88;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                        if (_la === 3) {
                            {
                                this.state = 87;
                                this.match(ExpressParser.T__2);
                            }
                        }
                    }
                }
                this.state = 92;
                this.match(ExpressParser.T__5);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    map_entry() {
        let localContext = new Map_entryContext(this.context, this.state);
        this.enterRule(localContext, 12, ExpressParser.RULE_map_entry);
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 96;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                    case ExpressParser.IDENTIFIER:
                        {
                            this.state = 94;
                            this.identifier();
                        }
                        break;
                    case ExpressParser.RAW_TRIPLE_STRING:
                    case ExpressParser.TRIPLE_STRING:
                    case ExpressParser.RAW_STRING:
                    case ExpressParser.STANDARD_STRING:
                        {
                            this.state = 95;
                            this.string_();
                        }
                        break;
                    default:
                        throw new antlr.NoViableAltException(this);
                }
                this.state = 98;
                this.match(ExpressParser.T__6);
                this.state = 99;
                this.expression();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    path() {
        let localContext = new PathContext(this.context, this.state);
        this.enterRule(localContext, 14, ExpressParser.RULE_path);
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 101;
                this.match(ExpressParser.PATH);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    check() {
        let localContext = new CheckContext(this.context, this.state);
        this.enterRule(localContext, 16, ExpressParser.RULE_check);
        let _la;
        try {
            let alternative;
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 103;
                this.match(ExpressParser.CHECK);
                this.state = 119;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 8) {
                    {
                        this.state = 104;
                        this.match(ExpressParser.T__7);
                        this.state = 116;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                        if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 4193316) !== 0)) {
                            {
                                this.state = 105;
                                this.expression();
                                this.state = 110;
                                this.errorHandler.sync(this);
                                alternative = this.interpreter.adaptivePredict(this.tokenStream, 11, this.context);
                                while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                                    if (alternative === 1) {
                                        {
                                            {
                                                this.state = 106;
                                                this.match(ExpressParser.T__2);
                                                this.state = 107;
                                                this.expression();
                                            }
                                        }
                                    }
                                    this.state = 112;
                                    this.errorHandler.sync(this);
                                    alternative = this.interpreter.adaptivePredict(this.tokenStream, 11, this.context);
                                }
                                this.state = 114;
                                this.errorHandler.sync(this);
                                _la = this.tokenStream.LA(1);
                                if (_la === 3) {
                                    {
                                        this.state = 113;
                                        this.match(ExpressParser.T__2);
                                    }
                                }
                            }
                        }
                        this.state = 118;
                        this.match(ExpressParser.T__8);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    call() {
        let localContext = new CallContext(this.context, this.state);
        this.enterRule(localContext, 18, ExpressParser.RULE_call);
        let _la;
        try {
            let alternative;
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 121;
                this.function_name();
                this.state = 122;
                this.match(ExpressParser.T__7);
                this.state = 134;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 4193316) !== 0)) {
                    {
                        this.state = 123;
                        this.arg();
                        this.state = 128;
                        this.errorHandler.sync(this);
                        alternative = this.interpreter.adaptivePredict(this.tokenStream, 15, this.context);
                        while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                            if (alternative === 1) {
                                {
                                    {
                                        this.state = 124;
                                        this.match(ExpressParser.T__2);
                                        this.state = 125;
                                        this.arg();
                                    }
                                }
                            }
                            this.state = 130;
                            this.errorHandler.sync(this);
                            alternative = this.interpreter.adaptivePredict(this.tokenStream, 15, this.context);
                        }
                        this.state = 132;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                        if (_la === 3) {
                            {
                                this.state = 131;
                                this.match(ExpressParser.T__2);
                            }
                        }
                    }
                }
                this.state = 136;
                this.match(ExpressParser.T__8);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    function_name() {
        let localContext = new Function_nameContext(this.context, this.state);
        this.enterRule(localContext, 20, ExpressParser.RULE_function_name);
        try {
            this.state = 140;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
                case ExpressParser.IDENTIFIER:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 138;
                        this.identifier();
                    }
                    break;
                case ExpressParser.SYSTEM_IDENTIFIER:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 139;
                        this.match(ExpressParser.SYSTEM_IDENTIFIER);
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    arg() {
        let localContext = new ArgContext(this.context, this.state);
        this.enterRule(localContext, 22, ExpressParser.RULE_arg);
        try {
            this.state = 144;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 19, this.context)) {
                case 1:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 142;
                        this.named_arg();
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 143;
                        this.expression();
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    named_arg() {
        let localContext = new Named_argContext(this.context, this.state);
        this.enterRule(localContext, 24, ExpressParser.RULE_named_arg);
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 146;
                this.identifier();
                this.state = 147;
                this.match(ExpressParser.T__0);
                this.state = 148;
                this.expression();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    variable() {
        let localContext = new VariableContext(this.context, this.state);
        this.enterRule(localContext, 26, ExpressParser.RULE_variable);
        try {
            this.state = 152;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
                case ExpressParser.T__9:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 150;
                        this.match(ExpressParser.T__9);
                    }
                    break;
                case ExpressParser.IDENTIFIER:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 151;
                        this.identifier();
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    literal() {
        let localContext = new LiteralContext(this.context, this.state);
        this.enterRule(localContext, 28, ExpressParser.RULE_literal);
        try {
            this.state = 158;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
                case ExpressParser.RAW_TRIPLE_STRING:
                case ExpressParser.TRIPLE_STRING:
                case ExpressParser.RAW_STRING:
                case ExpressParser.STANDARD_STRING:
                    this.enterOuterAlt(localContext, 1);
                    {
                        this.state = 154;
                        this.string_();
                    }
                    break;
                case ExpressParser.NUMBER:
                    this.enterOuterAlt(localContext, 2);
                    {
                        this.state = 155;
                        this.match(ExpressParser.NUMBER);
                    }
                    break;
                case ExpressParser.BOOLEAN:
                    this.enterOuterAlt(localContext, 3);
                    {
                        this.state = 156;
                        this.match(ExpressParser.BOOLEAN);
                    }
                    break;
                case ExpressParser.T__10:
                    this.enterOuterAlt(localContext, 4);
                    {
                        this.state = 157;
                        this.match(ExpressParser.T__10);
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    identifier() {
        let localContext = new IdentifierContext(this.context, this.state);
        this.enterRule(localContext, 30, ExpressParser.RULE_identifier);
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 160;
                this.match(ExpressParser.IDENTIFIER);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    string_() {
        let localContext = new StringContext(this.context, this.state);
        this.enterRule(localContext, 32, ExpressParser.RULE_string);
        let _la;
        try {
            this.enterOuterAlt(localContext, 1);
            {
                this.state = 162;
                _la = this.tokenStream.LA(1);
                if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & 61440) !== 0))) {
                    this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    static get _ATN() {
        if (!ExpressParser.__ATN) {
            ExpressParser.__ATN = new antlr.ATNDeserializer().deserialize(ExpressParser._serializedATN);
        }
        return ExpressParser.__ATN;
    }
    get vocabulary() {
        return ExpressParser.vocabulary;
    }
}
ExpressParser.T__0 = 1;
ExpressParser.T__1 = 2;
ExpressParser.T__2 = 3;
ExpressParser.T__3 = 4;
ExpressParser.T__4 = 5;
ExpressParser.T__5 = 6;
ExpressParser.T__6 = 7;
ExpressParser.T__7 = 8;
ExpressParser.T__8 = 9;
ExpressParser.T__9 = 10;
ExpressParser.T__10 = 11;
ExpressParser.RAW_TRIPLE_STRING = 12;
ExpressParser.TRIPLE_STRING = 13;
ExpressParser.RAW_STRING = 14;
ExpressParser.STANDARD_STRING = 15;
ExpressParser.PATH = 16;
ExpressParser.CHECK = 17;
ExpressParser.NUMBER = 18;
ExpressParser.BOOLEAN = 19;
ExpressParser.IDENTIFIER = 20;
ExpressParser.SYSTEM_IDENTIFIER = 21;
ExpressParser.COMMENT = 22;
ExpressParser.BLOCK_COMMENT = 23;
ExpressParser.SEMICOLON = 24;
ExpressParser.WS = 25;
ExpressParser.RULE_program = 0;
ExpressParser.RULE_statement = 1;
ExpressParser.RULE_assignment = 2;
ExpressParser.RULE_expression = 3;
ExpressParser.RULE_array = 4;
ExpressParser.RULE_map = 5;
ExpressParser.RULE_map_entry = 6;
ExpressParser.RULE_path = 7;
ExpressParser.RULE_check = 8;
ExpressParser.RULE_call = 9;
ExpressParser.RULE_function_name = 10;
ExpressParser.RULE_arg = 11;
ExpressParser.RULE_named_arg = 12;
ExpressParser.RULE_variable = 13;
ExpressParser.RULE_literal = 14;
ExpressParser.RULE_identifier = 15;
ExpressParser.RULE_string = 16;
ExpressParser.literalNames = [
    null, "'='", "'['", "','", "']'", "'{'", "'}'", "':'", "'('", "')'",
    "'_'", "'null'", null, null, null, null, null, null, null, null,
    null, null, null, null, "';'"
];
ExpressParser.symbolicNames = [
    null, null, null, null, null, null, null, null, null, null, null,
    null, "RAW_TRIPLE_STRING", "TRIPLE_STRING", "RAW_STRING", "STANDARD_STRING",
    "PATH", "CHECK", "NUMBER", "BOOLEAN", "IDENTIFIER", "SYSTEM_IDENTIFIER",
    "COMMENT", "BLOCK_COMMENT", "SEMICOLON", "WS"
];
ExpressParser.ruleNames = [
    "program", "statement", "assignment", "expression", "array", "map",
    "map_entry", "path", "check", "call", "function_name", "arg", "named_arg",
    "variable", "literal", "identifier", "string",
];
ExpressParser._serializedATN = [
    4, 1, 25, 165, 2, 0, 7, 0, 2, 1, 7, 1, 2, 2, 7, 2, 2, 3, 7, 3, 2, 4, 7, 4, 2, 5, 7, 5, 2, 6, 7,
    6, 2, 7, 7, 7, 2, 8, 7, 8, 2, 9, 7, 9, 2, 10, 7, 10, 2, 11, 7, 11, 2, 12, 7, 12, 2, 13, 7, 13,
    2, 14, 7, 14, 2, 15, 7, 15, 2, 16, 7, 16, 1, 0, 5, 0, 36, 8, 0, 10, 0, 12, 0, 39, 9, 0, 1,
    0, 1, 0, 1, 1, 1, 1, 3, 1, 45, 8, 1, 1, 2, 1, 2, 3, 2, 49, 8, 2, 1, 2, 1, 2, 1, 2, 1, 3, 1, 3,
    1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 3, 3, 61, 8, 3, 1, 4, 1, 4, 1, 4, 1, 4, 5, 4, 67, 8, 4, 10, 4, 12,
    4, 70, 9, 4, 1, 4, 3, 4, 73, 8, 4, 3, 4, 75, 8, 4, 1, 4, 1, 4, 1, 5, 1, 5, 1, 5, 1, 5, 5, 5, 83,
    8, 5, 10, 5, 12, 5, 86, 9, 5, 1, 5, 3, 5, 89, 8, 5, 3, 5, 91, 8, 5, 1, 5, 1, 5, 1, 6, 1, 6, 3,
    6, 97, 8, 6, 1, 6, 1, 6, 1, 6, 1, 7, 1, 7, 1, 8, 1, 8, 1, 8, 1, 8, 1, 8, 5, 8, 109, 8, 8, 10,
    8, 12, 8, 112, 9, 8, 1, 8, 3, 8, 115, 8, 8, 3, 8, 117, 8, 8, 1, 8, 3, 8, 120, 8, 8, 1, 9, 1,
    9, 1, 9, 1, 9, 1, 9, 5, 9, 127, 8, 9, 10, 9, 12, 9, 130, 9, 9, 1, 9, 3, 9, 133, 8, 9, 3, 9,
    135, 8, 9, 1, 9, 1, 9, 1, 10, 1, 10, 3, 10, 141, 8, 10, 1, 11, 1, 11, 3, 11, 145, 8, 11,
    1, 12, 1, 12, 1, 12, 1, 12, 1, 13, 1, 13, 3, 13, 153, 8, 13, 1, 14, 1, 14, 1, 14, 1, 14,
    3, 14, 159, 8, 14, 1, 15, 1, 15, 1, 16, 1, 16, 1, 16, 0, 0, 17, 0, 2, 4, 6, 8, 10, 12, 14,
    16, 18, 20, 22, 24, 26, 28, 30, 32, 0, 1, 1, 0, 12, 15, 176, 0, 37, 1, 0, 0, 0, 2, 44, 1,
    0, 0, 0, 4, 48, 1, 0, 0, 0, 6, 60, 1, 0, 0, 0, 8, 62, 1, 0, 0, 0, 10, 78, 1, 0, 0, 0, 12, 96,
    1, 0, 0, 0, 14, 101, 1, 0, 0, 0, 16, 103, 1, 0, 0, 0, 18, 121, 1, 0, 0, 0, 20, 140, 1, 0,
    0, 0, 22, 144, 1, 0, 0, 0, 24, 146, 1, 0, 0, 0, 26, 152, 1, 0, 0, 0, 28, 158, 1, 0, 0, 0,
    30, 160, 1, 0, 0, 0, 32, 162, 1, 0, 0, 0, 34, 36, 3, 2, 1, 0, 35, 34, 1, 0, 0, 0, 36, 39,
    1, 0, 0, 0, 37, 35, 1, 0, 0, 0, 37, 38, 1, 0, 0, 0, 38, 40, 1, 0, 0, 0, 39, 37, 1, 0, 0, 0,
    40, 41, 5, 0, 0, 1, 41, 1, 1, 0, 0, 0, 42, 45, 3, 4, 2, 0, 43, 45, 3, 6, 3, 0, 44, 42, 1, 0,
    0, 0, 44, 43, 1, 0, 0, 0, 45, 3, 1, 0, 0, 0, 46, 49, 3, 30, 15, 0, 47, 49, 3, 14, 7, 0, 48,
    46, 1, 0, 0, 0, 48, 47, 1, 0, 0, 0, 49, 50, 1, 0, 0, 0, 50, 51, 5, 1, 0, 0, 51, 52, 3, 6, 3,
    0, 52, 5, 1, 0, 0, 0, 53, 61, 3, 8, 4, 0, 54, 61, 3, 10, 5, 0, 55, 61, 3, 14, 7, 0, 56, 61,
    3, 16, 8, 0, 57, 61, 3, 18, 9, 0, 58, 61, 3, 26, 13, 0, 59, 61, 3, 28, 14, 0, 60, 53, 1,
    0, 0, 0, 60, 54, 1, 0, 0, 0, 60, 55, 1, 0, 0, 0, 60, 56, 1, 0, 0, 0, 60, 57, 1, 0, 0, 0, 60,
    58, 1, 0, 0, 0, 60, 59, 1, 0, 0, 0, 61, 7, 1, 0, 0, 0, 62, 74, 5, 2, 0, 0, 63, 68, 3, 6, 3,
    0, 64, 65, 5, 3, 0, 0, 65, 67, 3, 6, 3, 0, 66, 64, 1, 0, 0, 0, 67, 70, 1, 0, 0, 0, 68, 66,
    1, 0, 0, 0, 68, 69, 1, 0, 0, 0, 69, 72, 1, 0, 0, 0, 70, 68, 1, 0, 0, 0, 71, 73, 5, 3, 0, 0,
    72, 71, 1, 0, 0, 0, 72, 73, 1, 0, 0, 0, 73, 75, 1, 0, 0, 0, 74, 63, 1, 0, 0, 0, 74, 75, 1,
    0, 0, 0, 75, 76, 1, 0, 0, 0, 76, 77, 5, 4, 0, 0, 77, 9, 1, 0, 0, 0, 78, 90, 5, 5, 0, 0, 79,
    84, 3, 12, 6, 0, 80, 81, 5, 3, 0, 0, 81, 83, 3, 12, 6, 0, 82, 80, 1, 0, 0, 0, 83, 86, 1, 0,
    0, 0, 84, 82, 1, 0, 0, 0, 84, 85, 1, 0, 0, 0, 85, 88, 1, 0, 0, 0, 86, 84, 1, 0, 0, 0, 87, 89,
    5, 3, 0, 0, 88, 87, 1, 0, 0, 0, 88, 89, 1, 0, 0, 0, 89, 91, 1, 0, 0, 0, 90, 79, 1, 0, 0, 0,
    90, 91, 1, 0, 0, 0, 91, 92, 1, 0, 0, 0, 92, 93, 5, 6, 0, 0, 93, 11, 1, 0, 0, 0, 94, 97, 3,
    30, 15, 0, 95, 97, 3, 32, 16, 0, 96, 94, 1, 0, 0, 0, 96, 95, 1, 0, 0, 0, 97, 98, 1, 0, 0,
    0, 98, 99, 5, 7, 0, 0, 99, 100, 3, 6, 3, 0, 100, 13, 1, 0, 0, 0, 101, 102, 5, 16, 0, 0, 102,
    15, 1, 0, 0, 0, 103, 119, 5, 17, 0, 0, 104, 116, 5, 8, 0, 0, 105, 110, 3, 6, 3, 0, 106,
    107, 5, 3, 0, 0, 107, 109, 3, 6, 3, 0, 108, 106, 1, 0, 0, 0, 109, 112, 1, 0, 0, 0, 110,
    108, 1, 0, 0, 0, 110, 111, 1, 0, 0, 0, 111, 114, 1, 0, 0, 0, 112, 110, 1, 0, 0, 0, 113,
    115, 5, 3, 0, 0, 114, 113, 1, 0, 0, 0, 114, 115, 1, 0, 0, 0, 115, 117, 1, 0, 0, 0, 116,
    105, 1, 0, 0, 0, 116, 117, 1, 0, 0, 0, 117, 118, 1, 0, 0, 0, 118, 120, 5, 9, 0, 0, 119,
    104, 1, 0, 0, 0, 119, 120, 1, 0, 0, 0, 120, 17, 1, 0, 0, 0, 121, 122, 3, 20, 10, 0, 122,
    134, 5, 8, 0, 0, 123, 128, 3, 22, 11, 0, 124, 125, 5, 3, 0, 0, 125, 127, 3, 22, 11, 0,
    126, 124, 1, 0, 0, 0, 127, 130, 1, 0, 0, 0, 128, 126, 1, 0, 0, 0, 128, 129, 1, 0, 0, 0,
    129, 132, 1, 0, 0, 0, 130, 128, 1, 0, 0, 0, 131, 133, 5, 3, 0, 0, 132, 131, 1, 0, 0, 0,
    132, 133, 1, 0, 0, 0, 133, 135, 1, 0, 0, 0, 134, 123, 1, 0, 0, 0, 134, 135, 1, 0, 0, 0,
    135, 136, 1, 0, 0, 0, 136, 137, 5, 9, 0, 0, 137, 19, 1, 0, 0, 0, 138, 141, 3, 30, 15, 0,
    139, 141, 5, 21, 0, 0, 140, 138, 1, 0, 0, 0, 140, 139, 1, 0, 0, 0, 141, 21, 1, 0, 0, 0,
    142, 145, 3, 24, 12, 0, 143, 145, 3, 6, 3, 0, 144, 142, 1, 0, 0, 0, 144, 143, 1, 0, 0,
    0, 145, 23, 1, 0, 0, 0, 146, 147, 3, 30, 15, 0, 147, 148, 5, 1, 0, 0, 148, 149, 3, 6, 3,
    0, 149, 25, 1, 0, 0, 0, 150, 153, 5, 10, 0, 0, 151, 153, 3, 30, 15, 0, 152, 150, 1, 0,
    0, 0, 152, 151, 1, 0, 0, 0, 153, 27, 1, 0, 0, 0, 154, 159, 3, 32, 16, 0, 155, 159, 5, 18,
    0, 0, 156, 159, 5, 19, 0, 0, 157, 159, 5, 11, 0, 0, 158, 154, 1, 0, 0, 0, 158, 155, 1,
    0, 0, 0, 158, 156, 1, 0, 0, 0, 158, 157, 1, 0, 0, 0, 159, 29, 1, 0, 0, 0, 160, 161, 5, 20,
    0, 0, 161, 31, 1, 0, 0, 0, 162, 163, 7, 0, 0, 0, 163, 33, 1, 0, 0, 0, 22, 37, 44, 48, 60,
    68, 72, 74, 84, 88, 90, 96, 110, 114, 116, 119, 128, 132, 134, 140, 144, 152, 158
];
ExpressParser.vocabulary = new antlr.Vocabulary(ExpressParser.literalNames, ExpressParser.symbolicNames, []);
ExpressParser.decisionsToDFA = ExpressParser._ATN.decisionToState.map((ds, index) => new antlr.DFA(ds, index));
export class ProgramContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    EOF() {
        return this.getToken(ExpressParser.EOF, 0);
    }
    statement(i) {
        if (i === undefined) {
            return this.getRuleContexts(StatementContext);
        }
        return this.getRuleContext(i, StatementContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_program;
    }
    accept(visitor) {
        if (visitor.visitProgram) {
            return visitor.visitProgram(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class StatementContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    assignment() {
        return this.getRuleContext(0, AssignmentContext);
    }
    expression() {
        return this.getRuleContext(0, ExpressionContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_statement;
    }
    accept(visitor) {
        if (visitor.visitStatement) {
            return visitor.visitStatement(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class AssignmentContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    expression() {
        return this.getRuleContext(0, ExpressionContext);
    }
    identifier() {
        return this.getRuleContext(0, IdentifierContext);
    }
    path() {
        return this.getRuleContext(0, PathContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_assignment;
    }
    accept(visitor) {
        if (visitor.visitAssignment) {
            return visitor.visitAssignment(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ExpressionContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    array() {
        return this.getRuleContext(0, ArrayContext);
    }
    map() {
        return this.getRuleContext(0, MapContext);
    }
    path() {
        return this.getRuleContext(0, PathContext);
    }
    check() {
        return this.getRuleContext(0, CheckContext);
    }
    call() {
        return this.getRuleContext(0, CallContext);
    }
    variable() {
        return this.getRuleContext(0, VariableContext);
    }
    literal() {
        return this.getRuleContext(0, LiteralContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_expression;
    }
    accept(visitor) {
        if (visitor.visitExpression) {
            return visitor.visitExpression(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ArrayContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    expression(i) {
        if (i === undefined) {
            return this.getRuleContexts(ExpressionContext);
        }
        return this.getRuleContext(i, ExpressionContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_array;
    }
    accept(visitor) {
        if (visitor.visitArray) {
            return visitor.visitArray(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class MapContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    map_entry(i) {
        if (i === undefined) {
            return this.getRuleContexts(Map_entryContext);
        }
        return this.getRuleContext(i, Map_entryContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_map;
    }
    accept(visitor) {
        if (visitor.visitMap) {
            return visitor.visitMap(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class Map_entryContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    expression() {
        return this.getRuleContext(0, ExpressionContext);
    }
    identifier() {
        return this.getRuleContext(0, IdentifierContext);
    }
    string() {
        return this.getRuleContext(0, StringContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_map_entry;
    }
    accept(visitor) {
        if (visitor.visitMap_entry) {
            return visitor.visitMap_entry(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class PathContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    PATH() {
        return this.getToken(ExpressParser.PATH, 0);
    }
    get ruleIndex() {
        return ExpressParser.RULE_path;
    }
    accept(visitor) {
        if (visitor.visitPath) {
            return visitor.visitPath(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class CheckContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    CHECK() {
        return this.getToken(ExpressParser.CHECK, 0);
    }
    expression(i) {
        if (i === undefined) {
            return this.getRuleContexts(ExpressionContext);
        }
        return this.getRuleContext(i, ExpressionContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_check;
    }
    accept(visitor) {
        if (visitor.visitCheck) {
            return visitor.visitCheck(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class CallContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    function_name() {
        return this.getRuleContext(0, Function_nameContext);
    }
    arg(i) {
        if (i === undefined) {
            return this.getRuleContexts(ArgContext);
        }
        return this.getRuleContext(i, ArgContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_call;
    }
    accept(visitor) {
        if (visitor.visitCall) {
            return visitor.visitCall(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class Function_nameContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    identifier() {
        return this.getRuleContext(0, IdentifierContext);
    }
    SYSTEM_IDENTIFIER() {
        return this.getToken(ExpressParser.SYSTEM_IDENTIFIER, 0);
    }
    get ruleIndex() {
        return ExpressParser.RULE_function_name;
    }
    accept(visitor) {
        if (visitor.visitFunction_name) {
            return visitor.visitFunction_name(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ArgContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    named_arg() {
        return this.getRuleContext(0, Named_argContext);
    }
    expression() {
        return this.getRuleContext(0, ExpressionContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_arg;
    }
    accept(visitor) {
        if (visitor.visitArg) {
            return visitor.visitArg(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class Named_argContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    identifier() {
        return this.getRuleContext(0, IdentifierContext);
    }
    expression() {
        return this.getRuleContext(0, ExpressionContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_named_arg;
    }
    accept(visitor) {
        if (visitor.visitNamed_arg) {
            return visitor.visitNamed_arg(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class VariableContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    identifier() {
        return this.getRuleContext(0, IdentifierContext);
    }
    get ruleIndex() {
        return ExpressParser.RULE_variable;
    }
    accept(visitor) {
        if (visitor.visitVariable) {
            return visitor.visitVariable(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class LiteralContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    string() {
        return this.getRuleContext(0, StringContext);
    }
    NUMBER() {
        return this.getToken(ExpressParser.NUMBER, 0);
    }
    BOOLEAN() {
        return this.getToken(ExpressParser.BOOLEAN, 0);
    }
    get ruleIndex() {
        return ExpressParser.RULE_literal;
    }
    accept(visitor) {
        if (visitor.visitLiteral) {
            return visitor.visitLiteral(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class IdentifierContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    IDENTIFIER() {
        return this.getToken(ExpressParser.IDENTIFIER, 0);
    }
    get ruleIndex() {
        return ExpressParser.RULE_identifier;
    }
    accept(visitor) {
        if (visitor.visitIdentifier) {
            return visitor.visitIdentifier(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class StringContext extends antlr.ParserRuleContext {
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    RAW_TRIPLE_STRING() {
        return this.getToken(ExpressParser.RAW_TRIPLE_STRING, 0);
    }
    TRIPLE_STRING() {
        return this.getToken(ExpressParser.TRIPLE_STRING, 0);
    }
    RAW_STRING() {
        return this.getToken(ExpressParser.RAW_STRING, 0);
    }
    STANDARD_STRING() {
        return this.getToken(ExpressParser.STANDARD_STRING, 0);
    }
    get ruleIndex() {
        return ExpressParser.RULE_string;
    }
    accept(visitor) {
        if (visitor.visitString) {
            return visitor.visitString(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
//# sourceMappingURL=ExpressParser.js.map