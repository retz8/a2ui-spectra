/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Prompt generator for A2UI Express inference format.
 *
 * Compiles component catalog structures and logic helper catalogs into compact plain-text
 * signatures and instruction blocks.
 */
import { isAtLeastVersion } from '../../internal/web-core.js';
import { PromptGenerator } from '../../prompt/generator.js';
import { agentCallableFunctions } from '../../utils/agent-callable.js';
import { toWireProtocolVersion } from '../../utils/protocol-version.js';
import { buildSchemaHelpers, catalogsDefining, resolveExpressVersion } from './catalogs.js';
import { ExpressDecompiler, RawNumber } from './decompiler.js';
import { CatalogSchemaHelper, commonDefName, getEnvelopeValue } from './schema-helper.js';
const EVENT_RULE_V10 = `8. Action events: represent server-side actions using the Event helper, \`Event(name, context?, userMessage=...)\`:
   Event("save_deal", {rep: $/form/rep})
   Event("reply", userMessage="Replying now")
   Event("save_deal", {rep: $/form/rep}, userMessage=$/form/summary)
   The context map is optional. Pass \`userMessage=\` as a keyword argument (a string, \`$path\` binding, or function call) to set the message shown on the user's behalf when the event fires.`;
const EVENT_RULE_PRE_V10 = `8. Action events: represent server-side actions using the Event helper:
   Event("save_deal", {rep: $/form/rep})`;
const EXPRESS_RULES_PREFIX = `# A2UI Express DSL Output Contract

You must output the user interface using A2UI Express.

IMPORTANT: You MUST always surround the entire A2UI Express block with the literal sentinel tags \`<a2ui>\` and \`</a2ui>\` (always include both the opening and closing tags; do NOT wrap the tags in backticks or replace the opening tag with a markdown code fence such as \`\`\`a2ui).

The host compiler will compile your A2UI Express output into the correct JSON envelopes automatically.

## Grammar Rules

1. Component constructors can be assigned to variables or nested inline inside parent component arguments:
   header = ComponentA(prop1="val1")
   root = ComponentB([header, ComponentC("Click", action=Event("submit"))])

   Keyword arguments (\`param=value\`) and positional arguments with \`_\` placeholders are supported.

   Variable names MUST start with a letter or underscore, and only contain letters, digits, and underscores.

2. The interface tree must have a single entry point assigned to the reserved variable 'root'.

3. Primitives:
   - Strings: Quoted with \`"\` or \`"""\`. Support for \`\\n\`, \`\\t\`, \`\\\\\`, and \`\\"\` escapes.
     Raw Strings: Prefaced by \`r\` (e.g., \`r"..."\` or \`r"""..."""\`), with no escape processing.
   - Numbers: write as integers or decimals, e.g., 42
   - Booleans: write true or false
   - Null values: write null
   - Dates & Times: Values for date-time inputs (e.g. in DateTimeInput) must strictly use RFC 3339 format with a timezone offset (e.g. "2026-03-14T00:00:00Z").

4. Lists: represent as arrays, e.g., [child1, child2].

5. Maps: represent as key-value blocks, e.g., {title: "Overview", child: contentCol}. Map keys are always literal strings (dynamic variable resolution is not supported for keys).

6. Data bindings: prefix absolute paths in the data model with '$', e.g., $/user/firstName.
   Prefix relative list scopes with '$', e.g., $firstName.
   A lone '$' represents an empty relative path which resolves to the root of the current context (e.g. inside a template, representing the entire item itself).

7. Logic and validation: prefix client check rules with '?', e.g., ?required or ?regex("^[0-9]{5}$"). To specify a custom error message for validation failures, append it as an extra string argument, e.g. ?regex("^[0-9]{5}$", "Postal code must be 5 digits").`;
const EXPRESS_RULES_SUFFIX = `9. Nested functions: call client functions directly using catalog signatures, for example myFunction("value").

10. Data model population: Assign a value directly to an absolute data path (e.g. $/path/to/key = "value") to populate or initialize values inside the shared dataModel. The value can be a primitive, array, or map.

11. Dynamic list templates: If a component expects a template child list, represent it using the _template helper:
    _template($/path/to/list, itemTemplate)
    And define the template component variable on another line, utilizing relative path references prefixed with $:
    itemTemplate = Image($url)

12. To delete a user interface surface, output the standalone \`deleteSurface(surfaceId)\` command (no variable assignment):
    deleteSurface("dashboard-surface-1")

13. Static properties: Arguments annotated with '(static)' in the signatures below MUST be defined as literal values or arrays inline. You CANNOT use a dynamic data binding path (prefixed by $) for these arguments.

14. Required actions: Parameters named 'action' (or annotated in component signatures) are strictly required. You must pass a valid Event (e.g. Event("click")) or function call. If no specific action is described in the user request, you must provide a dummy click event like Event("click") instead of passing null or omitting the parameter.

15. Surface targeting: Output \`surface(surfaceId)\` to specify or target a user interface surface:
    surface("dashboard-surface-1")
    root = ComponentA(...)`;
export const EXPRESS_RULES = `${EXPRESS_RULES_PREFIX}\n\n${EVENT_RULE_V10}\n\n${EXPRESS_RULES_SUFFIX}`;
const EXPRESS_RULES_PRE_V10 = `${EXPRESS_RULES_PREFIX}\n\n${EVENT_RULE_PRE_V10}\n\n${EXPRESS_RULES_SUFFIX}`;
/**
 * Rule 15's example line. `generateBaseRules` replaces its placeholder name with a
 * component the active catalogs define, as Python's `_ROOT_EXAMPLE_LINE` does.
 */
const ROOT_EXAMPLE_LINE = 'root = ComponentA(...)';
/**
 * Picks the component that rule 15's `root = ...(...)` example names.
 *
 * The name is read from the catalogs, so the example never shows a component the model
 * can't use. It is the first component that holds a single child reference, as a container
 * such as a card does, or else the first component.
 *
 * @returns The component name, or undefined if the catalogs define no component.
 */
function exampleRootComponent(catalogs) {
    for (const catalog of catalogs) {
        for (const name of catalog.components.keys()) {
            const refs = Object.hasOwn(catalog.componentRefMap, name)
                ? catalog.componentRefMap[name]
                : undefined;
            if (refs !== undefined && refs.singleRefs.size > 0) {
                return name;
            }
        }
    }
    for (const catalog of catalogs) {
        for (const name of catalog.components.keys()) {
            return name;
        }
    }
    return undefined;
}
function renumberRules(text) {
    let ruleIndex = 0;
    return text.replace(/(?<=\n\n)(\d+\. )([^\n]*(?:\n(?!\n)[^\n]*)*)/g, (_match, oldPrefix, body) => {
        ruleIndex += 1;
        const newPrefix = `${ruleIndex}. `;
        const adjustedBody = oldPrefix.length === newPrefix.length
            ? body
            : body.replace(new RegExp(`\\n {${oldPrefix.length}}`, 'g'), '\n' + ' '.repeat(newPrefix.length));
        return `${newPrefix}${adjustedBody}`;
    });
}
/** The message types a fenced JSON example may contain to be rewritten as Express. */
const TRANSLATABLE_MESSAGE_TYPES = [
    'createSurface',
    'updateComponents',
    'updateDataModel',
    'deleteSurface',
    'callFunction',
    'callRendererFunction',
];
/**
 * Returns whether a parsed JSON value is a message the decompiler can translate.
 *
 * @param msg One element of a fenced JSON example.
 */
function isTranslatableMessage(msg) {
    return (!!msg &&
        typeof msg === 'object' &&
        TRANSLATABLE_MESSAGE_TYPES.some(type => type in msg));
}
function getSchemaEnum(propSchema) {
    if (!propSchema || typeof propSchema !== 'object') {
        return undefined;
    }
    const s = propSchema;
    if (Array.isArray(s.enum)) {
        return s.enum;
    }
    for (const key of ['oneOf', 'anyOf']) {
        const list = s[key];
        if (Array.isArray(list)) {
            for (const sub of list) {
                const val = getSchemaEnum(sub);
                if (val) {
                    return val;
                }
            }
        }
    }
    return undefined;
}
function applyDefaultCatalogToCalls(val, defaultCatalogId) {
    if (val instanceof RawNumber || !val || typeof val !== 'object') {
        return val;
    }
    if (Array.isArray(val)) {
        return val.map(item => applyDefaultCatalogToCalls(item, defaultCatalogId));
    }
    const obj = val;
    const copy = {};
    for (const [k, v] of Object.entries(obj)) {
        copy[k] = applyDefaultCatalogToCalls(v, defaultCatalogId);
    }
    const callName = typeof copy['@call'] === 'string'
        ? copy['@call']
        : typeof copy.call === 'string'
            ? copy.call
            : undefined;
    // A system function, such as `@index`, belongs to no catalog.
    const isCatalogCall = callName !== undefined && !callName.startsWith('@');
    if (isCatalogCall && !copy.catalogId) {
        copy.catalogId = defaultCatalogId;
    }
    return copy;
}
function applyDefaultCatalogToComponent(comp, defaultCatalogId, atLeastV10, helper) {
    const transformed = applyDefaultCatalogToCalls(comp, defaultCatalogId);
    if (!transformed || typeof transformed !== 'object' || Array.isArray(transformed)) {
        return transformed;
    }
    const copy = transformed;
    const compName = typeof copy.component === 'string' ? copy.component : undefined;
    if (!compName) {
        return copy;
    }
    const customProps = helper?.getCustomEnvelopeProperties(compName);
    if (getEnvelopeValue(copy, 'catalogId', atLeastV10, customProps) === undefined) {
        copy[atLeastV10 ? '@catalogId' : 'catalogId'] = defaultCatalogId;
    }
    return copy;
}
/**
 * Stamps a default `catalogId` on example messages that belong to a catalog but omit it.
 */
function withDefaultCatalog(messages, defaultCatalogId, atLeastV10 = true, helper) {
    if (!defaultCatalogId) {
        return messages;
    }
    const createdSurfaces = new Set();
    return messages.map(rawMsg => {
        if (!rawMsg || typeof rawMsg !== 'object') {
            return rawMsg;
        }
        const copy = { ...rawMsg };
        if (copy.createSurface && typeof copy.createSurface === 'object') {
            const cs = copy.createSurface;
            const sid = typeof cs.surfaceId === 'string' && cs.surfaceId ? cs.surfaceId : 'default_surface';
            createdSurfaces.add(sid);
            if (!cs.catalogId) {
                copy.createSurface = { ...cs, catalogId: defaultCatalogId };
            }
        }
        else if (copy.deleteSurface && typeof copy.deleteSurface === 'object') {
            const ds = copy.deleteSurface;
            const sid = typeof ds.surfaceId === 'string' && ds.surfaceId ? ds.surfaceId : 'default_surface';
            createdSurfaces.delete(sid);
        }
        else if (copy.updateComponents && typeof copy.updateComponents === 'object') {
            const uc = copy.updateComponents;
            const sid = typeof uc.surfaceId === 'string' && uc.surfaceId ? uc.surfaceId : 'default_surface';
            if (!createdSurfaces.has(sid) && Array.isArray(uc.components)) {
                copy.updateComponents = {
                    ...uc,
                    components: uc.components.map(comp => applyDefaultCatalogToComponent(comp, defaultCatalogId, atLeastV10, helper)),
                };
            }
        }
        else if (copy.callRendererFunction && typeof copy.callRendererFunction === 'object') {
            const crf = copy.callRendererFunction;
            if (crf.callFunction && typeof crf.callFunction === 'object') {
                const cf = crf.callFunction;
                if (!cf.catalogId) {
                    copy.callRendererFunction = {
                        ...crf,
                        callFunction: { ...cf, catalogId: defaultCatalogId },
                    };
                }
            }
        }
        else if (copy.callFunction && typeof copy.callFunction === 'object') {
            const cf = copy.callFunction;
            if (!cf.catalogId) {
                copy.callFunction = { ...cf, catalogId: defaultCatalogId };
            }
        }
        return copy;
    });
}
export class ExpressPromptGenerator extends PromptGenerator {
    /**
     * @param catalogs Active catalogs to render instructions for.
     * @param examples Few-shot examples keyed by catalog id.
     * @param allowedMessages Optional allowlist of message names (`createSurface`,
     *     `updateComponents`, `updateDataModel`, `deleteSurface`). The base rules drop the
     *     instructions for messages outside it.
     * @param version Optional wire protocol version override.
     */
    constructor(catalogs, examples, allowedMessages, version) {
        super(catalogs);
        this.allowedMessages = allowedMessages;
        this.version = resolveExpressVersion(this.catalogs, version);
        this.examples = examples;
        this.helpers = buildSchemaHelpers(this.catalogs, this.version);
    }
    getHelper(catalog) {
        let helper = this.helpers.get(catalog.id);
        if (!helper) {
            const version = toWireProtocolVersion(catalog.protocolVersion);
            helper = new CatalogSchemaHelper(catalog, version);
            this.helpers.set(catalog.id, helper);
        }
        return helper;
    }
    multiCatalogRules() {
        const catalogIds = [...this.helpers.keys()];
        const exampleId = catalogIds[catalogIds.length - 1];
        const listing = catalogIds.map(catId => `- \`${catId}\``).join('\n');
        const lines = [
            '',
            '## Multiple Catalogs',
            '',
            'Several component catalogs are active. Each is identified by its catalog ID, and the signatures below are grouped by catalog:',
            listing,
            '',
            '16. A surface has no catalog of its own: do not name a catalog on a `surface` line. Each component and function call, including checks, actions, nested function calls and inline child components, is found by its name in whichever catalog defines it.',
            '',
            '17. When several catalogs define the same component or function name, you MUST say which one you mean: add a `catalogId` keyword argument to the component or function call, or a `{catalogId: ...}` argument to a check. Do not add `catalogId` to any other name:',
            `    widget = ComponentName(..., catalogId="${exampleId}")`,
            `    action = functionName(..., catalogId="${exampleId}")`,
            `    ?checkName(..., {catalogId: "${exampleId}"})`,
        ];
        const sharedLines = [];
        const kinds = [
            ['component', 'Component'],
            ['function', 'Function'],
        ];
        for (const [kind, label] of kinds) {
            const names = new Set();
            for (const helper of this.helpers.values()) {
                const map = kind === 'component' ? helper.components : helper.functions;
                for (const name of map.keys()) {
                    names.add(name);
                }
            }
            for (const name of [...names].sort()) {
                const defining = catalogsDefining(this.helpers, kind, name);
                if (defining.length > 1) {
                    const ids = defining.map(catId => `\`${catId}\``).join(', ');
                    sharedLines.push(`- ${label} \`${name}\`: ${ids}`);
                }
            }
        }
        if (sharedLines.length > 0) {
            lines.push('', 'These names are defined in several catalogs and need a `catalogId`:', ...sharedLines);
        }
        return lines.join('\n');
    }
    /**
     * Returns the core syntax contract and grammar rules for A2UI Express.
     *
     * Matches `EXPRESS_RULES` (and express_base_rules.txt) when no allowlist of message
     * types was given, except that rule 15's `root = ...(...)` example names a component of
     * the active catalogs. Otherwise, also filters out envelope-specific instructions.
     */
    generateBaseRules() {
        const allowedMessages = this.allowedMessages;
        let rules = isAtLeastVersion(this.version, '1.0') ? EXPRESS_RULES : EXPRESS_RULES_PRE_V10;
        let wantsComponentsOrData = true;
        let wantsComponents = true;
        const callableFns = isAtLeastVersion(this.version, '1.0')
            ? agentCallableFunctions(this.catalogs)
            : [];
        const callRendererAllowed = !allowedMessages ||
            allowedMessages.includes('callRendererFunction') ||
            allowedMessages.includes('CallRendererFunctionMessage');
        if (allowedMessages) {
            // Filter rule 12 if deleteSurface is disallowed
            if (!allowedMessages.includes('deleteSurface') &&
                !allowedMessages.includes('DeleteSurfaceMessage')) {
                rules = rules.replace(/\n\n12\. To delete a user interface surface, output the standalone `deleteSurface\(surfaceId\)` command \(no variable assignment\):\n {4}deleteSurface\("dashboard-surface-1"\)/, '');
            }
            // Filter rule 10 if updateDataModel is disallowed
            if (!allowedMessages.includes('updateDataModel') &&
                !allowedMessages.includes('UpdateDataModelMessage')) {
                rules = rules.replace(/\n\n10\. Data model population: Assign a value directly to an absolute data path \(e\.g\. \$\/path\/to\/key = "value"\) to populate or initialize values inside the shared dataModel\. The value can be a primitive, array, or map\./, '');
            }
            // Rule 15 teaches `surface(...)`, which component and data statements both need to
            // target a surface. Its `root = ...` line applies only to components, and the rule
            // goes when neither kind of statement is allowed.
            const writesComponents = allowedMessages.includes('createSurface') ||
                allowedMessages.includes('CreateSurfaceMessage') ||
                allowedMessages.includes('updateComponents') ||
                allowedMessages.includes('UpdateComponentsMessage');
            const writesData = allowedMessages.includes('updateDataModel') ||
                allowedMessages.includes('UpdateDataModelMessage');
            wantsComponentsOrData = writesComponents || writesData;
            wantsComponents = writesComponents;
            if (!writesComponents) {
                rules = rules.replace(/\n {4}root = ComponentA\(\.\.\.\)$/, '');
                if (!writesData) {
                    rules = rules.replace(/\n\n15\. Surface targeting: Output `surface\(surfaceId\)` to specify or target a user interface surface:\n {4}surface\("dashboard-surface-1"\)$/, '');
                }
            }
        }
        const hasCallableRule = callRendererAllowed && callableFns.length > 0;
        if (hasCallableRule) {
            const formatted = callableFns.map(name => `\`${name}\``).join(', ');
            const callRule = 'To have the renderer run a function right away, output the call as a standalone command (no variable assignment):\n' +
                `    ${callableFns[0]}(...)\n` +
                `    Only these functions can be called this way: ${formatted}.`;
            rules = rules.replace(/\n\n13\. Static properties:/, `\n\n13. ${callRule}\n\n14. Static properties:`);
        }
        const rootComponent = exampleRootComponent(this.catalogs);
        if (rootComponent !== undefined) {
            rules = rules.replace(ROOT_EXAMPLE_LINE, `root = ${rootComponent}(...)`);
        }
        const hasMultiCatalogRules = this.catalogs.length > 1 && wantsComponentsOrData;
        const lines = [rules];
        if (hasMultiCatalogRules) {
            lines.push(this.multiCatalogRules());
        }
        let combined = lines.join('\n');
        if (allowedMessages !== undefined || hasCallableRule || hasMultiCatalogRules) {
            combined = renumberRules(combined);
        }
        if (wantsComponents) {
            const systemFunctions = this.generateSystemFunctionSignatures();
            if (systemFunctions) {
                combined += `\n\n${systemFunctions}`;
            }
        }
        return combined;
    }
    /**
     * Lists the system functions of the target version, such as `@index`.
     *
     * System functions are defined by the protocol rather than a catalog, so they are
     * listed once, in the same signature format as catalog functions, and only for a
     * version that defines them.
     *
     * @returns The section, or an empty string if the version defines none.
     */
    generateSystemFunctionSignatures() {
        const helper = this.catalogs.length > 0 ? this.getHelper(this.catalogs[0]) : undefined;
        if (!helper || helper.systemFunctions.size === 0) {
            return '';
        }
        const sigs = this.formatFunctionSignatures(helper, Array.from(helper.systemFunctions.keys()).sort());
        return ('## System Functions\n\nThese functions are defined by the A2UI protocol, not by a' +
            ' catalog. Call them by their `@` name, like any function, and never add a' +
            ` \`catalogId\` to them:\n${sigs}`);
    }
    renderCatalogInstructions(catalog) {
        const helper = this.getHelper(catalog);
        const compSigs = this.generateComponentSignatures(helper);
        const funcSigs = this.generateFunctionSignatures(helper);
        const rawInstructions = catalog.instructions || helper.catalog.instructions || '';
        let catalogInstructions = rawInstructions;
        if (catalogInstructions) {
            const pattern = /```json\s*\n([\s\S]*?)\n```/g;
            catalogInstructions = catalogInstructions.replace(pattern, (match, jsonContent) => this.replaceJsonBlockInInstructions(match, jsonContent, catalog));
        }
        const catalogInstructionsBlock = catalogInstructions
            ? `\n\n## Catalog Instructions\n\n${catalogInstructions}`
            : '';
        let header = '';
        if (this.catalogs.length > 1) {
            header = `# Catalog: ${catalog.id}\n\n`;
        }
        return (header +
            '## Positional Component Signatures\n\n' +
            'Use these exact positional signatures to instantiate components. Do not output property keys:\n' +
            compSigs +
            '\n\n## Positional Function Signatures\n\n' +
            'Use these exact positional signatures to instantiate check rules or logic functions:\n' +
            funcSigs +
            catalogInstructionsBlock);
    }
    replaceJsonBlockInInstructions(match, jsonContent, catalog) {
        try {
            // Python's json.loads keeps `1500.00` as the float 1500.0, which the decompiler
            // writes as `1500.0`. JS numbers lose that distinction, so integral values written
            // with a decimal point are wrapped in RawNumber. This relies on the reviver's
            // `context.source` argument (JSON.parse source text access, Node 21+); on older
            // runtimes `context` is undefined and such values decompile as integers.
            const reviver = (_key, value, context) => {
                if (typeof value === 'number' && context?.source && context.source.includes('.')) {
                    if (Number.isInteger(value)) {
                        return new RawNumber(`${value}.0`);
                    }
                }
                return value;
            };
            const parsed = JSON.parse(jsonContent.trim(), reviver);
            const messages = Array.isArray(parsed)
                ? parsed
                : typeof parsed === 'object' && parsed !== null
                    ? [parsed]
                    : [];
            if (messages.length === 0) {
                return match;
            }
            if (!messages.every(isTranslatableMessage)) {
                return match;
            }
            const fullDsl = this.decompileMessages(messages, catalog);
            return `\`\`\`\n${fullDsl}\n\`\`\``;
        }
        catch {
            // Mirrors prompt_generator.py:446 (except Exception:)
            return match;
        }
    }
    formatSignatureEntry(name, orderedArgs, description, propDetails) {
        let sig = `• ${name}(${orderedArgs.join(', ')})`;
        if (description) {
            const descIndented = description.replaceAll('\n', '\n    ');
            sig += `\n  - Description: ${descIndented}`;
        }
        if (propDetails.length > 0) {
            sig += '\n' + propDetails.join('\n');
        }
        return sig;
    }
    formatComponentArgLabel(propName, isRequired, pSchema, helper) {
        let argLabel = `${propName}${isRequired ? '' : '?'}`;
        const ref = pSchema && typeof pSchema === 'object' && typeof pSchema.$ref === 'string'
            ? pSchema.$ref
            : undefined;
        if (ref && commonDefName(ref) === 'ComponentId') {
            argLabel += ' (component ID)';
        }
        else if (!helper.admitsPath(pSchema)) {
            argLabel += ' (static)';
        }
        return argLabel;
    }
    formatSubKeyLines(properties) {
        return Object.entries(properties)
            .map(([subK, subV]) => {
            const desc = subV &&
                typeof subV === 'object' &&
                typeof subV.description === 'string'
                ? subV.description
                : '';
            return `    * ${subK}${desc ? ` - ${desc}` : ''}`;
        })
            .join('\n');
    }
    formatComponentPropertyDetail(propName, pSchema) {
        if (!pSchema || typeof pSchema !== 'object') {
            return undefined;
        }
        const pDesc = typeof pSchema.description === 'string' ? pSchema.description : undefined;
        const enumVals = getSchemaEnum(pSchema);
        const lineParts = [];
        if (pDesc) {
            lineParts.push(pDesc);
        }
        if (enumVals) {
            lineParts.push(`Must be one of: ${enumVals.map(v => `'${v}'`).join(', ')}`);
        }
        let detail = lineParts.length > 0 ? `  - ${propName}: ${lineParts.join(' ')}` : undefined;
        if (pSchema.type === 'object' && pSchema.properties && typeof pSchema.properties === 'object') {
            const subKeys = this.formatSubKeyLines(pSchema.properties);
            detail = detail
                ? `${detail}\n    Map keys:\n${subKeys}`
                : `  - ${propName}: Map with keys:\n${subKeys}`;
        }
        else if (pSchema.type === 'array' && pSchema.items && typeof pSchema.items === 'object') {
            const itemsSchema = pSchema.items;
            if (itemsSchema.type === 'object' &&
                itemsSchema.properties &&
                typeof itemsSchema.properties === 'object') {
                const subKeys = this.formatSubKeyLines(itemsSchema.properties);
                detail = detail
                    ? `${detail}\n    List of maps keys:\n${subKeys}`
                    : `  - ${propName}: List of maps with keys:\n${subKeys}`;
            }
        }
        return detail;
    }
    generateComponentSignatures(helper) {
        const compNames = Array.from(helper.components.keys()).sort();
        return compNames
            .map(name => {
            const props = helper.getComponentProperties(name);
            const reqs = helper.getComponentRequired(name);
            const orderedArgs = [];
            const propDetails = [];
            for (const p of props) {
                const pSchema = helper.getPropertySchema(name, p);
                orderedArgs.push(this.formatComponentArgLabel(p, reqs.includes(p), pSchema, helper));
                const detail = this.formatComponentPropertyDetail(p, pSchema);
                if (detail) {
                    propDetails.push(detail);
                }
            }
            return this.formatSignatureEntry(name, orderedArgs, helper.getComponentDescription(name), propDetails);
        })
            .join('\n');
    }
    generateFunctionSignatures(helper) {
        return this.formatFunctionSignatures(helper, Array.from(helper.functions.keys()).sort());
    }
    /** Writes one signature, with its descriptions, for each named function. */
    formatFunctionSignatures(helper, fnNames) {
        return fnNames
            .map(name => {
            const props = helper.getFunctionProperties(name);
            const reqs = helper.getFunctionRequired(name);
            const orderedArgs = [];
            const propDetails = [];
            for (const p of props) {
                orderedArgs.push(`${p}${reqs.includes(p) ? '' : '?'}`);
                const pSchema = helper.getFunctionPropertySchema(name, p);
                const pDesc = pSchema && typeof pSchema.description === 'string' ? pSchema.description : undefined;
                if (pDesc) {
                    propDetails.push(`  - ${p}: ${pDesc}`);
                }
            }
            return this.formatSignatureEntry(name, orderedArgs, helper.getFunctionDescription(name), propDetails);
        })
            .join('\n');
    }
    transformExamples(rawExamplesMarkdown, catalog) {
        const pattern = /```json\s*\n([\s\S]*?)\n```/g;
        return rawExamplesMarkdown.replace(pattern, (match, jsonContent) => this.replaceJsonBlock(match, jsonContent, catalog));
    }
    replaceJsonBlock(match, jsonContent, catalog) {
        try {
            const parsed = JSON.parse(jsonContent.trim());
            const messages = Array.isArray(parsed)
                ? parsed
                : typeof parsed === 'object' && parsed !== null
                    ? [parsed]
                    : [];
            if (messages.length === 0) {
                return match;
            }
            if (!messages.every(isTranslatableMessage)) {
                return match;
            }
            return this.decompileMessages(messages, catalog);
        }
        catch {
            // Mirrors prompt_generator.py:477 (except Exception:)
            return match;
        }
    }
    /**
     * Decompiles a list of messages into one sentinel-wrapped Express block.
     *
     * The list goes to the decompiler as a whole so that messages for the same surface
     * (e.g. `createSurface` followed by `updateComponents`) merge under a single
     * `surface(...)` header. Decompiling them one at a time would emit an empty
     * `surface(...)` scope per message, which fails to compile.
     *
     * @param messages The messages of one example.
     * @param catalog Optional catalog the example belongs to, used as the default catalog.
     */
    decompileMessages(messages, catalog) {
        const decompiler = new ExpressDecompiler(this.catalogs, this.version);
        const helper = catalog ? this.getHelper(catalog) : undefined;
        const normalized = withDefaultCatalog(messages, catalog?.id, this.version === '1.0', helper);
        return decompiler.wrap([
            { type: 'a2ui', a2uiRaw: decompiler.decompile(normalized), isFinal: true },
        ]);
    }
    renderExamples(catalog) {
        if (!this.examples || !this.examples[catalog.id]) {
            return '';
        }
        const exampleMessages = this.examples[catalog.id];
        if (typeof exampleMessages === 'string') {
            return this.transformExamples(exampleMessages, catalog);
        }
        if (Array.isArray(exampleMessages) && exampleMessages.length > 0) {
            if (Array.isArray(exampleMessages[0])) {
                const decompiler = new ExpressDecompiler(this.catalogs, this.version);
                const helper = this.getHelper(catalog);
                const blocks = [];
                for (const turn of exampleMessages) {
                    const dsl = decompiler.decompile(withDefaultCatalog(turn, catalog.id, this.version === '1.0', helper));
                    if (dsl) {
                        blocks.push(decompiler.wrap([{ type: 'a2ui', a2uiRaw: dsl, isFinal: true }]));
                    }
                }
                return blocks.join('\n\n');
            }
            return this.decompileMessages(exampleMessages, catalog);
        }
        return '';
    }
}
//# sourceMappingURL=prompt-generator.js.map