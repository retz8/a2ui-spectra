/**
 * Decompilation engine for A2UI Express.
 *
 * Reconstructs standard A2UI envelopes back into A2UI Express DSL code.
 */
import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { RawResponsePart } from '../../parser/response-part.js';
import { CatalogSchemaHelper } from './schema-helper.js';
/**
 * Wrapper for numeric literals that must retain raw formatting (e.g. floats like 1500.0).
 */
export declare class RawNumber {
    readonly value: string;
    constructor(value: string);
}
/**
 * Returns whether a data model value has anything to write.
 *
 * Only an empty object has nothing: an empty string, zero, `false` or an empty list at
 * a path is a value the renderer must receive.
 *
 * @param value The value of a data model write.
 */
export declare function hasDataToWrite(value: unknown): boolean;
/**
 * Flattens a nested dictionary dataModel structure into JSON Pointer path segments.
 *
 * A non-object value yields a single entry at the root path `''`.
 *
 * @param dataDict The nested data object, or any other JSON value.
 * @returns Array of [path, value] tuples.
 */
export declare function flattenDataModel(dataDict: unknown): Array<[string, unknown]>;
/**
 * Checks if a property schema defines a component reference (ComponentId or list of ComponentId).
 *
 * Catalog-agnostic: uses exact def name matching via `commonDefName` (plan §5.1, §5.2 item 6).
 *
 * @param propSchema The property JSON schema to inspect.
 * @returns True if property references component ID.
 */
export declare function isComponentReferenceProperty(propSchema: unknown): boolean;
/**
 * Writes a number the way ECMAScript `Number.prototype.toString` does, which is
 * the spelling the Express grammar and every SDK's decompiler agree on: plain
 * decimal for 1e-6 ≤ |v| < 1e21, otherwise exponent form such as `1e-7` or
 * `1.5e+21`. Negative zero is written `-0.0`, since `String(-0)` is `"0"`.
 *
 * @param val The number to decompile.
 * @returns The Express number literal.
 * @throws {A2uiValidationError} When `val` is `NaN` or infinite, which Express
 *   has no notation for.
 */
export declare function decompileNumber(val: number): string;
/**
 * Formats a string literal using the cleanest/most readable representation.
 *
 * @param val The string value to decompile.
 * @returns The quoted Express string literal.
 */
export declare function decompileString(val: string): string;
/**
 * Converts standard A2UI wire JSON trees back into A2UI Express syntax.
 */
export declare class ExpressDecompiler {
    readonly helpers: Map<string, CatalogSchemaHelper>;
    readonly catalogs: CatalogApi[];
    readonly protocolVersion: string;
    private readonly soleCatalogId;
    private readonly isV1;
    /**
     * @param catalogs The catalog, or several.
     * @param protocolVersion The protocol version of the messages.
     */
    constructor(catalogs: CatalogApi | CatalogApi[], protocolVersion: string);
    /**
     * Returns a helper that reads the system function a call names.
     *
     * A system function, such as `@index`, is defined by the protocol rather than a
     * catalog, so every helper of the version reads it.
     *
     * @throws {A2uiValidationError} If the version defines no system function of
     *   that name, or the call names a `catalogId`.
     */
    private systemFunctionHelper;
    /**
     * Resolves a component or function against its explicit or surface catalog, returning
     * the catalog's schema helper and the `catalogId` to write (if any).
     */
    private resolveSymbol;
    /**
     * Coalesces split surface messages (`createSurface` followed by `updateComponents` and
     * root `updateDataModel`) into the open `createSurface` for that surface, while keeping
     * incremental updates as separate messages.
     */
    private coalesceSurfaceMessages;
    /**
     * Formats a `surface(...)` statement line, omitting `catalogId`.
     */
    private formatSurfaceHeader;
    /**
     * Wraps raw response parts, adding format tags around A2UI payload sections.
     *
     * @param blocks A list of raw response parts.
     * @returns The formatted response string.
     */
    wrap(blocks: RawResponsePart[]): string;
    /**
     * Decompiles standard A2UI wire JSON into clean A2UI Express lines.
     *
     * @param messages Standard A2UI wire JSON message envelopes.
     * @param useKeywordArgs Whether to format component arguments as keyword parameters (e.g. param=value).
     * @returns The decompiled A2UI Express DSL string.
     */
    decompile(messages: AgentToRendererMessage[], useKeywordArgs?: boolean): string;
    private resolveSurfaceContext;
    private checkComponentIds;
    private collectVariableNames;
    private formatDataModelLines;
    private decompileDeleteSurface;
    private decompileCallFunction;
    private decompileUpdateDataModel;
    private decompileCreateSurface;
    private decompileUpdateComponents;
    private trimTrailingPlaceholders;
    private formatCheckPropertyArg;
    private formatRegularPropertyArg;
    /**
     * Returns the catalog override of a component, or undefined when it names none.
     *
     * From v1.0 the override is `@catalogId`. A bare `catalogId`, which v1.0
     * payloads used before the cutover, is read too, unless the component's
     * surface catalog declares `catalogId` as a property of the component.
     */
    private getComponentCatalogId;
    /**
     * Formats a single component definition into an Express assignment line.
     */
    private formatComponent;
    /**
     * Formats a check rule as `?funcName(...)` or `?funcName`.
     */
    private formatCheckRule;
    /**
     * Formats a function call object into an Express call string.
     */
    private formatFunctionCall;
    /**
     * Decompiles a single value node back to A2UI Express notation.
     *
     * @param val The JSON-serialized property value structure.
     * @param varNames Maps the ID of each component defined in the same block to its variable name.
     * @param isRef Whether this value is a component reference.
     * @param helper The schema helper of the value's catalog. Defaults to the first catalog.
     * @param surfaceCatalogId The catalog of the enclosing surface, if any.
     * @returns A plain-text representation of the value.
     */
    decompileValue(val: unknown, varNames: ReadonlyMap<string, string>, isRef?: boolean, helper?: CatalogSchemaHelper, surfaceCatalogId?: string | undefined): string;
}
//# sourceMappingURL=decompiler.d.ts.map