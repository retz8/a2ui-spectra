/**
 * @fileoverview Format definition and factory for A2UI Express DSL.
 */
import { InferenceFormat, InferenceFormatFactory } from '../../inference-format.js';
import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { Parser } from '../../parser/parser.js';
import { ExpressPromptGenerator } from './prompt-generator.js';
export interface ExpressFormatOptions {
    surfaceId?: string;
    version?: string;
    examples?: Record<string, AgentToRendererMessage[] | AgentToRendererMessage[][] | string>;
    allowedMessages?: readonly string[];
    progressiveKeys?: Iterable<string>;
}
export interface ExpressFormatFactoryOptions {
    surfaceId?: string;
    version?: string;
    allowedMessages?: readonly string[];
    progressiveKeys?: Iterable<string>;
}
/**
 * Express inference format implementation.
 */
export declare class ExpressFormat implements InferenceFormat {
    readonly promptGenerator: ExpressPromptGenerator;
    readonly progressiveKeys: ReadonlySet<string>;
    private readonly catalogs;
    private readonly surfaceId;
    private readonly version;
    constructor(catalogs: CatalogApi[], options?: ExpressFormatOptions);
    createParser(): Parser;
}
/**
 * Factory for creating ExpressFormat instances.
 */
export declare class ExpressFormatFactory implements InferenceFormatFactory {
    private readonly options;
    readonly progressiveKeys: ReadonlySet<string>;
    constructor(options?: ExpressFormatFactoryOptions);
    createFormat(catalogs: CatalogApi[], examples?: Record<string, AgentToRendererMessage[] | AgentToRendererMessage[][] | string>): InferenceFormat;
}
//# sourceMappingURL=format.d.ts.map