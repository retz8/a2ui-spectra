import { type AgentToRendererMessage, type CatalogApi } from '../../internal/web-core.js';
import { CatalogSchemaHelper, type ReservedKeys } from './schema-helper.js';
import { type ExpressCallNode, type ExpressStatement, type ExpressValue } from './visitor.js';
/**
 * Populates a nested dictionary or list path from an Express data path.
 *
 * @param d The target dictionary to mutate.
 * @param pathStr The data path string (e.g. "$/user/name" or "$/items/0/state").
 * @param val The value to set at the specified path.
 */
export declare function setNestedPath(d: Record<string, unknown>, pathStr: string, val: unknown): void;
/**
 * Checks if a parsed AST value represents a validation check expression (compiler.py:154-160).
 */
export declare function isCheckExpression(val: unknown): boolean;
/**
 * Formats an error for wrapping in another error's message. Syntax errors carry their
 * line number, which their own message leaves out.
 */
export declare function formatErrorMessage(e: unknown): string;
/**
 * Raised during streaming when an expression references an undefined value variable.
 */
export declare class PendingVariableError extends Error {
    readonly varName: string;
    constructor(varName: string);
}
/**
 * Holds mutable state for a single compiler execution pass (compiler.py:166-173).
 */
declare class CompileContext {
    extraComponents: Record<string, unknown>[];
    generatedIds: Set<string>;
    inlineCounter: number;
    callCounter: number;
    /** Compiled data bindings of the component being compiled, by property name. */
    activeBoundPaths: Map<string, Record<string, unknown>>;
    /** The variables whose values are being compiled, to catch a variable whose value refers back to it. */
    readonly resolving: Set<string>;
    /** Variable names referenced while compiling a single node or data path. */
    readonly referencedVars: Set<string>;
    readonly keys: ReservedKeys;
    /** The protocol version being compiled to. */
    readonly version: string;
    readonly allowPending: boolean;
    constructor(keys: ReservedKeys, version: string, allowPending?: boolean);
}
/**
 * Holds symbols and data path assignments for a target surface scope (compiler.py:175-183).
 */
declare class SurfaceScope {
    readonly surfaceId: string;
    readonly hasSurfaceDirective: boolean;
    readonly sendDataModel?: boolean;
    readonly update: boolean;
    readonly rawExtensions?: ExpressValue;
    readonly rawSymbols: Record<string, unknown>;
    readonly dataPathAssignments: Record<string, unknown>;
    constructor(surfaceId: string, sendDataModel?: boolean, update?: boolean, hasSurfaceDirective?: boolean, rawExtensions?: ExpressValue);
}
type CompilationUnit = {
    kind: 'scope';
    scope: SurfaceScope;
} | {
    kind: 'delete';
    surfaceId: string;
} | {
    kind: 'call';
    stmt: ExpressCallNode;
    scope: SurfaceScope | null;
};
interface CachedComponentEntry {
    ast: unknown;
    comps: Record<string, unknown>[];
    deps: Map<string, [unknown, string | undefined]>;
    startInline: number;
    inlineDelta: number;
    generatedIds: string[];
}
interface CachedDataEntry {
    ast: unknown;
    val: unknown;
    deps: Map<string, [unknown, string | undefined]>;
}
interface ScopeStreamState {
    surfaceId: string;
    surfaceCreated: boolean;
    emittedComponents: Map<string, string>;
    emittedDataPaths: Map<string, string>;
    varIds: Map<string, string>;
    compiledCache: Map<string, CachedComponentEntry>;
    dataCache: Map<string, CachedDataEntry>;
}
/**
 * Options for initializing an `ExpressScopeSession`.
 */
export interface ExpressScopeSessionOptions {
    surfaceId?: string;
    version?: string;
}
/**
 * Tracks incremental statement compilation across chunks of an `<a2ui>` block.
 */
export declare class ExpressScopeSession {
    readonly compiler: ExpressCompiler;
    readonly surfaceId: string;
    readonly version: string;
    hasEmitted: boolean;
    supersededComponents: Array<[string, string]>;
    private scopeStates;
    private emittedUnits;
    private cachedPrefix;
    private cachedStatements;
    constructor(compiler: ExpressCompiler, options?: ExpressScopeSessionOptions);
    /**
     * Captures a copy of the session's emitted state so a speculative step can roll back.
     */
    snapshot(): {
        hasEmitted: boolean;
        supersededComponents: Array<[string, string]>;
        scopeStates: Map<number, ScopeStreamState>;
        emittedUnits: Set<number>;
        cachedPrefix: string;
        cachedStatements: ExpressStatement[];
    };
    /**
     * Restores a snapshot captured by `snapshot()`.
     */
    restore(saved: ReturnType<ExpressScopeSession['snapshot']>): void;
    /**
     * Compiles any newly ready statements from `dslText` into delta messages.
     */
    compileStep(dslText: string, options: {
        isFinal: boolean;
        existingSurfaces: ReadonlySet<string>;
        cachePrefix?: boolean;
    }): AgentToRendererMessage[];
    private parseIncrementalStatements;
    private compileUnit;
    private compileCallUnit;
    private compileScopeDelta;
    private compileInitialCreate;
    private compileIncrementalUpdates;
    private earlierScopeComponent;
    private collectReadyComponents;
    private collectReadyData;
    private buildDataUpdates;
}
/**
 * Compilation pipeline for A2UI Express.
 *
 * Resolves positional parameters dynamically, flattens variable references into
 * an adjacency list component tree, and constructs valid A2UI JSON payloads.
 */
export declare class ExpressCompiler {
    readonly helpers: Map<string, CatalogSchemaHelper>;
    readonly catalogs: CatalogApi[];
    readonly version: string;
    /**
     * @param catalogs The active catalog, or several.
     * @param version The protocol version to emit. Defaults to the catalogs' version.
     */
    constructor(catalogs: CatalogApi | CatalogApi[], version?: string);
    /** Helpers for the system functions of versions that `compile` overrides, by version. */
    private readonly systemFunctionHelpers;
    /**
     * Checks whether a call names a component rather than a function across active catalogs.
     */
    private definesComponent;
    /**
     * Checks whether a call names a function across active catalogs or in the named catalog.
     *
     * A name starting with `@` is always a function call: no component can have one, and a
     * call to a system function, which no catalog defines, is checked when it is compiled.
     */
    private definesFunction;
    /**
     * Resolves a component or function symbol against the active catalogs.
     */
    private resolveSymbol;
    /**
     * Parses and validates a `surface(...)` statement.
     */
    private parseSurfaceCall;
    private resolveAstVar;
    private checkExtensionsAst;
    /**
     * Compiles and validates an `extensions=` keyword argument into a UAX #31-keyed map.
     */
    private compileExtensionsMap;
    /**
     * Strips sentinel tags and parses the DSL body into statements.
     */
    parseStatements(dslText: string, isFinal: boolean, stripSentinels?: boolean): ExpressStatement[];
    /**
     * Groups parsed AST statements into surface scopes, deletes, and standalone calls.
     */
    buildUnits(statements: ExpressStatement[], surfaceId: string, targetMajorMinor: [number, number]): CompilationUnit[];
    private appendExprUnit;
    private assignToScope;
    private parseDeleteSurfaceId;
    /**
     * Compiles a standalone function call into a `callRendererFunction` message.
     */
    compileStandaloneCall(stmt: ExpressCallNode, scope: SurfaceScope | null, ctx: CompileContext, targetVersion: string, targetMajorMinor: [number, number]): AgentToRendererMessage;
    /**
     * Collects the resolved component ID for every component variable in `scope`.
     */
    collectComponentIds(scope: SurfaceScope, targetMajorMinor: [number, number]): Map<string, string>;
    /**
     * Compiles the `surface(extensions=...)` argument of `scope` into
     * `createSurface.metadata`, or returns undefined when none was given.
     */
    compileSurfaceMetadata(scope: SurfaceScope, compIds: Map<string, string>, ctx: CompileContext, targetMajorMinor: [number, number]): Record<string, unknown> | undefined;
    /**
     * Builds the `createSurface` message(s) for a surface creation scope.
     */
    buildCreateMessages(scope: SurfaceScope, compiledComponents: Record<string, unknown>[], dataModel: Record<string, unknown>, targetVersion: string, metadata?: Record<string, unknown>): AgentToRendererMessage[];
    /**
     * Compiles a single variable's AST node for an incremental `ExpressScopeSession`.
     */
    compileAstNodeForSession(varName: string, ast: unknown, rawSymbols: Record<string, unknown>, compIds: Map<string, string>, ctx: CompileContext, targetMajorMinor: [number, number]): Record<string, unknown> | null;
    /**
     * Compiles a data path value for an incremental `ExpressScopeSession`.
     */
    compileDataValue(scope: SurfaceScope, astVal: unknown, compIds: Map<string, string>, ctx: CompileContext, targetMajorMinor: [number, number]): unknown;
    /**
     * Compiles plain A2UI Express DSL into standard A2UI wire messages.
     *
     * @param dslText The source A2UI Express DSL text block.
     * @param surfaceId The unique identifier for the compiled surface.
     * @param isFinal Whether this is the final compilation pass.
     * @param version Target version override ("v0.9", "v0.9.1", or "v1.0").
     * @returns A list of standard A2UI wire JSON message dicts.
     */
    compile(dslText: string, surfaceId?: string, isFinal?: boolean, version?: string): AgentToRendererMessage[];
    /**
     * Compiles a single surface scope into createSurface, updateComponents, and/or updateDataModel messages.
     */
    private compileScope;
    private compileUpdateScope;
    /**
     * Compiles a single variable's AST node into standard component format (compiler.py:471-643).
     *
     * @param varName The variable identifier (which becomes component ID unless `id=` is set).
     * @param ast The parsed expression AST node.
     * @param rawSymbols Parsed global variable symbol table.
     * @param compIds Mapping from variable names to resolved component IDs.
     * @param ctx Active compiler execution context.
     * @param targetMajorMinor Target major and minor protocol version numbers.
     * @returns The compiled component JSON dictionary, or null if not a component.
     */
    private _compileAstNode;
    /**
     * Compiles a `?check(...)` expression into a condition and failure message.
     */
    private compileCheckCall;
    /**
     * Compiles a function call AST node into a wire function call object.
     */
    private compileFunctionCall;
    /**
     * Compiles a call to a system function, such as `@index(offset=1)`.
     *
     * A system function is defined by the protocol, not a catalog, so it is looked
     * up in the protocol version's common types before any catalog, and the compiled
     * call never carries a `catalogId`. An empty argument list is left out, since a
     * system function's `args` are optional.
     *
     * @throws {ExpressValidationError} If the target version defines no system
     *   function of that name, or the call names a `catalogId`.
     */
    private compileSystemCall;
    /**
     * Checks a system function call and returns the helper that reads it.
     *
     * The helper reads the system functions of `version`, the compilation's target, which
     * `compile(dsl, surfaceId, version)` can set apart from the compiler's own version.
     *
     * @throws {ExpressValidationError} If `version` defines no system function of that
     *   name, or the call names a `catalogId`.
     */
    private systemFunctionHelper;
    /**
     * Maps a function call's positional and keyword arguments to its parameters.
     */
    private compileCallArgs;
    /**
     * Compiles the reserved `Event(name, context?, userMessage=?, context=?)` signature.
     *
     * `userMessage` is a v1.0 Action field. It is rejected when targeting an earlier
     * protocol version, and so is any other keyword the signature does not define,
     * rather than being dropped from the compiled action.
     *
     * The event's name, message and context entries are `DynamicValue`s, not actions, so a
     * function call among them stays a plain call whatever slot the event itself sits in.
     */
    private compileEventCall;
    /**
     * Compiles an individual AST node value into valid A2UI equivalents (compiler.py:644-838).
     *
     * @param val The parsed AST node value.
     * @param rawSymbols Parsed global variable symbol table.
     * @param compIds Mapping from variable names to resolved component IDs.
     * @param ctx Active compiler execution context.
     * @param targetMajorMinor Target major and minor protocol version numbers.
     * @param isAction Whether this value lies inside a component Action field.
     * @param inlineCtx Position used to derive deterministic ids for inline components.
     * @param allowComponentRef Whether an undefined variable in this slot is a forward component ID reference.
     * @param allowListComponentRefs Whether elements of a list in this slot are forward component ID references.
     * @param slot The catalog schema declared at this position, when known. Array items
     *   and map entries resolve their own sub-schema from it, so an `Action` slot nested
     *   inside a list item (e.g. `items: [{label, action}]`) is compiled as an action too.
     * @returns The semantically correct A2UI JSON structure.
     */
    private _compileValue;
    private compileMapLiteral;
    private compileVariableRef;
    private compileCallValue;
    private compileTemplateHelper;
    private compileInlineComponent;
    /**
     * Validates dynamic databindings against the schema (sanctioned departure §5.2 item 5).
     *
     * Walks the AST value alongside the schema. At each node, a `$path` is allowed iff
     * `helper.admitsPath(schemaAtThisPosition)`. Descends into arrays via schema `items`,
     * into map literals via `properties[key]`, and into the value of a referenced
     * variable. Walking the AST rather than the compiled value means a map literal whose
     * keys are named like a call, an event or a function call is still searched. Calls,
     * checks, events and templates are not searched, since they resolve their own
     * arguments. If schema cannot be determined at a position, the binding is treated
     * as allowed.
     */
    private _checkDataBindings;
}
export {};
//# sourceMappingURL=compiler.d.ts.map