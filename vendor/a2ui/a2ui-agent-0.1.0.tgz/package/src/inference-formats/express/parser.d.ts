/**
 * @fileoverview Concrete parser implementation for A2UI Express DSL responses.
 *
 * Tokenizes response text into format blocks and conversational text,
 * delegating compilation to ExpressCompiler and decompilation to ExpressDecompiler.
 */
import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { ContinuingStreamOptions, Parser, StreamOptions } from '../../parser/parser.js';
import { RawResponsePart, StreamPart } from '../../parser/response-part.js';
import { ExpressResponseStream } from './response-stream.js';
/** Options for configuring an `ExpressParser`. */
export interface ExpressParserOptions {
    progressiveKeys?: ReadonlySet<string> | Iterable<string>;
}
/**
 * Concrete parser implementation for A2UI Express DSL responses.
 */
export declare class ExpressParser extends Parser {
    readonly catalogs: CatalogApi[];
    readonly surfaceId: string;
    readonly version: string;
    readonly progressiveKeys: ReadonlySet<string>;
    private readonly lexer;
    private readonly decompiler;
    /**
     * Initializes the Express parser with catalog schemas and target version.
     *
     * @param catalogs The component catalog, or several. A `surface(...)` line picks one by id.
     * @param surfaceId Surface identifier for compiled messages.
     * @param version Target A2UI protocol version ("v0.9", "v0.9.1", or "v1.0").
     * @param options Optional streaming and parser configuration.
     */
    constructor(catalogs: CatalogApi | CatalogApi[], surfaceId?: string, version?: string, options?: ExpressParserOptions);
    get supportsStreaming(): boolean;
    openStream(options: ContinuingStreamOptions): ExpressResponseStream<StreamPart>;
    openStream(options?: StreamOptions): ExpressResponseStream;
    hasFormatContent(content: string, { complete }?: {
        complete?: boolean;
    }): boolean;
    /**
     * Unwraps response content into raw Express DSL parts and conversational text.
     */
    unwrap(content: string): RawResponsePart[];
    /**
     * Compiles raw Express DSL into structured A2UI messages.
     */
    compile(formatContent: string, isFinal?: boolean): AgentToRendererMessage[];
    /**
     * Decompiles structured A2UI messages back into Express notation.
     */
    decompile(messages: AgentToRendererMessage[]): string;
    /**
     * Wraps raw response parts, adding format tags around A2UI payload sections.
     */
    wrap(blocks: RawResponsePart[]): string;
}
//# sourceMappingURL=parser.d.ts.map