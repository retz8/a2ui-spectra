/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Utility for parsing A2UI component and function catalogs for Express inference format.
 *
 * Resolves component properties, functions, and requirements in strict schema definition
 * order to support positional parameter mapping.
 */
import { A2uiCatalogError } from '../../errors.js';
import { V09_STANDARD_DEFS, V10_STANDARD_DEFS } from '../../internal/web-core.js';
import { toWireProtocolVersion } from '../../utils/protocol-version.js';
const COMMON_DEF_REGEX = /(?:^|\/)common_types\.json#\/(?:\$defs|definitions)\/(\w+)$/;
/**
 * Recognizes protocol common types referenced via `$ref` into `common_types.json`.
 *
 * Matches both relative paths (`common_types.json#/$defs/<Name>`) and absolute URLs
 * (`https://a2ui.org/specification/.../common_types.json#/$defs/<Name>`), under either
 * `$defs` or the older `definitions`.
 *
 * @param ref The `$ref` string to inspect.
 * @returns The def name if pointing into `common_types.json`, or undefined.
 */
export function commonDefName(ref) {
    if (typeof ref !== 'string') {
        return undefined;
    }
    const match = COMMON_DEF_REGEX.exec(ref);
    return match ? match[1] : undefined;
}
/**
 * The four envelope mixin names that `ComponentCommon` and `Checkable` add to
 * component objects (`id` and `component` stay bare in all protocol versions).
 */
export const ENVELOPE_MIXIN_NAMES = ['catalogId', 'metadata', 'accessibility', 'checks'];
/** The `@`-prefixed v1.0 wire keys for the component envelope mixins. */
export const AT_ENVELOPE_MIXIN_KEYS = new Set(ENVELOPE_MIXIN_NAMES.map(name => `@${name}`));
const STANDARD_CATALOG_ID_DESCRIPTION = 'The catalog ID for this component, overriding any surface-level default catalogId.';
const STANDARD_METADATA_DESCRIPTION = 'Optional component-level metadata for vendor extensions.';
function isStandardCatalogIdSchema(schema) {
    return (Boolean(schema) &&
        typeof schema === 'object' &&
        schema.description === STANDARD_CATALOG_ID_DESCRIPTION);
}
function isStandardMetadataSchema(schema) {
    if (!schema || typeof schema !== 'object') {
        return false;
    }
    const s = schema;
    if (s.description === STANDARD_METADATA_DESCRIPTION) {
        return true;
    }
    const props = s.properties;
    if (props && typeof props === 'object') {
        const ext = props.extensions;
        if (ext &&
            typeof ext === 'object' &&
            commonDefName(ext.$ref) === 'Extensions') {
            return true;
        }
    }
    return false;
}
function isStandardAccessibilitySchema(schema) {
    return (Boolean(schema) &&
        typeof schema === 'object' &&
        commonDefName(schema.$ref) === 'AccessibilityAttributes');
}
/**
 * Returns the wire key to write for an envelope mixin on a component object.
 */
export function envelopeKey(name, atLeastV10) {
    return atLeastV10 ? `@${name}` : name;
}
/**
 * Returns the key under which `component` holds envelope mixin `name`, or undefined.
 *
 * On v1.0, prefers `@<name>`, falling back to legacy bare `<name>` only when `<name>`
 * is not declared as a custom property of the component.
 */
export function envelopeReadKey(component, name, atLeastV10, customProperties) {
    if (atLeastV10) {
        const atKey = `@${name}`;
        if (Object.hasOwn(component, atKey)) {
            return atKey;
        }
        if (customProperties?.has(name)) {
            return undefined;
        }
    }
    return Object.hasOwn(component, name) ? name : undefined;
}
/**
 * Reads an envelope mixin value from a component object, or returns undefined.
 */
export function getEnvelopeValue(component, name, atLeastV10, customProperties) {
    const key = envelopeReadKey(component, name, atLeastV10, customProperties);
    return key !== undefined ? component[key] : undefined;
}
/**
 * Checks whether a property schema is an Action slot.
 *
 * A property is an action slot when its schema references the common `Action` def,
 * directly or through `oneOf`/`anyOf`/`allOf`.
 *
 * @param schema The property JSON schema to inspect.
 * @returns True if the schema references the common `Action` type.
 */
export function isActionSlot(schema) {
    if (!schema || typeof schema !== 'object') {
        return false;
    }
    const s = schema;
    if (typeof s.$ref === 'string' && commonDefName(s.$ref) === 'Action') {
        return true;
    }
    for (const key of ['allOf', 'oneOf', 'anyOf']) {
        const list = s[key];
        if (Array.isArray(list) && list.some(sub => isActionSlot(sub))) {
            return true;
        }
    }
    return false;
}
/**
 * Checks if a property's schema expects a list of objects with label/value properties.
 *
 * Ported verbatim from Python's `_schema_expects_option_objects` (compiler.py:124-152).
 * Sanctioned exception: plan §5.2 item 2.
 *
 * @param schema The property JSON schema to inspect.
 * @returns True if schema expects option objects.
 */
export function expectsOptionObjects(schema) {
    if (!schema || typeof schema !== 'object') {
        return false;
    }
    const s = schema;
    if ('items' in s) {
        const itemsSchema = s.items;
        const hasLabelValue = (sub) => {
            if (!sub || typeof sub !== 'object') {
                return false;
            }
            const subObj = sub;
            if (subObj.properties &&
                typeof subObj.properties === 'object' &&
                'label' in subObj.properties &&
                'value' in subObj.properties) {
                return true;
            }
            for (const k of ['allOf', 'oneOf', 'anyOf']) {
                const list = subObj[k];
                if (Array.isArray(list)) {
                    if (list.some(hasLabelValue)) {
                        return true;
                    }
                }
            }
            return false;
        };
        return hasLabelValue(itemsSchema);
    }
    for (const key of ['allOf', 'oneOf', 'anyOf']) {
        const list = s[key];
        if (Array.isArray(list)) {
            if (list.some(sub => expectsOptionObjects(sub))) {
                return true;
            }
        }
    }
    return false;
}
/**
 * Dynamic schema crawler for A2UI catalogs used by Express format.
 */
/**
 * Returns the `$ref` of a schema when it points inside the same document (`#/...`).
 *
 * @param sub The schema to inspect.
 * @returns The local reference, or undefined.
 */
function localRef(sub) {
    if (!sub || typeof sub !== 'object') {
        return undefined;
    }
    const ref = sub.$ref;
    return typeof ref === 'string' && ref.startsWith('#/') ? ref : undefined;
}
/**
 * Returns the common type definitions (`common_types.json` `$defs`) for a protocol
 * version, as web_core generates them from the specification.
 */
function standardDefsFor(protocolVersion) {
    switch (toWireProtocolVersion(protocolVersion)) {
        case 'v0.9':
        case 'v0.9.1':
            return V09_STANDARD_DEFS;
        case '1.0':
            return V10_STANDARD_DEFS;
        default:
            throw new A2uiCatalogError(`No common types for protocol version '${protocolVersion}'.`);
    }
}
/**
 * Returns the system functions that a protocol version's common types define.
 *
 * A system function is defined by the protocol rather than by a catalog: it is
 * a common types `$defs` entry whose `@call` property is a constant name
 * starting with `@`, such as `@index` from v1.0. It has the same shape as a
 * catalog function, so the same code reads its arguments.
 *
 * @param defs The common types `$defs` of a protocol version.
 * @returns The system function schemas keyed by their `@` name, which is empty
 *   for a version that defines none.
 */
export function systemFunctionSchemas(defs) {
    const found = new Map();
    for (const schema of Object.values(defs ?? {})) {
        if (!schema || typeof schema !== 'object') {
            continue;
        }
        const props = schema.properties;
        const call = props && typeof props === 'object' ? props['@call'] : undefined;
        const name = call && typeof call === 'object' ? call.const : undefined;
        if (typeof name === 'string' && name.startsWith('@')) {
            found.set(name, schema);
        }
    }
    return found;
}
/**
 * Returns the wire keys for data bindings and function calls in a protocol version.
 */
function reservedKeysFor(protocolVersion) {
    switch (toWireProtocolVersion(protocolVersion)) {
        case 'v0.9':
        case 'v0.9.1':
            return { path: 'path', call: 'call' };
        default:
            return { path: '@path', call: '@call' };
    }
}
export class CatalogSchemaHelper {
    constructor(catalog, protocolVersion) {
        this.componentProperties = new Map();
        this.componentRequired = new Map();
        this.checkRuleProperties = new Map();
        this.inheritedCheckRulePropertyNames = new Map();
        this.inheritedCheckRuleSchemas = new Map();
        this.customEnvelopeProperties = new Map();
        this.componentPropertyEnums = new Map();
        this.functionProperties = new Map();
        this.functionRequired = new Map();
        this.systemFunctionProperties = new Map();
        this.systemFunctionRequired = new Map();
        this.catalog = catalog.toJson();
        try {
            this.commonTypes = { $defs: standardDefsFor(protocolVersion) };
            this.commonTypesLoaded = true;
        }
        catch {
            this.commonTypes = { $defs: {} };
            this.commonTypesLoaded = false;
        }
        this.keys = reservedKeysFor(protocolVersion);
        this.systemFunctions = systemFunctionSchemas(this.commonTypes.$defs);
        const rawComponents = (this.catalog.components ?? {});
        const componentsMap = new Map();
        for (const [name, schema] of Object.entries(rawComponents)) {
            if (catalog.components.has(name) && schema && typeof schema === 'object') {
                componentsMap.set(name, schema);
            }
        }
        this.components = componentsMap;
        const rawFunctions = (this.catalog.functions ?? {});
        const functionsMap = new Map();
        for (const [name, schema] of Object.entries(rawFunctions)) {
            if (catalog.functions.has(name) && schema && typeof schema === 'object') {
                functionsMap.set(name, schema);
            }
        }
        this.functions = functionsMap;
        this.loadMappings();
    }
    lookupCommonDef(defName) {
        const defs = this.commonTypes.$defs ??
            this.commonTypes.definitions;
        return defs ? defs[defName] : undefined;
    }
    resolveJsonPointer(root, pointer) {
        if (!pointer.startsWith('#/')) {
            return undefined;
        }
        const parts = pointer.slice(2).split('/');
        let current = root;
        for (const part of parts) {
            if (!current || typeof current !== 'object') {
                return undefined;
            }
            const unescaped = part.replace(/~1/g, '/').replace(/~0/g, '~');
            current = current[unescaped];
        }
        return current;
    }
    /**
     * Resolves a schema that is a local `#/...` reference against the catalog.
     *
     * @param sub The schema that may be a reference.
     * @returns The referenced schema, or undefined if `sub` is not a local reference.
     */
    resolveLocalRef(sub) {
        const ref = localRef(sub);
        return ref ? this.resolveJsonPointer(this.catalog, ref) : undefined;
    }
    /**
     * Lists the sub-schemas of a component in the order its properties are read.
     *
     * The component's own schema comes first, so its own definition of a property
     * overrides an inherited one. Then come the allOf entries that declare
     * `component` (the specific schemas), then the other allOf entries (the
     * common mixins). Each allOf entry is expanded depth first: a local `#/...`
     * reference is resolved against the catalog, and the entries of its own
     * allOf follow it. References into `common_types.json` are kept as is.
     *
     * @param schema The component schema.
     * @returns The ordered sub-schemas.
     */
    orderedComponentSubSchemas(schema) {
        const specific = [];
        const inherited = [];
        if (Array.isArray(schema.allOf)) {
            for (let sub of schema.allOf) {
                if (localRef(sub)) {
                    const resolved = this.resolveLocalRef(sub);
                    if (resolved && typeof resolved === 'object') {
                        sub = resolved;
                    }
                }
                if (!sub || typeof sub !== 'object') {
                    continue;
                }
                const subObj = sub;
                const props = subObj.properties;
                if (props &&
                    typeof props === 'object' &&
                    'component' in props) {
                    specific.push(subObj);
                }
                else {
                    inherited.push(subObj);
                }
            }
        }
        const expanded = [schema];
        const visited = new Set([schema]);
        const expand = (node) => {
            let target = node;
            if (localRef(target)) {
                const resolved = this.resolveLocalRef(target);
                if (resolved && typeof resolved === 'object') {
                    target = resolved;
                }
            }
            if (visited.has(target)) {
                return;
            }
            visited.add(target);
            expanded.push(target);
            if (Array.isArray(target.allOf)) {
                for (const child of target.allOf) {
                    if (child && typeof child === 'object') {
                        expand(child);
                    }
                }
            }
        };
        for (const s of [...specific, ...inherited]) {
            expand(s);
        }
        return expanded;
    }
    getCheckRuleDefName(ref) {
        if (typeof ref !== 'string') {
            return undefined;
        }
        const commonName = commonDefName(ref);
        if (commonName) {
            return commonName;
        }
        if (ref.startsWith('#/$defs/')) {
            return ref.slice(8);
        }
        if (ref.startsWith('#/definitions/')) {
            return ref.slice(14);
        }
        return undefined;
    }
    isCheckRuleArraySchema(propSchema) {
        if (!propSchema || typeof propSchema !== 'object') {
            return false;
        }
        const s = propSchema;
        if (s.type !== 'array') {
            return false;
        }
        const items = s.items;
        if (!items || typeof items !== 'object') {
            return false;
        }
        const itemsRef = items.$ref;
        return commonDefName(itemsRef) === 'CheckRule';
    }
    loadMappings() {
        const findEnum = (s) => {
            if (s && typeof s === 'object') {
                let obj = s;
                const visitedPointers = new Set();
                let ref = localRef(obj);
                while (ref) {
                    if (visitedPointers.has(ref)) {
                        break;
                    }
                    visitedPointers.add(ref);
                    const resolved = this.resolveJsonPointer(this.catalog, ref);
                    if (resolved && typeof resolved === 'object') {
                        obj = resolved;
                        ref = localRef(obj);
                    }
                    else {
                        break;
                    }
                }
                if (Array.isArray(obj.enum)) {
                    return obj.enum;
                }
                for (const k of ['oneOf', 'anyOf', 'allOf']) {
                    const list = obj[k];
                    if (Array.isArray(list)) {
                        for (const subS of list) {
                            const res = findEnum(subS);
                            if (res) {
                                return res;
                            }
                        }
                    }
                }
            }
            return undefined;
        };
        for (const [name, schema] of this.components.entries()) {
            const props = {};
            const reqs = [];
            const subSchemas = this.orderedComponentSubSchemas(schema);
            // Checkability (plan §5.2 item 4):
            // (a) own property whose schema is {type: 'array', items: {$ref: <common_types CheckRule>}}
            let ownCheckProp;
            for (const subObj of subSchemas) {
                if (subObj.$ref) {
                    continue;
                }
                if (subObj.properties && typeof subObj.properties === 'object') {
                    for (const [pk, pv] of Object.entries(subObj.properties)) {
                        if (this.isCheckRuleArraySchema(pv)) {
                            if (pk === '@checks') {
                                ownCheckProp = 'checks';
                                this.inheritedCheckRuleSchemas.set(name, pv);
                            }
                            else {
                                ownCheckProp = pk;
                            }
                            break;
                        }
                    }
                }
                if (ownCheckProp) {
                    break;
                }
            }
            // (b) inherited property from allOf $ref into common_types
            let inheritedCheckProp;
            let inheritedSchema;
            if (!ownCheckProp) {
                for (const subObj of subSchemas) {
                    if (typeof subObj.$ref !== 'string') {
                        continue;
                    }
                    const defName = commonDefName(subObj.$ref);
                    if (defName) {
                        const commonDef = this.lookupCommonDef(defName);
                        if (commonDef && typeof commonDef === 'object') {
                            const commonObj = commonDef;
                            if (commonObj.properties && typeof commonObj.properties === 'object') {
                                for (const [pk, pv] of Object.entries(commonObj.properties)) {
                                    if (pv && typeof pv === 'object') {
                                        const propObj = pv;
                                        if (propObj.type === 'array' &&
                                            propObj.items &&
                                            typeof propObj.items === 'object') {
                                            const itemsRef = propObj.items.$ref;
                                            if (this.getCheckRuleDefName(itemsRef) === 'CheckRule') {
                                                inheritedCheckProp = pk === '@checks' ? 'checks' : pk;
                                                inheritedSchema = propObj;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (inheritedCheckProp) {
                        break;
                    }
                }
            }
            if (ownCheckProp) {
                this.checkRuleProperties.set(name, ownCheckProp);
            }
            else if (inheritedCheckProp) {
                this.checkRuleProperties.set(name, inheritedCheckProp);
                this.inheritedCheckRulePropertyNames.set(name, inheritedCheckProp);
                if (inheritedSchema) {
                    this.inheritedCheckRuleSchemas.set(name, inheritedSchema);
                }
            }
            for (const subObj of subSchemas) {
                if (subObj.properties && typeof subObj.properties === 'object') {
                    // `subSchemas` lists the component's own schema first, then its
                    // specific allOf entries, then its mixins, each with its nested
                    // allOf. The first definition of a property wins, as in
                    // `getPropertySchema`, so the component's own definition overrides
                    // an inherited one, and a property keeps the position where it is
                    // first declared.
                    for (const [pk, pv] of Object.entries(subObj.properties)) {
                        if (Object.hasOwn(props, pk)) {
                            continue;
                        }
                        props[pk] = pv;
                        const enumVal = findEnum(pv);
                        if (enumVal) {
                            this.componentPropertyEnums.set(`${name}.${pk}`, enumVal);
                        }
                    }
                }
                if (Array.isArray(subObj.required)) {
                    for (const r of subObj.required) {
                        if (!reqs.includes(r)) {
                            reqs.push(r);
                        }
                    }
                }
            }
            const isStandardCheckable = ownCheckProp === 'checks' || inheritedCheckProp === 'checks';
            const customEnvelope = new Set();
            for (const mixinName of ENVELOPE_MIXIN_NAMES) {
                if (Object.hasOwn(props, mixinName)) {
                    customEnvelope.add(mixinName);
                }
            }
            if (customEnvelope.has('checks') && this.isCheckRuleArraySchema(props.checks)) {
                customEnvelope.delete('checks');
            }
            if (customEnvelope.has('catalogId') && isStandardCatalogIdSchema(props.catalogId)) {
                customEnvelope.delete('catalogId');
            }
            if (customEnvelope.has('metadata') && isStandardMetadataSchema(props.metadata)) {
                customEnvelope.delete('metadata');
            }
            if (customEnvelope.has('accessibility') &&
                isStandardAccessibilitySchema(props.accessibility)) {
                customEnvelope.delete('accessibility');
            }
            this.customEnvelopeProperties.set(name, customEnvelope);
            const excluded = new Set(['component', 'id', ...AT_ENVELOPE_MIXIN_KEYS]);
            for (const mixinName of ['catalogId', 'metadata', 'accessibility']) {
                if (!customEnvelope.has(mixinName)) {
                    excluded.add(mixinName);
                }
            }
            if (isStandardCheckable && !customEnvelope.has('checks')) {
                excluded.add('checks');
            }
            const orderedKeys = [];
            for (const k of Object.keys(props)) {
                if (!excluded.has(k)) {
                    orderedKeys.push(k);
                }
            }
            if (isStandardCheckable && !customEnvelope.has('checks')) {
                orderedKeys.push('checks');
            }
            else if (inheritedCheckProp &&
                !customEnvelope.has(inheritedCheckProp) &&
                !orderedKeys.includes(inheritedCheckProp)) {
                orderedKeys.push(inheritedCheckProp);
            }
            this.componentProperties.set(name, orderedKeys);
            this.componentRequired.set(name, reqs);
        }
        for (const [name, schema] of this.functions.entries()) {
            const [props, reqs] = this.functionSignature(schema);
            this.functionProperties.set(name, props);
            this.functionRequired.set(name, reqs);
        }
        // System function names start with `@`, which no catalog function name
        // can, so they share the lookups without shadowing anything.
        for (const [name, schema] of this.systemFunctions.entries()) {
            const [props, reqs] = this.functionSignature(schema);
            this.systemFunctionProperties.set(name, props);
            this.systemFunctionRequired.set(name, reqs);
        }
    }
    /**
     * Returns a function schema's argument names in order, and the required ones.
     */
    functionSignature(schema) {
        const subSchemas = [schema];
        const localRefs = [];
        if (Array.isArray(schema.allOf)) {
            for (const sub of schema.allOf) {
                if (localRef(sub)) {
                    localRefs.push(sub);
                }
                else {
                    subSchemas.push(sub);
                }
            }
        }
        subSchemas.push(...localRefs);
        const props = {};
        const reqs = [];
        for (let sub of subSchemas) {
            if (!sub || typeof sub !== 'object') {
                continue;
            }
            if (localRef(sub)) {
                const resolved = this.resolveLocalRef(sub);
                if (resolved && typeof resolved === 'object') {
                    sub = resolved;
                }
            }
            const subObj = sub;
            if (subObj.properties && typeof subObj.properties === 'object') {
                const argsObj = subObj.properties.args;
                if (argsObj && typeof argsObj === 'object') {
                    const argsProps = argsObj.properties;
                    if (argsProps && typeof argsProps === 'object') {
                        Object.assign(props, argsProps);
                    }
                    const argsReq = argsObj.required;
                    if (Array.isArray(argsReq)) {
                        reqs.push(...argsReq);
                    }
                }
            }
        }
        return [Object.keys(props), reqs];
    }
    /** Returns the schema of a catalog or system function, or undefined. */
    functionSchema(name) {
        return this.functions.get(name) ?? this.systemFunctions.get(name);
    }
    /**
     * Returns the ordered properties of the specified component.
     */
    getComponentProperties(name) {
        return this.componentProperties.get(name) ?? [];
    }
    /**
     * Returns the list of required properties for the specified component.
     */
    getComponentRequired(name) {
        return this.componentRequired.get(name) ?? [];
    }
    /**
     * Returns whether the specified component supports client-side checks.
     */
    isCheckable(name) {
        return this.getCheckRuleProperty(name) !== undefined;
    }
    /**
     * Returns the check-rule property name for the specified component, or undefined.
     */
    getCheckRuleProperty(name) {
        return this.checkRuleProperties.get(name);
    }
    /**
     * Returns the bare envelope mixin names (`catalogId`, `metadata`,
     * `accessibility`, `checks`) that the component declares as custom
     * properties in its own schema rather than inheriting from `ComponentCommon`
     * or `Checkable`.
     */
    getCustomEnvelopeProperties(name) {
        return this.customEnvelopeProperties.get(name) ?? new Set();
    }
    /**
     * Returns the ordered properties of a catalog or system function's arguments.
     */
    getFunctionProperties(name) {
        return this.functionProperties.get(name) ?? this.systemFunctionProperties.get(name) ?? [];
    }
    /**
     * Returns the required argument properties of a catalog or system function.
     */
    getFunctionRequired(name) {
        return this.functionRequired.get(name) ?? this.systemFunctionRequired.get(name) ?? [];
    }
    /**
     * Retrieves the JSON schema for a specific function argument property.
     */
    getFunctionPropertySchema(fnName, propName) {
        const fnSchema = this.functionSchema(fnName);
        if (!fnSchema) {
            return undefined;
        }
        const subSchemas = [fnSchema];
        const localRefs = [];
        if (Array.isArray(fnSchema.allOf)) {
            for (const sub of fnSchema.allOf) {
                if (localRef(sub)) {
                    localRefs.push(sub);
                }
                else {
                    subSchemas.push(sub);
                }
            }
        }
        subSchemas.push(...localRefs);
        for (let sub of subSchemas) {
            if (sub && typeof sub === 'object') {
                if (localRef(sub)) {
                    const resolved = this.resolveLocalRef(sub);
                    if (resolved && typeof resolved === 'object') {
                        sub = resolved;
                    }
                }
                const subObj = sub;
                if (subObj.properties && typeof subObj.properties === 'object') {
                    const argsObj = subObj.properties.args;
                    if (argsObj && typeof argsObj === 'object') {
                        const argsProps = argsObj.properties;
                        if (argsProps && typeof argsProps === 'object' && propName in argsProps) {
                            return argsProps[propName];
                        }
                    }
                }
            }
        }
        return undefined;
    }
    /**
     * Returns the list of allowed enum values for a component property, or undefined.
     */
    getPropertyEnum(componentName, propertyName) {
        return this.componentPropertyEnums.get(`${componentName}.${propertyName}`);
    }
    /**
     * Retrieves the description of the component from its catalog schema.
     */
    getComponentDescription(name) {
        const schema = this.components.get(name);
        if (!schema) {
            return undefined;
        }
        if (typeof schema.description === 'string') {
            return schema.description;
        }
        if (Array.isArray(schema.allOf)) {
            for (let sub of schema.allOf) {
                if (localRef(sub)) {
                    const resolved = this.resolveLocalRef(sub);
                    if (resolved && typeof resolved === 'object') {
                        sub = resolved;
                    }
                }
                if (sub &&
                    typeof sub === 'object' &&
                    typeof sub.description === 'string') {
                    return sub.description;
                }
            }
        }
        return undefined;
    }
    /**
     * Retrieves the description of a catalog or system function.
     */
    getFunctionDescription(name) {
        const schema = this.functionSchema(name);
        if (!schema) {
            return undefined;
        }
        return typeof schema.description === 'string' ? schema.description : undefined;
    }
    /**
     * Crawls all sub-schemas of a component to retrieve a property's schema definition.
     *
     * The sub-schemas are searched in the order `orderedComponentSubSchemas`
     * lists them, the component's own schema first, and the first definition
     * found is returned, so the component's own definition of a property
     * overrides an inherited one, including one from a nested allOf.
     */
    getPropertySchema(componentName, propertyName) {
        const schema = this.components.get(componentName);
        if (!schema) {
            return undefined;
        }
        for (const subObj of this.orderedComponentSubSchemas(schema)) {
            if (subObj.properties && typeof subObj.properties === 'object') {
                const props = subObj.properties;
                const lookupKey = propertyName in props
                    ? propertyName
                    : propertyName === 'checks' && '@checks' in props
                        ? '@checks'
                        : undefined;
                if (lookupKey !== undefined) {
                    const propVal = props[lookupKey];
                    if (!propVal || typeof propVal !== 'object') {
                        return undefined;
                    }
                    const current = propVal;
                    const visitedPointers = new Set();
                    let ref = localRef(current);
                    let merged = current;
                    while (ref) {
                        if (visitedPointers.has(ref)) {
                            break;
                        }
                        visitedPointers.add(ref);
                        const resolved = this.resolveJsonPointer(this.catalog, ref);
                        if (resolved && typeof resolved === 'object') {
                            merged = {
                                ...resolved,
                                ...merged,
                            };
                            ref = localRef(resolved);
                        }
                        else {
                            break;
                        }
                    }
                    return merged;
                }
            }
        }
        return undefined;
    }
    /**
     * Retrieves the check-rule property's schema for a component (own or inherited).
     */
    getCheckRulePropertySchema(componentName) {
        const propName = this.getCheckRuleProperty(componentName);
        if (!propName) {
            return undefined;
        }
        const own = this.getPropertySchema(componentName, propName);
        if (own) {
            return own;
        }
        return this.inheritedCheckRuleSchemas.get(componentName);
    }
    /**
     * Checks whether a schema admits a data binding path.
     *
     * True when the schema is, or combines via `$ref`/oneOf/anyOf/allOf, an object schema
     * whose `properties` contains `path` (v0.9) or `@path` (v1.0).
     *
     * Follows `$ref`s in `commonTypes` or the catalog document.
     * Never descends into `items` or property values.
     */
    admitsPath(schema) {
        const visited = new Set();
        const check = (s, inCommonTypes) => {
            if (!s || typeof s !== 'object') {
                return false;
            }
            if (visited.has(s)) {
                return false;
            }
            visited.add(s);
            const obj = s;
            if (obj.properties && typeof obj.properties === 'object') {
                const props = obj.properties;
                if ('path' in props || '@path' in props) {
                    return true;
                }
            }
            if (typeof obj.$ref === 'string') {
                const ref = obj.$ref;
                const defName = commonDefName(ref);
                if (defName) {
                    const resolved = this.lookupCommonDef(defName);
                    if (resolved && check(resolved, true)) {
                        return true;
                    }
                }
                else if (inCommonTypes &&
                    (ref.startsWith('#/$defs/') || ref.startsWith('#/definitions/'))) {
                    const name = ref.startsWith('#/$defs/') ? ref.slice(8) : ref.slice(14);
                    const resolved = this.lookupCommonDef(name);
                    if (resolved && check(resolved, true)) {
                        return true;
                    }
                }
                else if (ref.startsWith('#/')) {
                    const resolved = this.resolveJsonPointer(this.catalog, ref);
                    if (resolved && check(resolved, false)) {
                        return true;
                    }
                }
            }
            for (const key of ['allOf', 'oneOf', 'anyOf']) {
                const list = obj[key];
                if (Array.isArray(list)) {
                    for (const sub of list) {
                        if (check(sub, inCommonTypes)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };
        return check(schema, false);
    }
    /**
     * Checks whether a property schema accepts a numeric value by resolving `$ref`s
     * in `commonTypes` or the catalog document.
     */
    acceptsNumber(schema) {
        const visited = new Set();
        const check = (s, inCommonTypes) => {
            if (!s || typeof s !== 'object') {
                return false;
            }
            if (visited.has(s)) {
                return false;
            }
            visited.add(s);
            const obj = s;
            const type = obj.type;
            if (type === 'number' || type === 'integer') {
                return true;
            }
            if (Array.isArray(type) && (type.includes('number') || type.includes('integer'))) {
                return true;
            }
            if (typeof obj.const === 'number') {
                return true;
            }
            if (Array.isArray(obj.enum) && obj.enum.some(v => typeof v === 'number')) {
                return true;
            }
            if (typeof obj.$ref === 'string') {
                const ref = obj.$ref;
                const defName = commonDefName(ref);
                if (defName) {
                    const resolved = this.lookupCommonDef(defName);
                    if (!resolved) {
                        return true;
                    }
                    if (check(resolved, true)) {
                        return true;
                    }
                }
                else if (inCommonTypes &&
                    (ref.startsWith('#/$defs/') || ref.startsWith('#/definitions/'))) {
                    const name = ref.startsWith('#/$defs/') ? ref.slice(8) : ref.slice(14);
                    const resolved = this.lookupCommonDef(name);
                    if (!resolved) {
                        return true;
                    }
                    if (check(resolved, true)) {
                        return true;
                    }
                }
                else if (ref.startsWith('#/')) {
                    const resolved = this.resolveJsonPointer(this.catalog, ref);
                    if (!resolved) {
                        return true;
                    }
                    if (check(resolved, false)) {
                        return true;
                    }
                }
                else if (ref.startsWith('catalog.json#/')) {
                    const resolved = this.resolveJsonPointer(this.catalog, ref.slice(12));
                    if (!resolved) {
                        return true;
                    }
                    if (check(resolved, false)) {
                        return true;
                    }
                }
                else {
                    return true;
                }
            }
            for (const key of ['allOf', 'oneOf', 'anyOf']) {
                const list = obj[key];
                if (Array.isArray(list)) {
                    for (const sub of list) {
                        if (check(sub, inCommonTypes)) {
                            return true;
                        }
                    }
                }
            }
            const typeKeys = [
                'type',
                'const',
                'enum',
                '$ref',
                'allOf',
                'oneOf',
                'anyOf',
                'properties',
                'items',
                'prefixItems',
                'not',
            ];
            if (!typeKeys.some(k => k in obj)) {
                return true;
            }
            return false;
        };
        return check(schema, false);
    }
    /**
     * Resolves the schema of an array's items.
     *
     * Traverses $ref (both in common types and catalog document), allOf, oneOf, and anyOf
     * to find the declared schema at that position.
     *
     * @param schema The array's JSON schema.
     * @returns The resolved item schema, or undefined if not declared.
     */
    resolveItemSchema(schema) {
        return this.resolveAt(schema, undefined);
    }
    /**
     * Resolves the schema of an object's property, falling back to `additionalProperties`
     * when the property is not declared.
     *
     * Traverses $ref (both in common types and catalog document), allOf, oneOf, and anyOf
     * to find the declared schema at that position. A property named `items` is looked up
     * as a property, not as the array items.
     *
     * @param schema The object's JSON schema.
     * @param name The property name.
     * @returns The resolved property schema, or undefined if not declared.
     */
    resolvePropertySchema(schema, name) {
        return this.resolveAt(schema, name);
    }
    /**
     * @param property The property to resolve, or undefined for the array items.
     */
    resolveAt(schema, property) {
        const visited = new Set();
        const resolve = (s, inCommonTypes) => {
            if (!s || typeof s !== 'object') {
                return undefined;
            }
            if (visited.has(s)) {
                return undefined;
            }
            visited.add(s);
            const obj = s;
            if (property === undefined) {
                if (obj.items && typeof obj.items === 'object') {
                    return obj.items;
                }
            }
            else {
                if (obj.properties && typeof obj.properties === 'object') {
                    const props = obj.properties;
                    const declared = Object.hasOwn(props, property) ? props[property] : undefined;
                    if (declared && typeof declared === 'object') {
                        return declared;
                    }
                }
                if (obj.additionalProperties && typeof obj.additionalProperties === 'object') {
                    return obj.additionalProperties;
                }
            }
            if (typeof obj.$ref === 'string') {
                const ref = obj.$ref;
                const defName = commonDefName(ref);
                if (defName) {
                    const target = this.lookupCommonDef(defName);
                    const found = resolve(target, true);
                    if (found) {
                        return found;
                    }
                }
                else if (inCommonTypes &&
                    (ref.startsWith('#/$defs/') || ref.startsWith('#/definitions/'))) {
                    const name = ref.startsWith('#/$defs/') ? ref.slice(8) : ref.slice(14);
                    const target = this.lookupCommonDef(name);
                    const found = resolve(target, true);
                    if (found) {
                        return found;
                    }
                }
                else if (ref.startsWith('#/')) {
                    const target = this.resolveJsonPointer(this.catalog, ref);
                    const found = resolve(target, false);
                    if (found) {
                        return found;
                    }
                }
            }
            for (const k of ['allOf', 'oneOf', 'anyOf']) {
                const list = obj[k];
                if (Array.isArray(list)) {
                    for (const sub of list) {
                        const found = resolve(sub, inCommonTypes);
                        if (found) {
                            return found;
                        }
                    }
                }
            }
            return undefined;
        };
        return resolve(schema, false);
    }
}
//# sourceMappingURL=schema-helper.js.map