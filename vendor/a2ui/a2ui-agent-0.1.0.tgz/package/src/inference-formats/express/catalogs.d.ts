import { CatalogApi } from '../../internal/web-core.js';
import { ExpressValidationError } from './errors.js';
import { CatalogSchemaHelper } from './schema-helper.js';
/**
 * Normalizes the catalogs argument of the Express classes, which accept either one
 * catalog or a list of them.
 *
 * @param catalogs One catalog or a non-empty list of catalogs.
 * @returns The catalogs as a list.
 * @throws A2uiCatalogError if the list is empty.
 */
export declare function toCatalogList(catalogs: CatalogApi | CatalogApi[]): CatalogApi[];
/**
 * Checks that all catalogs share one protocol release line and have unique IDs,
 * and that multi-catalog configurations target v1.0 or later.
 *
 * @param catalogs The active catalogs (non-empty).
 * @returns The first catalog's wire protocol version.
 * @throws A2uiCatalogError if catalog IDs are duplicated, versions span release lines,
 *     or multiple catalogs are used below v1.0.
 */
export declare function checkMixedCatalogs(catalogs: CatalogApi[]): string;
/**
 * Returns the wire protocol version Express should emit for a set of catalogs.
 *
 * An Express block compiles to messages of a single version, so all catalogs must
 * belong to one release line (`v0.9` and `v0.9.1` do; `v0.9` and `v1.0` don't). A
 * requested version must be on that line too. Crossing lines would produce, for
 * example, a v1.0 `createSurface` that names a v0.9 catalog.
 *
 * @param catalogs The active catalogs (non-empty).
 * @param requested An explicitly requested version, if any.
 * @returns The requested version, or the first catalog's version.
 * @throws A2uiCatalogError if the catalogs, or the requested version, span release lines.
 */
export declare function resolveExpressVersion(catalogs: CatalogApi[], requested?: string): string;
/**
 * Returns the catalogId to put on `createSurface`, or `undefined` when several catalogs are active.
 *
 * With one active catalog, the surface is bound to it on `createSurface` and its
 * components need no `catalogId`. With several, the surface is not bound to one
 * catalog; components and function calls carry their own `catalogId`.
 */
export declare function surfaceCatalogId(catalogs: CatalogApi[]): string | undefined;
/**
 * Returns the catalog IDs (in catalog order) whose helper defines the component or function `name`.
 */
export declare function catalogsDefining(helpers: ReadonlyMap<string, CatalogSchemaHelper>, kind: 'component' | 'function', name: string): string[];
/**
 * Builds one schema helper per catalog, keyed by catalog id.
 *
 * @param catalogs The active catalogs.
 * @param version The protocol version the helpers read the schemas for.
 * @returns The helpers, in catalog order.
 */
export declare function buildSchemaHelpers(catalogs: CatalogApi[], version: string): Map<string, CatalogSchemaHelper>;
/**
 * Builds a validation error when a surface, component, or function targets an inactive catalog.
 */
export declare function unknownCatalogError(target: string, catalogId: string, catalogs: readonly CatalogApi[]): ExpressValidationError;
/**
 * Builds a validation error when a component or function is not defined in a target catalog
 * (or in any active catalog).
 */
export declare function unknownSymbolError(kind: 'component' | 'function', name: string, catalogId: string | undefined, helpers: ReadonlyMap<string, CatalogSchemaHelper>): ExpressValidationError;
//# sourceMappingURL=catalogs.d.ts.map