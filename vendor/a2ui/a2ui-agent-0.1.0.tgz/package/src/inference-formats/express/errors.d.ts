import { A2uiError } from '../../internal/web-core.js';
/**
 * Base class for all Express DSL compilation errors.
 */
export declare class ExpressCompilerError extends A2uiError {
    readonly helpMessage?: string;
    constructor(message: string, helpMessage?: string);
}
/**
 * Base class for blocks the compiler cannot read.
 *
 * The block is malformed on its own terms, so the compiler never reaches the
 * point of asking the catalog about anything it names.
 */
export declare class ExpressParseError extends ExpressCompilerError {
    constructor(message: string, helpMessage?: string);
}
/**
 * Base class for readable blocks the catalog refuses.
 *
 * The block parses; what it names or the value it gives is what the catalog
 * does not admit.
 */
export declare class ExpressValidationError extends ExpressCompilerError {
    constructor(message: string, helpMessage?: string);
}
/**
 * Raised when a component is not defined in the catalog.
 */
export declare class ExpressUnknownComponentError extends ExpressValidationError {
    readonly compName: string;
    constructor(compName: string);
}
/**
 * Raised when a component is missing a property its catalog schema requires.
 */
export declare class ExpressMissingRequiredPropertyError extends ExpressValidationError {
    readonly compName: string;
    readonly propName: string;
    constructor(compName: string, propName: string);
}
/**
 * Raised when a component argument is not a valid property in the catalog schema.
 */
export declare class ExpressUnknownPropertyError extends ExpressValidationError {
    readonly compName: string;
    readonly propName: string;
    readonly validProps: string[];
    constructor(compName: string, propName: string, validProps: string[]);
}
/**
 * Raised when a property is provided multiple times for a single component instance.
 */
export declare class ExpressDuplicatePropertyError extends ExpressValidationError {
    readonly compName: string;
    readonly propName: string;
    constructor(compName: string, propName: string);
}
/**
 * Raised when a function is not defined in the catalog.
 */
export declare class ExpressUnknownFunctionError extends ExpressValidationError {
    readonly fnName: string;
    constructor(fnName: string);
}
/**
 * Raised when a function argument is not a valid parameter in the function schema.
 */
export declare class ExpressInvalidParamError extends ExpressValidationError {
    readonly fnName: string;
    readonly paramName: string;
    readonly validParams: string[];
    constructor(fnName: string, paramName: string, validParams: string[]);
}
/**
 * Raised when a function parameter is provided multiple times.
 */
export declare class ExpressDuplicateParamError extends ExpressValidationError {
    readonly fnName: string;
    readonly paramName: string;
    constructor(fnName: string, paramName: string);
}
/**
 * Raised when dynamic databinding ($path) is used on a property that forbids databinding.
 */
export declare class ExpressForbiddenDatabindingError extends ExpressValidationError {
    readonly compName: string;
    readonly propName: string;
    constructor(compName: string, propName: string);
}
/**
 * Raised when a root component reference is missing from the DSL.
 */
export declare class ExpressUndefinedRootError extends ExpressParseError {
    readonly rootTarget: string;
    constructor(rootTarget: string);
}
/**
 * Raised when a child component variable reference is missing from the DSL.
 */
export declare class ExpressUndefinedChildError extends ExpressParseError {
    readonly childId: string;
    constructor(childId: string);
}
/**
 * Raised when a lexer or parser syntax error is encountered in the Express DSL.
 */
export declare class ExpressSyntaxError extends ExpressParseError {
    readonly line: number;
    readonly column: number;
    readonly isLexer: boolean;
    constructor(message: string, line: number, column: number, isLexer: boolean);
}
/**
 * Raised when a generated inline component ID collides with an existing component or variable ID.
 */
export declare class ExpressIdCollisionError extends ExpressValidationError {
    readonly idName: string;
    constructor(idName: string);
}
/**
 * Raised when a `surface(...)` line names a catalog that is not one of the active
 * catalogs.
 */
export declare class ExpressUnknownCatalogError extends ExpressValidationError {
    readonly catalogId: string;
    constructor(catalogId: string, activeCatalogIds: string[]);
}
//# sourceMappingURL=errors.d.ts.map