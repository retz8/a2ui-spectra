import { RawResponsePart } from '../../parser/response-part.js';
export declare const OPEN_TAG = "<a2ui-json>";
export declare const CLOSE_TAG = "</a2ui-json>";
/** Where an open tag starts and ends. */
export interface TagMatch {
    start: number;
    end: number;
}
/** Finds the first open tag in `text` at or after `from`. */
export declare function searchOpenTag(text: string, from?: number): TagMatch | undefined;
/** Returns where a close tag that starts exactly at `at` ends, if one does. */
export declare function matchCloseTag(text: string, at: number): number | undefined;
/** Returns where a tail of `text` could start an open tag, else its length. */
export declare function possibleTagStart(text: string): number;
/**
 * Finds the close tag of a block whose body starts at `start`.
 *
 * A tag written inside a JSON string does not count.
 *
 * @returns The close tag's offset, or undefined if the block is still open, and the length
 *     of the body that can be read: up to the close tag, or up to a tail that could start
 *     one.
 */
export declare function scanBlock(content: string, start: number): [number | undefined, number];
/**
 * Finds the close tag of a block as its text arrives, reading each character once across
 * the scans of a longer and longer text.
 */
export declare class BlockScanner {
    private readonly start;
    private i;
    private inString;
    /** @param start Where the block's body starts. */
    constructor(start: number);
    /**
     * Scans `content`, the text the last scan read and more, from where the last scan
     * stopped. Returns what `scanBlock` returns.
     */
    scan(content: string): [number | undefined, number];
}
/** Appends `text` as a final text part, unless it is empty once cleaned. */
export declare function addText(parts: RawResponsePart[], text: string): void;
/** Strips whitespace and one Markdown code fence around a block body. */
export declare function clean(text: string): string;
/** Strips whitespace, fences, and inline-code edge backticks from a block body. */
export declare function cleanRaw(text: string): string;
/**
 * Where the payload of a block still arriving starts: after leading whitespace, and after
 * the line of a leading Markdown fence, or undefined while that line is not complete.
 *
 * @param text The text of the block.
 * @param end Where the part of `text` that can be read ends.
 */
export declare function payloadStart(text: string, end: number): number | undefined;
/**
 * Where a Markdown fence that ends the part of `text` from `start` to `end`, or the start of
 * one, begins, with the whitespace before it, or `end` if none ends it.
 *
 * Finds what `\s*`{1,3}[a-zA-Z-]*\s*$` matches by reading back from the end, since a regular
 * expression would try every offset of a block that is read again on every chunk.
 */
export declare function trailingFenceStart(text: string, start: number, end: number): number;
//# sourceMappingURL=blocks.d.ts.map