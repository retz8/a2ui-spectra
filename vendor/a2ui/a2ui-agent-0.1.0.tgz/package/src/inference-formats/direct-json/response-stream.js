/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Reading a streamed Direct JSON response chunk by chunk.
 */
import { ParseError, withPartialResults } from '../../errors.js';
import { A2uiError, A2uiIntegrityError, isAtLeastVersion, validateRecursionAndPaths, } from '../../internal/web-core.js';
import { TextRun } from '../../parser/text-run.js';
import { BlockScanner, CLOSE_TAG, matchCloseTag, OPEN_TAG, payloadStart, possibleTagStart, searchOpenTag, trailingFenceStart, } from './blocks.js';
import { PartialReadCache, readPartialMessages } from './json-reader.js';
/**
 * Envelope keys of the messages a renderer applies again as they grow, so a stream emits them
 * before their object closes. Any other message is applied once, so it is held until it
 * closes: creating a surface twice fails, a deleted surface cannot be restored, and a
 * function runs each time it is called.
 */
const GROWING_KEYS = ['updateComponents', 'updateDataModel'];
/** How deep the value of an `updateDataModel` sits in its message: envelope, body, value. */
const VALUE_DEPTH = 2;
/**
 * Reads one streamed Direct JSON response.
 *
 * A message is emitted, and applied to the state, as soon as it reads and the state accepts
 * it, and again each time it grows. Only `updateComponents` and `updateDataModel` are emitted
 * while they grow; any other message is held until its object closes, and the messages after
 * it wait with it. When a block closes, the messages it holds are applied in full and every
 * surface they touched is checked in full.
 *
 * Each chunk is read once. The scan for the close tag and the read of the open block go on
 * where the previous chunk left them, a message that has closed is not read or checked
 * again, and a message that grows is checked for what it gains: an `updateComponents` for
 * the components it adds, and an `updateDataModel` for the lists and maps its value gains.
 * An `updateDataModel` is applied when it first reads and again once it closes. A closed
 * message the state rejects fails the same way on every later chunk, so nothing after it is
 * emitted, and the block throws when it closes.
 *
 * The stream ends when `close` returns or when `feed` or `close` throws. By default it throws
 * at the first rejected block; opened with `afterRejectedBlock: 'continue'`, it returns an
 * `ErrorPart` in its place, skips the rest of the block, and reads on. Either way the messages
 * the block emitted stay in the state, since the renderer holds them, and the components they
 * added are marked checked (`RendererState.markChecked`), so a later turn on the surface is
 * not required to make them reachable.
 *
 * @template Part The parts the stream returns. See `ResponseStream`.
 */
export class DirectJsonResponseStream {
    /**
     * @param parser The parser that opened the stream.
     * @param options Whether the response is wrapped in tags, the state the stream's messages
     *     are applied to, and whether the stream reads past a rejected block.
     */
    constructor(parser, { wrapped, state, afterRejectedBlock }) {
        this.parser = parser;
        this.closed = false;
        // Text outside blocks.
        this.held = '';
        this.text = new TextRun();
        this.heldBackticks = '';
        this.stripCloseBackticks = false;
        /** Whether the open block was rejected, so the rest of it is skipped. */
        this.rejected = false;
        this.block = '';
        this.scanner = new BlockScanner(0);
        this.readCache = new PartialReadCache();
        /** The messages of the block whose objects have closed, in order. */
        this.closedMessages = [];
        /** How many of `closedMessages` have been applied and emitted. */
        this.committed = 0;
        /** Whether the closed message after the committed ones was rejected. */
        this.stalled = false;
        this.touched = new Set();
        this.buffersComponents =
            Boolean(parser.bufferIncompleteComponents) ||
                isAtLeastVersion(parser.catalogs[0].protocolVersion ?? '1.0', '1.0');
        this.wrapped = wrapped;
        this.state = state;
        this.continues = afterRejectedBlock === 'continue';
        this.inBlock = !wrapped;
    }
    get isInBlock() {
        return !this.closed && this.inBlock;
    }
    feed(chunk) {
        if (this.closed) {
            throw new Error('The response stream is closed.');
        }
        const parts = [];
        try {
            this.read(chunk, parts);
        }
        catch (e) {
            this.fail();
            throw withPartialResults(e, parts.filter(isResponsePart));
        }
        // Only a stream that reads past rejected blocks, whose parts are `StreamPart`s, returns an
        // `ErrorPart`.
        return parts;
    }
    close() {
        return this.end();
    }
    end() {
        if (this.closed)
            return [];
        this.closed = true;
        const parts = [];
        try {
            if (!this.wrapped) {
                if (!this.rejected)
                    this.readBlock(parts, () => this.finishBlock(parts, this.block));
                return parts;
            }
            if (this.inBlock) {
                if (!this.rejected) {
                    this.readBlock(parts, () => {
                        throw new ParseError(`The response ended inside an ${OPEN_TAG} block, before its ${CLOSE_TAG} tag.`);
                    });
                }
                return parts;
            }
        }
        catch (e) {
            this.fail();
            throw withPartialResults(e, parts.filter(isResponsePart));
        }
        if (this.heldBackticks) {
            this.text.emit(parts, this.heldBackticks);
            this.heldBackticks = '';
        }
        else if (this.held) {
            this.text.emit(parts, this.held);
            this.held = '';
        }
        return parts;
    }
    /**
     * Ends the stream after a failure, keeping what it emitted.
     *
     * The renderer holds the messages already emitted, and so does the state. No message
     * removes a component, so the components they added are marked checked: a later turn is
     * not required to make them reachable.
     */
    fail() {
        this.closed = true;
        this.state.markChecked(this.touched);
    }
    /**
     * Runs a step that reads the open block. If the block is rejected and the stream reads past
     * rejected blocks, returns an `ErrorPart` for it and skips the rest of it; otherwise the
     * error propagates.
     */
    readBlock(parts, step) {
        try {
            step();
        }
        catch (e) {
            if (!this.continues || !(e instanceof A2uiError))
                throw e;
            parts.push({ type: 'error', error: e });
            this.state.markChecked(this.touched);
            this.rejected = true;
        }
    }
    read(chunk, parts) {
        if (!this.wrapped) {
            this.block += chunk;
            if (!this.rejected)
                this.readBlock(parts, () => this.emitReady(parts, this.block.length));
            return;
        }
        let input = this.held + chunk;
        this.held = '';
        if (this.stripCloseBackticks) {
            if (input.startsWith('`')) {
                input = input.replace(/^`+/, '');
            }
            if (input.length > 0) {
                this.stripCloseBackticks = false;
            }
        }
        if (!this.inBlock && this.heldBackticks.length > 0) {
            if (input.length > 0) {
                const isOpenTag = searchOpenTag(input)?.start === 0 ||
                    (input.startsWith('<') && OPEN_TAG.toLowerCase().startsWith(input.toLowerCase()));
                if (isOpenTag) {
                    this.heldBackticks = '';
                }
                else {
                    input = `${this.heldBackticks}${input}`;
                    this.heldBackticks = '';
                }
            }
        }
        while (input) {
            if (this.inBlock) {
                this.block += input;
                input = '';
                const [closeStart, readableEnd] = this.scanner.scan(this.block);
                if (closeStart === undefined) {
                    if (!this.rejected)
                        this.readBlock(parts, () => this.emitReady(parts, readableEnd));
                    break;
                }
                const closeEnd = matchCloseTag(this.block, closeStart);
                input = this.block.slice(closeEnd);
                if (input.startsWith('`')) {
                    input = input.replace(/^`+/, '');
                }
                else if (!input) {
                    this.stripCloseBackticks = true;
                }
                const body = this.block.slice(0, closeStart);
                if (!this.rejected)
                    this.readBlock(parts, () => this.finishBlock(parts, body));
                this.resetBlock();
                continue;
            }
            const open = searchOpenTag(input);
            if (open) {
                let textBefore = input.slice(0, open.start);
                if (textBefore.endsWith('`')) {
                    textBefore = textBefore.replace(/`+$/, '');
                }
                this.text.emit(parts, textBefore);
                this.text.reset();
                this.heldBackticks = '';
                this.inBlock = true;
                input = input.slice(open.end);
                continue;
            }
            let hold = possibleTagStart(input);
            if (hold < input.length) {
                while (hold > 0 && input.charCodeAt(hold - 1) === 0x60) {
                    hold--;
                }
            }
            let textToEmit = input.slice(0, hold);
            this.held = input.slice(hold);
            input = '';
            if (!this.held) {
                const ticksMatch = textToEmit.match(/`+$/);
                if (ticksMatch) {
                    this.heldBackticks = ticksMatch[0];
                    textToEmit = textToEmit.slice(0, textToEmit.length - this.heldBackticks.length);
                }
            }
            this.text.emit(parts, textToEmit);
        }
    }
    /**
     * Emits the messages of the open block that read and are accepted.
     *
     * @param end Where the part of the block that can be read ends.
     */
    emitReady(parts, end) {
        const start = payloadStart(this.block, end);
        if (start === undefined)
            return;
        // The block only grows, so what earlier reads found holds while the payload starts at
        // the same place.
        if (start !== this.readStart) {
            this.readStart = start;
            this.readCache = new PartialReadCache();
        }
        const read = readPartialMessages(this.block, this.parser.progressiveKeys, {
            wholeItemKeys: this.buffersComponents ? ['components'] : [],
            cache: this.readCache,
            start,
            end: trailingFenceStart(this.block, start, end),
        });
        let open;
        for (const [offset, [envelope, closed]] of read.messages.entries()) {
            const index = read.skipped + offset;
            if (index !== this.closedMessages.length)
                continue;
            if (closed) {
                this.closedMessages.push(envelope);
            }
            else {
                open = envelope;
            }
        }
        if (this.stalled)
            return;
        const ready = [];
        // The messages applied before a rejected one are emitted with the error, since the state
        // holds them.
        try {
            while (this.committed < this.closedMessages.length) {
                const envelope = this.closedMessages[this.committed];
                try {
                    ready.push(...this.applyMessage(this.committed, envelope, true));
                }
                catch (e) {
                    if (e instanceof A2uiError && this.raisesWhileArriving(envelope))
                        throw e;
                    this.stalled = true;
                    break;
                }
                this.committed += 1;
            }
            if (!this.stalled && isObject(open) && GROWING_KEYS.some(key => key in open)) {
                try {
                    ready.push(...this.applyMessage(this.committed, open, false));
                }
                catch (e) {
                    // Held back, and checked again as it grows.
                    if (e instanceof A2uiError && this.raisesWhileArriving(open))
                        throw e;
                }
            }
        }
        finally {
            if (ready.length > 0)
                parts.push({ type: 'a2ui', a2ui: ready });
        }
    }
    /**
     * Whether a rejected message is reported as soon as it arrives rather than held back: a
     * v1.0 `updateComponents` that names its surface and whose components have read whole.
     */
    raisesWhileArriving(envelope) {
        if (!isObject(envelope))
            return false;
        const body = envelope.updateComponents;
        return (this.buffersComponents &&
            typeof envelope.version === 'string' &&
            isObject(body) &&
            typeof body.surfaceId === 'string' &&
            Array.isArray(body.components) &&
            body.components.length > 0);
    }
    /**
     * Applies the rest of a closed block and checks the surfaces it touched.
     *
     * `compile` only reads the block. Each message is checked when the state applies it: the
     * messages that closed while the block arrived were checked then, and the rest are checked
     * here. The trees of the surfaces the block touched are checked last.
     *
     * The messages not emitted yet are emitted only if the checks pass, so a failed block
     * leaves the state holding what was emitted.
     */
    finishBlock(parts, block) {
        const messages = this.parser.compile(block);
        const ready = this.state.transaction(() => {
            const applied = [];
            messages.forEach((envelope, index) => {
                if (index >= this.committed)
                    applied.push(...this.applyMessage(index, envelope, true));
            });
            this.state.checkTopology(this.touched);
            return applied;
        });
        if (ready.length > 0)
            parts.push({ type: 'a2ui', a2ui: ready });
    }
    /** Forgets the block that closed, whether it was read or rejected. */
    resetBlock() {
        this.inBlock = false;
        this.rejected = false;
        this.block = '';
        this.scanner = new BlockScanner(0);
        this.readCache = new PartialReadCache();
        this.readStart = undefined;
        this.closedMessages = [];
        this.committed = 0;
        this.stalled = false;
        this.growing = undefined;
        this.touched.clear();
    }
    /**
     * Applies the message at an index of the block, as far as the state does not hold it yet.
     *
     * A message seen for the first time is applied whole. A message that grew since the last
     * chunk is checked for what it gained, since applying that over what was applied before
     * leaves the state as applying the whole message would: components are replaced by id. An
     * `updateDataModel` is applied whole again once it closes.
     *
     * @param closed Whether the message's object has closed.
     * @returns The message, if the renderer has not received it as it now stands.
     */
    applyMessage(index, envelope, closed) {
        const growing = this.growing?.index === index ? this.growing : undefined;
        let emit;
        if (growing?.kind === 'components' &&
            restOf(envelope, 'updateComponents', 'components') === growing.rest) {
            emit = this.applyAddedComponents(growing, envelope);
        }
        else if (growing?.kind === 'dataModel' &&
            restOf(envelope, 'updateDataModel', 'value') === growing.rest) {
            emit = this.checkGrownValue(growing, envelope, closed);
        }
        else if (growing?.kind === 'other' && !closed && stableStringify(envelope) === growing.json) {
            emit = false;
        }
        else {
            this.applyWhole(envelope);
            this.growing = closed ? undefined : growingOf(index, envelope);
            return [envelope];
        }
        if (closed)
            this.growing = undefined;
        return emit ? [envelope] : [];
    }
    /**
     * Applies the components an `updateComponents` gained since it was last applied, and the
     * last one applied before if it has grown since.
     *
     * The state sees only those components as a batch, so it would take an id repeated from an
     * earlier batch of the same message for an update; such an id is rejected here, as the
     * state rejects one repeated within a batch.
     *
     * @returns Whether the message changed.
     */
    applyAddedComponents(growing, envelope) {
        const body = envelope.updateComponents;
        const components = body.components;
        let kept = growing.count;
        if (components.length < kept)
            kept = 0;
        if (kept > 0 && JSON.stringify(components[kept - 1]) !== growing.lastJson)
            kept -= 1;
        if (kept === components.length)
            return false;
        const added = components.slice(kept);
        // The ids the components before the re-read ones hold.
        const rereadLast = kept === growing.count - 1;
        const earlier = (id) => kept > 0 && growing.ids.has(id) && !(rereadLast && id === growing.lastId);
        const seen = new Set();
        for (const component of added) {
            const id = isObject(component) ? component.id : undefined;
            if (typeof id !== 'string')
                continue;
            if (earlier(id) || seen.has(id)) {
                throw new A2uiIntegrityError(`Duplicate component ID: '${id}'`, [id]);
            }
            seen.add(id);
        }
        this.applyWhole({ ...envelope, updateComponents: { ...body, components: added } });
        if (kept === 0)
            growing.ids.clear();
        if (rereadLast)
            growing.ids.delete(growing.lastId);
        for (const id of seen)
            growing.ids.add(id);
        const last = components[components.length - 1];
        growing.count = components.length;
        growing.lastJson = JSON.stringify(last);
        growing.lastId = isObject(last) ? last.id : undefined;
        return true;
    }
    /**
     * Checks what the value of an `updateDataModel` gained since it was last emitted, or
     * applies it whole once it has closed.
     *
     * Of what the state checks, only the depth of the value and the paths it binds depend on
     * the value, so only the lists and maps it gained are checked while it grows.
     *
     * @returns Whether the message changed.
     */
    checkGrownValue(growing, envelope, closed) {
        const value = envelope.updateDataModel.value;
        const changed = !sameJson(value, growing.value);
        if (closed) {
            this.applyWhole(envelope);
        }
        else if (changed) {
            checkGained(value, growing.value, VALUE_DEPTH);
            growing.value = value;
        }
        return changed;
    }
    applyWhole(envelope) {
        for (const surfaceId of this.state.apply([envelope])) {
            this.touched.add(surfaceId);
        }
    }
}
function isResponsePart(part) {
    return part.type !== 'error';
}
/** What the stream keeps of a message it applied whole while it grows. */
function growingOf(index, envelope) {
    if (isObject(envelope)) {
        const components = isObject(envelope.updateComponents)
            ? envelope.updateComponents.components
            : undefined;
        if (Array.isArray(components)) {
            const last = components[components.length - 1];
            return {
                kind: 'components',
                index,
                rest: restOf(envelope, 'updateComponents', 'components'),
                count: components.length,
                lastJson: components.length > 0 ? JSON.stringify(last) : undefined,
                lastId: isObject(last) ? last.id : undefined,
                ids: new Set(components.map(c => (isObject(c) ? c.id : undefined))),
            };
        }
        const dataModel = envelope.updateDataModel;
        if (isObject(dataModel) && 'value' in dataModel) {
            return {
                kind: 'dataModel',
                index,
                rest: restOf(envelope, 'updateDataModel', 'value'),
                value: dataModel.value,
            };
        }
    }
    return { kind: 'other', index, json: stableStringify(envelope) };
}
/**
 * The JSON of a message less the field it grows by, or undefined if it is not a message of
 * that action with that field.
 */
function restOf(envelope, action, field) {
    if (!isObject(envelope))
        return undefined;
    const body = envelope[action];
    if (!isObject(body) || !(field in body))
        return undefined;
    const rest = { ...body };
    delete rest[field];
    return JSON.stringify({ ...envelope, [action]: rest });
}
/**
 * Checks the lists and maps a value gained over the one before it, at a depth of the
 * message, for what the state checks of a value: its depth and the paths it binds.
 *
 * A list or map that closed reads as the same object on every chunk, so it is skipped
 * without being read.
 */
function checkGained(value, previous, depth) {
    if (value === previous)
        return;
    if (Array.isArray(value) && Array.isArray(previous)) {
        value.forEach((item, i) => checkGained(item, previous[i], depth + 1));
        return;
    }
    if (isObject(value) && isObject(previous)) {
        const paths = {};
        for (const key of ['path', '@path']) {
            if (value[key] !== previous[key])
                paths[key] = value[key];
        }
        if (Object.keys(paths).length > 0)
            validateAt(paths, depth);
        for (const key of Object.keys(value)) {
            if (key !== 'path' && key !== '@path')
                checkGained(value[key], previous[key], depth + 1);
        }
        return;
    }
    validateAt(value, depth);
}
/** Checks a value as the state checks the part of a message at a depth of it. */
function validateAt(value, depth) {
    let wrapped = value;
    for (let i = 0; i < depth; i++)
        wrapped = [wrapped];
    validateRecursionAndPaths(wrapped);
}
/**
 * Whether two JSON values are the same. A list or map that is the same object in both, as a
 * read through the cache returns one that closed, is not read.
 */
function sameJson(a, b) {
    if (a === b)
        return true;
    if (Array.isArray(a) && Array.isArray(b)) {
        return a.length === b.length && a.every((item, i) => sameJson(item, b[i]));
    }
    if (isObject(a) && isObject(b)) {
        const keys = Object.keys(a);
        return (keys.length === Object.keys(b).length &&
            keys.every(key => Object.prototype.hasOwnProperty.call(b, key) && sameJson(a[key], b[key])));
    }
    return false;
}
function isObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** Encodes a JSON value with its object keys sorted, so equal values encode the same. */
function stableStringify(value) {
    return JSON.stringify(value, (_key, val) => {
        if (!isObject(val))
            return val;
        const sorted = {};
        for (const key of Object.keys(val).sort()) {
            Object.defineProperty(sorted, key, { value: val[key], enumerable: true });
        }
        return sorted;
    });
}
//# sourceMappingURL=response-stream.js.map