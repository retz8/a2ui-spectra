import { AgentToRendererMessage } from '../../internal/web-core.js';
import { ResponsePart, StreamPart } from '../../parser/response-part.js';
import { ResponseStream } from '../../parser/response-stream.js';
import { RendererState } from '../../utils/renderer-state.js';
/** What the stream needs from the parser that opened it. */
export interface DirectJsonStreamSource {
    readonly catalogs: readonly {
        protocolVersion?: string;
    }[];
    readonly progressiveKeys: ReadonlySet<string>;
    readonly bufferIncompleteComponents?: boolean;
    compile(formatContent: string): AgentToRendererMessage[];
}
/** How a stream is opened. */
export interface DirectJsonStreamOptions {
    /** False if the whole response is one block, without tags. */
    wrapped: boolean;
    /** The state the stream's messages are applied to. */
    state: RendererState;
    /** Whether the stream ends at a rejected block or reads past it. */
    afterRejectedBlock: 'end' | 'continue';
}
/**
 * Reads one streamed Direct JSON response.
 *
 * A message is emitted, and applied to the state, as soon as it reads and the state accepts
 * it, and again each time it grows. Only `updateComponents` and `updateDataModel` are emitted
 * while they grow; any other message is held until its object closes, and the messages after
 * it wait with it. When a block closes, the messages it holds are applied in full and every
 * surface they touched is checked in full.
 *
 * Each chunk is read once. The scan for the close tag and the read of the open block go on
 * where the previous chunk left them, a message that has closed is not read or checked
 * again, and a message that grows is checked for what it gains: an `updateComponents` for
 * the components it adds, and an `updateDataModel` for the lists and maps its value gains.
 * An `updateDataModel` is applied when it first reads and again once it closes. A closed
 * message the state rejects fails the same way on every later chunk, so nothing after it is
 * emitted, and the block throws when it closes.
 *
 * The stream ends when `close` returns or when `feed` or `close` throws. By default it throws
 * at the first rejected block; opened with `afterRejectedBlock: 'continue'`, it returns an
 * `ErrorPart` in its place, skips the rest of the block, and reads on. Either way the messages
 * the block emitted stay in the state, since the renderer holds them, and the components they
 * added are marked checked (`RendererState.markChecked`), so a later turn on the surface is
 * not required to make them reachable.
 *
 * @template Part The parts the stream returns. See `ResponseStream`.
 */
export declare class DirectJsonResponseStream<Part extends StreamPart = ResponsePart> implements ResponseStream<Part> {
    private readonly parser;
    private readonly buffersComponents;
    private readonly wrapped;
    readonly state: RendererState;
    private readonly continues;
    private closed;
    private held;
    private readonly text;
    private heldBackticks;
    private stripCloseBackticks;
    private inBlock;
    /** Whether the open block was rejected, so the rest of it is skipped. */
    private rejected;
    private block;
    private scanner;
    private readCache;
    private readStart;
    /** The messages of the block whose objects have closed, in order. */
    private closedMessages;
    /** How many of `closedMessages` have been applied and emitted. */
    private committed;
    /** Whether the closed message after the committed ones was rejected. */
    private stalled;
    private growing;
    private readonly touched;
    /**
     * @param parser The parser that opened the stream.
     * @param options Whether the response is wrapped in tags, the state the stream's messages
     *     are applied to, and whether the stream reads past a rejected block.
     */
    constructor(parser: DirectJsonStreamSource, { wrapped, state, afterRejectedBlock }: DirectJsonStreamOptions);
    get isInBlock(): boolean;
    feed(chunk: string): Part[];
    close(): Part[];
    private end;
    /**
     * Ends the stream after a failure, keeping what it emitted.
     *
     * The renderer holds the messages already emitted, and so does the state. No message
     * removes a component, so the components they added are marked checked: a later turn is
     * not required to make them reachable.
     */
    private fail;
    /**
     * Runs a step that reads the open block. If the block is rejected and the stream reads past
     * rejected blocks, returns an `ErrorPart` for it and skips the rest of it; otherwise the
     * error propagates.
     */
    private readBlock;
    private read;
    /**
     * Emits the messages of the open block that read and are accepted.
     *
     * @param end Where the part of the block that can be read ends.
     */
    private emitReady;
    /**
     * Whether a rejected message is reported as soon as it arrives rather than held back: a
     * v1.0 `updateComponents` that names its surface and whose components have read whole.
     */
    private raisesWhileArriving;
    /**
     * Applies the rest of a closed block and checks the surfaces it touched.
     *
     * `compile` only reads the block. Each message is checked when the state applies it: the
     * messages that closed while the block arrived were checked then, and the rest are checked
     * here. The trees of the surfaces the block touched are checked last.
     *
     * The messages not emitted yet are emitted only if the checks pass, so a failed block
     * leaves the state holding what was emitted.
     */
    private finishBlock;
    /** Forgets the block that closed, whether it was read or rejected. */
    private resetBlock;
    /**
     * Applies the message at an index of the block, as far as the state does not hold it yet.
     *
     * A message seen for the first time is applied whole. A message that grew since the last
     * chunk is checked for what it gained, since applying that over what was applied before
     * leaves the state as applying the whole message would: components are replaced by id. An
     * `updateDataModel` is applied whole again once it closes.
     *
     * @param closed Whether the message's object has closed.
     * @returns The message, if the renderer has not received it as it now stands.
     */
    private applyMessage;
    /**
     * Applies the components an `updateComponents` gained since it was last applied, and the
     * last one applied before if it has grown since.
     *
     * The state sees only those components as a batch, so it would take an id repeated from an
     * earlier batch of the same message for an update; such an id is rejected here, as the
     * state rejects one repeated within a batch.
     *
     * @returns Whether the message changed.
     */
    private applyAddedComponents;
    /**
     * Checks what the value of an `updateDataModel` gained since it was last emitted, or
     * applies it whole once it has closed.
     *
     * Of what the state checks, only the depth of the value and the paths it binds depend on
     * the value, so only the lists and maps it gained are checked while it grows.
     *
     * @returns Whether the message changed.
     */
    private checkGrownValue;
    private applyWhole;
}
//# sourceMappingURL=response-stream.d.ts.map