/** A JSON value the reader produced. */
export type JsonValue = unknown;
/** Thrown when the text is not JSON. */
export declare class JsonReadError extends Error {
    constructor(message: string);
}
/**
 * Reads the complete JSON document `text`.
 *
 * @throws {JsonReadError} If `text` is not a single JSON value.
 */
export declare function readJson(text: string): JsonValue;
/** What one read of a block still arriving found. */
export interface PartialRead {
    /**
     * How many messages before `messages` had closed on an earlier read through the same
     * cache. They are not read again, so they are not in `messages`.
     */
    readonly skipped: number;
    /**
     * One `[envelope, closed]` pair per message read, in order. `closed` is false when the
     * message's text was still arriving and the reader healed it; only the last can be.
     */
    readonly messages: Array<[JsonValue, boolean]>;
}
/** Options for `readPartialMessages`. */
export interface PartialReadOptions {
    /** Keys whose array items are read only once each item is whole. */
    wholeItemKeys?: Iterable<string>;
    /**
     * What earlier reads of the same text found, so a read goes on where they stopped. The
     * text must only have grown since, and be read from the same `start`.
     */
    cache?: PartialReadCache;
    /** Where the payload starts in `text`. Defaults to 0. */
    start?: number;
    /** Where the part of `text` that can be read ends. Defaults to its length. */
    end?: number;
}
/**
 * What the reads of a block still arriving keep from one chunk to the next.
 *
 * The block only grows, so a list or map that closed reads the same on every later chunk,
 * and so do the items of a list still open, up to the last one that closed. A read through
 * the cache takes those from it rather than reading their text again, so reading every chunk
 * of a block reads each character about once.
 */
export declare class PartialReadCache {
    /** The state of the reads of the text as it is. */
    readonly plain: ReadState;
    /** The state of the reads of the text with curly quotes straightened, at the same offsets. */
    readonly straight: ReadState;
}
declare class ReadState {
    /** Each list or map that closed, by the offset of its opening bracket, with the offset after its closing one. */
    readonly closed: Map<number, [unknown, number]>;
    /** Each list still open, by the offset of its opening bracket, with the items that closed and the offset after the last of them. */
    readonly open: Map<number, [unknown[], number]>;
    /** For a payload written as a list of messages, how many messages closed, and the offset after the last of them. */
    messages: [number, number] | undefined;
}
/**
 * Reads a partial JSON array or object into candidate envelopes.
 *
 * @param text The text of a block that may still be arriving.
 * @param progressiveKeys Keys whose string values are closed where they stand while they
 *     arrive.
 * @param options What to read and what earlier reads found.
 * @returns The messages read, after those earlier reads saw close. When the text is not
 *     JSON, no messages.
 */
export declare function readPartialMessages(text: string, progressiveKeys: Iterable<string>, { wholeItemKeys, cache, start, end }?: PartialReadOptions): PartialRead;
export {};
//# sourceMappingURL=json-reader.d.ts.map