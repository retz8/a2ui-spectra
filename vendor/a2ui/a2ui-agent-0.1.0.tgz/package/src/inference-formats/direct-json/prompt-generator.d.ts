import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { PromptGenerator } from '../../prompt/generator.js';
export type DirectJsonExamples = Record<string, AgentToRendererMessage[] | string> | ReadonlyArray<AgentToRendererMessage[] | string>;
/**
 * Renders the Direct JSON prompt snippet: the payload rules, a schema block with the
 * protocol schemas, one schema block per catalog, and any examples inside `<a2ui-json>` tags.
 */
export declare class DirectJsonPromptGenerator extends PromptGenerator {
    private readonly examples?;
    private readonly allowedMessages?;
    private readonly decompiler;
    /**
     * @param catalogs Active catalogs to describe.
     * @param examples Optional examples keyed by catalog id or provided as an ordered list
     *     of turns, either as messages or as preformatted text.
     * @param allowedMessages Optional allowlist of message names (`createSurface`,
     *     `updateComponents`, ...). Only these messages are described. Without it, every
     *     message of the catalogs' protocol version is described.
     */
    constructor(catalogs: CatalogApi[], examples?: DirectJsonExamples | undefined, allowedMessages?: readonly string[] | undefined);
    /**
     * The payload rules, then a schema block with the protocol schemas: the agent-to-renderer
     * schema and the common types schema pruned to what the active catalogs and that schema
     * use. The protocol schemas live here rather than in the catalog instructions, so output
     * that combines several catalogs' instructions holds them once.
     */
    generateBaseRules(): string;
    /** A schema block holding one catalog's serialized JSON document (`catalog.toJson()`). */
    protected renderCatalogInstructions(catalog: CatalogApi): string;
    private isTurnArray;
    /**
     * Renders the examples.
     *
     * Examples keyed by catalog id are filtered to `catalog` when it is given. An ordered
     * list of turns is not tied to a catalog, so every turn is rendered either way, as in
     * Python's `DirectJsonPromptGenerator.generate_examples`.
     */
    generateExamples(catalog?: CatalogApi): string;
    protected renderExamples(catalog: CatalogApi): string;
    private renderTurns;
    private renderExampleTurn;
}
//# sourceMappingURL=prompt-generator.d.ts.map