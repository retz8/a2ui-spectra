import { AgentToRendererMessage } from '../../internal/web-core.js';
import { RawResponsePart } from '../../parser/response-part.js';
/**
 * Standard Direct JSON format decompiler.
 */
export declare class DirectJsonDecompiler {
    /**
     * Decompiles structured JSON payloads to pretty-printed JSON.
     */
    decompile(payload: AgentToRendererMessage[]): string;
    /**
     * Wraps raw response parts, adding format tags around A2UI payload sections.
     */
    wrap(blocks: RawResponsePart[]): string;
}
//# sourceMappingURL=decompiler.d.ts.map