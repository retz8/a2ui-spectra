/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { checkParserCatalogs } from '../../utils/catalog-checks.js';
import { DirectJsonParser } from './parser.js';
import { DirectJsonPromptGenerator } from './prompt-generator.js';
/** The keys whose string values a Direct JSON stream heals unless the format names others. */
const DEFAULT_PROGRESSIVE_KEYS = ['text'];
/**
 * Direct JSON format implementation.
 */
export class DirectJsonFormat {
    constructor(catalogs, examples, options = {}) {
        this.catalogs = catalogs;
        checkParserCatalogs(catalogs);
        this.progressiveKeys = [...(options.progressiveKeys ?? DEFAULT_PROGRESSIVE_KEYS)];
        this.bufferIncompleteComponents = options.bufferIncompleteComponents ?? false;
        this.promptGenerator = new DirectJsonPromptGenerator(catalogs, examples);
    }
    createParser() {
        return new DirectJsonParser(this.catalogs, {
            progressiveKeys: this.progressiveKeys,
            bufferIncompleteComponents: this.bufferIncompleteComponents,
        });
    }
}
/**
 * Factory for creating DirectJsonFormat instances.
 */
export class DirectJsonFormatFactory {
    constructor(options = {}) {
        this.options = options;
    }
    createFormat(catalogs, examples) {
        return new DirectJsonFormat(catalogs, examples, this.options);
    }
}
//# sourceMappingURL=format.js.map