/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { ParseError } from '../../errors.js';
import { BlockLexer, JSON_PAYLOAD_START_RE } from '../../parser/lexer.js';
import { Parser } from '../../parser/parser.js';
import { checkParserCatalogs } from '../../utils/catalog-checks.js';
import { CLOSE_TAG, OPEN_TAG, cleanRaw } from './blocks.js';
import { DirectJsonDecompiler } from './decompiler.js';
import { readJson } from './json-reader.js';
import { DirectJsonResponseStream } from './response-stream.js';
/** Parser for the Direct JSON format, for complete and streamed responses. */
export class DirectJsonParser extends Parser {
    /**
     * @param catalogs The active catalogs, which must target compatible protocol versions.
     * @param options How a stream reads values that are still arriving.
     * @throws {A2uiCatalogError} If no catalogs are given or their versions are incompatible.
     */
    constructor(catalogs, options = {}) {
        super();
        this.decompiler = new DirectJsonDecompiler();
        this.lexer = new BlockLexer(OPEN_TAG, CLOSE_TAG, new Set(["'", '"']), new Set(), JSON_PAYLOAD_START_RE, true);
        checkParserCatalogs(catalogs);
        this.catalogs = catalogs;
        this.progressiveKeys = new Set(options.progressiveKeys ?? []);
        this.bufferIncompleteComponents = options.bufferIncompleteComponents ?? false;
    }
    get supportsStreaming() {
        return true;
    }
    hasFormatContent(content, { complete = false } = {}) {
        const parts = this.lexer.tokenize(content);
        return parts.some(p => p.type === 'a2ui' && (!complete || p.isFinal));
    }
    unwrap(content) {
        return this.lexer.tokenize(content);
    }
    /**
     * Reads a block as a JSON message or a JSON array of messages.
     *
     * @throws {ParseError} If the block is empty or is not JSON.
     */
    compile(formatContent, isFinal = true) {
        if (!isFinal) {
            throw new ParseError(`The response ended inside an ${OPEN_TAG} block, before its ${CLOSE_TAG} tag.`);
        }
        const cleaned = cleanRaw(formatContent);
        if (!cleaned) {
            throw new ParseError('The direct JSON block is empty.');
        }
        let decoded;
        try {
            decoded = readJson(cleaned);
        }
        catch (e) {
            throw new ParseError(`The direct JSON block is not JSON: ${e.message}`);
        }
        return (Array.isArray(decoded) ? decoded : [decoded]);
    }
    decompile(a2uiPayload) {
        return this.decompiler.decompile(a2uiPayload);
    }
    wrap(blocks) {
        return this.decompiler.wrap(blocks);
    }
    openStream({ wrapped = true, state, afterRejectedBlock = 'end', } = {}) {
        return new DirectJsonResponseStream(this, {
            wrapped,
            state: state ?? this.emptyState(),
            afterRejectedBlock,
        });
    }
}
//# sourceMappingURL=parser.js.map