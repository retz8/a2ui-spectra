import { InferenceFormat, InferenceFormatFactory } from '../../inference-format.js';
import { CatalogApi } from '../../internal/web-core.js';
import { DirectJsonParser } from './parser.js';
import { DirectJsonExamples, DirectJsonPromptGenerator } from './prompt-generator.js';
/** Options for the Direct JSON format. */
export interface DirectJsonFormatOptions {
    /**
     * Keys whose string values a stream closes where they stand while they arrive, so a long
     * text is emitted as it grows. Defaults to `['text']`. Pass an empty list to emit each
     * message only once its values have arrived whole.
     */
    progressiveKeys?: Iterable<string>;
    /**
     * Whether a pre-v1.0 stream holds back incomplete components until their JSON object
     * closes rather than healing them as they arrive. Components of v1.0+ catalogs are always
     * held back regardless of this setting.
     */
    bufferIncompleteComponents?: boolean;
}
/**
 * Direct JSON format implementation.
 */
export declare class DirectJsonFormat implements InferenceFormat {
    private readonly catalogs;
    readonly promptGenerator: DirectJsonPromptGenerator;
    private readonly progressiveKeys;
    private readonly bufferIncompleteComponents;
    constructor(catalogs: CatalogApi[], examples?: DirectJsonExamples, options?: DirectJsonFormatOptions);
    createParser(): DirectJsonParser;
}
/**
 * Factory for creating DirectJsonFormat instances.
 */
export declare class DirectJsonFormatFactory implements InferenceFormatFactory {
    private readonly options;
    constructor(options?: DirectJsonFormatOptions);
    createFormat(catalogs: CatalogApi[], examples?: DirectJsonExamples): InferenceFormat;
}
//# sourceMappingURL=format.d.ts.map