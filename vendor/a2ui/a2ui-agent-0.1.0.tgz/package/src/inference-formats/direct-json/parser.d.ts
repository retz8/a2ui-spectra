import { AgentToRendererMessage, CatalogApi } from '../../internal/web-core.js';
import { ContinuingStreamOptions, Parser, StreamOptions } from '../../parser/parser.js';
import { RawResponsePart, StreamPart } from '../../parser/response-part.js';
import { DirectJsonResponseStream } from './response-stream.js';
/** Options for a Direct JSON parser. */
export interface DirectJsonParserOptions {
    /**
     * Keys whose string values a stream closes where they stand while they arrive, so a long
     * text is emitted as it grows. Values that start like a URL are never closed early. None
     * by default.
     */
    progressiveKeys?: Iterable<string>;
    /**
     * Whether a pre-v1.0 stream holds back incomplete components until their JSON object
     * closes rather than healing them as they arrive. Components of v1.0+ catalogs are always
     * held back regardless of this setting.
     */
    bufferIncompleteComponents?: boolean;
}
/** Parser for the Direct JSON format, for complete and streamed responses. */
export declare class DirectJsonParser extends Parser {
    /** The active catalogs. */
    readonly catalogs: CatalogApi[];
    /** The keys whose string values a stream heals while they arrive. */
    readonly progressiveKeys: ReadonlySet<string>;
    /** Whether pre-v1.0 streams hold components until their JSON object closes. */
    readonly bufferIncompleteComponents: boolean;
    private readonly decompiler;
    private readonly lexer;
    /**
     * @param catalogs The active catalogs, which must target compatible protocol versions.
     * @param options How a stream reads values that are still arriving.
     * @throws {A2uiCatalogError} If no catalogs are given or their versions are incompatible.
     */
    constructor(catalogs: CatalogApi[], options?: DirectJsonParserOptions);
    get supportsStreaming(): boolean;
    hasFormatContent(content: string, { complete }?: {
        complete?: boolean;
    }): boolean;
    unwrap(content: string): RawResponsePart[];
    /**
     * Reads a block as a JSON message or a JSON array of messages.
     *
     * @throws {ParseError} If the block is empty or is not JSON.
     */
    compile(formatContent: string, isFinal?: boolean): AgentToRendererMessage[];
    decompile(a2uiPayload: AgentToRendererMessage[]): string;
    wrap(blocks: RawResponsePart[]): string;
    openStream(options: ContinuingStreamOptions): DirectJsonResponseStream<StreamPart>;
    openStream(options?: StreamOptions): DirectJsonResponseStream;
}
//# sourceMappingURL=parser.d.ts.map