/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Reads the JSON a model writes, which is often almost JSON.
 *
 * Both readers accept what a model commonly gets wrong and a strict decoder rejects: a
 * trailing comma before `]` or `}`, and a raw line break or tab inside a string. When the
 * text does not read as it is, they read it again with curly quotes straightened, so a curly
 * quote inside a string that is otherwise valid JSON is kept.
 */
const NUMBER_RE = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/;
const HEX_RE = /^[0-9a-fA-F]{4}$/;
// Values that are never healed while they arrive: a cut URL is a different, usually broken,
// address rather than a shorter version of the same text.
const URL_PREFIXES = ['http://', 'https://', 'data:'];
const NEWLINE_STRIPPED_KEYS = new Set([
    'id',
    'component',
    'child',
    'surfaceId',
    'catalogId',
    // The v1.0 component-level catalog override.
    '@catalogId',
    'componentId',
]);
/** Thrown when the text is not JSON. */
export class JsonReadError extends Error {
    constructor(message) {
        super(message);
        this.name = 'JsonReadError';
    }
}
/**
 * Reads the complete JSON document `text`.
 *
 * @throws {JsonReadError} If `text` is not a single JSON value.
 */
export function readJson(text) {
    try {
        return new Reader(text, undefined).document();
    }
    catch (e) {
        const straight = straightenQuotes(text);
        if (straight === text)
            throw e;
        return new Reader(straight, undefined).document();
    }
}
/**
 * What the reads of a block still arriving keep from one chunk to the next.
 *
 * The block only grows, so a list or map that closed reads the same on every later chunk,
 * and so do the items of a list still open, up to the last one that closed. A read through
 * the cache takes those from it rather than reading their text again, so reading every chunk
 * of a block reads each character about once.
 */
export class PartialReadCache {
    constructor() {
        /** The state of the reads of the text as it is. */
        this.plain = new ReadState();
        /** The state of the reads of the text with curly quotes straightened, at the same offsets. */
        this.straight = new ReadState();
    }
}
class ReadState {
    constructor() {
        /** Each list or map that closed, by the offset of its opening bracket, with the offset after its closing one. */
        this.closed = new Map();
        /** Each list still open, by the offset of its opening bracket, with the items that closed and the offset after the last of them. */
        this.open = new Map();
    }
}
/**
 * Reads a partial JSON array or object into candidate envelopes.
 *
 * @param text The text of a block that may still be arriving.
 * @param progressiveKeys Keys whose string values are closed where they stand while they
 *     arrive.
 * @param options What to read and what earlier reads found.
 * @returns The messages read, after those earlier reads saw close. When the text is not
 *     JSON, no messages.
 */
export function readPartialMessages(text, progressiveKeys, { wholeItemKeys = [], cache, start = 0, end } = {}) {
    const progressive = new Set(progressiveKeys);
    const whole = new Set(wholeItemKeys);
    const read = (input, state) => new Reader(input, progressive, whole, state, start, end).messageItems();
    try {
        return read(text, cache?.plain);
    }
    catch (e) {
        if (!(e instanceof JsonReadError))
            throw e;
        const straight = straightenQuotes(text);
        if (straight === text)
            return { skipped: 0, messages: [] };
        try {
            return read(straight, cache?.straight);
        }
        catch (e2) {
            if (!(e2 instanceof JsonReadError))
                throw e2;
            return { skipped: 0, messages: [] };
        }
    }
}
function straightenQuotes(text) {
    return text
        .replace(/\u201c/g, '"')
        .replace(/\u201d/g, '"')
        .replace(/\u2018/g, "'")
        .replace(/\u2019/g, "'");
}
/** Thrown where the text ends before a value that cannot be healed. */
class Unfinished extends Error {
}
/** Recursive-descent JSON and partial-JSON reader. */
class Reader {
    /**
     * @param text The text to read.
     * @param progressiveKeys The keys whose string value may be closed early, or undefined when
     *     `text` must be complete.
     * @param wholeItemKeys The keys whose list value holds only the items that have closed.
     * @param state What earlier reads of `text` found, or undefined.
     * @param start Where to start reading.
     * @param end Where the part of `text` to read ends.
     */
    constructor(text, progressiveKeys, wholeItemKeys = new Set(), state, start = 0, end) {
        this.text = text;
        this.progressiveKeys = progressiveKeys;
        this.wholeItemKeys = wholeItemKeys;
        this.state = state;
        this.cut = false;
        this.inDataModel = false;
        this.i = start;
        this.limit = end ?? text.length;
    }
    get partial() {
        return this.progressiveKeys !== undefined;
    }
    get atEnd() {
        return this.i >= this.limit;
    }
    document() {
        this.skipSpace();
        const value = this.value(false);
        this.skipSpace();
        if (!this.atEnd)
            this.fail('unexpected text after the JSON value');
        return value;
    }
    messageItems() {
        this.skipSpace();
        if (this.atEnd)
            return { skipped: 0, messages: [] };
        if (this.text[this.i] !== '[') {
            try {
                const message = this.message();
                this.skipSpace();
                if (!this.atEnd)
                    this.fail('unexpected text after the JSON value');
                return { skipped: 0, messages: [message] };
            }
            catch (e) {
                if (e instanceof Unfinished)
                    return { skipped: 0, messages: [] };
                throw e;
            }
        }
        this.i += 1;
        // How many messages closed, and where the text after the last of them starts, for the
        // next read to go on from.
        let skipped = 0;
        let closedCount = 0;
        let resume = this.i;
        let afterItem = false;
        if (this.state?.messages) {
            [closedCount, resume] = this.state.messages;
            skipped = closedCount;
            this.i = resume;
            afterItem = closedCount > 0;
        }
        const messages = [];
        const soFar = () => {
            if (this.state)
                this.state.messages = [closedCount, resume];
            return { skipped, messages };
        };
        for (;;) {
            if (afterItem) {
                this.skipSpace();
                if (this.atEnd)
                    return soFar();
                if (this.text[this.i] === ',') {
                    this.i += 1;
                }
                else if (this.text[this.i] !== ']') {
                    this.fail("expected ',' or ']'");
                }
            }
            afterItem = true;
            this.skipSpace();
            if (this.atEnd)
                return soFar();
            if (this.text[this.i] === ']') {
                this.i += 1;
                this.skipSpace();
                if (!this.atEnd)
                    this.fail('unexpected text after the JSON value');
                return { skipped, messages };
            }
            let message;
            try {
                message = this.message();
            }
            catch (e) {
                if (e instanceof Unfinished)
                    return soFar();
                throw e;
            }
            messages.push(message);
            if (message[1]) {
                closedCount = skipped + messages.length;
                resume = this.i;
            }
        }
    }
    /** Reads one message, noting whether the text closed it or it was healed. */
    message() {
        this.cut = false;
        const message = this.value(false);
        return [message, !this.cut];
    }
    value(healable, stripNewlines = false) {
        if (this.atEnd)
            this.end();
        const c = this.text[this.i];
        if (c === '{')
            return this.closedOr(() => this.object());
        if (c === '[')
            return this.closedOr(() => this.array(false));
        if (c === '"')
            return this.string(healable, stripNewlines);
        if (c === '-' || (c >= '0' && c <= '9'))
            return this.number();
        const words = [
            ['true', true],
            ['false', false],
            ['null', null],
        ];
        for (const [word, val] of words) {
            if (this.i + word.length <= this.limit && this.text.startsWith(word, this.i)) {
                this.i += word.length;
                return val;
            }
            if (this.partial && word.startsWith(this.text.slice(this.i, this.limit))) {
                this.end();
            }
        }
        return this.fail(`unexpected character '${c}'`);
    }
    /**
     * Reads a list or map through `read`, unless an earlier read saw the one that starts here
     * close, and keeps it if it closes.
     */
    closedOr(read) {
        const closed = this.state?.closed;
        if (!closed)
            return read();
        const start = this.i;
        const known = closed.get(start);
        if (known) {
            this.i = known[1];
            return known[0];
        }
        const cutBefore = this.cut;
        this.cut = false;
        const value = read();
        if (!this.cut)
            closed.set(start, [value, this.i]);
        this.cut = cutBefore || this.cut;
        return value;
    }
    object(parentKey) {
        this.i += 1;
        const obj = {};
        for (;;) {
            this.skipSpace();
            if (this.atEnd)
                return this.healed(obj);
            if (this.text[this.i] === '}') {
                this.i += 1;
                return obj;
            }
            if (this.text[this.i] !== '"')
                this.fail('expected a key');
            const key = this.string(false, !this.inDataModel);
            this.skipSpace();
            if (this.atEnd)
                this.end();
            if (this.text[this.i] !== ':')
                this.fail(`expected ':' after key '${key}'`);
            this.i += 1;
            this.skipSpace();
            const isDataValue = !this.inDataModel &&
                ((parentKey === 'updateDataModel' && key === 'value') ||
                    (parentKey === 'createSurface' && key === 'dataModel'));
            if (isDataValue)
                this.inDataModel = true;
            let value;
            try {
                if (!this.atEnd && this.text[this.i] === '[') {
                    value = this.closedOr(() => this.array(this.partial && this.wholeItemKeys.has(key), key === 'children' && !this.inDataModel));
                }
                else if (!this.atEnd && this.text[this.i] === '{') {
                    value = this.closedOr(() => this.object(key));
                }
                else {
                    value = this.value(this.progressiveKeys?.has(key) ?? false, NEWLINE_STRIPPED_KEYS.has(key) && !this.inDataModel);
                }
            }
            finally {
                if (isDataValue)
                    this.inDataModel = false;
            }
            // Defined as an own property, so a key such as `__proto__` stays plain data.
            Object.defineProperty(obj, key, {
                value,
                enumerable: true,
                writable: true,
                configurable: true,
            });
            this.skipSpace();
            if (this.atEnd)
                return this.healed(obj);
            if (this.text[this.i] === ',') {
                this.i += 1;
            }
            else if (this.text[this.i] !== '}') {
                this.fail("expected ',' or '}'");
            }
        }
    }
    /**
     * Reads a list. When `wholeItems` is true, an item the text ends in is left out rather than
     * healed. A list still open goes on after the items an earlier read saw close.
     */
    array(wholeItems, stripItemNewlines = false) {
        const start = this.i;
        this.i += 1;
        let arr = [];
        // How many items closed, and where the text after the last of them starts.
        let closedItems = 0;
        let resume = this.i;
        let afterItem = false;
        const known = this.state?.open.get(start);
        if (known) {
            arr = [...known[0]];
            closedItems = arr.length;
            resume = this.i = known[1];
            afterItem = closedItems > 0;
        }
        const healed = () => {
            this.state?.open.set(start, [
                closedItems === arr.length ? arr : arr.slice(0, closedItems),
                resume,
            ]);
            return this.healed(arr);
        };
        for (;;) {
            if (afterItem) {
                this.skipSpace();
                if (this.atEnd)
                    return healed();
                if (this.text[this.i] === ',') {
                    this.i += 1;
                }
                else if (this.text[this.i] !== ']') {
                    this.fail("expected ',' or ']'");
                }
            }
            afterItem = true;
            this.skipSpace();
            if (this.atEnd)
                return healed();
            if (this.text[this.i] === ']') {
                this.i += 1;
                this.state?.open.delete(start);
                return arr;
            }
            const cutBefore = this.cut;
            this.cut = false;
            let item;
            if (wholeItems) {
                try {
                    item = this.value(false, stripItemNewlines);
                }
                catch (e) {
                    if (e instanceof Unfinished)
                        return healed();
                    throw e;
                }
                if (this.cut)
                    return healed();
            }
            else {
                item = this.value(false, stripItemNewlines);
            }
            arr.push(item);
            // An item closed early ends the text, so the list closes early too.
            if (this.cut)
                continue;
            this.cut = cutBefore;
            closedItems = arr.length;
            resume = this.i;
        }
    }
    healed(value) {
        if (!this.partial)
            this.end();
        this.cut = true;
        return value;
    }
    string(healable, stripNewlines = false) {
        this.i += 1;
        let buf = '';
        const text = this.text;
        const n = this.limit;
        while (!this.atEnd) {
            const c = text[this.i];
            if (c === '"') {
                this.i += 1;
                return buf;
            }
            if (c !== '\\') {
                if (stripNewlines && (c === '\r' || c === '\n')) {
                    this.i += 1;
                    continue;
                }
                buf += c;
                this.i += 1;
                continue;
            }
            if (this.i + 1 >= n) {
                this.i = n;
                break;
            }
            const escaped = text[this.i + 1];
            if (escaped === '"' || escaped === '\\' || escaped === '/') {
                buf += escaped;
            }
            else if (escaped === 'b') {
                buf += '\b';
            }
            else if (escaped === 'f') {
                buf += '\f';
            }
            else if (escaped === 'n') {
                buf += '\n';
            }
            else if (escaped === 'r') {
                buf += '\r';
            }
            else if (escaped === 't') {
                buf += '\t';
            }
            else if (escaped === 'u') {
                if (this.i + 6 > n) {
                    this.i = n;
                    continue;
                }
                let code = this.hex(text.slice(this.i + 2, this.i + 6));
                if (code >= 0xd800 && code <= 0xdbff) {
                    if (this.i + 12 > n) {
                        const rest = text.slice(this.i + 6, n);
                        if (this.partial &&
                            (rest === '\\u'.slice(0, n - (this.i + 6)) ||
                                (this.i + 8 <= n && text.slice(this.i + 6, this.i + 8) === '\\u'))) {
                            this.i = n;
                            continue;
                        }
                    }
                    if (this.i + 12 <= n && text.slice(this.i + 6, this.i + 8) === '\\u') {
                        const low = this.hex(text.slice(this.i + 8, this.i + 12));
                        if (low >= 0xdc00 && low <= 0xdfff) {
                            code = 0x10000 + ((code - 0xd800) << 10) + (low - 0xdc00);
                            this.i += 6;
                        }
                    }
                }
                buf += String.fromCodePoint(code);
                this.i += 4;
            }
            else {
                this.fail(`invalid escape '\\${escaped}'`);
            }
            this.i += 2;
        }
        if (healable && this.partial) {
            // A URL that is still arriving names the wrong resource, so it waits for its closing
            // quote like any value that can't heal.
            if (!URL_PREFIXES.some(prefix => buf.startsWith(prefix))) {
                this.cut = true;
                return buf;
            }
        }
        return this.end();
    }
    hex(digits) {
        if (!HEX_RE.test(digits))
            this.fail('invalid unicode escape');
        return parseInt(digits, 16);
    }
    number() {
        const start = this.i;
        if (this.text[this.i] === '-')
            this.i += 1;
        while (!this.atEnd && /[0-9+\-.eE]/.test(this.text[this.i])) {
            this.i += 1;
        }
        if (this.atEnd && this.partial)
            this.end();
        const literal = this.text.slice(start, this.i);
        if (!NUMBER_RE.test(literal))
            this.fail(`invalid number '${literal}'`);
        return Number(literal);
    }
    skipSpace() {
        while (!this.atEnd && ' \t\n\r'.includes(this.text[this.i])) {
            this.i += 1;
        }
    }
    end() {
        if (this.partial)
            throw new Unfinished();
        return this.fail('unexpected end of the JSON text');
    }
    fail(reason) {
        throw new JsonReadError(`Invalid JSON at ${this.i}: ${reason}`);
    }
}
//# sourceMappingURL=json-reader.js.map