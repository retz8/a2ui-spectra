import { InferenceFormat } from '../inference-format.js';
import { CatalogApi } from '../internal/web-core.js';
import { Skill, SkillSet } from './skill.js';
export interface GenerateSkillOptions {
    /** Skill name. Defaults to `a2ui`. */
    name?: string;
    /** LLM-facing description. Defaults to a generic one. */
    description?: string;
    /** Catalogs to compile. Defaults to the catalogs bound to the format. */
    catalogs?: readonly CatalogApi[];
}
export interface GenerateCatalogSkillOptions {
    /** Catalog to compile. Defaults to the first catalog bound to the format. */
    catalog?: CatalogApi;
    /** Skill name. Defaults to `a2ui-<catalog name>`. */
    name?: string;
    /** LLM-facing description. Defaults to one derived from the catalog name. */
    description?: string;
    /** Whether to append the catalog's examples. Defaults to `true`. */
    includeExamples?: boolean;
}
export interface GenerateCoreSkillOptions {
    /** Skill name. Defaults to `a2ui-core`. */
    name?: string;
    /** LLM-facing description. Defaults to a generic one. */
    description?: string;
}
export interface GenerateSkillSetOptions {
    /** Catalogs to compile, one skill each. Defaults to the catalogs bound to the format. */
    catalogs?: readonly CatalogApi[];
    /** Name of the core syntax skill. Defaults to `a2ui-core`. */
    coreName?: string;
}
/**
 * Compiles InferenceFormat rules and Catalog instances into Skill and SkillSet packages.
 */
export declare class SkillGenerator {
    readonly fmt: InferenceFormat;
    constructor(fmt: InferenceFormat);
    /**
     * Compiles an InferenceFormat into a single unified (monolithic) Skill.
     *
     * If `catalogs` is not specified, defaults to the catalogs configured on the inference format.
     */
    generateSkill(options?: GenerateSkillOptions): Skill;
    /**
     * Compiles a single catalog into a dedicated catalog Skill.
     *
     * If `catalog` is not specified, defaults to the first catalog configured on the inference
     * format.
     *
     * @throws {A2uiCatalogError} If no catalog is given and the format has none.
     */
    generateCatalogSkill(options?: GenerateCatalogSkillOptions): Skill;
    private buildCatalogSkill;
    /**
     * Compiles core syntax rules for an inference format into a base core skill.
     */
    generateCoreSkill(options?: GenerateCoreSkillOptions): Skill;
    /**
     * Generates standard modular skills (`a2ui-core` + 1 skill per catalog) for an inference format.
     *
     * If `catalogs` is not specified, defaults to the catalogs configured on the inference format.
     */
    generateSkillSet(options?: GenerateSkillSetOptions): SkillSet;
}
//# sourceMappingURL=generator.d.ts.map