import { InferenceFormat } from '../inference-format.js';
import { CatalogApi } from '../internal/web-core.js';
/**
 * Derives a clean, LLM-friendly catalog name from a catalog ID or URL.
 */
export declare function cleanCatalogName(catalog: unknown): string;
/**
 * Resolves catalogs from an explicit sequence or the format's prompt generator.
 */
export declare function resolveCatalogsList(catalogs: readonly CatalogApi[] | undefined, fmt: InferenceFormat): CatalogApi[];
/**
 * Checks that a skill filename is a relative path that stays inside the directory a
 * `SkillSet` is exported to: no absolute path, no empty segment, and no `.` or `..`
 * segment. Both `/` and `\\` separate segments, so a filename is rejected on every
 * platform it would escape on.
 *
 * @throws {A2uiValidationError} If the filename is not such a path.
 */
export declare function validateSkillFilename(filename: string): string;
export interface SkillOptions {
    name: string;
    description: string;
    content: string;
    metadata?: Record<string, unknown>;
    filename?: string;
}
/**
 * Represents a single A2UI Skill package with YAML frontmatter metadata and markdown content.
 *
 * Allows developers to inspect and mutate fields (`name`, `description`, `metadata`, `content`)
 * before serializing back to markdown format.
 *
 * `filename` is the path the skill is written to, relative to the directory a `SkillSet` is
 * exported to. It is checked on construction (see {@link validateSkillFilename}) and is
 * read-only, so `SkillSet.exportToDirectory` can rely on every filename staying inside its
 * output directory. To write a skill somewhere else, construct a new one.
 */
export declare class Skill {
    name: string;
    description: string;
    content: string;
    metadata: Record<string, unknown>;
    readonly filename: string;
    constructor(options: SkillOptions);
    /**
     * Serializes skill object back to a complete markdown string with YAML frontmatter.
     */
    toMarkdown(): string;
}
/**
 * Collection of Skill objects representing a modular or multi-skill package.
 */
export declare class SkillSet implements Iterable<[string, Skill]> {
    private readonly skills;
    constructor(skills?: Record<string, Skill> | Iterable<[string, Skill]>);
    /**
     * Adds a Skill to the collection, keyed by its filename.
     *
     * The filename is checked again here: it is read-only in TypeScript, but a JavaScript
     * caller can still reassign it, and the export trusts every key of this map.
     */
    add(skill: Skill): void;
    /**
     * Retrieves a Skill by filename, exact skill name, or substring match (minimum 3 characters).
     */
    get(filename: string): Skill | undefined;
    /**
     * Checks whether an exact filename key exists in the skill set.
     */
    has(filename: string): boolean;
    /**
     * Serializes all skills to a dictionary mapping filename to markdown text.
     */
    toDict(): Record<string, string>;
    /**
     * Exports all skills in the set to the specified output directory on disk.
     *
     * The directory holding each skill file (for example, `{outputDir}/a2ui-core`
     * or `{outputDir}/a2ui-basic`) is removed before writing so no stale files
     * persist. A symlink or file at that path is removed as such, not followed.
     * Unrelated sibling directories and files in `outputDir` are preserved, and
     * `outputDir` itself is never removed.
     *
     * Every filename was checked by {@link validateSkillFilename} when it entered
     * the set, and each skill directory's parent is resolved through symlinks before
     * anything is removed, so nothing here can reach outside `outputDir`.
     *
     * @param outputDir Root directory where skill packages should be written.
     * @returns A dictionary mapping skill filenames to generated markdown content.
     * @throws {A2uiValidationError} If a skill directory's parent is a symlink that
     *     resolves outside `outputDir`. Nothing is removed or written in that case.
     */
    exportToDirectory(outputDir: string): Record<string, string>;
    get size(): number;
    keys(): IterableIterator<string>;
    values(): IterableIterator<Skill>;
    entries(): IterableIterator<[string, Skill]>;
    [Symbol.iterator](): IterableIterator<[string, Skill]>;
}
//# sourceMappingURL=skill.d.ts.map