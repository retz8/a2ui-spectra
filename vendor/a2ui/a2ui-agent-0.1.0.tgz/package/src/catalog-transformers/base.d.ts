import { CatalogApi } from '../internal/web-core.js';
/**
 * Abstract base interface for transformation rules applied to catalog schemas.
 */
export interface CatalogTransformer {
    /**
     * Transforms a Catalog into a modified Catalog.
     *
     * Must return a new catalog instance rather than mutating the input.
     *
     * @param catalog The catalog to transform.
     * @returns A new, transformed catalog instance.
     */
    transform(catalog: CatalogApi): CatalogApi;
}
//# sourceMappingURL=base.d.ts.map