import { CatalogTransformer } from './base.js';
import { CatalogApi } from '../internal/web-core.js';
/**
 * Prunes catalog component definitions to an allowlist of allowed components.
 */
export declare class ComponentPruningTransformer implements CatalogTransformer {
    /** The set of allowed component names. */
    readonly allowedComponents: Set<string>;
    /**
     * Initializes a ComponentPruningTransformer.
     *
     * @param allowedComponents List of allowed component names, or null to allow none.
     */
    constructor(allowedComponents: string[] | null);
    /**
     * Returns a new Catalog filtered to only include components in allowedComponents.
     *
     * @param catalog The catalog to prune.
     * @returns A new, pruned catalog instance.
     */
    transform(catalog: CatalogApi): CatalogApi;
}
/**
 * Prunes catalog function definitions to an allowlist of allowed functions.
 */
export declare class FunctionPruningTransformer implements CatalogTransformer {
    /** The set of allowed function names. */
    readonly allowedFunctions: Set<string>;
    /**
     * Initializes a FunctionPruningTransformer.
     *
     * @param allowedFunctions List of allowed function names, or null to allow none.
     */
    constructor(allowedFunctions: string[] | null);
    /**
     * Returns a new Catalog filtered to only include functions in allowedFunctions.
     *
     * @param catalog The catalog to prune.
     * @returns A new, pruned catalog instance.
     */
    transform(catalog: CatalogApi): CatalogApi;
}
//# sourceMappingURL=pruning.d.ts.map