import { RawResponsePart } from './response-part.js';
export declare enum LexerState {
    NORMAL = 0,// Outside tag (conversational text)
    IN_A2UI = 1,// Inside tag (scanning code)
    IN_STRING = 2,// Inside string literal
    IN_COMMENT = 3,// Inside single-line comment
    IN_BLOCK_COMMENT = 4
}
export declare const EXPRESS_PAYLOAD_START_RE: RegExp;
export declare const JSON_PAYLOAD_START_RE: RegExp;
/**
 * A generic state-machine-based scanner to extract structured format blocks from text.
 *
 * Correctly handles nested string literals and comments to prevent premature tag detection,
 * and strips Markdown code block wrapping artifacts.
 */
export declare class BlockLexer {
    private readonly openTagPattern;
    private readonly openTagSearchPattern;
    private readonly closeTagPattern;
    private readonly closeTagSearchPattern;
    private readonly stringDelimiters;
    private readonly singleLineComments;
    private readonly payloadStartPattern;
    private readonly stripEdgeBackticks;
    private readonly blockComments;
    /**
     * Initializes the block lexer with tag patterns, string delimiters, and comments.
     *
     * @param openTag Either the literal open tag string or a pre-compiled regex pattern.
     * @param closeTag Either the literal close tag string or a pre-compiled regex pattern.
     * @param stringDelimiters Character set representing string bounds.
     * @param singleLineComments Character set representing single-line comment markers.
     * @param payloadStartPattern Line-anchored regex matching the start of an unfenced payload.
     * @param stripEdgeBackticks Whether to strip inline-code backticks adjacent to tags.
     * @param blockComments Pairs of open and close markers for block comments.
     */
    constructor(openTag?: string | RegExp, closeTag?: string | RegExp, stringDelimiters?: Set<string>, singleLineComments?: Set<string>, payloadStartPattern?: RegExp, stripEdgeBackticks?: boolean, blockComments?: ReadonlyArray<readonly [string, string]>);
    private toStickyRegExp;
    private toSearchRegExp;
    /**
     * Cleans Markdown code block wrappers from either conversational text or inner raw content.
     *
     * A run made of nothing but backticks is left over from tags written as inline code, so it is
     * dropped.
     */
    private cleanMarkdown;
    /**
     * Cleans a raw block: Markdown fences, then backticks left at its edges.
     *
     * No payload format starts or ends with a backtick, so the ones at the edges are left over from
     * tags written as inline code, such as `` `<a2ui>` ``.
     */
    private cleanRaw;
    private addText;
    private scanBlock;
    private tryRecoverUnmatchedClose;
    /**
     * Scans response content to extract format blocks.
     *
     * @param content The raw text response string to scan.
     * @returns A list of tokenized response parts.
     */
    tokenize(content: string): RawResponsePart[];
}
//# sourceMappingURL=lexer.d.ts.map