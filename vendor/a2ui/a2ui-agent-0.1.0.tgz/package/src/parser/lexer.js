/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export var LexerState;
(function (LexerState) {
    LexerState[LexerState["NORMAL"] = 0] = "NORMAL";
    LexerState[LexerState["IN_A2UI"] = 1] = "IN_A2UI";
    LexerState[LexerState["IN_STRING"] = 2] = "IN_STRING";
    LexerState[LexerState["IN_COMMENT"] = 3] = "IN_COMMENT";
    LexerState[LexerState["IN_BLOCK_COMMENT"] = 4] = "IN_BLOCK_COMMENT";
})(LexerState || (LexerState = {}));
const LEADING_FENCE_RE = /^```[a-zA-Z0-9_-]*\s*/i;
const TRAILING_FENCE_RE = /\s*```[a-zA-Z0-9_-]*$/i;
const OPEN_FENCE_RE = /^[ \t]*```[a-zA-Z0-9_-]*[ \t]*\r?\n?/gm;
const CLOSING_FENCE_END_RE = /\r?\n?[ \t]*```[ \t]*\r?\n?$/;
export const EXPRESS_PAYLOAD_START_RE = /^[ \t]*(?:surface\s*\(|deleteSurface\s*\(|\$[a-zA-Z0-9_/]*\s*=(?!=)|[a-zA-Z_][a-zA-Z0-9_]*\s*=(?!=))/m;
export const JSON_PAYLOAD_START_RE = /^[ \t]*(?:\[\s*(?:\{|\]|$)|\{\s*(?:"|\}|$))/m;
/**
 * A generic state-machine-based scanner to extract structured format blocks from text.
 *
 * Correctly handles nested string literals and comments to prevent premature tag detection,
 * and strips Markdown code block wrapping artifacts.
 */
export class BlockLexer {
    /**
     * Initializes the block lexer with tag patterns, string delimiters, and comments.
     *
     * @param openTag Either the literal open tag string or a pre-compiled regex pattern.
     * @param closeTag Either the literal close tag string or a pre-compiled regex pattern.
     * @param stringDelimiters Character set representing string bounds.
     * @param singleLineComments Character set representing single-line comment markers.
     * @param payloadStartPattern Line-anchored regex matching the start of an unfenced payload.
     * @param stripEdgeBackticks Whether to strip inline-code backticks adjacent to tags.
     * @param blockComments Pairs of open and close markers for block comments.
     */
    constructor(openTag = '<a2ui>', closeTag = '</a2ui>', stringDelimiters = new Set(["'", '"']), singleLineComments = new Set(['#']), payloadStartPattern = EXPRESS_PAYLOAD_START_RE, stripEdgeBackticks = false, blockComments = []) {
        this.openTagPattern = this.toStickyRegExp(openTag, false);
        this.openTagSearchPattern = this.toSearchRegExp(openTag, false);
        this.closeTagPattern = this.toStickyRegExp(closeTag, true);
        this.closeTagSearchPattern = this.toSearchRegExp(closeTag, true);
        this.stringDelimiters = stringDelimiters;
        this.singleLineComments = singleLineComments;
        this.payloadStartPattern = payloadStartPattern;
        this.stripEdgeBackticks = stripEdgeBackticks;
        this.blockComments = blockComments;
        if (blockComments.some(([open, close]) => !open || !close)) {
            // An empty marker matches everywhere and would stop the scan advancing.
            throw new Error('Block comment markers must be non-empty strings.');
        }
    }
    toStickyRegExp(tag, isClose) {
        if (typeof tag === 'string') {
            const tagName = tag.replace(/[<>/]/g, '');
            if (isClose) {
                return new RegExp(`</${tagName}\\s*>`, 'iy');
            }
            return new RegExp(`<${tagName}(?:\\s[^>]*)?>`, 'iy');
        }
        let flags = tag.flags;
        if (!flags.includes('y')) {
            flags += 'y';
        }
        let source = tag.source;
        if (source.startsWith('^')) {
            source = source.substring(1);
        }
        return new RegExp(source, flags);
    }
    toSearchRegExp(tag, isClose) {
        if (typeof tag === 'string') {
            const tagName = tag.replace(/[<>/]/g, '');
            if (isClose) {
                return new RegExp(`</${tagName}\\s*>`, 'i');
            }
            return new RegExp(`<${tagName}(?:\\s[^>]*)?>`, 'i');
        }
        const flags = tag.flags.replace(/[yg]/g, '');
        let source = tag.source;
        if (source.startsWith('^')) {
            source = source.substring(1);
        }
        return new RegExp(source, flags);
    }
    /**
     * Cleans Markdown code block wrappers from either conversational text or inner raw content.
     *
     * A run made of nothing but backticks is left over from tags written as inline code, so it is
     * dropped.
     */
    cleanMarkdown(text) {
        if (!text) {
            return '';
        }
        let cleaned = text.trim();
        cleaned = cleaned.replace(LEADING_FENCE_RE, '');
        cleaned = cleaned.replace(TRAILING_FENCE_RE, '');
        cleaned = cleaned.trim();
        return /^`*$/.test(cleaned) ? '' : cleaned;
    }
    /**
     * Cleans a raw block: Markdown fences, then backticks left at its edges.
     *
     * No payload format starts or ends with a backtick, so the ones at the edges are left over from
     * tags written as inline code, such as `` `<a2ui>` ``.
     */
    cleanRaw(text) {
        return this.cleanMarkdown(text)
            .replace(/^`+|`+$/g, '')
            .trim();
    }
    addText(parts, text) {
        const cleaned = this.cleanMarkdown(text);
        if (cleaned) {
            parts.push({ type: 'text', text: cleaned, isFinal: true });
        }
    }
    scanBlock(content, start, end) {
        let i = start;
        let state = LexerState.IN_A2UI;
        let stringDelim = null;
        let tripleQuote = false;
        let blockClose = '';
        while (i < end) {
            if (state === LexerState.IN_A2UI) {
                this.closeTagPattern.lastIndex = i;
                const match = this.closeTagPattern.exec(content);
                if (match && this.closeTagPattern.lastIndex <= end) {
                    return [i, this.closeTagPattern.lastIndex];
                }
                const ch = content[i];
                if (this.stringDelimiters.has(ch)) {
                    if (i + 2 < end && content.startsWith(ch.repeat(3), i)) {
                        stringDelim = ch.repeat(3);
                        tripleQuote = true;
                        i += 3;
                    }
                    else {
                        stringDelim = ch;
                        tripleQuote = false;
                        i += 1;
                    }
                    state = LexerState.IN_STRING;
                    continue;
                }
                const block = this.blockComments.find(([open]) => content.startsWith(open, i));
                if (block) {
                    i += block[0].length;
                    blockClose = block[1];
                    state = LexerState.IN_BLOCK_COMMENT;
                    continue;
                }
                let commentStart = false;
                for (const cm of this.singleLineComments) {
                    if (content.startsWith(cm, i)) {
                        i += cm.length;
                        state = LexerState.IN_COMMENT;
                        commentStart = true;
                        break;
                    }
                }
                if (commentStart) {
                    continue;
                }
                i += 1;
                continue;
            }
            if (state === LexerState.IN_STRING) {
                if (content[i] === '\\') {
                    i += 2;
                    continue;
                }
                if (tripleQuote) {
                    if (content.startsWith(stringDelim, i)) {
                        i += 3;
                        state = LexerState.IN_A2UI;
                        continue;
                    }
                }
                else {
                    if (content[i] === stringDelim) {
                        i += 1;
                        state = LexerState.IN_A2UI;
                        continue;
                    }
                }
                i += 1;
                continue;
            }
            if (state === LexerState.IN_COMMENT) {
                this.closeTagPattern.lastIndex = i;
                const match = this.closeTagPattern.exec(content);
                if (match && this.closeTagPattern.lastIndex <= end) {
                    return [i, this.closeTagPattern.lastIndex];
                }
                const ch = content[i];
                if (ch === '\n' || ch === '\r') {
                    state = LexerState.IN_A2UI;
                }
                i += 1;
                continue;
            }
            if (state === LexerState.IN_BLOCK_COMMENT) {
                // A close tag inside a block comment does not end the block.
                if (content.startsWith(blockClose, i)) {
                    i += blockClose.length;
                    state = LexerState.IN_A2UI;
                    continue;
                }
                i += 1;
                continue;
            }
        }
        return null;
    }
    tryRecoverUnmatchedClose(parts, content, start, searchEnd) {
        const segment = content.slice(start, searchEnd);
        if (!this.closeTagSearchPattern.test(segment)) {
            return null;
        }
        const fences = Array.from(segment.matchAll(OPEN_FENCE_RE));
        for (let idx = 0; idx < fences.length; idx += 2) {
            const fence = fences[idx];
            const fenceStart = fence.index ?? 0;
            const fenceEnd = fenceStart + fence[0].length;
            const closeSpan = this.scanBlock(segment, fenceEnd, segment.length);
            if (!closeSpan) {
                continue;
            }
            const [closeStart, closeEnd] = closeSpan;
            const body = segment.slice(fenceEnd, closeStart);
            const bodyStripped = body.replace(CLOSING_FENCE_END_RE, '');
            OPEN_FENCE_RE.lastIndex = 0;
            if (OPEN_FENCE_RE.test(bodyStripped)) {
                continue;
            }
            const rawContent = this.cleanRaw(bodyStripped);
            if (!rawContent) {
                continue;
            }
            this.addText(parts, segment.slice(0, fenceStart));
            parts.push({ type: 'a2ui', a2uiRaw: rawContent, isFinal: true });
            return start + closeEnd;
        }
        let searchFrom = 0;
        let pairIdx = 0;
        while (pairIdx + 1 < fences.length) {
            const closeFence = fences[pairIdx + 1];
            const closeFenceEnd = (closeFence.index ?? 0) + closeFence[0].length;
            if (!this.scanBlock(segment, closeFenceEnd, segment.length)) {
                break;
            }
            searchFrom = closeFenceEnd;
            pairIdx += 2;
        }
        const subSegment = segment.slice(searchFrom);
        const stmtMatch = this.payloadStartPattern.exec(subSegment);
        if (!stmtMatch || stmtMatch.index === undefined) {
            return null;
        }
        const stmtStart = searchFrom + stmtMatch.index;
        const closeSpan = this.scanBlock(segment, stmtStart, segment.length);
        if (!closeSpan) {
            return null;
        }
        const [closeStart, closeEnd] = closeSpan;
        const rawContent = this.cleanRaw(segment.slice(stmtStart, closeStart));
        if (!rawContent) {
            return null;
        }
        this.addText(parts, segment.slice(0, stmtStart));
        parts.push({ type: 'a2ui', a2uiRaw: rawContent, isFinal: true });
        return start + closeEnd;
    }
    /**
     * Scans response content to extract format blocks.
     *
     * @param content The raw text response string to scan.
     * @returns A list of tokenized response parts.
     */
    tokenize(content) {
        const parts = [];
        const n = content.length;
        let i = 0;
        let recoveredUnmatched = false;
        while (i < n) {
            const remaining = content.slice(i);
            const openMatch = this.openTagSearchPattern.exec(remaining);
            const openStart = openMatch && openMatch.index !== undefined ? i + openMatch.index : null;
            const searchEnd = openStart ?? n;
            if (!recoveredUnmatched && searchEnd > i) {
                const nextI = this.tryRecoverUnmatchedClose(parts, content, i, searchEnd);
                if (nextI !== null) {
                    recoveredUnmatched = true;
                    i = nextI;
                    continue;
                }
            }
            if (openStart === null || !openMatch) {
                break;
            }
            let textBefore = content.slice(i, openStart);
            if (this.stripEdgeBackticks && textBefore.endsWith('`')) {
                textBefore = textBefore.replace(/`+$/, '');
            }
            this.addText(parts, textBefore);
            const openEnd = openStart + openMatch[0].length;
            const closeSpan = this.scanBlock(content, openEnd, n);
            if (!closeSpan) {
                parts.push({
                    type: 'a2ui',
                    a2uiRaw: this.cleanRaw(content.slice(openEnd)),
                    isFinal: false,
                });
                return parts;
            }
            const [closeStart, closeEnd] = closeSpan;
            parts.push({
                type: 'a2ui',
                a2uiRaw: this.cleanRaw(content.slice(openEnd, closeStart)),
                isFinal: true,
            });
            i = closeEnd;
            if (this.stripEdgeBackticks) {
                while (i < n && content[i] === '`') {
                    i++;
                }
            }
        }
        this.addText(parts, content.slice(i));
        return parts;
    }
}
//# sourceMappingURL=lexer.js.map