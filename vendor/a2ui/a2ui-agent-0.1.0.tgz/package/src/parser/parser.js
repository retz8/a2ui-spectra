/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiCompilationError, withPartialResults } from '../errors.js';
import { A2uiError } from '../internal/web-core.js';
import { RendererState } from '../utils/renderer-state.js';
/**
 * Abstract base class for A2UI payload parsers.
 *
 * A format implements `compile` and `decompile`, which translate between its notation and
 * A2UI messages, and the tag handling around them. The base class reads model responses:
 * `parseResponse` reads a whole one and `openStream` a streamed one, and both check every
 * message they compile against a `RendererState`, the one a call is given or a new one. A
 * chat agent passes none, so every turn shows new UI. A canvas agent passes the same state
 * every turn, so each turn is checked against the surfaces earlier turns built.
 *
 * A parser holds no state, so one parser can be reused across turns and responses.
 */
export class Parser {
    /**
     * Creates the empty state a call uses when it is given none.
     *
     * A call without a state checks a response that shows new UI, so an update to a surface
     * the response did not create is rejected.
     */
    emptyState() {
        return new RendererState(this.catalogs);
    }
    /**
     * Parses a complete model response into structured parts.
     *
     * Nothing has been sent when a whole response is parsed, so it is checked as a whole: a
     * component may name a child that a later block adds, and the trees of the surfaces the
     * response touches are checked once every block is applied. The messages are applied to
     * the state all or nothing: if any check fails, the state is left as it was.
     *
     * A block cut off at the end of the response, which formats other than Direct JSON compile
     * as far as it goes, is applied too, but the trees of the surfaces it touches are not
     * checked.
     *
     * @param content The raw model response.
     * @param options Whether the response is wrapped in tags, and the state to check it
     *     against.
     * @throws {A2uiError} If a block cannot be read or the state rejects it. The error's
     *     `partialResults` holds the parts before the failing block, or only the text when a
     *     tree check fails, since that check spans every block. None of them is applied to the
     *     state.
     */
    parseResponse(content, { wrapped = true, state } = {}) {
        const target = state ?? this.emptyState();
        const parts = [];
        return target.transaction(() => {
            const touched = new Set();
            const incomplete = new Set();
            try {
                const rawParts = wrapped
                    ? this.unwrap(content)
                    : [{ type: 'a2ui', a2uiRaw: content, isFinal: true }];
                for (const raw of rawParts) {
                    if (raw.type === 'text') {
                        parts.push({ type: 'text', text: raw.text });
                        continue;
                    }
                    const messages = this.compileBlock(raw.a2uiRaw, raw.isFinal);
                    for (const surfaceId of target.apply(messages)) {
                        touched.add(surfaceId);
                        if (!raw.isFinal)
                            incomplete.add(surfaceId);
                    }
                    parts.push({ type: 'a2ui', a2ui: messages });
                }
            }
            catch (e) {
                throw withPartialResults(e, parts);
            }
            try {
                const complete = [...touched].filter(s => !incomplete.has(s));
                if (complete.length > 0)
                    target.checkTopology(complete);
            }
            catch (e) {
                // The tree check spans every block, so no block is known to be good: only the text is
                // kept.
                throw withPartialResults(e, parts.filter(p => p.type === 'text'));
            }
            // A truncated block's messages are kept, as the renderer the caller sends them to will
            // hold them, but its trees are not checked: a cut-off block is missing what it would
            // have added. Its components are marked checked, so a later turn is not required to
            // make them reachable; its dangling references and a missing root are still reported
            // when a later turn checks the surface.
            target.markChecked(incomplete);
            return parts;
        });
    }
    /**
     * Compiles a block, raising any failure that is not an `A2uiError` as
     * `A2uiCompilationError`.
     */
    compileBlock(formatContent, isFinal) {
        try {
            return this.compile(formatContent, isFinal);
        }
        catch (e) {
            if (e instanceof A2uiError)
                throw e;
            const reason = e instanceof Error ? e.message : String(e);
            throw new A2uiCompilationError(`Failed to compile A2UI block: ${reason}`, {
                rawContent: formatContent,
            });
        }
    }
    /** Whether `openStream` can read a response from this format chunk by chunk. */
    get supportsStreaming() {
        return false;
    }
    openStream(_options = {}) {
        throw new Error(`Streaming is not supported by ${this.constructor.name}`);
    }
}
//# sourceMappingURL=parser.js.map