import { A2uiError, AgentToRendererMessage } from '../internal/web-core.js';
/**
 * A text segment from the model's response.
 */
export interface TextPart {
    type: 'text';
    text: string;
}
/**
 * An uncompiled format-specific block (e.g., raw JSON string).
 */
export interface RawA2uiPart {
    type: 'a2ui';
    a2uiRaw: string;
}
/**
 * A response part before format-specific compilation.
 * Uses an intersection type to ergonomically attach the stream truncation state
 * without adding wrapping indirection that would break discriminated union narrowing.
 */
export type RawResponsePart = (TextPart | RawA2uiPart) & {
    isFinal: boolean;
};
/**
 * A compiled A2UI payload block.
 */
export interface A2uiPart {
    type: 'a2ui';
    a2ui: AgentToRendererMessage[];
}
/**
 * A structured part of a model's response.
 */
export type ResponsePart = TextPart | A2uiPart;
/**
 * A block that a response stream rejected and read past, in place of the block.
 *
 * Only a stream opened with `afterRejectedBlock: 'continue'` returns one.
 */
export interface ErrorPart {
    type: 'error';
    /** Why the block was rejected. */
    error: A2uiError;
}
/**
 * A part of a streamed response.
 */
export type StreamPart = ResponsePart | ErrorPart;
//# sourceMappingURL=response-part.d.ts.map