import { StreamPart } from './response-part.js';
/**
 * Emits the text of a streamed response that lies between its blocks.
 *
 * The text between two blocks is one run. A run is emitted as it arrives, less the
 * whitespace at its edges: leading whitespace is dropped at the start of a run, and trailing
 * whitespace is held until more text of the run follows, so a run ends where its last
 * non-blank character does, as the text parts of a whole response do.
 */
export declare class TextRun {
    private started;
    private heldSpace;
    /**
     * Emits `text` as the next piece of the run.
     *
     * Nothing is emitted for a piece that is blank; its whitespace is held for the next piece.
     */
    emit(parts: StreamPart[], text: string): void;
    /** Ends the run, as a block does; whitespace held at its end is dropped. */
    reset(): void;
}
//# sourceMappingURL=text-run.d.ts.map