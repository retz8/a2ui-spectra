import { CatalogApi } from '../internal/web-core.js';
import { ProtocolVersion } from '../types.js';
import { CatalogTransformer } from '../catalog-transformers/base.js';
/**
 * Associates a catalog with the transformations to apply to it.
 */
export declare class CatalogConfig {
    readonly catalog: CatalogApi;
    readonly transformers?: CatalogTransformer[] | undefined;
    private _transformedCatalogMemo?;
    /**
     * Initializes a CatalogConfig.
     *
     * @param catalog The resolved catalog instance.
     * @param transformers Optional list of transformers to apply sequentially.
     */
    constructor(catalog: CatalogApi, transformers?: CatalogTransformer[] | undefined);
    /**
     * The catalog with all configured transformers applied in order.
     *
     * @remarks
     * This property memoizes the transformed catalog instance on first access.
     * Modifying the `transformers` array after accessing this getter will not
     * recompute the transformed catalog.
     */
    get transformedCatalog(): CatalogApi;
    /**
     * Loads a catalog from disk into a CatalogConfig.
     *
     * @param catalogPath Path to the catalog JSON file.
     * @param transformers Optional list of catalog transformers.
     * @param protocolVersion Protocol version to use when the document states none.
     * @param catalogId Catalog id to use when the document states none.
     * @returns A CatalogConfig instance.
     */
    static fromPath(catalogPath: string, transformers?: CatalogTransformer[], protocolVersion?: ProtocolVersion, catalogId?: string): CatalogConfig;
}
//# sourceMappingURL=catalog-config.d.ts.map