/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { FileSystemCatalogProvider } from './catalog-providers.js';
/**
 * Associates a catalog with the transformations to apply to it.
 */
export class CatalogConfig {
    /**
     * Initializes a CatalogConfig.
     *
     * @param catalog The resolved catalog instance.
     * @param transformers Optional list of transformers to apply sequentially.
     */
    constructor(catalog, transformers) {
        this.catalog = catalog;
        this.transformers = transformers;
    }
    /**
     * The catalog with all configured transformers applied in order.
     *
     * @remarks
     * This property memoizes the transformed catalog instance on first access.
     * Modifying the `transformers` array after accessing this getter will not
     * recompute the transformed catalog.
     */
    get transformedCatalog() {
        if (!this._transformedCatalogMemo) {
            let current = this.catalog;
            if (this.transformers) {
                for (const t of this.transformers) {
                    current = t.transform(current);
                }
            }
            this._transformedCatalogMemo = current;
        }
        return this._transformedCatalogMemo;
    }
    /**
     * Loads a catalog from disk into a CatalogConfig.
     *
     * @param catalogPath Path to the catalog JSON file.
     * @param transformers Optional list of catalog transformers.
     * @param protocolVersion Protocol version to use when the document states none.
     * @param catalogId Catalog id to use when the document states none.
     * @returns A CatalogConfig instance.
     */
    static fromPath(catalogPath, transformers, protocolVersion, catalogId) {
        const provider = new FileSystemCatalogProvider(catalogPath, protocolVersion, catalogId);
        const catalog = provider.load();
        return new CatalogConfig(catalog, transformers);
    }
}
//# sourceMappingURL=catalog-config.js.map