import { InferenceFormatFactory } from '../inference-format.js';
import { AgentToRendererMessage, CatalogApi } from '../internal/web-core.js';
import { ContinuingStreamOptions, ParseOptions, Parser, StreamOptions } from '../parser/parser.js';
import { ResponsePart, StreamPart } from '../parser/response-part.js';
import { ResponseStream } from '../parser/response-stream.js';
import { RendererState } from '../utils/renderer-state.js';
/** Options for a request processor. */
export interface A2uiRequestProcessorOptions {
    /**
     * The renderer state a canvas agent keeps for the conversation. `parseResponse` and
     * `openStream` use it when a call passes none. Without one, each call checks the response
     * against a new state, as a chat agent wants. A processor bound to a state serves only that
     * conversation.
     */
    state?: RendererState;
}
/** Request-scoped facade over the negotiated catalogs, prompt, parser, and validation. */
export declare class A2uiRequestProcessor {
    private readonly _examples?;
    private readonly _catalogs;
    private readonly _format;
    private _parser?;
    private readonly _state?;
    /**
     * @param catalogs The negotiated catalogs active for this request.
     * @param _examples Prompt examples, keyed by name.
     * @param formatFactory The inference format. Express by default.
     * @param options The renderer state to bind, if any.
     * @throws {A2uiCatalogError} If `options.state` holds other catalogs than `catalogs`.
     */
    constructor(catalogs: CatalogApi[], _examples?: Record<string, AgentToRendererMessage[] | string> | undefined, formatFactory?: InferenceFormatFactory, options?: A2uiRequestProcessorOptions);
    /** The negotiated catalogs active for this request. */
    get catalogs(): CatalogApi[];
    get examples(): Record<string, AgentToRendererMessage[] | string> | undefined;
    /** The renderer state bound to this processor, if any. */
    get state(): RendererState | undefined;
    /**
     * Format-specific system prompt snippet to feed the model.
     *
     * The snippet covers the format's rules, the active catalogs and any examples. The agent
     * developer writes the rest of the system prompt and places the snippet within it.
     */
    get promptSnippet(): string;
    /**
     * The parser for the format, bound to the active catalogs.
     *
     * A parser holds no state, so the processor creates one and reuses it.
     */
    get parser(): Parser;
    /**
     * Creates an empty renderer state that holds the active catalogs.
     *
     * A canvas agent keeps the state for the whole conversation and passes it to
     * `parseResponse` or `openStream` on every turn, or binds it to the processor.
     */
    createState(): RendererState;
    /**
     * Parses a model response and checks it against a renderer state.
     *
     * @param content The response text.
     * @param options Whether the response is wrapped in tags, and the renderer state to check
     *     the response against and apply it to. The state defaults to the one bound to the
     *     processor. With neither, the response is checked on its own, against a new state.
     * @throws {A2uiCatalogError} If the state holds other catalogs than the processor.
     * @throws {A2uiError} If a block cannot be read or a message is rejected.
     */
    parseResponse(content: string, options?: ParseOptions): ResponsePart[];
    /**
     * Opens a stream that reads one model response chunk by chunk.
     *
     * @param options Whether the response is wrapped in tags, the renderer state to check the
     *     response against and apply it to, as for `parseResponse`, and whether to read past a
     *     rejected block.
     * @throws {A2uiCatalogError} If the state holds other catalogs than the processor.
     * @throws {Error} If the format cannot be read incrementally.
     */
    openStream(options: ContinuingStreamOptions): ResponseStream<StreamPart>;
    openStream(options?: StreamOptions): ResponseStream;
    private resolveState;
    /**
     * Whether the processor can check responses against a renderer state.
     *
     * A state is accepted when it holds the processor's active catalogs, in the same order, since
     * the order decides which catalog a surface resolves to. A state made with `createState` is
     * always accepted. An agent that keeps a state per conversation calls this to tell whether the
     * state still fits the request's catalogs, and makes a new one with `createState` when it
     * doesn't.
     */
    acceptsState(state: RendererState): boolean;
    private checkState;
}
//# sourceMappingURL=processor.d.ts.map