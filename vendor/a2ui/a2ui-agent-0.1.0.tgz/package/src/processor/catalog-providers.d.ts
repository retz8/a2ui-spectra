import { CatalogApi } from '../internal/web-core.js';
import { ProtocolVersion } from '../types.js';
/**
 * Builds a catalog from a parsed catalog document, filling in the id and protocol version
 * the document leaves out.
 *
 * Older documents omit one or the other: v0.8 catalogs have no `catalogId`, and v0.9
 * catalogs have no `protocolVersion`. A provider's constructor arguments supply them. When
 * the document states a value too, the two must agree, so a provider never silently
 * overrides what the document says. When neither states a value the load fails, because a
 * catalog with no id cannot be addressed and one with no version would be validated
 * against the wrong protocol.
 *
 * Only `catalogId` counts as the document's id. `$id` is the JSON Schema identifier of the
 * document, which is not the same thing and is often a URL for the file.
 *
 * Shared by the providers and by catalog resolution, which builds inline catalogs the same
 * way. Not part of the public API.
 *
 * @param document The parsed catalog document.
 * @param source Describes where the document came from, for error messages.
 * @param protocolVersion Version to use when the document states none.
 * @param catalogId Id to use when the document states none.
 * @returns The catalog, with its protocol version in the `v`-prefixed wire form.
 * @throws {A2uiCatalogError} If a value conflicts with the document, if nothing states an
 *     id or a version, or if the document is not a valid catalog.
 */
export declare function catalogFromDocument(document: Record<string, unknown>, source: string, protocolVersion?: ProtocolVersion, catalogId?: string): CatalogApi;
/**
 * Loads a catalog definition.
 */
export interface CatalogProvider {
    /**
     * Loads and returns a catalog.
     *
     * @returns The catalog instance.
     */
    load(): CatalogApi;
}
/**
 * Loads a catalog from a JSON file on disk.
 */
export declare class FileSystemCatalogProvider implements CatalogProvider {
    readonly path: string;
    readonly protocolVersion?: ProtocolVersion | undefined;
    readonly catalogId?: string | undefined;
    /**
     * Initializes the filesystem catalog provider.
     *
     * @param path File path to load the catalog from.
     * @param protocolVersion Protocol version to use when the document states none, as v0.9
     *     documents do. Throws on load if the document states a different one.
     * @param catalogId Catalog id to use when the document states none, as v0.8 documents
     *     do. Throws on load if the document states a different one.
     */
    constructor(path: string, protocolVersion?: ProtocolVersion | undefined, catalogId?: string | undefined);
    /**
     * Reads the catalog JSON file and returns a Catalog instance.
     *
     * @returns The catalog instance.
     * @throws {A2uiCatalogError} If the file cannot be read or parsed, if the id or version
     *     conflicts with the document, or if nothing states an id or a version.
     */
    load(): CatalogApi;
}
/**
 * Builds a catalog from an in-memory schema object.
 */
export declare class InMemoryCatalogProvider implements CatalogProvider {
    readonly catalog: Record<string, unknown>;
    readonly protocolVersion?: ProtocolVersion | undefined;
    readonly catalogId?: string | undefined;
    /**
     * Initializes the in-memory provider.
     *
     * @param catalog Raw catalog schema dictionary.
     * @param protocolVersion Protocol version to use when the schema states none. Throws on
     *     load if the schema states a different one.
     * @param catalogId Catalog id to use when the schema states none. Throws on load if the
     *     schema states a different one.
     */
    constructor(catalog: Record<string, unknown>, protocolVersion?: ProtocolVersion | undefined, catalogId?: string | undefined);
    /**
     * Constructs and returns a Catalog instance from the raw schema dictionary.
     *
     * @returns The catalog instance.
     * @throws {A2uiCatalogError} If the schema is invalid, if the id or version conflicts
     *     with it, or if nothing states an id or a version.
     */
    load(): CatalogApi;
}
//# sourceMappingURL=catalog-providers.d.ts.map