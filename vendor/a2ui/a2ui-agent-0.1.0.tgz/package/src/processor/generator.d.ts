import { InferenceFormatFactory } from '../inference-format.js';
import { AgentToRendererMessage, RendererCapabilities } from '../internal/web-core.js';
import { CatalogConfig } from './catalog-config.js';
import { A2uiRequestProcessor, A2uiRequestProcessorOptions } from './processor.js';
/**
 * Agent-lifetime object holding every catalog the agent supports.
 *
 * Construct one at startup and keep it. Per request, ask it for a processor bound to
 * that caller's renderer capabilities.
 */
export declare class A2uiGenerator {
    private readonly catalogs;
    private readonly examples?;
    private readonly factory;
    constructor(catalogs: CatalogConfig[], examples?: Record<string, AgentToRendererMessage[] | string> | undefined, inferenceFormatFactory?: InferenceFormatFactory);
    /**
     * Creates a processor negotiated against one renderer's capabilities.
     *
     * Checks each configured example against the resolved catalogs, as `validatePayload`
     * does, and throws if a renderer holding them would reject it. Text examples are not
     * checked.
     *
     * @param rendererCapabilities The capabilities of the renderer the processor serves.
     * @param inferenceFormatFactory Overrides the generator's format for this processor.
     * @param options The renderer state a canvas agent keeps for the conversation, bound to
     *     the processor so that its `parseResponse` and `openStream` use it.
     * @throws {A2uiCatalogError} If `rendererCapabilities` is missing, since there is
     *     nothing to negotiate against, if negotiation leaves no catalog, or if
     *     `options.state` holds other catalogs than the negotiated ones.
     * @throws {A2uiValidationError} If the capabilities lack an entry for the catalogs'
     *     protocol version, if an example message is not an object, or if a renderer holding
     *     the negotiated catalogs would reject an example.
     */
    createProcessor(rendererCapabilities: Record<string, RendererCapabilities> | RendererCapabilities, inferenceFormatFactory?: InferenceFormatFactory, options?: A2uiRequestProcessorOptions): A2uiRequestProcessor;
}
//# sourceMappingURL=generator.d.ts.map