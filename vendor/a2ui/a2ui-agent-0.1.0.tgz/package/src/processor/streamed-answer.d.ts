import { ComponentApi, MessageProcessor, SurfaceModel } from '../internal/web-core.js';
import { ErrorPart } from '../parser/response-part.js';
import { A2uiRequestProcessor } from './processor.js';
/** Text the model wrote between two surfaces, or before or after them. */
export interface AnswerTextPart {
    type: 'text';
    text: string;
}
/** A surface the answer created, where the model wrote it. */
export interface AnswerSurfacePart<T extends ComponentApi = ComponentApi> {
    type: 'surface';
    surface: SurfaceModel<T>;
}
/** A part of an answer: its text, its surfaces, and the blocks it rejected. */
export type AnswerPart<T extends ComponentApi = ComponentApi> = AnswerTextPart | AnswerSurfacePart<T> | ErrorPart;
/** Options for a streamed answer. */
export interface StreamedAnswerOptions<T extends ComponentApi = ComponentApi> {
    /**
     * The processor the app renders the answer's surfaces from. It holds the processor's
     * active catalogs, and the answer's messages are checked and applied to it through
     * `RendererState.of`, so it takes its messages from the answer only.
     */
    renderer: MessageProcessor<T>;
}
/**
 * One model answer, read as it streams, for an app that is both the agent and the renderer.
 *
 * The answer opens a stream on the request processor that applies each message to the
 * renderer's processor, and reads past a rejected block. It keeps the answer's parts in the
 * order the model wrote them: the text, one part per surface the answer creates, and an
 * `ErrorPart` where a block was rejected, followed by the text and surfaces after it. A
 * surface the answer deletes leaves the parts.
 *
 * Text the stream returns in pieces is joined into one part until a block comes between.
 */
export declare class StreamedAnswer<T extends ComponentApi = ComponentApi> {
    /** The processor the answer's surfaces are applied to. */
    readonly renderer: MessageProcessor<T>;
    private readonly stream;
    private _parts;
    /** Whether the last part the stream returned was text, so more text joins it. */
    private inText;
    /**
     * @param processor The request processor whose prompt the model answered.
     * @param options The renderer's processor.
     * @throws {A2uiCatalogError} If the renderer's catalogs are not the processor's active
     *     catalogs, in the same order.
     * @throws {Error} If the processor's format cannot be read incrementally.
     */
    constructor(processor: A2uiRequestProcessor, { renderer }: StreamedAnswerOptions<T>);
    /**
     * The parts of the answer so far, in the order the model wrote them. The list is replaced,
     * not changed, when the parts change.
     */
    get parts(): readonly AnswerPart<T>[];
    /** Whether the answer so far ends inside a block. See `ResponseStream.isInBlock`. */
    get isInBlock(): boolean;
    /**
     * Reads the next chunk of the answer.
     *
     * @throws {Error} If the answer has been closed, or the stream fails for a reason other
     *     than a rejected block.
     */
    feed(chunk: string): void;
    /** Ends the answer, adding the text held back as a possible tag and any rejected block. */
    close(): void;
    private show;
}
//# sourceMappingURL=streamed-answer.d.ts.map