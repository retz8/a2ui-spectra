import * as react from 'react';
import react__default, { ComponentType, ReactNode } from 'react';
import * as Types from '@a2ui/web_core/types/types';
export { Types };
import * as Primitives from '@a2ui/web_core/types/primitives';
export { Primitives };
import { ClassValue } from 'clsx';

type AnyComponentNode = Types.AnyComponentNode;
type Surface = Types.Surface;
type SurfaceID = Types.SurfaceID;
type Theme = Types.Theme;
type ServerToClientMessage = Types.ServerToClientMessage;
type A2UIClientEventMessage = Types.A2UIClientEventMessage;
type Action = Types.Action;
type DataValue = Types.DataValue;
type MessageProcessor = Types.MessageProcessor;
type StringValue = Primitives.StringValue;
type NumberValue = Primitives.NumberValue;
type BooleanValue = Primitives.BooleanValue;
/**
 * Props passed to all A2UI React components.
 */
interface A2UIComponentProps<T extends Types.AnyComponentNode = Types.AnyComponentNode> {
    /** The resolved component node from the A2UI message processor */
    node: T;
    /** The surface ID this component belongs to */
    surfaceId: string;
}
/**
 * A function that loads a React component asynchronously.
 */
type ComponentLoader<T extends Types.AnyComponentNode = Types.AnyComponentNode> = () => Promise<{
    default: ComponentType<A2UIComponentProps<T>>;
}>;
/**
 * Registration entry for a component in the registry.
 */
interface ComponentRegistration<T extends Types.AnyComponentNode = Types.AnyComponentNode> {
    /** The React component or a loader function for lazy loading */
    component: ComponentType<A2UIComponentProps<T>> | ComponentLoader<T>;
    /** If true, the component will be lazy loaded */
    lazy?: boolean;
}
/**
 * Callback for when a user action is dispatched.
 */
type OnActionCallback = (message: Types.A2UIClientEventMessage) => void | Promise<void>;
/**
 * Configuration options for the A2UI provider.
 */
interface A2UIProviderConfig {
    /** Callback invoked when a user action is dispatched (button click, etc.) */
    onAction?: OnActionCallback;
    /** Initial theme configuration */
    theme?: Types.Theme;
}

/**
 * Stable actions that never change (won't cause re-renders).
 * These are stored in a ref and exposed via A2UIActionsContext.
 */
interface A2UIActions {
    /** Process incoming server messages */
    processMessages: (messages: Types.ServerToClientMessage[]) => void;
    /** Update data in the data model (for two-way binding) */
    setData: (node: Types.AnyComponentNode | null, path: string, value: Types.DataValue, surfaceId: string) => void;
    /** Dispatch a user action to the server */
    dispatch: (message: Types.A2UIClientEventMessage) => void;
    /** Clear all surfaces */
    clearSurfaces: () => void;
    /** Get a surface by ID */
    getSurface: (surfaceId: string) => Types.Surface | undefined;
    /** Get all surfaces */
    getSurfaces: () => ReadonlyMap<string, Types.Surface>;
    /** Get data from the data model */
    getData: (node: Types.AnyComponentNode, path: string, surfaceId: string) => Types.DataValue | null;
    /** Resolve a relative path to an absolute path */
    resolvePath: (path: string, dataContextPath?: string) => string;
}
/**
 * The shape of the A2UI context value.
 * Combines stable actions with reactive state.
 */
interface A2UIContextValue extends A2UIActions {
    /** The underlying message processor from @a2ui/web_core */
    processor: Types.MessageProcessor;
    /** Version counter for triggering React re-renders */
    version: number;
    /** Callback for dispatching actions to the server */
    onAction: OnActionCallback | null;
}

/**
 * Props for the A2UIProvider component.
 */
interface A2UIProviderProps {
    /** Callback invoked when a user action is dispatched (button click, etc.) */
    onAction?: OnActionCallback;
    /** Theme configuration. Falls back to default theme if not provided. */
    theme?: Types.Theme;
    /** Child components */
    children: ReactNode;
}
/**
 * Provider component that sets up the A2UI context for descendant components.
 *
 * This provider uses a two-context architecture for performance:
 * - A2UIActionsContext: Stable actions that never change (no re-renders)
 * - A2UIStateContext: Reactive state that triggers re-renders when needed
 *
 * @example
 * ```tsx
 * function App() {
 *   const handleAction = async (message) => {
 *     const response = await fetch('/api/a2ui', {
 *       method: 'POST',
 *       body: JSON.stringify(message)
 *     });
 *     const newMessages = await response.json();
 *   };
 *
 *   return (
 *     <A2UIProvider onAction={handleAction}>
 *       <A2UIRenderer surfaceId="main" />
 *     </A2UIProvider>
 *   );
 * }
 * ```
 */
declare function A2UIProvider({ onAction, theme, children }: A2UIProviderProps): react.JSX.Element;
/**
 * Hook to access stable A2UI actions (won't cause re-renders).
 * Use this when you only need to dispatch actions or read data.
 *
 * @returns Stable actions object
 * @throws If used outside of an A2UIProvider
 */
declare function useA2UIActions(): A2UIActions;
/**
 * Hook to subscribe to A2UI state changes.
 * Components using this will re-render when state changes.
 *
 * @returns Current version number
 * @throws If used outside of an A2UIProvider
 */
declare function useA2UIState(): {
    version: number;
};
/**
 * Hook to access the full A2UI context (actions + state).
 * Components using this will re-render when state changes.
 *
 * @returns The A2UI context value
 * @throws If used outside of an A2UIProvider
 */
declare function useA2UIContext(): A2UIContextValue;

/**
 * Registry for A2UI components. Allows registration of custom components
 * and supports lazy loading for code splitting.
 *
 * @example
 * ```tsx
 * const registry = new ComponentRegistry();
 *
 * // Register a component directly
 * registry.register('Text', { component: Text });
 *
 * // Register with lazy loading
 * registry.register('Modal', {
 *   component: () => import('./components/Modal'),
 *   lazy: true
 * });
 *
 * // Use with A2UIRenderer
 * <A2UIRenderer surfaceId="main" registry={registry} />
 * ```
 */
declare class ComponentRegistry {
    private static _instance;
    private registry;
    private lazyCache;
    /**
     * Get the singleton instance of the registry.
     * Use this for the default global registry.
     */
    static getInstance(): ComponentRegistry;
    /**
     * Reset the singleton instance.
     * Useful for testing.
     */
    static resetInstance(): void;
    /**
     * Register a component type.
     *
     * @param type - The A2UI component type name (e.g., 'Text', 'Button')
     * @param registration - The component registration
     */
    register<T extends Types.AnyComponentNode>(type: string, registration: ComponentRegistration<T>): void;
    /**
     * Unregister a component type.
     *
     * @param type - The component type to unregister
     */
    unregister(type: string): void;
    /**
     * Check if a component type is registered.
     *
     * @param type - The component type to check
     * @returns True if the component is registered
     */
    has(type: string): boolean;
    /**
     * Get a component by type. If the component is registered with lazy loading,
     * returns a React.lazy wrapped component.
     *
     * @param type - The component type to get
     * @returns The React component, or null if not found
     */
    get(type: string): ComponentType<A2UIComponentProps> | null;
    /**
     * Get all registered component types.
     *
     * @returns Array of registered type names
     */
    getRegisteredTypes(): string[];
    /**
     * Clear all registrations.
     */
    clear(): void;
}

interface A2UIRendererProps {
    /** The surface ID to render */
    surfaceId: string;
    /** Additional CSS classes for the surface container */
    className?: string;
    /** Fallback content when surface is not yet available */
    fallback?: ReactNode;
    /** Loading fallback for lazy-loaded components */
    loadingFallback?: ReactNode;
    /** Optional custom component registry */
    registry?: ComponentRegistry;
}
/**
 * A2UIRenderer - renders an A2UI surface.
 *
 * This is the main entry point for rendering A2UI content in your React app.
 * It reads the surface state from the A2UI store and renders the component tree.
 *
 * Memoized to prevent unnecessary re-renders when props haven't changed.
 *
 * @example
 * ```tsx
 * function App() {
 *   return (
 *     <A2UIProvider onAction={handleAction}>
 *       <A2UIRenderer surfaceId="main" />
 *     </A2UIProvider>
 *   );
 * }
 * ```
 */
declare const A2UIRenderer: react.NamedExoticComponent<A2UIRendererProps>;

/**
 * Component instance format for static A2UI definitions.
 */
interface ComponentInstance {
    id: string;
    component: Record<string, unknown>;
}
/**
 * Action event dispatched when a user interacts with a component.
 */
interface A2UIActionEvent {
    actionName: string;
    sourceComponentId: string;
    timestamp: string;
    context: Record<string, unknown>;
}
interface A2UIViewerProps {
    /** The root component ID */
    root: string;
    /** Array of component definitions */
    components: ComponentInstance[];
    /** Data model for the surface */
    data?: Record<string, unknown>;
    /** Callback when an action is triggered */
    onAction?: (action: A2UIActionEvent) => void;
    /** Custom theme (defaults to litTheme) */
    theme?: Types.Theme;
    /** Additional CSS class */
    className?: string;
}
/**
 * A2UIViewer renders an A2UI component tree from static JSON definitions.
 *
 * Use this when you have component definitions and data as props rather than
 * streaming messages from a server. For streaming use cases, use A2UIProvider
 * with A2UIRenderer and useA2UI instead.
 *
 * @example
 * ```tsx
 * const components = [
 *   { id: 'root', component: { Card: { child: 'text' } } },
 *   { id: 'text', component: { Text: { text: { path: '/message' } } } },
 * ];
 *
 * <A2UIViewer
 *   root="root"
 *   components={components}
 *   data={{ message: 'Hello World!' }}
 *   onAction={(action) => console.log('Action:', action)}
 * />
 * ```
 */
declare function A2UIViewer({ root, components, data, onAction, theme, className, }: A2UIViewerProps): react__default.JSX.Element;

interface ComponentNodeProps {
    /** The component node to render (can be null/undefined for safety) */
    node: Types.AnyComponentNode | null | undefined;
    /** The surface ID this component belongs to */
    surfaceId: string;
    /** Optional custom registry. Falls back to singleton. */
    registry?: ComponentRegistry;
}
/**
 * ComponentNode - dynamically renders an A2UI component based on its type.
 *
 * Looks up the component in the registry and renders it with the appropriate props.
 * Supports lazy-loaded components via React.Suspense.
 *
 * No wrapper div is rendered - the component's root div (e.g., .a2ui-image) is the
 * direct flex child, exactly matching Lit's structure where the :host element IS
 * the flex item. Each component handles --weight CSS variable on its root div.
 *
 * Memoized to prevent unnecessary re-renders when parent updates but node hasn't changed.
 */
declare const ComponentNode: react.NamedExoticComponent<ComponentNodeProps>;

/**
 * Result returned by the useA2UI hook.
 */
interface UseA2UIResult {
    /** Process incoming server messages */
    processMessages: (messages: Types.ServerToClientMessage[]) => void;
    /** Get a surface by ID */
    getSurface: (surfaceId: string) => Types.Surface | undefined;
    /** Get all surfaces */
    getSurfaces: () => ReadonlyMap<string, Types.Surface>;
    /** Clear all surfaces */
    clearSurfaces: () => void;
    /** The current version number (increments on state changes) */
    version: number;
}
/**
 * Main API hook for A2UI. Provides methods to process messages
 * and access surface state.
 *
 * Note: This hook subscribes to state changes. Components using this
 * will re-render when the A2UI state changes. For action-only usage
 * (no re-renders), use useA2UIActions() instead.
 *
 * @returns Object with message processing and surface access methods
 *
 * @example
 * ```tsx
 * function ChatApp() {
 *   const { processMessages, getSurface } = useA2UI();
 *
 *   useEffect(() => {
 *     const ws = new WebSocket('wss://agent.example.com');
 *     ws.onmessage = (event) => {
 *       const messages = JSON.parse(event.data);
 *       processMessages(messages);
 *     };
 *     return () => ws.close();
 *   }, [processMessages]);
 *
 *   return <A2UIRenderer surfaceId="main" />;
 * }
 * ```
 */
declare function useA2UI(): UseA2UIResult;

/**
 * Result returned by the useA2UIComponent hook.
 */
interface UseA2UIComponentResult {
    /** The current theme */
    theme: Types.Theme;
    /** Resolve a StringValue to its actual string value */
    resolveString: (value: Primitives.StringValue | null | undefined) => string | null;
    /** Resolve a NumberValue to its actual number value */
    resolveNumber: (value: Primitives.NumberValue | null | undefined) => number | null;
    /** Resolve a BooleanValue to its actual boolean value */
    resolveBoolean: (value: Primitives.BooleanValue | null | undefined) => boolean | null;
    /** Set a value in the data model (for two-way binding) */
    setValue: (path: string, value: Types.DataValue) => void;
    /** Get a value from the data model */
    getValue: (path: string) => Types.DataValue | null;
    /** Dispatch a user action */
    sendAction: (action: Types.Action) => void;
    /** Generate a unique ID for accessibility */
    getUniqueId: (prefix: string) => string;
}
/**
 * Base hook for A2UI components. Provides data binding, theme access,
 * and action dispatching.
 *
 * @param node - The component node from the A2UI message processor
 * @param surfaceId - The surface ID this component belongs to
 * @returns Object with theme, data binding helpers, and action dispatcher
 *
 * @example
 * ```tsx
 * function TextField({ node, surfaceId }: A2UIComponentProps<Types.TextFieldNode>) {
 *   const { theme, resolveString, setValue } = useA2UIComponent(node, surfaceId);
 *
 *   const label = resolveString(node.properties.label);
 *   const value = resolveString(node.properties.text) ?? '';
 *
 *   return (
 *     <div className={classMapToString(theme.components.TextField.container)}>
 *       <label>{label}</label>
 *       <input
 *         value={value}
 *         onChange={(e) => setValue(node.properties.text?.path!, e.target.value)}
 *       />
 *     </div>
 *   );
 * }
 * ```
 */
declare function useA2UIComponent<T extends Types.AnyComponentNode>(node: T, surfaceId: string): UseA2UIComponentResult;

/**
 * Registers all standard A2UI components in the registry.
 *
 * @param registry - The component registry to populate
 */
declare function registerDefaultCatalog(registry: ComponentRegistry): void;
/**
 * Initialize the default catalog in the singleton registry.
 * Call this once at app startup.
 */
declare function initializeDefaultCatalog(): void;

/**
 * Props for the ThemeProvider component.
 */
interface ThemeProviderProps {
    /** The theme to provide. Falls back to defaultTheme if not specified. */
    theme?: Types.Theme;
    /** Child components that will have access to the theme */
    children: ReactNode;
}
/**
 * Provider component that makes the A2UI theme available to descendant components.
 */
declare function ThemeProvider({ theme, children }: ThemeProviderProps): react.JSX.Element;
/**
 * Hook to access the current A2UI theme.
 *
 * @returns The current theme
 * @throws If used outside of a ThemeProvider
 */
declare function useTheme(): Types.Theme;
/**
 * Hook to optionally access the current A2UI theme.
 *
 * @returns The current theme, or undefined if not within a provider
 */
declare function useThemeOptional(): Types.Theme | undefined;

declare const litTheme: Types.Theme;
/**
 * Alias for litTheme - the default theme for A2UI React components.
 * @see litTheme
 */
declare const defaultTheme: Types.Theme;

/**
 * Converts a theme class map (Record<string, boolean>) to a className string.
 *
 * @param classMap - An object where keys are class names and values are booleans
 * @returns A space-separated string of class names where the value is true
 *
 * @example
 * classMapToString({ 'a2ui-button': true, 'a2ui-button--primary': true, 'disabled': false })
 * // Returns: 'a2ui-button a2ui-button--primary'
 */
declare function classMapToString(classMap: Record<string, boolean> | undefined): string;
/**
 * Converts an additional styles object (Record<string, string>) to a React style object.
 *
 * @param styles - An object with CSS property names as keys and values as strings
 * @returns A React-compatible style object, or undefined if no styles
 *
 * @example
 * stylesToObject({ 'background-color': 'red', 'font-size': '16px', '--custom-var': 'blue' })
 * // Returns: { backgroundColor: 'red', fontSize: '16px', '--custom-var': 'blue' }
 */
declare function stylesToObject(styles: Record<string, string> | undefined): React.CSSProperties | undefined;

/**
 * Utility function to merge class names.
 * Combines clsx for conditional classes.
 *
 * @param inputs - Class values to merge
 * @returns Merged class name string
 *
 * @example
 * cn('base-class', condition && 'conditional-class', { 'object-class': true })
 */
declare function cn(...inputs: ClassValue[]): string;

/**
 * Text component - renders text content with markdown support.
 *
 * Structure mirrors Lit's Text component:
 *   <div class="a2ui-text">      ← :host equivalent
 *     <section class="...">      ← theme classes
 *       <h2>...</h2>             ← rendered markdown content
 *     </section>
 *   </div>
 *
 * Text is parsed as markdown and rendered as HTML (matches Lit renderer behavior).
 * Supports usageHint values: h1, h2, h3, h4, h5, caption, body
 *
 * Markdown features supported:
 * - **Bold** and *italic* text
 * - Lists (ordered and unordered)
 * - `inline code` and code blocks
 * - [Links](url) (auto-linkified URLs too)
 * - Blockquotes
 * - Horizontal rules
 *
 * Note: Raw HTML is disabled for security.
 */
declare const Text: react.NamedExoticComponent<A2UIComponentProps<Types.TextNode>>;

/**
 * Image component - renders an image from a URL with optional sizing and fit modes.
 *
 * Supports usageHint values: icon, avatar, smallFeature, mediumFeature, largeFeature, header
 * Supports fit values: contain, cover, fill, none, scale-down (maps to object-fit via CSS variable)
 */
declare const Image: react.NamedExoticComponent<A2UIComponentProps<Types.ImageNode>>;

/**
 * Icon component - renders an icon using Material Symbols Outlined font.
 *
 * This matches the Lit renderer's approach using the g-icon class with
 * Material Symbols Outlined font.
 *
 * @example Add Material Symbols font to your HTML:
 * ```html
 * <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
 * ```
 */
declare const Icon: react.NamedExoticComponent<A2UIComponentProps<Types.IconNode>>;

/**
 * Divider component - renders a visual separator line.
 *
 * Structure mirrors Lit's Divider component:
 *   <div class="a2ui-divider">  ← :host equivalent
 *     <hr class="...">          ← internal element
 *   </div>
 */
declare const Divider: react.NamedExoticComponent<A2UIComponentProps<Types.DividerNode>>;

/**
 * Video component - renders a video player.
 *
 * Supports regular video URLs and YouTube URLs (renders as embedded iframe).
 */
declare const Video: react.NamedExoticComponent<A2UIComponentProps<Types.VideoNode>>;

/**
 * AudioPlayer component - renders an audio player with optional description.
 */
declare const AudioPlayer: react.NamedExoticComponent<A2UIComponentProps<Types.AudioPlayerNode>>;

/**
 * Row component - arranges children horizontally using flexbox.
 *
 * Supports distribution (justify-content) and alignment (align-items) properties.
 */
declare const Row: react.NamedExoticComponent<A2UIComponentProps<Types.RowNode>>;

/**
 * Column component - arranges children vertically using flexbox.
 *
 * Supports distribution (justify-content) and alignment (align-items) properties.
 */
declare const Column: react.NamedExoticComponent<A2UIComponentProps<Types.ColumnNode>>;

/**
 * List component - renders a scrollable list of items.
 *
 * Supports direction (vertical/horizontal) properties.
 */
declare const List: react.NamedExoticComponent<A2UIComponentProps<Types.ListNode>>;

/**
 * Card component - a container that visually groups content.
 *
 * Structure mirrors Lit's Card component:
 *   <div class="a2ui-card">      ← :host equivalent
 *     <section class="...">      ← theme classes (border, padding, background)
 *       {children}               ← ::slotted(*) equivalent
 *     </section>
 *   </div>
 *
 * All styles come from componentSpecificStyles CSS, no inline styles needed.
 */
declare const Card: react.NamedExoticComponent<A2UIComponentProps<Types.CardNode>>;

/**
 * Tabs component - displays content in switchable tabs.
 */
declare const Tabs: react.NamedExoticComponent<A2UIComponentProps<Types.TabsNode>>;

/**
 * Modal component - displays content in a dialog overlay.
 *
 * Matches Lit's rendering approach:
 * - When closed: renders section with entry point child
 * - When open: renders dialog with content child (entry point is replaced)
 *
 * The dialog is rendered in place (no portal) so it stays inside .a2ui-surface
 * and CSS selectors work correctly. showModal() handles the top-layer overlay.
 */
declare const Modal: react.NamedExoticComponent<A2UIComponentProps<Types.ModalNode>>;

/**
 * Button component - a clickable element that triggers an action.
 *
 * Contains a child component (usually Text or Icon) and dispatches
 * a user action when clicked.
 */
declare const Button: react.NamedExoticComponent<A2UIComponentProps<Types.ButtonNode>>;

/**
 * TextField component - an input field for text entry.
 *
 * Supports various input types and two-way data binding.
 */
declare const TextField: react.NamedExoticComponent<A2UIComponentProps<Types.TextFieldNode>>;

/**
 * CheckBox component - a boolean toggle with a label.
 *
 * Supports two-way data binding for the checked state.
 */
declare const CheckBox: react.NamedExoticComponent<A2UIComponentProps<Types.CheckboxNode>>;

/**
 * Slider component - a numeric value selector with a range.
 *
 * Supports two-way data binding for the value.
 */
declare const Slider: react.NamedExoticComponent<A2UIComponentProps<Types.SliderNode>>;

/**
 * DateTimeInput component - a date and/or time picker.
 *
 * Supports enabling date, time, or both. Uses native HTML5 date/time inputs.
 */
declare const DateTimeInput: react.NamedExoticComponent<A2UIComponentProps<Types.DateTimeInputNode>>;

/**
 * MultipleChoice component - a selection component using a dropdown.
 *
 * Renders a <select> element with options, matching the Lit renderer's behavior.
 * Supports two-way data binding for the selected value.
 */
declare const MultipleChoice: react.NamedExoticComponent<A2UIComponentProps<Types.MultipleChoiceNode>>;

export { type A2UIActionEvent, type A2UIClientEventMessage, type A2UIComponentProps, A2UIProvider, type A2UIProviderConfig, type A2UIProviderProps, A2UIRenderer, type A2UIRendererProps, A2UIViewer, type A2UIViewerProps, type Action, type AnyComponentNode, AudioPlayer, type BooleanValue, Button, Card, CheckBox, Column, type ComponentInstance, type ComponentLoader, ComponentNode, type ComponentRegistration, ComponentRegistry, type DataValue, DateTimeInput, Divider, Icon, Image, List, type MessageProcessor, Modal, MultipleChoice, type NumberValue, type OnActionCallback, Row, type ServerToClientMessage, Slider, type StringValue, type Surface, type SurfaceID, Tabs, Text, TextField, type Theme, ThemeProvider, type UseA2UIComponentResult, type UseA2UIResult, Video, classMapToString, cn, defaultTheme, initializeDefaultCatalog, litTheme, registerDefaultCatalog, stylesToObject, useA2UI, useA2UIActions, useA2UIComponent, useA2UIContext, useA2UIState, useTheme, useThemeOptional };
