'use strict';

var React = require('react');
var modelProcessor = require('@a2ui/web_core/data/model-processor');
var clsx = require('clsx');
var Styles = require('@a2ui/web_core/styles/index');
var MarkdownIt = require('markdown-it');
var web_core = require('@a2ui/web_core');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n.default = e;
  return Object.freeze(n);
}

var React__default = /*#__PURE__*/_interopDefault(React);
var Styles__namespace = /*#__PURE__*/_interopNamespace(Styles);
var MarkdownIt__default = /*#__PURE__*/_interopDefault(MarkdownIt);

const {createElement: __a2uiCreateElement, Fragment: __a2uiFragment} = require('react');

// src/v0_8/theme/litTheme.ts
var elementA = {
  "typography-f-sf": true,
  "typography-fs-n": true,
  "typography-w-500": true,
  "layout-as-n": true,
  "layout-dis-iflx": true,
  "layout-al-c": true,
  "typography-td-none": true,
  "color-c-p40": true
};
var elementAudio = {
  "layout-w-100": true
};
var elementBody = {
  "typography-f-s": true,
  "typography-fs-n": true,
  "typography-w-400": true,
  "layout-mt-0": true,
  "layout-mb-2": true,
  "typography-sz-bm": true,
  "color-c-n10": true
};
var elementButton = {
  "typography-f-sf": true,
  "typography-fs-n": true,
  "typography-w-500": true,
  "layout-pt-3": true,
  "layout-pb-3": true,
  "layout-pl-5": true,
  "layout-pr-5": true,
  "layout-mb-1": true,
  "border-br-16": true,
  "border-bw-0": true,
  "border-c-n70": true,
  "border-bs-s": true,
  "color-bgc-s30": true,
  "behavior-ho-80": true
};
var elementHeading = {
  "typography-f-sf": true,
  "typography-fs-n": true,
  "typography-w-500": true,
  "layout-mt-0": true,
  "layout-mb-2": true
};
var elementIframe = {
  "behavior-sw-n": true
};
var elementInput = {
  "typography-f-sf": true,
  "typography-fs-n": true,
  "typography-w-400": true,
  "layout-pl-4": true,
  "layout-pr-4": true,
  "layout-pt-2": true,
  "layout-pb-2": true,
  "border-br-6": true,
  "border-bw-1": true,
  "color-bc-s70": true,
  "border-bs-s": true,
  "layout-as-n": true,
  "color-c-n10": true
};
var elementP = {
  "typography-f-s": true,
  "typography-fs-n": true,
  "typography-w-400": true,
  "layout-m-0": true,
  "typography-sz-bm": true,
  "layout-as-n": true,
  "color-c-n10": true
};
var elementList = {
  "typography-f-s": true,
  "typography-fs-n": true,
  "typography-w-400": true,
  "layout-m-0": true,
  "typography-sz-bm": true,
  "layout-as-n": true,
  "color-c-n10": true
};
var elementPre = {
  "typography-f-c": true,
  "typography-fs-n": true,
  "typography-w-400": true,
  "typography-sz-bm": true,
  "typography-ws-p": true,
  "layout-as-n": true
};
var elementTextarea = {
  ...elementInput,
  "layout-r-none": true,
  "layout-fs-c": true
};
var elementVideo = {
  "layout-el-cv": true
};
var litTheme = {
  // ===========================================================================
  // Additional Styles (inline CSS properties)
  // ===========================================================================
  // additionalStyles is optional - only define if custom styling is needed
  // The default Lit theme does not apply any additional inline styles
  components: {
    // =========================================================================
    // Content Components
    // =========================================================================
    AudioPlayer: {},
    Divider: {},
    Icon: {},
    Image: {
      all: {
        "border-br-5": true,
        "layout-el-cv": true,
        "layout-w-100": true,
        "layout-h-100": true
      },
      avatar: { "is-avatar": true },
      header: {},
      icon: {},
      largeFeature: {},
      mediumFeature: {},
      smallFeature: {}
    },
    Text: {
      all: {
        "layout-w-100": true,
        "layout-g-2": true
      },
      h1: {
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-m-0": true,
        "layout-p-0": true,
        "typography-sz-hs": true
      },
      h2: {
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-m-0": true,
        "layout-p-0": true,
        "typography-sz-tl": true
      },
      h3: {
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-m-0": true,
        "layout-p-0": true,
        "typography-sz-tl": true
      },
      h4: {
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-m-0": true,
        "layout-p-0": true,
        "typography-sz-bl": true
      },
      h5: {
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-m-0": true,
        "layout-p-0": true,
        "typography-sz-bm": true
      },
      body: {},
      caption: {}
    },
    Video: {
      "border-br-5": true,
      "layout-el-cv": true
    },
    // =========================================================================
    // Layout Components
    // =========================================================================
    Card: {
      "border-br-9": true,
      "layout-p-4": true,
      "color-bgc-n100": true
    },
    Column: {
      "layout-g-2": true
    },
    List: {
      "layout-g-4": true,
      "layout-p-2": true
    },
    Modal: {
      backdrop: {
        "color-bbgc-p60_20": true
      },
      element: {
        "border-br-2": true,
        "color-bgc-p100": true,
        "layout-p-4": true,
        "border-bw-1": true,
        "border-bs-s": true,
        "color-bc-p80": true
      }
    },
    Row: {
      "layout-g-4": true
    },
    Tabs: {
      container: {},
      controls: {
        all: {},
        selected: {}
      },
      element: {}
    },
    // =========================================================================
    // Interactive Components
    // =========================================================================
    Button: {
      "layout-pt-2": true,
      "layout-pb-2": true,
      "layout-pl-3": true,
      "layout-pr-3": true,
      "border-br-12": true,
      "border-bw-0": true,
      "border-bs-s": true,
      "color-bgc-p30": true,
      "color-c-p100": true,
      // White text on dark purple background
      "behavior-ho-70": true,
      "typography-w-400": true
    },
    CheckBox: {
      container: {
        "layout-dsp-iflex": true,
        "layout-al-c": true
      },
      element: {
        "layout-m-0": true,
        "layout-mr-2": true,
        "layout-p-2": true,
        "border-br-12": true,
        "border-bw-1": true,
        "border-bs-s": true,
        "color-bgc-p100": true,
        "color-bc-p60": true,
        "color-c-n30": true,
        "color-c-p30": true
      },
      label: {
        "color-c-p30": true,
        "typography-f-sf": true,
        "typography-v-r": true,
        "typography-w-400": true,
        "layout-flx-1": true,
        "typography-sz-ll": true
      }
    },
    DateTimeInput: {
      container: {
        "typography-sz-bm": true,
        "layout-w-100": true,
        "layout-g-2": true,
        "layout-dsp-flexhor": true,
        "layout-al-c": true,
        "typography-ws-nw": true
      },
      label: {
        "color-c-p30": true,
        "typography-sz-bm": true
      },
      element: {
        "layout-pt-2": true,
        "layout-pb-2": true,
        "layout-pl-3": true,
        "layout-pr-3": true,
        "border-br-2": true,
        "border-bw-1": true,
        "border-bs-s": true,
        "color-bgc-p100": true,
        "color-bc-p60": true,
        "color-c-n30": true,
        "color-c-p30": true
      }
    },
    MultipleChoice: {
      container: {},
      label: {},
      element: {}
    },
    Slider: {
      container: {},
      label: {},
      element: {}
    },
    TextField: {
      container: {
        "typography-sz-bm": true,
        "layout-w-100": true,
        "layout-g-2": true,
        "layout-dsp-flexhor": true,
        "layout-al-c": true,
        "typography-ws-nw": true
      },
      label: {
        "layout-flx-0": true,
        "color-c-p30": true
      },
      element: {
        "typography-sz-bm": true,
        "layout-pt-2": true,
        "layout-pb-2": true,
        "layout-pl-3": true,
        "layout-pr-3": true,
        "border-br-2": true,
        "border-bw-1": true,
        "border-bs-s": true,
        "color-bgc-p100": true,
        "color-bc-p60": true,
        "color-c-n30": true,
        "color-c-p30": true
      }
    }
  },
  // ===========================================================================
  // HTML Elements (used for markdown rendering and raw HTML)
  // ===========================================================================
  elements: {
    a: elementA,
    audio: elementAudio,
    body: elementBody,
    button: elementButton,
    h1: elementHeading,
    h2: elementHeading,
    h3: elementHeading,
    h4: elementHeading,
    h5: elementHeading,
    iframe: elementIframe,
    input: elementInput,
    p: elementP,
    pre: elementPre,
    textarea: elementTextarea,
    video: elementVideo
  },
  // ===========================================================================
  // Markdown (class arrays for markdown-it renderer)
  // ===========================================================================
  markdown: {
    p: Object.keys(elementP),
    h1: Object.keys(elementHeading),
    h2: Object.keys(elementHeading),
    h3: Object.keys(elementHeading),
    h4: Object.keys(elementHeading),
    h5: Object.keys(elementHeading),
    ul: Object.keys(elementList),
    ol: Object.keys(elementList),
    li: Object.keys(elementList),
    a: Object.keys(elementA),
    strong: [],
    em: []
  }
};
var defaultTheme = litTheme;

// src/v0_8/theme/ThemeContext.tsx
var ThemeContext = React.createContext(void 0);
function ThemeProvider({ theme, children }) {
  return /* @__PURE__ */ __a2uiCreateElement(ThemeContext.Provider, { value: theme ?? defaultTheme }, children);
}
function useTheme() {
  const theme = React.useContext(ThemeContext);
  if (!theme) {
    throw new Error("useTheme must be used within a ThemeProvider or A2UIProvider");
  }
  return theme;
}
function useThemeOptional() {
  return React.useContext(ThemeContext);
}
var ComponentRegistry = class _ComponentRegistry {
  static _instance = null;
  registry = /* @__PURE__ */ new Map();
  lazyCache = /* @__PURE__ */ new Map();
  /**
   * Get the singleton instance of the registry.
   * Use this for the default global registry.
   */
  static getInstance() {
    if (!_ComponentRegistry._instance) {
      _ComponentRegistry._instance = new _ComponentRegistry();
    }
    return _ComponentRegistry._instance;
  }
  /**
   * Reset the singleton instance.
   * Useful for testing.
   */
  static resetInstance() {
    _ComponentRegistry._instance = null;
  }
  /**
   * Register a component type.
   *
   * @param type - The A2UI component type name (e.g., 'Text', 'Button')
   * @param registration - The component registration
   */
  register(type, registration) {
    this.registry.set(type, registration);
  }
  /**
   * Unregister a component type.
   *
   * @param type - The component type to unregister
   */
  unregister(type) {
    this.registry.delete(type);
    this.lazyCache.delete(type);
  }
  /**
   * Check if a component type is registered.
   *
   * @param type - The component type to check
   * @returns True if the component is registered
   */
  has(type) {
    return this.registry.has(type);
  }
  /**
   * Get a component by type. If the component is registered with lazy loading,
   * returns a React.lazy wrapped component.
   *
   * @param type - The component type to get
   * @returns The React component, or null if not found
   */
  get(type) {
    const registration = this.registry.get(type);
    if (!registration) return null;
    if (registration.lazy && typeof registration.component === "function") {
      const cached = this.lazyCache.get(type);
      if (cached) return cached;
      const lazyComponent = React.lazy(registration.component);
      this.lazyCache.set(type, lazyComponent);
      return lazyComponent;
    }
    return registration.component;
  }
  /**
   * Get all registered component types.
   *
   * @returns Array of registered type names
   */
  getRegisteredTypes() {
    return Array.from(this.registry.keys());
  }
  /**
   * Clear all registrations.
   */
  clear() {
    this.registry.clear();
    this.lazyCache.clear();
  }
};
var nextFallbackId = 0;
function useIdFallback() {
  const [id] = React.useState(() => `a2ui-id-${++nextFallbackId}`);
  return id;
}
var nativeUseId = React__default.default.useId;
var useIdCompat = nativeUseId ?? useIdFallback;

// src/v0_8/hooks/useA2UIComponent.ts
function useA2UIComponent(node, surfaceId) {
  const actions = useA2UIActions();
  const theme = useTheme();
  const baseId = useIdCompat();
  useA2UIState();
  const resolveString = React.useCallback(
    (value) => {
      if (!value) return null;
      if (typeof value !== "object") return null;
      if (value.literalString !== void 0) {
        return value.literalString;
      }
      if (value.literal !== void 0) {
        return String(value.literal);
      }
      if (value.path) {
        const data = actions.getData(node, value.path, surfaceId);
        return data !== null ? String(data) : null;
      }
      return null;
    },
    [actions, node, surfaceId]
  );
  const resolveNumber = React.useCallback(
    (value) => {
      if (!value) return null;
      if (typeof value !== "object") return null;
      if (value.literalNumber !== void 0) {
        return value.literalNumber;
      }
      if (value.literal !== void 0) {
        return Number(value.literal);
      }
      if (value.path) {
        const data = actions.getData(node, value.path, surfaceId);
        return data !== null ? Number(data) : null;
      }
      return null;
    },
    [actions, node, surfaceId]
  );
  const resolveBoolean = React.useCallback(
    (value) => {
      if (!value) return null;
      if (typeof value !== "object") return null;
      if (value.literalBoolean !== void 0) {
        return value.literalBoolean;
      }
      if (value.literal !== void 0) {
        return Boolean(value.literal);
      }
      if (value.path) {
        const data = actions.getData(node, value.path, surfaceId);
        return data !== null ? Boolean(data) : null;
      }
      return null;
    },
    [actions, node, surfaceId]
  );
  const setValue = React.useCallback(
    (path, value) => {
      actions.setData(node, path, value, surfaceId);
    },
    [actions, node, surfaceId]
  );
  const getValue = React.useCallback(
    (path) => {
      return actions.getData(node, path, surfaceId);
    },
    [actions, node, surfaceId]
  );
  const sendAction = React.useCallback(
    (action) => {
      const actionContext = {};
      if (action.context) {
        for (const item of action.context) {
          if (item.value.literalString !== void 0) {
            actionContext[item.key] = item.value.literalString;
          } else if (item.value.literalNumber !== void 0) {
            actionContext[item.key] = item.value.literalNumber;
          } else if (item.value.literalBoolean !== void 0) {
            actionContext[item.key] = item.value.literalBoolean;
          } else if (item.value.path) {
            const resolvedPath = actions.resolvePath(item.value.path, node.dataContextPath);
            actionContext[item.key] = actions.getData(node, resolvedPath, surfaceId);
          }
        }
      }
      actions.dispatch({
        userAction: {
          name: action.name,
          sourceComponentId: node.id,
          surfaceId,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          context: actionContext
        }
      });
    },
    [actions, node, surfaceId]
  );
  const getUniqueId = React.useCallback(
    (prefix) => {
      return `${prefix}${baseId}`;
    },
    [baseId]
  );
  return React.useMemo(
    () => ({
      theme,
      resolveString,
      resolveNumber,
      resolveBoolean,
      setValue,
      getValue,
      sendAction,
      getUniqueId
    }),
    [
      theme,
      resolveString,
      resolveNumber,
      resolveBoolean,
      setValue,
      getValue,
      sendAction,
      getUniqueId
    ]
  );
}

// src/v0_8/theme/utils.ts
function classMapToString(classMap) {
  if (!classMap) return "";
  return Object.entries(classMap).filter(([, enabled]) => enabled).map(([className]) => className).join(" ");
}
function stylesToObject(styles) {
  if (!styles || Object.keys(styles).length === 0) return void 0;
  const result = {};
  for (const [key, value] of Object.entries(styles)) {
    if (key.startsWith("--")) {
      result[key] = value;
    } else {
      const camelKey = key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      result[camelKey] = value;
    }
  }
  return result;
}

// src/v0_8/lib/utils.ts
function cn(...inputs) {
  return clsx.clsx(inputs);
}
function mergeClassMaps(...maps) {
  const validMaps = maps.filter((m) => m !== void 0);
  if (validMaps.length === 0) return {};
  return Styles__namespace.merge(...validMaps);
}
function isHintedStyles(styles) {
  if (typeof styles !== "object" || !styles || Array.isArray(styles)) return false;
  const expected = ["h1", "h2", "h3", "h4", "h5", "caption", "body"];
  return expected.some((v) => v in styles);
}
var markdownRenderer = new MarkdownIt__default.default();
var TAG_TO_TOKEN = {
  p: "paragraph",
  h1: "heading",
  h2: "heading",
  h3: "heading",
  h4: "heading",
  h5: "heading",
  h6: "heading",
  ul: "bullet_list",
  ol: "ordered_list",
  li: "list_item",
  a: "link",
  strong: "strong",
  em: "em"
};
function toClassArray(classes) {
  if (Array.isArray(classes)) return classes;
  return Object.entries(classes).filter(([, v]) => v).map(([k]) => k);
}
function renderWithTheme(text, markdownTheme) {
  const appliedKeys = [];
  const themeMap = markdownTheme;
  if (themeMap) {
    for (const [tag, classes] of Object.entries(themeMap)) {
      if (!classes) continue;
      const tokenName = TAG_TO_TOKEN[tag];
      if (!tokenName) continue;
      const key = `${tokenName}_open`;
      if (!appliedKeys.includes(key)) appliedKeys.push(key);
      markdownRenderer.renderer.rules[key] = (tokens, idx, options, _env, self) => {
        const token = tokens[idx];
        if (token) {
          const tagClasses = themeMap[token.tag];
          if (tagClasses) {
            for (const cls of toClassArray(tagClasses)) {
              token.attrJoin("class", cls);
            }
          }
        }
        return self.renderToken(tokens, idx, options);
      };
    }
  }
  const html = markdownRenderer.render(text);
  for (const key of appliedKeys) {
    delete markdownRenderer.renderer.rules[key];
  }
  return html;
}
var Text = React.memo(function Text2({ node, surfaceId }) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const textValue = resolveString(props.text);
  const usageHint = props.usageHint;
  const classes = mergeClassMaps(
    theme.components.Text.all,
    usageHint ? theme.components.Text[usageHint] : {}
  );
  const additionalStyles = React.useMemo(() => {
    const textStyles = theme.additionalStyles?.Text;
    if (!textStyles) return void 0;
    if (isHintedStyles(textStyles)) {
      const hint = usageHint ?? "body";
      return stylesToObject(textStyles[hint]);
    }
    return stylesToObject(textStyles);
  }, [theme.additionalStyles?.Text, usageHint]);
  const renderedContent = React.useMemo(() => {
    if (textValue === null || textValue === void 0) {
      return null;
    }
    let markdownText = textValue;
    switch (usageHint) {
      case "h1":
        markdownText = `# ${markdownText}`;
        break;
      case "h2":
        markdownText = `## ${markdownText}`;
        break;
      case "h3":
        markdownText = `### ${markdownText}`;
        break;
      case "h4":
        markdownText = `#### ${markdownText}`;
        break;
      case "h5":
        markdownText = `##### ${markdownText}`;
        break;
      case "caption":
        markdownText = `*${markdownText}*`;
        break;
    }
    return { __html: renderWithTheme(markdownText, theme.markdown) };
  }, [textValue, theme.markdown, usageHint]);
  if (!renderedContent) {
    return null;
  }
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-text", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(classes),
      style: additionalStyles,
      dangerouslySetInnerHTML: renderedContent
    }
  ));
});
var Image = React.memo(function Image2({ node, surfaceId }) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const url = resolveString(props.url);
  const altText = resolveString(
    props.altText
  );
  const usageHint = props.usageHint;
  const fit = props.fit ?? "fill";
  const classes = mergeClassMaps(
    theme.components.Image.all,
    usageHint ? theme.components.Image[usageHint] : {}
  );
  const style = {
    ...stylesToObject(theme.additionalStyles?.Image),
    "--object-fit": fit
  };
  if (!url) {
    return null;
  }
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-image", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { className: classMapToString(classes), style }, /* @__PURE__ */ __a2uiCreateElement("img", { src: url, alt: altText || "" })));
});
function toSnakeCase(str) {
  return str.replace(/([A-Z])/g, "_$1").toLowerCase();
}
var Icon = React.memo(function Icon2({ node, surfaceId }) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const iconName = resolveString(props.name);
  if (!iconName) {
    return null;
  }
  const snakeCaseName = toSnakeCase(iconName);
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-icon", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.Icon),
      style: stylesToObject(theme.additionalStyles?.Icon)
    },
    /* @__PURE__ */ __a2uiCreateElement("span", { className: "g-icon" }, snakeCaseName)
  ));
});
var Divider = React.memo(function Divider2({
  node,
  surfaceId
}) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-divider", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "hr",
    {
      className: classMapToString(theme.components.Divider),
      style: stylesToObject(theme.additionalStyles?.Divider)
    }
  ));
});
function getYouTubeVideoId(url) {
  const patterns = [/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\s?]+)/];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match && match.length > 1) {
      return match[1];
    }
  }
  return null;
}
var Video = React.memo(function Video2({ node, surfaceId }) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const url = resolveString(props.url);
  if (!url) {
    return null;
  }
  const youtubeId = getYouTubeVideoId(url);
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-video", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.Video),
      style: stylesToObject(theme.additionalStyles?.Video)
    },
    youtubeId ? /* @__PURE__ */ __a2uiCreateElement(
      "iframe",
      {
        src: `https://www.youtube.com/embed/${youtubeId}`,
        title: "YouTube video player",
        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
        allowFullScreen: true,
        style: { border: "none", width: "100%", aspectRatio: "16/9" }
      }
    ) : /* @__PURE__ */ __a2uiCreateElement("video", { src: url, controls: true })
  ));
});
var AudioPlayer = React.memo(function AudioPlayer2({
  node,
  surfaceId
}) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const url = resolveString(props.url);
  const description = resolveString(props.description ?? null);
  if (!url) {
    return null;
  }
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-audio", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.AudioPlayer),
      style: stylesToObject(theme.additionalStyles?.AudioPlayer)
    },
    description && /* @__PURE__ */ __a2uiCreateElement("p", null, description),
    /* @__PURE__ */ __a2uiCreateElement("audio", { src: url, controls: true })
  ));
});
var LoadingFallback = React.memo(function LoadingFallback2() {
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-loading", style: { padding: "8px", opacity: 0.5 } }, "Loading...");
});
var ComponentNode = React.memo(function ComponentNode2({
  node,
  surfaceId,
  registry
}) {
  const actualRegistry = registry ?? ComponentRegistry.getInstance();
  const nodeType = node && typeof node === "object" && "type" in node ? node.type : null;
  const Component = React.useMemo(
    () => nodeType ? actualRegistry.get(nodeType) : null,
    [actualRegistry, nodeType]
  );
  if (!nodeType) {
    if (node) {
      console.warn("[A2UI] Invalid component node (not resolved?):", node);
    }
    return null;
  }
  if (!Component) {
    console.warn(`[A2UI] Unknown component type: ${nodeType}`);
    return null;
  }
  return /* @__PURE__ */ __a2uiCreateElement(React.Suspense, { fallback: /* @__PURE__ */ __a2uiCreateElement(LoadingFallback, null) }, /* @__PURE__ */ __a2uiCreateElement(Component, { node, surfaceId }));
});

// src/v0_8/components/layout/Row.tsx
var Row = React.memo(function Row2({ node, surfaceId }) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const alignment = props.alignment ?? "stretch";
  const distribution = props.distribution ?? "start";
  const children = Array.isArray(props.children) ? props.children : [];
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement(
    "div",
    {
      className: "a2ui-row",
      "data-alignment": alignment,
      "data-distribution": distribution,
      style: hostStyle
    },
    /* @__PURE__ */ __a2uiCreateElement(
      "section",
      {
        className: classMapToString(theme.components.Row),
        style: stylesToObject(theme.additionalStyles?.Row)
      },
      children.map((child, index) => {
        const childId = typeof child === "object" && child !== null && "id" in child ? child.id : `child-${index}`;
        const childNode = typeof child === "object" && child !== null && "type" in child ? child : null;
        return /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { key: childId, node: childNode, surfaceId });
      })
    )
  );
});
var Column = React.memo(function Column2({
  node,
  surfaceId
}) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const alignment = props.alignment ?? "stretch";
  const distribution = props.distribution ?? "start";
  const children = Array.isArray(props.children) ? props.children : [];
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement(
    "div",
    {
      className: "a2ui-column",
      "data-alignment": alignment,
      "data-distribution": distribution,
      style: hostStyle
    },
    /* @__PURE__ */ __a2uiCreateElement(
      "section",
      {
        className: classMapToString(theme.components.Column),
        style: stylesToObject(theme.additionalStyles?.Column)
      },
      children.map((child, index) => {
        const childId = typeof child === "object" && child !== null && "id" in child ? child.id : `child-${index}`;
        const childNode = typeof child === "object" && child !== null && "type" in child ? child : null;
        return /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { key: childId, node: childNode, surfaceId });
      })
    )
  );
});
var List = React.memo(function List2({ node, surfaceId }) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const direction = props.direction ?? "vertical";
  const children = Array.isArray(props.children) ? props.children : [];
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-list", "data-direction": direction, style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.List),
      style: stylesToObject(theme.additionalStyles?.List)
    },
    children.map((child, index) => {
      const childId = typeof child === "object" && child !== null && "id" in child ? child.id : `child-${index}`;
      const childNode = typeof child === "object" && child !== null && "type" in child ? child : null;
      return /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { key: childId, node: childNode, surfaceId });
    })
  ));
});
var Card = React.memo(function Card2({ node, surfaceId }) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const rawChildren = props.children ?? (props.child ? [props.child] : []);
  const children = Array.isArray(rawChildren) ? rawChildren : [];
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-card", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.Card),
      style: stylesToObject(theme.additionalStyles?.Card)
    },
    children.map((child, index) => {
      const childId = typeof child === "object" && child !== null && "id" in child ? child.id : `child-${index}`;
      const childNode = typeof child === "object" && child !== null && "type" in child ? child : null;
      return /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { key: childId, node: childNode, surfaceId });
    })
  ));
});
var Tabs = React.memo(function Tabs2({ node, surfaceId }) {
  const { theme, resolveString } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const tabItems = props.tabItems ?? [];
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-tabs", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.Tabs.container),
      style: stylesToObject(theme.additionalStyles?.Tabs)
    },
    /* @__PURE__ */ __a2uiCreateElement("div", { id: "buttons", className: classMapToString(theme.components.Tabs.element) }, tabItems.map((tab, index) => {
      const title = resolveString(tab.title);
      const isSelected = index === selectedIndex;
      const classes = isSelected ? mergeClassMaps(
        theme.components.Tabs.controls.all,
        theme.components.Tabs.controls.selected
      ) : theme.components.Tabs.controls.all;
      return /* @__PURE__ */ __a2uiCreateElement(
        "button",
        {
          key: index,
          disabled: isSelected,
          className: classMapToString(classes),
          onClick: () => setSelectedIndex(index)
        },
        title
      );
    })),
    tabItems[selectedIndex] && /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { node: tabItems[selectedIndex].child, surfaceId })
  ));
});
var Modal = React.memo(function Modal2({ node, surfaceId }) {
  const { theme } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const [isOpen, setIsOpen] = React.useState(false);
  const dialogRef = React.useRef(null);
  const openModal = React.useCallback(() => {
    setIsOpen(true);
  }, []);
  const closeModal = React.useCallback(() => {
    setIsOpen(false);
  }, []);
  React.useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (isOpen && !dialog.open) {
      dialog.showModal();
    }
    const handleClose = () => {
      setIsOpen(false);
    };
    dialog.addEventListener("close", handleClose);
    return () => dialog.removeEventListener("close", handleClose);
  }, [isOpen]);
  const handleBackdropClick = React.useCallback(
    (e) => {
      if (e.target === e.currentTarget) {
        closeModal();
      }
    },
    [closeModal]
  );
  const handleKeyDown = React.useCallback(
    (e) => {
      if (e.key === "Escape") {
        closeModal();
      }
    },
    [closeModal]
  );
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  if (!isOpen) {
    return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-modal", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { onClick: openModal, style: { cursor: "pointer" } }, /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { node: props.entryPointChild, surfaceId })));
  }
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-modal", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "dialog",
    {
      ref: dialogRef,
      className: classMapToString(theme.components.Modal.backdrop),
      onClick: handleBackdropClick,
      onKeyDown: handleKeyDown
    },
    /* @__PURE__ */ __a2uiCreateElement(
      "section",
      {
        className: classMapToString(theme.components.Modal.element),
        style: stylesToObject(theme.additionalStyles?.Modal)
      },
      /* @__PURE__ */ __a2uiCreateElement("div", { id: "controls" }, /* @__PURE__ */ __a2uiCreateElement("button", { onClick: closeModal, "aria-label": "Close modal" }, /* @__PURE__ */ __a2uiCreateElement("span", { className: "g-icon" }, "close"))),
      /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { node: props.contentChild, surfaceId })
    )
  ));
});
var Button = React.memo(function Button2({
  node,
  surfaceId
}) {
  const { theme, sendAction } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const handleClick = React.useCallback(() => {
    if (props.action) {
      sendAction(props.action);
    }
  }, [props.action, sendAction]);
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-button", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "button",
    {
      className: classMapToString(theme.components.Button),
      style: stylesToObject(theme.additionalStyles?.Button),
      onClick: handleClick
    },
    /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { node: props.child, surfaceId })
  ));
});
var TextField = React.memo(function TextField2({
  node,
  surfaceId
}) {
  const { theme, resolveString, setValue, getValue } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const id = useIdCompat();
  const label = resolveString(props.label);
  const textPath = props.text?.path;
  const initialValue = resolveString(props.text) ?? "";
  const propsRecord = props;
  const fieldType = propsRecord.textFieldType || propsRecord.type;
  const validationRegexp = props.validationRegexp;
  const [value, setLocalValue] = React.useState(initialValue);
  const [_isValid, setIsValid] = React.useState(true);
  React.useEffect(() => {
    if (textPath) {
      const externalValue = getValue(textPath);
      if (externalValue !== null && String(externalValue) !== value) {
        setLocalValue(String(externalValue));
      }
    }
  }, [textPath, getValue]);
  const handleChange = React.useCallback(
    (e) => {
      const newValue = e.target.value;
      setLocalValue(newValue);
      if (validationRegexp) {
        try {
          if (web_core.isSafeRegex(validationRegexp)) {
            setIsValid(new RegExp(validationRegexp).test(newValue));
          } else {
            setIsValid(false);
          }
        } catch {
          setIsValid(false);
        }
      }
      if (textPath) {
        setValue(textPath, newValue);
      }
    },
    [validationRegexp, textPath, setValue]
  );
  const inputType = fieldType === "number" ? "number" : fieldType === "date" ? "date" : "text";
  const isTextArea = fieldType === "longText";
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-textfield", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { className: classMapToString(theme.components.TextField.container) }, label && /* @__PURE__ */ __a2uiCreateElement("label", { htmlFor: id, className: classMapToString(theme.components.TextField.label) }, label), isTextArea ? /* @__PURE__ */ __a2uiCreateElement(
    "textarea",
    {
      id,
      value,
      onChange: handleChange,
      placeholder: "Please enter a value",
      className: classMapToString(theme.components.TextField.element),
      style: stylesToObject(theme.additionalStyles?.TextField)
    }
  ) : /* @__PURE__ */ __a2uiCreateElement(
    "input",
    {
      type: inputType,
      id,
      value,
      onChange: handleChange,
      placeholder: "Please enter a value",
      className: classMapToString(theme.components.TextField.element),
      style: stylesToObject(theme.additionalStyles?.TextField)
    }
  )));
});
var CheckBox = React.memo(function CheckBox2({
  node,
  surfaceId
}) {
  const { theme, resolveString, resolveBoolean, setValue, getValue } = useA2UIComponent(
    node,
    surfaceId
  );
  const props = node.properties;
  const id = useIdCompat();
  const label = resolveString(props.label);
  const valuePath = props.value?.path;
  const initialChecked = resolveBoolean(props.value) ?? false;
  const [checked, setChecked] = React.useState(initialChecked);
  React.useEffect(() => {
    if (valuePath) {
      const externalValue = getValue(valuePath);
      if (externalValue !== null && Boolean(externalValue) !== checked) {
        setChecked(Boolean(externalValue));
      }
    }
  }, [valuePath, getValue]);
  React.useEffect(() => {
    if (props.value?.literalBoolean !== void 0) {
      setChecked(props.value.literalBoolean);
    }
  }, [props.value?.literalBoolean]);
  const handleChange = React.useCallback(
    (e) => {
      const newValue = e.target.checked;
      setChecked(newValue);
      if (valuePath) {
        setValue(valuePath, newValue);
      }
    },
    [valuePath, setValue]
  );
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-checkbox", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement(
    "section",
    {
      className: classMapToString(theme.components.CheckBox.container),
      style: stylesToObject(theme.additionalStyles?.CheckBox)
    },
    /* @__PURE__ */ __a2uiCreateElement(
      "input",
      {
        type: "checkbox",
        id,
        checked,
        onChange: handleChange,
        className: classMapToString(theme.components.CheckBox.element)
      }
    ),
    label && /* @__PURE__ */ __a2uiCreateElement("label", { htmlFor: id, className: classMapToString(theme.components.CheckBox.label) }, label)
  ));
});
var Slider = React.memo(function Slider2({
  node,
  surfaceId
}) {
  const { theme, resolveNumber, resolveString, setValue, getValue } = useA2UIComponent(
    node,
    surfaceId
  );
  const props = node.properties;
  const id = useIdCompat();
  const valuePath = props.value?.path;
  const initialValue = resolveNumber(props.value) ?? 0;
  const minValue = props.minValue ?? 0;
  const maxValue = props.maxValue ?? 0;
  const [value, setLocalValue] = React.useState(initialValue);
  React.useEffect(() => {
    if (valuePath) {
      const externalValue = getValue(valuePath);
      if (externalValue !== null && Number(externalValue) !== value) {
        setLocalValue(Number(externalValue));
      }
    }
  }, [valuePath, getValue]);
  React.useEffect(() => {
    if (props.value?.literalNumber !== void 0) {
      setLocalValue(props.value.literalNumber);
    }
  }, [props.value?.literalNumber]);
  const handleChange = React.useCallback(
    (e) => {
      const newValue = Number(e.target.value);
      setLocalValue(newValue);
      if (valuePath) {
        setValue(valuePath, newValue);
      }
    },
    [valuePath, setValue]
  );
  const labelValue = props.label;
  const label = labelValue ? resolveString(labelValue) : "";
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-slider", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { className: classMapToString(theme.components.Slider.container) }, label && /* @__PURE__ */ __a2uiCreateElement("label", { htmlFor: id, className: classMapToString(theme.components.Slider.label) }, label), /* @__PURE__ */ __a2uiCreateElement(
    "input",
    {
      type: "range",
      id,
      name: "data",
      value,
      min: minValue,
      max: maxValue,
      onChange: handleChange,
      className: classMapToString(theme.components.Slider.element),
      style: stylesToObject(theme.additionalStyles?.Slider)
    }
  ), /* @__PURE__ */ __a2uiCreateElement("span", { className: classMapToString(theme.components.Slider.label) }, value)));
});
var DateTimeInput = React.memo(function DateTimeInput2({
  node,
  surfaceId
}) {
  const { theme, resolveString, setValue, getValue } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const id = useIdCompat();
  const valuePath = props.value?.path;
  const initialValue = resolveString(props.value) ?? "";
  const enableDate = props.enableDate ?? true;
  const enableTime = props.enableTime ?? false;
  const [value, setLocalValue] = React.useState(initialValue);
  React.useEffect(() => {
    if (valuePath) {
      const externalValue = getValue(valuePath);
      if (externalValue !== null && String(externalValue) !== value) {
        setLocalValue(String(externalValue));
      }
    }
  }, [valuePath, getValue]);
  const handleChange = React.useCallback(
    (e) => {
      const newValue = e.target.value;
      setLocalValue(newValue);
      if (valuePath) {
        setValue(valuePath, newValue);
      }
    },
    [valuePath, setValue]
  );
  let inputType = "date";
  if (enableDate && enableTime) {
    inputType = "datetime-local";
  } else if (enableTime && !enableDate) {
    inputType = "time";
  }
  const getPlaceholderText = () => {
    if (enableDate && enableTime) {
      return "Date & Time";
    } else if (enableTime) {
      return "Time";
    }
    return "Date";
  };
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-datetime-input", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { className: classMapToString(theme.components.DateTimeInput.container) }, /* @__PURE__ */ __a2uiCreateElement("label", { htmlFor: id, className: classMapToString(theme.components.DateTimeInput.label) }, getPlaceholderText()), /* @__PURE__ */ __a2uiCreateElement(
    "input",
    {
      type: inputType,
      id,
      value,
      onChange: handleChange,
      className: classMapToString(theme.components.DateTimeInput.element),
      style: stylesToObject(theme.additionalStyles?.DateTimeInput)
    }
  )));
});
var MultipleChoice = React.memo(function MultipleChoice2({
  node,
  surfaceId
}) {
  const { theme, resolveString, setValue } = useA2UIComponent(node, surfaceId);
  const props = node.properties;
  const id = useIdCompat();
  const options = props.options ?? [];
  const selectionsPath = props.selections?.path;
  const description = resolveString(props.description) ?? "Select an item";
  const handleChange = React.useCallback(
    (e) => {
      if (selectionsPath) {
        setValue(selectionsPath, [e.target.value]);
      }
    },
    [selectionsPath, setValue]
  );
  const hostStyle = node.weight !== void 0 ? { "--weight": node.weight } : {};
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-multiplechoice", style: hostStyle }, /* @__PURE__ */ __a2uiCreateElement("section", { className: classMapToString(theme.components.MultipleChoice.container) }, /* @__PURE__ */ __a2uiCreateElement("label", { htmlFor: id, className: classMapToString(theme.components.MultipleChoice.label) }, description), /* @__PURE__ */ __a2uiCreateElement(
    "select",
    {
      name: "data",
      id,
      className: classMapToString(theme.components.MultipleChoice.element),
      style: stylesToObject(theme.additionalStyles?.MultipleChoice),
      onChange: handleChange
    },
    options.map((option) => {
      const label = resolveString(option.label);
      return /* @__PURE__ */ __a2uiCreateElement("option", { key: option.value, value: option.value }, label);
    })
  )));
});

// src/v0_8/registry/defaultCatalog.ts
function registerDefaultCatalog(registry) {
  registry.register("Text", { component: Text });
  registry.register("Image", { component: Image });
  registry.register("Icon", { component: Icon });
  registry.register("Divider", { component: Divider });
  registry.register("Video", { component: Video });
  registry.register("AudioPlayer", { component: AudioPlayer });
  registry.register("Row", { component: Row });
  registry.register("Column", { component: Column });
  registry.register("List", { component: List });
  registry.register("Card", { component: Card });
  registry.register("Tabs", { component: Tabs });
  registry.register("Modal", { component: Modal });
  registry.register("Button", { component: Button });
  registry.register("TextField", { component: TextField });
  registry.register("CheckBox", { component: CheckBox });
  registry.register("Slider", { component: Slider });
  registry.register("DateTimeInput", { component: DateTimeInput });
  registry.register("MultipleChoice", { component: MultipleChoice });
}
function initializeDefaultCatalog() {
  registerDefaultCatalog(ComponentRegistry.getInstance());
}

// src/v0_8/styles/reset.ts
var resetStyles = `
@layer a2ui-reset {
  :where(.a2ui-surface) :where(*:not(svg, svg *:not(foreignObject *))) {
    all: revert;
  }
}
`;

// src/v0_8/styles/index.ts
var structuralStyles2 = Styles__namespace.structuralStyles.replace(
  /:host\s*\{/g,
  ".a2ui-surface {"
);
var componentSpecificStyles = `
.a2ui-surface .a2ui-card {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
.a2ui-surface .a2ui-card > section {
  height: 100%;
  width: 100%;
  min-height: 0;
  overflow: auto;
}
.a2ui-surface .a2ui-card > section > * {
  height: 100%;
  width: 100%;
}

.a2ui-surface .a2ui-divider {
  display: block;
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-divider) hr {
  height: 1px;
  background: #ccc;
  border: none;
}

.a2ui-surface .a2ui-text {
  display: block;
  flex: var(--weight);
}
:where(.a2ui-surface .a2ui-text) h1,
:where(.a2ui-surface .a2ui-text) h2,
:where(.a2ui-surface .a2ui-text) h3,
:where(.a2ui-surface .a2ui-text) h4,
:where(.a2ui-surface .a2ui-text) h5 {
  line-height: inherit;
  font: inherit;
}
.a2ui-surface .a2ui-text p {
  margin: 0;
}

.a2ui-surface .a2ui-textfield {
  display: flex;
  flex: var(--weight);
}
:where(.a2ui-surface .a2ui-textfield) input {
  display: block;
  width: 100%;
}
:where(.a2ui-surface .a2ui-textfield) label {
  display: block;
  margin-bottom: 4px;
}
:where(.a2ui-surface .a2ui-textfield) textarea {
  display: block;
  width: 100%;
}

.a2ui-surface .a2ui-checkbox {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-checkbox) input {
  display: block;
  width: 100%;
}

.a2ui-surface .a2ui-slider {
  display: block;
  flex: var(--weight);
}
:where(.a2ui-surface .a2ui-slider) input {
  display: block;
  width: 100%;
}

.a2ui-surface .a2ui-button {
  display: block;
  flex: var(--weight);
  min-height: 0;
}

.a2ui-surface .a2ui-icon {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-icon) .g-icon {
  font-size: 24px;
}

.a2ui-surface .a2ui-tabs {
  display: block;
  flex: var(--weight);
}

.a2ui-surface .a2ui-modal {
  display: block;
  flex: var(--weight);
}
:where(.a2ui-surface .a2ui-modal) dialog {
  padding: 0;
  border: none;
  background: none;
}
.a2ui-surface .a2ui-modal dialog section #controls {
  display: flex;
  justify-content: end;
  margin-bottom: 4px;
}
.a2ui-surface .a2ui-modal dialog section #controls button {
  padding: 0;
  background: none;
  width: 20px;
  height: 20px;
  cursor: pointer;
  border: none;
}

.a2ui-surface .a2ui-image {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-image) img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: var(--object-fit, fill);
}

.a2ui-surface .a2ui-video {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-video) video {
  display: block;
  width: 100%;
}

.a2ui-surface .a2ui-audio {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-audio) audio {
  display: block;
  width: 100%;
}

.a2ui-surface .a2ui-multiplechoice {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-multiplechoice) select {
  width: 100%;
}

.a2ui-surface .a2ui-column {
  display: flex;
  flex: var(--weight);
}
.a2ui-surface .a2ui-column > section {
  display: flex;
  flex-direction: column;
  min-width: 100%;
  height: 100%;
}
.a2ui-surface .a2ui-column[data-alignment="start"] > section { align-items: start; }
.a2ui-surface .a2ui-column[data-alignment="center"] > section { align-items: center; }
.a2ui-surface .a2ui-column[data-alignment="end"] > section { align-items: end; }
.a2ui-surface .a2ui-column[data-alignment="stretch"] > section { align-items: stretch; }
.a2ui-surface .a2ui-column[data-distribution="start"] > section { justify-content: start; }
.a2ui-surface .a2ui-column[data-distribution="center"] > section { justify-content: center; }
.a2ui-surface .a2ui-column[data-distribution="end"] > section { justify-content: end; }
.a2ui-surface .a2ui-column[data-distribution="spaceBetween"] > section { justify-content: space-between; }
.a2ui-surface .a2ui-column[data-distribution="spaceAround"] > section { justify-content: space-around; }
.a2ui-surface .a2ui-column[data-distribution="spaceEvenly"] > section { justify-content: space-evenly; }

.a2ui-surface .a2ui-row {
  display: flex;
  flex: var(--weight);
}
.a2ui-surface .a2ui-row > section {
  display: flex;
  flex-direction: row;
  width: 100%;
  min-height: 100%;
}
.a2ui-surface .a2ui-row[data-alignment="start"] > section { align-items: start; }
.a2ui-surface .a2ui-row[data-alignment="center"] > section { align-items: center; }
.a2ui-surface .a2ui-row[data-alignment="end"] > section { align-items: end; }
.a2ui-surface .a2ui-row[data-alignment="stretch"] > section { align-items: stretch; }
.a2ui-surface .a2ui-row[data-distribution="start"] > section { justify-content: start; }
.a2ui-surface .a2ui-row[data-distribution="center"] > section { justify-content: center; }
.a2ui-surface .a2ui-row[data-distribution="end"] > section { justify-content: end; }
.a2ui-surface .a2ui-row[data-distribution="spaceBetween"] > section { justify-content: space-between; }
.a2ui-surface .a2ui-row[data-distribution="spaceAround"] > section { justify-content: space-around; }
.a2ui-surface .a2ui-row[data-distribution="spaceEvenly"] > section { justify-content: space-evenly; }

.a2ui-surface .a2ui-list {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
.a2ui-surface .a2ui-list[data-direction="vertical"] > section {
  display: grid;
}
.a2ui-surface .a2ui-list[data-direction="horizontal"] > section {
  display: flex;
  max-width: 100%;
  overflow-x: scroll;
  overflow-y: hidden;
  scrollbar-width: none;
}
.a2ui-surface .a2ui-list[data-direction="horizontal"] > section > * {
  flex: 1 0 fit-content;
  max-width: min(80%, 400px);
}

.a2ui-surface .a2ui-datetime-input {
  display: block;
  flex: var(--weight);
  min-height: 0;
  overflow: auto;
}
:where(.a2ui-surface .a2ui-datetime-input) input {
  display: block;
  border-radius: 8px;
  padding: 8px;
  border: 1px solid #ccc;
  width: 100%;
  color: #333;
}
:where(.a2ui-surface .a2ui-datetime-input) input::-webkit-datetime-edit,
:where(.a2ui-surface .a2ui-datetime-input) input::-webkit-datetime-edit-fields-wrapper {
  color: #333;
}

.a2ui-surface *,
.a2ui-surface *::before,
.a2ui-surface *::after {
  box-sizing: border-box;
}
`;
function injectStyles() {
  if (typeof document === "undefined") {
    return;
  }
  const styleId = "a2ui-structural-styles";
  if (document.getElementById(styleId)) {
    return;
  }
  const styleElement = document.createElement("style");
  styleElement.id = styleId;
  styleElement.textContent = resetStyles + "\n" + structuralStyles2 + "\n" + componentSpecificStyles;
  document.head.appendChild(styleElement);
}

// src/v0_8/core/A2UIProvider.tsx
var initialized = false;
function ensureInitialized() {
  if (!initialized) {
    initializeDefaultCatalog();
    injectStyles();
    initialized = true;
  }
}
var A2UIActionsContext = React.createContext(null);
var A2UIStateContext = React.createContext(null);
function A2UIProvider({ onAction, theme, children }) {
  ensureInitialized();
  const processorRef = React.useRef(null);
  if (!processorRef.current) {
    processorRef.current = new modelProcessor.A2uiMessageProcessor();
  }
  const processor = processorRef.current;
  const [version, setVersion] = React.useState(0);
  const onActionRef = React.useRef(onAction ?? null);
  onActionRef.current = onAction ?? null;
  const actionsRef = React.useRef(null);
  if (!actionsRef.current) {
    actionsRef.current = {
      processMessages: (messages) => {
        processor.processMessages(messages);
        setVersion((v) => v + 1);
      },
      setData: (node, path, value, surfaceId) => {
        processor.setData(node, path, value, surfaceId);
        setVersion((v) => v + 1);
      },
      dispatch: (message) => {
        if (onActionRef.current) {
          void onActionRef.current(message);
        }
      },
      clearSurfaces: () => {
        processor.clearSurfaces();
        setVersion((v) => v + 1);
      },
      getSurface: (surfaceId) => {
        return processor.getSurfaces().get(surfaceId);
      },
      getSurfaces: () => {
        return processor.getSurfaces();
      },
      getData: (node, path, surfaceId) => {
        return processor.getData(node, path, surfaceId);
      },
      resolvePath: (path, dataContextPath) => {
        return processor.resolvePath(path, dataContextPath);
      }
    };
  }
  const actions = actionsRef.current;
  const stateValue = React.useMemo(() => ({ version }), [version]);
  return /* @__PURE__ */ __a2uiCreateElement(A2UIActionsContext.Provider, { value: actions }, /* @__PURE__ */ __a2uiCreateElement(A2UIStateContext.Provider, { value: stateValue }, /* @__PURE__ */ __a2uiCreateElement(ThemeProvider, { theme }, children)));
}
function useA2UIActions() {
  const actions = React.useContext(A2UIActionsContext);
  if (!actions) {
    throw new Error("useA2UIActions must be used within an A2UIProvider");
  }
  return actions;
}
function useA2UIState() {
  const state = React.useContext(A2UIStateContext);
  if (!state) {
    throw new Error("useA2UIState must be used within an A2UIProvider");
  }
  return state;
}
function useA2UIContext() {
  const actions = useA2UIActions();
  const state = useA2UIState();
  return React.useMemo(
    () => ({
      ...actions,
      processor: null,
      // Not exposed directly
      version: state.version,
      onAction: null
      // Use dispatch instead
    }),
    [actions, state.version]
  );
}

// src/v0_8/hooks/useA2UI.ts
function useA2UI() {
  const actions = useA2UIActions();
  const state = useA2UIState();
  return {
    processMessages: actions.processMessages,
    getSurface: actions.getSurface,
    getSurfaces: actions.getSurfaces,
    clearSurfaces: actions.clearSurfaces,
    version: state.version
  };
}

// src/v0_8/core/A2UIRenderer.tsx
var DefaultLoadingFallback = React.memo(function DefaultLoadingFallback2() {
  return /* @__PURE__ */ __a2uiCreateElement("div", { className: "a2ui-loading", style: { padding: "16px", opacity: 0.5 } }, "Loading...");
});
var A2UIRenderer = React.memo(function A2UIRenderer2({
  surfaceId,
  className,
  fallback = null,
  loadingFallback,
  registry
}) {
  const { getSurface, version } = useA2UI();
  const surface = getSurface(surfaceId);
  const surfaceStyles = React.useMemo(() => {
    if (!surface?.styles) return {};
    const styles = {};
    for (const [key, value] of Object.entries(surface.styles)) {
      switch (key) {
        // Generate a color palette from the primary color.
        // Values range from 0-100 where 0=black, 100=white, 50=primary color.
        // Uses color-mix to create intermediate values.
        case "primaryColor": {
          styles["--p-100"] = "#ffffff";
          styles["--p-99"] = `color-mix(in srgb, ${value} 2%, white 98%)`;
          styles["--p-98"] = `color-mix(in srgb, ${value} 4%, white 96%)`;
          styles["--p-95"] = `color-mix(in srgb, ${value} 10%, white 90%)`;
          styles["--p-90"] = `color-mix(in srgb, ${value} 20%, white 80%)`;
          styles["--p-80"] = `color-mix(in srgb, ${value} 40%, white 60%)`;
          styles["--p-70"] = `color-mix(in srgb, ${value} 60%, white 40%)`;
          styles["--p-60"] = `color-mix(in srgb, ${value} 80%, white 20%)`;
          styles["--p-50"] = String(value);
          styles["--p-40"] = `color-mix(in srgb, ${value} 80%, black 20%)`;
          styles["--p-35"] = `color-mix(in srgb, ${value} 70%, black 30%)`;
          styles["--p-30"] = `color-mix(in srgb, ${value} 60%, black 40%)`;
          styles["--p-25"] = `color-mix(in srgb, ${value} 50%, black 50%)`;
          styles["--p-20"] = `color-mix(in srgb, ${value} 40%, black 60%)`;
          styles["--p-15"] = `color-mix(in srgb, ${value} 30%, black 70%)`;
          styles["--p-10"] = `color-mix(in srgb, ${value} 20%, black 80%)`;
          styles["--p-5"] = `color-mix(in srgb, ${value} 10%, black 90%)`;
          styles["--p-0"] = "#000000";
          break;
        }
        case "font": {
          styles["--font-family"] = String(value);
          styles["--font-family-flex"] = String(value);
          break;
        }
      }
    }
    return styles;
  }, [surface?.styles]);
  if (!surface || !surface.componentTree) {
    return /* @__PURE__ */ __a2uiCreateElement(__a2uiFragment, null, fallback);
  }
  const actualLoadingFallback = loadingFallback ?? /* @__PURE__ */ __a2uiCreateElement(DefaultLoadingFallback, null);
  return /* @__PURE__ */ __a2uiCreateElement(
    "div",
    {
      className: cn("a2ui-surface", className),
      style: surfaceStyles,
      "data-surface-id": surfaceId,
      "data-version": version
    },
    /* @__PURE__ */ __a2uiCreateElement(React.Suspense, { fallback: actualLoadingFallback }, /* @__PURE__ */ __a2uiCreateElement(ComponentNode, { node: surface.componentTree, surfaceId, registry }))
  );
});
function A2UIViewer({
  root,
  components,
  data = {},
  onAction,
  theme = litTheme,
  className
}) {
  const baseId = useIdCompat();
  const surfaceId = React.useMemo(() => {
    const definitionKey = `${root}-${JSON.stringify(components)}`;
    let hash = 0;
    for (let i = 0; i < definitionKey.length; i++) {
      hash = 31 * hash + definitionKey.charCodeAt(i);
    }
    return `surface${baseId.replace(/:/g, "-")}${hash}`;
  }, [baseId, root, components]);
  const handleAction = React.useMemo(() => {
    if (!onAction) return void 0;
    return (message) => {
      const userAction = message.userAction;
      if (userAction) {
        onAction({
          actionName: userAction.name,
          sourceComponentId: userAction.sourceComponentId,
          timestamp: userAction.timestamp,
          context: userAction.context ?? {}
        });
      }
    };
  }, [onAction]);
  return /* @__PURE__ */ __a2uiCreateElement(A2UIProvider, { onAction: handleAction, theme }, /* @__PURE__ */ __a2uiCreateElement(
    A2UIViewerInner,
    {
      surfaceId,
      root,
      components,
      data,
      className
    }
  ));
}
function A2UIViewerInner({
  surfaceId,
  root,
  components,
  data,
  className
}) {
  const { processMessages } = useA2UIActions();
  const lastProcessedRef = React.useRef("");
  React.useEffect(() => {
    const key = `${surfaceId}-${JSON.stringify(components)}-${JSON.stringify(data)}`;
    if (key === lastProcessedRef.current) return;
    lastProcessedRef.current = key;
    const messages = [
      { beginRendering: { surfaceId, root, styles: {} } },
      { surfaceUpdate: { surfaceId, components } }
    ];
    if (data && Object.keys(data).length > 0) {
      const contents = objectToValueMaps(data);
      if (contents.length > 0) {
        messages.push({
          dataModelUpdate: { surfaceId, path: "/", contents }
        });
      }
    }
    processMessages(messages);
  }, [processMessages, surfaceId, root, components, data]);
  return /* @__PURE__ */ __a2uiCreateElement("div", { className }, /* @__PURE__ */ __a2uiCreateElement(A2UIRenderer, { surfaceId }));
}
function objectToValueMaps(obj) {
  return Object.entries(obj).map(([key, value]) => valueToValueMap(key, value));
}
function valueToValueMap(key, value) {
  if (typeof value === "string") {
    return { key, valueString: value };
  }
  if (typeof value === "number") {
    return { key, valueNumber: value };
  }
  if (typeof value === "boolean") {
    return { key, valueBoolean: value };
  }
  if (value === null || value === void 0) {
    return { key };
  }
  if (Array.isArray(value)) {
    const valueMap = value.map((item, index) => valueToValueMap(String(index), item));
    return { key, valueMap };
  }
  if (typeof value === "object") {
    const valueMap = objectToValueMaps(value);
    return { key, valueMap };
  }
  return { key };
}

exports.A2UIProvider = A2UIProvider;
exports.A2UIRenderer = A2UIRenderer;
exports.A2UIViewer = A2UIViewer;
exports.AudioPlayer = AudioPlayer;
exports.Button = Button;
exports.Card = Card;
exports.CheckBox = CheckBox;
exports.Column = Column;
exports.ComponentNode = ComponentNode;
exports.ComponentRegistry = ComponentRegistry;
exports.DateTimeInput = DateTimeInput;
exports.Divider = Divider;
exports.Icon = Icon;
exports.Image = Image;
exports.List = List;
exports.Modal = Modal;
exports.MultipleChoice = MultipleChoice;
exports.Row = Row;
exports.Slider = Slider;
exports.Tabs = Tabs;
exports.Text = Text;
exports.TextField = TextField;
exports.ThemeProvider = ThemeProvider;
exports.Video = Video;
exports.classMapToString = classMapToString;
exports.cn = cn;
exports.defaultTheme = defaultTheme;
exports.initializeDefaultCatalog = initializeDefaultCatalog;
exports.litTheme = litTheme;
exports.registerDefaultCatalog = registerDefaultCatalog;
exports.stylesToObject = stylesToObject;
exports.useA2UI = useA2UI;
exports.useA2UIActions = useA2UIActions;
exports.useA2UIComponent = useA2UIComponent;
exports.useA2UIContext = useA2UIContext;
exports.useA2UIState = useA2UIState;
exports.useTheme = useTheme;
exports.useThemeOptional = useThemeOptional;
//# sourceMappingURL=index.cjs.map
//# sourceMappingURL=index.cjs.map