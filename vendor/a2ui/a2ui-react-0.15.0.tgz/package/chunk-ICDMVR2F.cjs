'use strict';

var React = require('react');
var web_core = require('@a2ui/web_core');
var universal = require('@a2ui/web_core/universal');
var reactDom = require('react-dom');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

var React__default = /*#__PURE__*/_interopDefault(React);

const {createElement: __a2uiCreateElement, Fragment: __a2uiFragment} = require('react');

// src/host_registry.ts
var HostOwner = class {
  surface;
  constructor(surface) {
    this.surface = surface;
  }
};
var rendered = /* @__PURE__ */ new WeakMap();
function markReactRendered(element, owner) {
  rendered.set(element, owner);
}
function isReactRendered(element) {
  return rendered.has(element);
}
function ownerAbove(element) {
  let current = element.parentNode;
  while (current) {
    const owner = current instanceof Element ? rendered.get(current) : void 0;
    if (owner) return owner;
    current = current instanceof ShadowRoot ? current.host : current.parentNode;
  }
  return null;
}
var HostRegistry = class _HostRegistry {
  static registries = /* @__PURE__ */ new WeakMap();
  /** The registry of `surface`; hosts find it through their node's context. */
  static forSurface(surface) {
    let registry = _HostRegistry.registries.get(surface);
    if (!registry) {
      registry = new _HostRegistry();
      _HostRegistry.registries.set(surface, registry);
    }
    return registry;
  }
  hosts = /* @__PURE__ */ new Map();
  snapshots = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Map();
  add(host, node, owner) {
    const current = this.hosts.get(host);
    if (current && current.entry.node === node && current.owner === owner) return;
    this.hosts.set(host, { entry: { host, node }, owner });
    if (current && current.owner !== owner) this.publish(current.owner);
    this.publish(owner);
  }
  delete(host) {
    const current = this.hosts.get(host);
    if (!current) return;
    this.hosts.delete(host);
    this.publish(current.owner);
  }
  has(host) {
    return this.hosts.has(host);
  }
  /** Every registered host, in registration order. */
  entries() {
    return [...this.hosts.values()].map(({ entry }) => entry);
  }
  /** Notifies `listener` when the hosts owned by `owner` change. */
  subscribe(owner, listener) {
    let listeners = this.listeners.get(owner);
    if (!listeners) {
      listeners = /* @__PURE__ */ new Set();
      this.listeners.set(owner, listeners);
    }
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }
  /** The hosts owned by `owner`; the same array until they change. */
  getSnapshot(owner) {
    let snapshot = this.snapshots.get(owner);
    if (!snapshot) {
      snapshot = this.compute(owner);
      this.snapshots.set(owner, snapshot);
    }
    return snapshot;
  }
  compute(owner) {
    const result = [];
    for (const { entry, owner: entryOwner } of this.hosts.values()) {
      if (entryOwner === owner) result.push(entry);
    }
    return result;
  }
  publish(owner) {
    this.snapshots.set(owner, this.compute(owner));
    for (const listener of this.listeners.get(owner) ?? []) listener();
  }
};
var hostRefs = /* @__PURE__ */ new WeakMap();
function hostRefsOf(node) {
  let refs = hostRefs.get(node);
  if (!refs) {
    const targets = universal.createAccessibilityTargets();
    refs = {
      ...targets,
      accessibilityRef: (element) => web_core.setValue(targets.target, element),
      validationErrorsRef: (element) => web_core.setValue(targets.errors, element)
    };
    hostRefs.set(node, refs);
  }
  return refs;
}

// src/catalog/react_host_element.ts
var ReactWcHost = class extends HTMLElement {
  /** @deprecated Assign `node` instead. */
  context;
  _node;
  registry;
  accessibilityNode;
  stopAccessibility;
  connectedCallback() {
    this.style.display = "contents";
    this.register();
    this.bindAccessibility();
  }
  disconnectedCallback() {
    queueMicrotask(() => {
      if (!this.isConnected) {
        this.registry?.delete(this);
        this.registry = void 0;
        this.unbindAccessibility();
      }
    });
  }
  set node(node) {
    this._node = node;
    this.context = node?.context;
    this.register();
    this.bindAccessibility();
  }
  get node() {
    return this._node;
  }
  register() {
    const node = this._node;
    if (!this.isConnected || !node || isReactRendered(this)) return;
    const owner = ownerAbove(this);
    const surface = owner?.surface ?? node.context?.dataContext.surface;
    if (!surface) return;
    const registry = HostRegistry.forSurface(surface);
    if (this.registry !== registry) {
      this.registry?.delete(this);
      this.registry = registry;
    }
    registry.add(this, node, owner);
  }
  /** Keeps the ARIA attributes in step with the node while the host is connected. */
  bindAccessibility() {
    const node = this._node;
    if (!this.isConnected || node === this.accessibilityNode) return;
    this.unbindAccessibility();
    this.accessibilityNode = node;
    if (node) {
      this.stopAccessibility = universal.bindHostAccessibility(this, node, hostRefsOf(node));
    }
  }
  unbindAccessibility() {
    this.stopAccessibility?.();
    this.stopAccessibility = void 0;
    this.accessibilityNode = void 0;
  }
};

// src/catalog/to_web_component.tsx
var hosted = /* @__PURE__ */ new WeakMap();
var tagNameCounts = /* @__PURE__ */ new Map();
function computeTagName(name) {
  const baseTagName = `a2ui-react-${name.toLowerCase()}`;
  const count = (tagNameCounts.get(baseTagName) ?? 0) + 1;
  tagNameCounts.set(baseTagName, count);
  return count === 1 ? baseTagName : `${baseTagName}-${count}`;
}
function toWebComponent(implementation) {
  if (universal.isWebComponentImplementation(implementation)) {
    return implementation;
  }
  const cached = hosted.get(implementation);
  if (cached) {
    return cached;
  }
  const entry = {
    ...implementation,
    tagName: computeTagName(implementation.name),
    // `customElements` refuses to define one class under two tag names.
    element: class extends ReactWcHost {
    }
  };
  hosted.set(implementation, entry);
  return entry;
}

// src/catalog/prepare_catalogs.ts
var prepared = /* @__PURE__ */ new WeakSet();
function prepare(catalog) {
  if (prepared.has(catalog)) return;
  prepared.add(catalog);
  const components = catalog.components;
  for (const [name, implementation] of components) {
    if (!universal.isWebComponentImplementation(implementation)) {
      components.set(name, toWebComponent(implementation));
    }
  }
}
function prepareCatalogs(surface) {
  if (surface.defaultCatalog) prepare(surface.defaultCatalog);
  for (const catalog of surface.availableCatalogs.values()) prepare(catalog);
}
var MarkdownContext = React.createContext(void 0);
var useMarkdownRenderer = () => React.useContext(MarkdownContext);
var MarkdownComponentContext = React.createContext(void 0);
function checkIfSnapshotChanged(inst) {
  const latestGetSnapshot = inst.getSnapshot;
  const prevValue = inst.value;
  try {
    const nextValue = latestGetSnapshot();
    return !Object.is(prevValue, nextValue);
  } catch {
    return true;
  }
}
function useSyncExternalStoreClient(subscribe, getSnapshot) {
  const value = getSnapshot();
  const [, forceUpdate] = React.useState({});
  const instRef = React.useRef({ value, getSnapshot });
  React.useLayoutEffect(() => {
    instRef.current.value = value;
    instRef.current.getSnapshot = getSnapshot;
    if (checkIfSnapshotChanged(instRef.current)) {
      forceUpdate({});
    }
  }, [subscribe, value, getSnapshot]);
  React.useEffect(() => {
    if (checkIfSnapshotChanged(instRef.current)) {
      forceUpdate({});
    }
    return subscribe(() => {
      if (checkIfSnapshotChanged(instRef.current)) {
        forceUpdate({});
      }
    });
  }, [subscribe]);
  React.useDebugValue(value);
  return value;
}
function useSyncExternalStoreServer(_subscribe, getSnapshot, getServerSnapshot) {
  return getServerSnapshot ? getServerSnapshot() : getSnapshot();
}
var isServerEnvironment = typeof window === "undefined" || typeof window.document === "undefined" || typeof window.document.createElement === "undefined";
var useSyncExternalStoreCompat = isServerEnvironment ? useSyncExternalStoreServer : useSyncExternalStoreClient;
var nativeUseSyncExternalStore = React__default.default.useSyncExternalStore;
var useSyncExternalStore = nativeUseSyncExternalStore ?? useSyncExternalStoreCompat;

// src/markdown_hosts.tsx
var TAG = "a2ui-react-markdown";
var ATTRIBUTE = "data-markdown";
var MarkdownHosts = class {
  hosts = /* @__PURE__ */ new Map();
  snapshots = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Map();
  nextKey = 0;
  add(host, markdown, owner) {
    const current = this.hosts.get(host);
    if (current?.owner === owner) return;
    const key = current?.entry.key ?? String(this.nextKey++);
    this.hosts.set(host, { entry: { host, markdown, key }, owner });
    if (current) this.publish(current.owner);
    this.publish(owner);
  }
  delete(host) {
    const current = this.hosts.get(host);
    if (!current) return;
    this.hosts.delete(host);
    this.publish(current.owner);
  }
  subscribe(owner, listener) {
    let listeners = this.listeners.get(owner);
    if (!listeners) {
      listeners = /* @__PURE__ */ new Set();
      this.listeners.set(owner, listeners);
    }
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
      if (listeners.size === 0) {
        this.listeners.delete(owner);
        this.snapshots.delete(owner);
      }
    };
  }
  /** The hosts owned by `owner`; the same array until they change. */
  getSnapshot(owner) {
    let snapshot = this.snapshots.get(owner);
    if (!snapshot) {
      snapshot = this.compute(owner);
      this.snapshots.set(owner, snapshot);
    }
    return snapshot;
  }
  compute(owner) {
    const result = [];
    for (const { entry, owner: entryOwner } of this.hosts.values()) {
      if (entryOwner === owner) result.push(entry);
    }
    return result;
  }
  publish(owner) {
    if (!this.listeners.has(owner)) {
      this.snapshots.delete(owner);
      return;
    }
    this.snapshots.set(owner, this.compute(owner));
    for (const listener of this.listeners.get(owner) ?? []) listener();
  }
};
var markdownHosts = new MarkdownHosts();
function defineMarkdownHost() {
  if (customElements.get(TAG)) return;
  customElements.define(
    TAG,
    class extends HTMLElement {
      connectedCallback() {
        this.style.display = "contents";
        const owner = ownerAbove(this);
        if (owner) markdownHosts.add(this, this.getAttribute(ATTRIBUTE) ?? "", owner);
      }
      disconnectedCallback() {
        queueMicrotask(() => {
          if (!this.isConnected) markdownHosts.delete(this);
        });
      }
    }
  );
}
function escapeAttribute(text) {
  return text.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var renderMarkdownHost = async (markdown) => {
  defineMarkdownHost();
  return `<${TAG} ${ATTRIBUTE}="${escapeAttribute(markdown)}"></${TAG}>`;
};
var hostRendererUsers = 0;
var rendererBeforeHosts;
function registerMarkdownHostRenderer() {
  if (hostRendererUsers++ === 0) {
    rendererBeforeHosts = universal.getMarkdownRenderer();
  }
  universal.setMarkdownRenderer(renderMarkdownHost);
  return () => {
    if (--hostRendererUsers === 0 && universal.getMarkdownRenderer() === renderMarkdownHost) {
      universal.setMarkdownRenderer(rendererBeforeHosts);
    }
  };
}
var HostedMarkdown = ({ owner }) => {
  const Component = React.useContext(MarkdownComponentContext);
  return Component ? /* @__PURE__ */ __a2uiCreateElement(MarkdownPortals, { owner, component: Component }) : null;
};
var MarkdownPortals = ({ owner, component: Component }) => {
  const subscribe = React.useCallback(
    (listener) => markdownHosts.subscribe(owner, listener),
    [owner]
  );
  const getSnapshot = React.useCallback(() => markdownHosts.getSnapshot(owner), [owner]);
  const hosts = useSyncExternalStore(subscribe, getSnapshot);
  return /* @__PURE__ */ __a2uiCreateElement(__a2uiFragment, null, hosts.map(
    ({ host, markdown, key }) => reactDom.createPortal(/* @__PURE__ */ __a2uiCreateElement(Component, { markdown }), host, key)
  ));
};
function assign(element, node) {
  element.node = node;
}
function disposeElementControllers(root) {
  const disposeOne = (el) => {
    if (el._controller) {
      el.removeController?.(el._controller);
      el._controller.dispose();
      el._controller = void 0;
      el._controllerContext = void 0;
      el._controllerNode = void 0;
    }
  };
  disposeOne(root);
  for (const child of root.querySelectorAll("*")) {
    disposeOne(child);
  }
}
var WebComponentNode = React.memo(
  ({
    node,
    owner,
    children
  }) => {
    const implementation = node.impl;
    if (!universal.isWebComponentImplementation(implementation)) {
      throw new Error(
        `A2UI catalog entry '${node.type}' has no element. A2uiSurface prepares the surface's default and available catalogs; this entry came from another catalog.`
      );
    }
    universal.registerUniversalElement(implementation);
    const elRef = React.useRef(null);
    const nodeRef = React.useRef(node);
    nodeRef.current = node;
    const setRef = React.useCallback(
      (element) => {
        elRef.current = element;
        if (element) {
          if (owner) markReactRendered(element, owner);
          assign(element, nodeRef.current);
        }
      },
      [owner]
    );
    React.useEffect(() => {
      const element = elRef.current;
      if (element) {
        assign(element, node);
      }
      return () => {
        if (element && !element.isConnected) {
          disposeElementControllers(element);
        }
      };
    }, [node]);
    return React__default.default.createElement(implementation.tagName, { ref: setRef }, children);
  }
);
WebComponentNode.displayName = "WebComponentNode";

// src/node-view.tsx
var SurfaceContext = React.createContext(
  void 0
);
function useA2uiSurface() {
  return React.useContext(SurfaceContext);
}
function useSurface(node) {
  const surface = React.useContext(SurfaceContext);
  if (surface) {
    return surface;
  }
  if (node) {
    return contextOf(node).dataContext.surface;
  }
  throw new Error("A2UI node views must be rendered inside an <A2uiSurface>.");
}
function contextOf(node) {
  if (!node.context) {
    throw new Error(`A2UI views render only resolved nodes; '${node.componentId}' has no context.`);
  }
  return node.context;
}
var reportedUnresolved = /* @__PURE__ */ new WeakMap();
var UnresolvedChildReference = ({ surface, id, requestedPath, detail }) => {
  const message = `Unresolved child reference '${id}' at '${requestedPath}': ${detail}`;
  React.useEffect(() => {
    let seen = reportedUnresolved.get(surface);
    if (!seen) {
      seen = /* @__PURE__ */ new Set();
      reportedUnresolved.set(surface, seen);
    }
    const key = JSON.stringify([id, requestedPath]);
    if (!seen.has(key)) {
      seen.add(key);
      void surface.dispatchError({ code: "UNRESOLVED_CHILD_REFERENCE", message });
    }
  }, [surface, id, requestedPath, message]);
  return null;
};
function useSignalValue(signal) {
  const subscribe = React.useCallback(
    (onChange) => web_core.effect(() => {
      web_core.getValue(signal);
      onChange();
    }),
    [signal]
  );
  const getSnapshot = React.useCallback(() => web_core.peekValue(signal), [signal]);
  return useSyncExternalStore(subscribe, getSnapshot);
}
function registerChild(index, child) {
  index.set(child.id, child);
  return child.id;
}
function toViewValue(parent, value, index) {
  if (web_core.isComponentNode(value)) {
    const token = registerChild(index, value);
    if (value.dataPath !== parent.dataPath) {
      return { id: token, basePath: value.dataPath };
    }
    return token;
  }
  if (value instanceof web_core.ResolvedBinding) {
    return toViewValue(parent, value.value, index);
  }
  if (Array.isArray(value)) {
    return value.map((item) => toViewValue(parent, item, index));
  }
  if (isPlainObject(value)) {
    return toViewProps(parent, value, index);
  }
  return value;
}
function isPlainObject(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function toViewProps(parent, props, index) {
  const result = {};
  for (const [key, inner] of Object.entries(props)) {
    if (inner instanceof web_core.ResolvedBinding) {
      result[key] = toViewValue(parent, inner.value, index);
      result[`set${key.charAt(0).toUpperCase()}${key.slice(1)}`] = web_core.isWritable(inner) ? inner.set : () => {
      };
    } else {
      result[key] = toViewValue(parent, inner, index);
    }
  }
  return result;
}
function useNodeView(node, buildChild) {
  const baseContext = contextOf(node);
  const surface = useSurface(node);
  const resolved = useSignalValue(node.props);
  const metadataReadRef = React.useRef(false);
  const subscribeMetadata = React.useCallback(
    (onChange) => web_core.effect(() => {
      web_core.getValue(node.metadata);
      if (metadataReadRef.current) {
        onChange();
      }
    }),
    [node.metadata]
  );
  const getMetadataSnapshot = React.useCallback(() => web_core.peekValue(node.metadata), [node.metadata]);
  const metadataSnapshot = useSyncExternalStore(subscribeMetadata, getMetadataSnapshot);
  const hasReadMetadata = React.useCallback(() => metadataReadRef.current, []);
  const context = React.useMemo(() => {
    const baseModel = baseContext.componentModel;
    const trackedModel = new Proxy(baseModel, {
      get(target, prop) {
        if (prop === "metadata") {
          metadataReadRef.current = true;
          return web_core.peekValue(node.metadata);
        }
        if (prop === "extensions") {
          metadataReadRef.current = true;
          return web_core.peekValue(node.metadata)?.extensions;
        }
        const value = Reflect.get(target, prop, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
      set(target, prop, value) {
        return Reflect.set(target, prop, value, target);
      }
    });
    return new Proxy(baseContext, {
      get(target, prop) {
        if (prop === "componentModel") {
          return trackedModel;
        }
        const value = Reflect.get(target, prop, target);
        return typeof value === "function" ? value.bind(target) : value;
      }
    });
  }, [baseContext, node.metadata]);
  const { viewProps, childIndex } = React.useMemo(() => {
    const index = /* @__PURE__ */ new Map();
    return { viewProps: toViewProps(node, resolved, index), childIndex: index };
  }, [node, resolved]);
  const rawBuildChild = React.useCallback(
    (id, basePath) => {
      const requested = basePath ?? node.dataPath;
      const instances = [...childIndex.values()].filter((child) => child.componentId === id);
      const childNode = instances.find((child) => child.dataPath === requested);
      if (childNode) {
        return buildChild(childNode, basePath);
      }
      const elsewhere = [...new Set(instances.map((child) => child.dataPath))];
      if (elsewhere.length > 0) {
        return /* @__PURE__ */ __a2uiCreateElement(
          UnresolvedChildReference,
          {
            key: JSON.stringify([id, requested]),
            surface,
            id,
            requestedPath: requested,
            detail: `instances exist at ${elsewhere.join(", ")}. Instances are created only at the data paths the payload implies; buildChild selects among them.`
          }
        );
      }
      return buildChild(id, basePath);
    },
    [buildChild, node, surface, childIndex]
  );
  const viewBuildChild = React.useCallback(
    (id, basePath) => {
      const childNode = childIndex.get(id);
      return childNode ? buildChild(childNode, basePath) : rawBuildChild(id, basePath);
    },
    [buildChild, rawBuildChild, childIndex]
  );
  const result = {
    viewProps,
    metadataSnapshot,
    hasReadMetadata,
    context,
    viewBuildChild,
    rawBuildChild
  };
  Object.defineProperty(result, "metadata", {
    enumerable: true,
    get() {
      metadataReadRef.current = true;
      return web_core.peekValue(node.metadata);
    }
  });
  return result;
}
var RenderFallback = ({ node, impl, buildChild }) => {
  const viewState = useNodeView(node, buildChild);
  const Render = impl.render;
  const renderProps = {
    context: viewState.context,
    buildChild: viewState.rawBuildChild
  };
  Object.defineProperty(renderProps, "metadata", {
    enumerable: true,
    get: () => viewState.metadata
  });
  return Render(renderProps);
};
var ChildElement = React.memo(({ node }) => {
  const ambientSurface = React.useContext(SurfaceContext);
  const owner = React.useMemo(() => new HostOwner(), []);
  if (node.isPlaceholder || !node.impl) {
    return null;
  }
  const surface = ambientSurface ?? contextOf(node).dataContext.surface;
  owner.surface = surface;
  if ("render" in node.impl) {
    return /* @__PURE__ */ __a2uiCreateElement(__a2uiFragment, null, /* @__PURE__ */ __a2uiCreateElement(WebComponentNode, { node, owner }, /* @__PURE__ */ __a2uiCreateElement(NodeContent, { node })), /* @__PURE__ */ __a2uiCreateElement(HostedMarkdown, { owner }));
  }
  return /* @__PURE__ */ __a2uiCreateElement(__a2uiFragment, null, /* @__PURE__ */ __a2uiCreateElement(WebComponentNode, { node, owner }), /* @__PURE__ */ __a2uiCreateElement(HostedChildren, { surface, owner }), /* @__PURE__ */ __a2uiCreateElement(HostedMarkdown, { owner }));
});
ChildElement.displayName = "ChildElement";
var HostedChildren = ({ surface, owner }) => {
  const registry = HostRegistry.forSurface(surface);
  const subscribe = React.useCallback(
    (listener) => registry.subscribe(owner, listener),
    [registry, owner]
  );
  const getSnapshot = React.useCallback(() => registry.getSnapshot(owner), [registry, owner]);
  const hosts = useSyncExternalStore(subscribe, getSnapshot);
  return /* @__PURE__ */ __a2uiCreateElement(__a2uiFragment, null, hosts.map(({ host, node }) => reactDom.createPortal(/* @__PURE__ */ __a2uiCreateElement(NodeContent, { node }), host, node.id)));
};
var NodeContent = React.memo(({ node }) => {
  const surface = useSurface(node);
  const buildChild = React.useCallback(
    (child, basePath) => {
      if (web_core.isComponentNode(child)) {
        return /* @__PURE__ */ __a2uiCreateElement(ChildElement, { key: child.id, node: child });
      }
      const requested = basePath ?? node.dataPath;
      const detail = surface.componentsModel.get(child) ? "the component exists, but the catalog schema does not mark the referencing property as a component id. Use componentId() or childList() from @a2ui/web_core." : "no component with this id exists on the surface.";
      return /* @__PURE__ */ __a2uiCreateElement(
        UnresolvedChildReference,
        {
          key: JSON.stringify([child, requested]),
          surface,
          id: child,
          requestedPath: requested,
          detail
        }
      );
    },
    [surface, node]
  );
  const impl = node.impl;
  if (node.disposed || !impl || !("render" in impl)) {
    return null;
  }
  const View = impl.view;
  if (!View) {
    return /* @__PURE__ */ __a2uiCreateElement(RenderFallback, { node, impl, buildChild });
  }
  return /* @__PURE__ */ __a2uiCreateElement(View, { node, buildChild });
});
NodeContent.displayName = "NodeContent";

// src/A2uiSurface.tsx
var A2uiSurface = ({ surface }) => {
  const markdownRenderer = useMarkdownRenderer();
  const hasMarkdownComponent = React.useContext(MarkdownComponentContext) !== void 0;
  React.useLayoutEffect(() => {
    if (hasMarkdownComponent) {
      return registerMarkdownHostRenderer();
    }
    if (markdownRenderer) {
      universal.setMarkdownRenderer(markdownRenderer);
    }
    return void 0;
  }, [markdownRenderer, hasMarkdownComponent]);
  const box = React.useMemo(
    () => ({ resolver: void 0 }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [surface]
  );
  const subscribe = React.useCallback(
    (onChange) => {
      prepareCatalogs(surface);
      const onCreatedSub = surface.componentsModel.onCreated.subscribe(() => {
        prepareCatalogs(surface);
      });
      const resolver = new web_core.NodeResolver(surface, surface.defaultCatalog);
      box.resolver = resolver;
      const stopEffect = web_core.effect(() => {
        web_core.getValue(resolver.rootNode);
        onChange();
      });
      return () => {
        stopEffect();
        onCreatedSub.unsubscribe();
        resolver.dispose();
        if (box.resolver === resolver) {
          box.resolver = void 0;
        }
      };
    },
    [surface, box]
  );
  const getSnapshot = React.useCallback(
    () => box.resolver ? web_core.peekValue(box.resolver.rootNode) : void 0,
    [box]
  );
  const root = useSyncExternalStore(subscribe, getSnapshot);
  if (!root) {
    return null;
  }
  return /* @__PURE__ */ __a2uiCreateElement(SurfaceContext.Provider, { value: surface }, /* @__PURE__ */ __a2uiCreateElement(ChildElement, { node: root }), /* @__PURE__ */ __a2uiCreateElement(HostedChildren, { surface, owner: null }));
};
function componentApiFields(api) {
  return {
    name: api.name,
    schema: api.schema,
    allowedParents: api.allowedParents,
    allowedChildren: api.allowedChildren,
    ...api.metadata !== void 0 ? { metadata: api.metadata } : {}
  };
}
function createComponentImplementation(api, RenderComponent) {
  const MemoizedRender = React.memo(
    ({
      props,
      buildChild,
      context,
      accessibilityRef,
      validationErrorsRef,
      getMetadata
    }) => {
      const componentProps = {
        props,
        buildChild,
        context,
        accessibilityRef,
        validationErrorsRef
      };
      Object.defineProperty(componentProps, "metadata", {
        enumerable: true,
        get: getMetadata
      });
      return RenderComponent(componentProps);
    },
    (prev, next) => {
      if (prev.props !== next.props) return false;
      if (prev.hasReadMetadata() && prev.metadataSnapshot !== next.metadataSnapshot) return false;
      if (prev.buildChild !== next.buildChild) return false;
      if (prev.accessibilityRef !== next.accessibilityRef) return false;
      if (prev.validationErrorsRef !== next.validationErrorsRef) return false;
      if (prev.context.componentModel.id !== next.context.componentModel.id) return false;
      if (prev.context.dataContext.path !== next.context.dataContext.path) return false;
      return true;
    }
  );
  MemoizedRender.displayName = `${api.name}.memo`;
  const ReactWrapper = ({ context, buildChild }) => {
    const bindingRef = React.useRef(null);
    const metadataReadRef = React.useRef(false);
    if (!bindingRef.current) {
      bindingRef.current = new web_core.GenericBinder(context, api.schema);
    } else if (bindingRef.current.context !== context) {
      bindingRef.current.dispose();
      bindingRef.current = new web_core.GenericBinder(context, api.schema);
    }
    const binding = bindingRef.current;
    const subscribe = React.useCallback(
      (callback) => {
        const sub = binding.subscribe(callback);
        return () => sub.unsubscribe();
      },
      [binding]
    );
    const getSnapshot = React.useCallback(() => binding.snapshot, [binding]);
    const props = useSyncExternalStore(subscribe, getSnapshot);
    const subscribeMetadata = React.useCallback(
      (callback) => {
        const sub = context.componentModel.onMetadataChanged.subscribe(() => {
          if (metadataReadRef.current) {
            callback();
          }
        });
        return () => sub.unsubscribe();
      },
      [context.componentModel]
    );
    const getMetadataSnapshot = React.useCallback(
      () => context.componentModel.metadata,
      [context.componentModel]
    );
    const metadataSnapshot = useSyncExternalStore(subscribeMetadata, getMetadataSnapshot);
    const hasReadMetadata = React.useCallback(() => metadataReadRef.current, []);
    const getMetadata = React.useCallback(() => {
      metadataReadRef.current = true;
      return context.componentModel.metadata;
    }, [context.componentModel]);
    React.useEffect(() => {
      return () => binding.dispose();
    }, [binding]);
    return /* @__PURE__ */ __a2uiCreateElement(
      MemoizedRender,
      {
        props: props || {},
        buildChild,
        context,
        metadataSnapshot,
        hasReadMetadata,
        getMetadata
      }
    );
  };
  const NodeView = ({ node, buildChild }) => {
    const viewState = useNodeView(node, buildChild);
    const refs = hostRefsOf(node);
    return /* @__PURE__ */ __a2uiCreateElement(
      MemoizedRender,
      {
        props: viewState.viewProps,
        buildChild: viewState.viewBuildChild,
        context: viewState.context,
        accessibilityRef: refs.accessibilityRef,
        validationErrorsRef: refs.validationErrorsRef,
        metadataSnapshot: viewState.metadataSnapshot,
        hasReadMetadata: viewState.hasReadMetadata,
        getMetadata: () => viewState.metadata
      }
    );
  };
  NodeView.displayName = `${api.name}.view`;
  return {
    ...componentApiFields(api),
    render: ReactWrapper,
    view: NodeView
  };
}
function createBinderlessComponentImplementation(api, RenderComponent) {
  const NodeView = ({ node, buildChild }) => {
    const viewState = useNodeView(node, buildChild);
    const renderProps = {
      context: viewState.context,
      buildChild: viewState.rawBuildChild,
      accessibilityRef: hostRefsOf(node).accessibilityRef,
      validationErrorsRef: hostRefsOf(node).validationErrorsRef
    };
    Object.defineProperty(renderProps, "metadata", {
      enumerable: true,
      get: () => viewState.metadata
    });
    return RenderComponent(renderProps);
  };
  NodeView.displayName = `${api.name}.view`;
  return {
    ...componentApiFields(api),
    render: RenderComponent,
    view: NodeView
  };
}

exports.A2uiSurface = A2uiSurface;
exports.MarkdownComponentContext = MarkdownComponentContext;
exports.MarkdownContext = MarkdownContext;
exports.createBinderlessComponentImplementation = createBinderlessComponentImplementation;
exports.createComponentImplementation = createComponentImplementation;
exports.useA2uiSurface = useA2uiSurface;
exports.useMarkdownRenderer = useMarkdownRenderer;
exports.useNodeView = useNodeView;
exports.useSignalValue = useSignalValue;
//# sourceMappingURL=chunk-ICDMVR2F.cjs.map
//# sourceMappingURL=chunk-ICDMVR2F.cjs.map